package integration.java8;

import java.util.Locale;

public class JAVA_PORTABILITY_FLAW_LOCALE {
    public void test(String a, Locale locale){
        "a".equals(a.toLowerCase()); //@ JAVA_PORTABILITY_FLAW_LOCALE-j11fl3
        a.toUpperCase().equals("v"); //@ JAVA_PORTABILITY_FLAW_LOCALE-j11fl3
        "a".equals(a.toLowerCase(locale));
        a.toUpperCase(locale).equals("3");
        a.toLowerCase().contains("oracle"); //@ JAVA_PORTABILITY_FLAW_LOCALE-j11fl3
    }
}
