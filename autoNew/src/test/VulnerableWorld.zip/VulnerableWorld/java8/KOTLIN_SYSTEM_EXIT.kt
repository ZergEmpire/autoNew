package integration.java8

class KOTLIN_SYSTEM_EXIT {
    fun test() {
        System.exit(1) //@ KOTLIN_SYSTEM_EXIT-d8ae59
    }

    fun test1() {
        Runtime.getRuntime().exit(1) //@ KOTLIN_SYSTEM_EXIT-d8ae59
    }

    fun test2() {
        val runtime = Runtime.getRuntime()
        val x = 666
        runtime.exit(1) //@ KOTLIN_SYSTEM_EXIT-d8ae59
    }
}