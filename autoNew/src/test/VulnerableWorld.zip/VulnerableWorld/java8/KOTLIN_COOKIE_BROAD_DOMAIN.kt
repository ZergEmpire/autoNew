package integration.java8

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.features.cookies.AcceptAllCookiesStorage
import io.ktor.client.features.cookies.ConstantCookieStorage
import io.ktor.client.features.cookies.HttpCookies
import io.ktor.client.features.cookies.cookies
import io.ktor.http.Cookie
import io.ktor.http.renderSetCookieHeader
import io.ktor.response.ApplicationResponse
import io.ktor.response.ResponseCookies
import io.ktor.sessions.CookieConfiguration

fun cookieBroadDomain(engine: HttpClientEngine, config: HttpClientConfig, response: ApplicationResponse) {

    val cookie = Cookie(name = "name", value = "value", domain = ".example.com", secure = true, httpOnly = true) //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_COOKIE_BROAD_DOMAIN-2ip887

    ResponseCookies(response, true).append(name = "name", value = "value", domain = ".example.com", secure = true, httpOnly = true) //@ KOTLIN_COOKIE_BROAD_DOMAIN-tsewe0

    renderSetCookieHeader(name = "name", value = "value", domain = ".example.com", secure = true, httpOnly = true) //@ KOTLIN_COOKIE_BROAD_DOMAIN-qerwe7
    val cookieConf = CookieConfiguration()

    cookieConf.domain = ".example.com" //@ KOTLIN_COOKIE_BROAD_DOMAIN-23388f
}
