package integration.java8;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;
import org.apache.commons.net.util.Base64;
import org.owasp.encoder.Encoder;

import java.io.FileWriter;
import java.net.PasswordAuthentication;
import java.nio.CharBuffer;
import java.nio.charset.CoderResult;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class JAVA_PASSWORD_CRYPTO {
    private SQLiteDatabase mDB;
    public void saveCredentials(View view) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, ShortBufferException, BadPaddingException, IllegalBlockSizeException {

        KeyAgreement a = null; //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        SecretKey pwd = a.generateSecret("password"); //@ JAVA_NULL_DEREFERENCE-66jnpd
        SecretKey usr = a.generateSecret("password");
        byte[] keyBytes = null;
        byte[] ivBytes = null;
        SecretKeySpec key = new SecretKeySpec(keyBytes, "DES"); //@ JAVA_CRYPTO_BAD_ALGORITHM-261e38
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes); //@ JAVA_CRYPTO_BAD_IV-0bf092
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
        byte[] encrypted= new byte[cipher.getOutputSize(pwd.toString().getBytes().length)];
        int enc_len = cipher.update(pwd.toString().getBytes(), 0, pwd.toString().getBytes().length, encrypted, 0);
        enc_len += cipher.doFinal(encrypted, enc_len); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] t = md.digest(pwd.toString().getBytes());
        md.update(pwd.toString().getBytes());
        byte[] t_ = md.digest();
        try {

            mDB.execSQL("INSERT INTO myuser VALUES ('"+ usr.toString() +"', '"+ pwd.toString() +"');"); //@ JAVA_PASSWORD_CRYPTO-06dsi1

            Base64 c = new Base64();
            Encoder d = null;
            CharBuffer k = null;
            boolean m = false;
            CoderResult l = d.encode((CharBuffer)pwd,k,m); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_NULL_DEREFERENCE-66jnpd
            mDB.execSQL(" " + "INSERT INTO myuser VALUES ('"+ usr.toString() +"', '"+ pwd.toString() +"');"); //@ JAVA_PASSWORD_CRYPTO-06dsi1
            mDB.execSQL(" " + "INSERT INTO myuser VALUES ('"+ c.encode(pwd.toString().getBytes()).toString() +"');");
            mDB.execSQL(" " + "INSERT INTO myuser VALUES ('"+ k.toString() +"');"); //@ JAVA_NULL_DEREFERENCE-66jnpd
            mDB.execSQL(" " + "INSERT INTO myuser VALUES ('"+ encrypted +"');");
            mDB.execSQL(" " + "INSERT INTO myuser VALUES ('"+ t +"');");
            mDB.execSQL(" " + "INSERT INTO myuser VALUES ('"+ t_ +"');");
            FileWriter b = new FileWriter("text.txt"); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

            b.write("sdvefvfpwd" + pwd + "dsvdcedve" + "dfwec"); //@ JAVA_PRIVACY_VIOLATION-143b17,JAVA_PASSWORD_CRYPTO-06dsi2
            mDB.close();

        }
        catch(Exception e) {
            Log.d("Diva", "Error occurred while inserting into database: " + e.getMessage()); //@ JAVA_INFORMATION_LEAK_INTERNAL-3200d6
        }
    }
    public void passwordDecode(PasswordAuthentication passwordAuthentication) throws SQLException {
        DriverManager.getConnection("url", "user", //@ JAVA_PASSWORD_CRYPTO-5ebcce,JAVA_GETCONNECTION-d0810d,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1, JAVA_MISSING_AUTHORIZATION-kts455
                Arrays.toString(Base64.decodeBase64(String.valueOf(passwordAuthentication.getPassword())))); //@ JAVA_PRIVACY_VIOLATION_HEAP-6a4gd5
    }
}
