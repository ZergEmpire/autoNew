package integration.java8

import io.ktor.auth.AuthenticationPipeline
import io.ktor.auth.FormAuthChallenge
import io.ktor.auth.formAuthentication
import io.ktor.client.features.auth.basic.BasicAuth

class KOTLIN_PASSWORD_EMPTY {
    fun foo() {
        AuthenticationPipeline().formAuthentication(
                userParamName = "user",
                passwordParamName = "password",
                challenge = FormAuthChallenge.Unauthorized,
                validate = { null }
        )

        BasicAuth(username = "user", password = "") //@ KOTLIN_PASSWORD_EMPTY-pwdemk
    }
}


