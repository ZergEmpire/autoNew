package integration.java8;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.ecs.ElementContainer;
import org.apache.ecs.html.H1;
import org.apache.ecs.html.HR;
import org.apache.ecs.html.Input;
import org.apache.ecs.html.P;
import org.apache.ecs.html.TD;
import org.apache.ecs.html.TR;
import org.eclipse.jetty.server.NetworkConnector;
import org.eclipse.jetty.server.Server;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.prefs.Preferences;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;


public class JAVA_XSS_REFLECTED {
    public final static String __message =
        "0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 \n" +
        "9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 \n" +
        "1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 \n" +
        "0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 \n" +
        "abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz \n" +
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ \n" +
        "Now is the time for all good men to come to the aid of the party.\n" +
        "How now brown cow.\n" +
        "The quick brown fox jumped over the lazy dog.\n";
    private static Server _server;
    JTextField textOutput = null;
    public static final String KEY_PREVIOUS_SELECTION = "PreviouslySelected";

    public static File fileChooser(String defaultPath)
    {
        Preferences prefs = null;
        System.out.println(defaultPath); //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        String previousPath = prefs.get(KEY_PREVIOUS_SELECTION, defaultPath); //@ JAVA_NULL_DEREFERENCE-66jnpd
        System.out.println(previousPath); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        JFileChooser chooser = new JFileChooser(previousPath);
        System.out.println(chooser); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_INFORMATION_LEAK_INTERNAL-vnrejr
        File selected = null;
        selected = chooser.getSelectedFile();
        System.out.println(selected); //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        return selected;

    }

    public void dsfdf(
        InputStream content,
        ServletOutputStream out) throws Exception
    {
        Socket socket = new Socket("127.0.0.1", ((NetworkConnector) _server.getConnectors()[0]).getLocalPort()); //@ JAVA_J2EE_SOCKETS-34473d,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        byte[] buf = new byte[4096];
        int len = content.read(buf);

        out.write(buf, 0, len); //@ JAVA_XSS_REFLECTED-99c388

        out.write(buf); //@ JAVA_XSS_REFLECTED-99c388
    }

    static public void XSS_REFLECTED(
        HttpServletRequest request,
        ServletResponse resp1,
        HttpServletResponse resp2,
        OutputStream outPut,
        InputStream stream) throws IOException
    {

        String URI = request.getRequestURI();

        String decodedURI = URLDecoder.decode(URI); //@ JAVA_ESAPI_DEPRECATED-d58f85

        resp1.getOutputStream().write(decodedURI.getBytes()); //@ JAVA_XSS_REFLECTED-99c388

        JEditorPane pane = new JEditorPane(decodedURI); //@ JAVA_XSS_REFLECTED-42232f
        Properties properties = FLAG_STREAM.STREAM_PROPERTIES_READER(stream);
        Properties properties1 = FLAG_STREAM.STREAM_PROPERTIES_STREAM();

        pane.setText(properties.toString()); //@ JAVA_XSS_REFLECTED-jxr001,JAVA_INFORMATION_LEAK_EXTERNAL-cd9503

        pane.setText(properties1.toString()); //@ JAVA_XSS_REFLECTED-jxr001,JAVA_INFORMATION_LEAK_EXTERNAL-cd9503

        resp1.getWriter().print("<!--" + request.getQueryString() + "-->"); //@ JAVA_DOS-9a92b8,JAVA_XSS_REFLECTED-5527c6

        PrintWriter writer = resp2.getWriter();

        writer.print("<!--" + request.getQueryString() + "-->"); //@ JAVA_XSS_REFLECTED-5527c6,JAVA_DOS-9a92b8
    }

    public void _jspService(
        final javax.servlet.http.HttpServletRequest request,
        final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException
    {
        javax.servlet.jsp.JspWriter out = null;

        String evilInput = (String) request.getAttribute("input");

        out.print(evilInput); //@ JAVA_NULL_DEREFERENCE-66jnpd,JAVA_XSS_REFLECTED-80b0e0
        final PrintWriter pw = response.getWriter();
        final String indexFile = "string";
        final BufferedReader br = new BufferedReader(new FileReader(indexFile)); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        String line;
        while ((line = br.readLine()) != null) { //@ JAVA_DOS-7adk6b

            pw.println(line); //@ JAVA_XSS_REFLECTED-5527c6
        }

        response.getWriter().write(evilInput); //@ JAVA_XSS_REFLECTED-9b81d9
        TR tr = new TR();

        tr.addElement(new TD(evilInput)); //@ JAVA_XSS_REFLECTED-a00666

        tr.addElement(new TD("password"));

        ElementContainer ec2 = new ElementContainer();
        ec2.addElement(new H1().addElement("Original Website Text1"));
        ec2.addElement(new HR());
        ec2.addElement(new H1().addElement("Defaced Website Text1"));

        ec2.addElement(new P().addElement(evilInput)); //@ JAVA_XSS_REFLECTED-b00666
        ec2.addElement(new HR());

    }

    public void service(
        ServletRequest pServletRequest,
        ServletResponse pServletResponse) throws IOException, ServletException
    {
        Object orderParam = pServletRequest.getParameter("order_id");

        pServletResponse.getWriter().write(String.format("%s%s", "Credit order status was updated. Order ID - ", orderParam)); //@ JAVA_XSS_REFLECTED-9b81d9
    }

    public @ResponseBody
    String completed(@RequestHeader String URI)
    {

        return URI; //@ JAVA_XSS_REFLECTED-j11xs1
    }


    private static final JTextComponent textField = new JTextArea(10, 10);

    public static void setText(String text)
    {
        String origText = textField.getText();
        if (origText.equals(text)) {
            return;
        }

        textField.setText(text); //@ JAVA_XSS_REFLECTED-jxr001
    }

    public static void echo(char chr)
    {
        setText(textField.getText() + chr);
    }

    public static void main(String[] args) throws IOException
    {
        InetAddress host = null; //@ JAVA_J2EE_DEBUG_CODE-514398
        int port = 1;
        Socket socket = new Socket(host, port); //@ JAVA_J2EE_SOCKETS-34473d
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        StringBuilder stringBuilder = new StringBuilder();
        for (String arg : args) {
            stringBuilder.append(arg).append(" ");
        }
        out.println(stringBuilder.toString()); //@ JAVA_XSS_REFLECTED-5527c6
        JAVA_XSS_REFLECTED a = new JAVA_XSS_REFLECTED();
        echo('a');
        JTextField textOutput = new JTextField();
        a = new JAVA_XSS_REFLECTED();
        System.out.println(a.textOutput.getText()); //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_NULL_DEREFERENCE-j11nd8

        File f = a.fileChooser(a.textOutput.getText());

        textOutput.setText(f.getAbsolutePath()); //@ JAVA_INFORMATION_LEAK_EXTERNAL-cd9503,JAVA_XSS_REFLECTED-jxr001
    }

    private static final long serialVersionUID = 1L;

    public void doGet(
        HttpServletRequest request,
        HttpServletResponse response) throws ServletException, IOException
    {
        doPost(request, response);
    }

    public void doPost(
        HttpServletRequest request,
        HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");

        String param = request.getParameter("BenchmarkTest00375");
        if (param == null) {
            param = "";
        }

        FileInputStream a = new FileInputStream("~/Documents/"); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

        Properties b = new Properties();

        b.load(a);
        Object[] obj_ = {b};

        String bar = "";

        if (param != null) {
            bar = param.split(" ")[0];
        }
        response.setHeader("X-XSS-Protection", "0");
        Object[] obj = {"a", "b"};

        response.getWriter().format(java.util.Locale.US, bar, obj); //@ JAVA_XSS_REFLECTED-99c3d2

        response.getWriter().format(java.util.Locale.US, response.encodeRedirectURL(bar), obj_); //@ JAVA_XSS_REFLECTED-99c3d2,JAVA_INFORMATION_LEAK_EXTERNAL-f9ba68,JAVA_XSS_PERSISTENT-99c3d5,JAVA_ESAPI_DEPRECATED-94fc09

        response.getWriter().printf(java.util.Locale.US, bar, obj); //@ JAVA_XSS_REFLECTED-99c3d2


        bar = "alsosafe";
        String bar_ = "alsosafe";

        if (param != null) {
            java.util.List<String> valuesList = new java.util.ArrayList<String>();
            valuesList.add("safe");
            valuesList.add(param);
            valuesList.add("moresafe");

            valuesList.remove(0);

            bar = valuesList.get(0);
            bar_ = valuesList.get(1);
        }


        response.setHeader("X-XSS-Protection", "0");
        Object[] obj00 = {"a", bar};
        Object[] obj01 = {"a", bar_};

        response.getWriter().format("Formatted like: %1$s and %2$s.", obj00); //@ JAVA_XSS_REFLECTED-99c3d3

        response.getWriter().format("Formatted like: %1$s and %2$s.", obj01); //@ JAVA_XSS_REFLECTED-99c3d3

        int num = 106;
        bar = (7 * 42) - num > 200 ? "This should never happen" : param;
        response.setHeader("X-XSS-Protection", "0");
        Object[] obj__ = {"a", bar};

        response.getWriter().format("Formatted like: %1$s and %2$s.", obj__); //@ JAVA_XSS_REFLECTED-99c3d3

        String a2196 = param;
        StringBuilder b2196 = new StringBuilder(a2196);
        b2196.append(" SafeStuff");
        b2196.replace(b2196.length() - "Chars".length(), b2196.length(), "Chars");
        java.util.HashMap<String, Object> map2196 = new java.util.HashMap<String, Object>();
        String a_ = "key2196";
        String b_ = "key124154";
        map2196.put(a_, b2196.toString());
        java.util.HashMap<String, Object> map2197 = new java.util.HashMap<String, Object>();
        map2197.put(b_, b_);
        String c2196 = (String) map2196.get(a_);
        Object[] obj000 = {"a", "b"};
        Object[] obj001 = {map2196.get(a_)};

        response.getWriter().printf(java.util.Locale.US, a_, map2196.get(a_)); //@ JAVA_XSS_REFLECTED-99c3d2

        response.getWriter().printf(java.util.Locale.US, a_, obj001); //@ JAVA_XSS_REFLECTED-99c3d2

        response.getWriter().printf(java.util.Locale.US, c2196, obj000); //@ JAVA_XSS_REFLECTED-99c3d2

        String c2197 = (String) map2197.get(b_);

        response.getWriter().printf(java.util.Locale.US, c2197, obj000);

        StringBuilder sbxyz30382 = new StringBuilder(param);
        bar = sbxyz30382.append("_SafeStuff").toString();
        response.setHeader("X-XSS-Protection", "0");

        response.getWriter().println(bar.toCharArray()); //@ JAVA_XSS_REFLECTED-5527c6
        String bar0 = org.owasp.esapi.ESAPI.encoder().encodeForHTML(param);
        response.setHeader("X-XSS-Protection", "0");
        response.getWriter().write(bar0); //@ JAVA_XSS_VALIDATION-4e647a

        response.getWriter().println(bar0); //@ JAVA_XSS_VALIDATION-4e647a

        bar = StringEscapeUtils.escapeHtml(param);
        response.setHeader("X-XSS-Protection", "0");

        response.getWriter().println(bar); //@ JAVA_XSS_VALIDATION-4e647a

        response.sendError(404, param); //@ JAVA_XSS_REFLECTED-jkwlq1

    }

    @RequestMapping(method = RequestMethod.GET)
    public @ResponseBody
    String completed(
        @RequestParam Integer arg1,
        @RequestParam Integer arg2,
        @RequestParam Integer arg3,
        @RequestParam Integer arg4,
        @RequestParam String arg5,
        @RequestParam String arg6)
        throws IOException
    {


        textField.setText(arg5); //@ JAVA_XSS_REFLECTED-jxr001
        return arg6; //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @PostMapping
    public @ResponseBody
    String checkout(@RequestHeader("Authorization") String token)
    {


        textField.setText(token); //@ JAVA_XSS_REFLECTED-jxr001

        return token; //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @PostMapping(consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public String passwordReset(@RequestParam Map<String, Object> json)
    {
        textField.setText(json.toString()); //@ JAVA_XSS_REFLECTED-jxr001

        return json.toString(); //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @PostMapping("newToken")
    public @ResponseBody
    String newToken(
        @RequestHeader("Authorization") String token,
        @RequestBody Map<String, Object> json)
    {

        textField.setText(token); //@ JAVA_XSS_REFLECTED-jxr001

        return token; //@ JAVA_XSS_REFLECTED-j11xs1
    }

    public void test(ServletRequest request)
    {
        String param = request.getParameter("1");
        Input input = new Input(Input.TEXT, "SQL", param); //@ JAVA_XSS_REFLECTED-b00667
    }

    @GetMapping("/xss")
    @ResponseBody
    public String test2(@RequestParam final int num) throws IOException
    {

        return FLAG_WEB_HEADERS.getWebFromHeaderInt(num, "https://www.danger.com"); //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @GetMapping("/xsss")
    @ResponseBody
    public String test3(@RequestParam final String header) throws IOException
    {

        return FLAG_WEB_HEADERS.getWebFromHeaderString(header, "https://www.danger.com"); //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @GetMapping("/xssss")
    @ResponseBody
    public String test3(@RequestParam final int num) throws IOException
    {

        return FLAG_WEB_HEADERS.getWebFromHeaderKey(num, "https://www.danger.com"); //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @GetMapping("/xsssss")
    @ResponseBody
    public String test4(@RequestParam final String header) throws IOException
    {

        return FLAG_WEB_HEADERS.getWebFromHeaders("https://www.danger.com").get(header).get(0); //@ JAVA_XSS_REFLECTED-j11xs1
    }

    @RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseEntity<Map<String, Object>> noReport(@RequestParam("enabled") Boolean enabled)
    {
        Map<String, Object> result = new HashMap<>();
        result.put("key", enabled);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public @ResponseBody
    String completed(
        @RequestParam Integer QTY1,
        @RequestParam Integer QTY2,
        @RequestParam Integer QTY3,
        @RequestParam Integer QTY4,
        @RequestParam String field1,
        @RequestParam Integer field2,
        HttpServletRequest request) throws IOException
    {
        double totalSale = QTY1.intValue() * 69.99 + QTY2.intValue() * 27.99 + QTY3.intValue() * 1599.99 + QTY4.intValue() * 299.99;

        StringBuffer cart = new StringBuffer();
        cart.append("Thank you for shopping at WebGoat. <br />You're support is appreciated<hr />");
        cart.append("<p>We have charged credit card:" + field1 + "<br />");
        cart.append("                             ------------------- <br />");
        cart.append("                               $" + totalSale);

        if (field1.toLowerCase().contains("<script>alert('my javascript here')</script>")) { //@ JAVA_PORTABILITY_FLAW_LOCALE-j11fl3
            return cart.toString(); //@ JAVA_XSS_REFLECTED-j11xs1
        } else {
            return cart.toString(); //@ JAVA_XSS_REFLECTED-j11xs1
        }
    }

    public void bad(
        HttpServletRequest request,
        HttpServletResponse response) throws Throwable
    {
        String data;
        data = ""; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        URL url = new URL("http://www.example.org/"); //@ JAVA_HTTP_USAGE-fa824a, JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e
        URLConnection urlConnection = url.openConnection(); //@ JAVA_HTTP_USAGE-fa824b
        BufferedReader readerBuffered = null;
        InputStreamReader readerInputStream = null;
        readerInputStream = new InputStreamReader(urlConnection.getInputStream(), "UTF-8");
        readerBuffered = new BufferedReader(readerInputStream); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        data = readerBuffered.readLine(); //@ JAVA_DOS-9ad0eb
        if (data != null) {
            response.getWriter().println("<br>bad(): data = " + data.replaceAll("(<script>)", "")); //@ JAVA_XSS_REFLECTED-5527c6
            response.sendError(404,  "<br>bad() - Parameter name has value " + data); //@ JAVA_XSS_REFLECTED-jkwlq1
        }
    }
}
