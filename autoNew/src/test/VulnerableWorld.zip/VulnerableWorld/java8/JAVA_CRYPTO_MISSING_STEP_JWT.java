package integration.java8;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.io.UnsupportedEncodingException;

public class JAVA_CRYPTO_MISSING_STEP_JWT {

    public void verificationAuth0(final String token) throws UnsupportedEncodingException
    {
        final Algorithm algorithm = Algorithm.HMAC256("secret"); //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwtalg
        final JWTVerifier verifier = JWT.require(algorithm)
            .withIssuer("auth0")
            .build();
        final DecodedJWT jwt = verifier.verify(token);
        jwt.getClaims();
        jwt.getClaim("claim");
    }

    public void verificationWithAlgorithmAuth0(final String token) throws UnsupportedEncodingException
    {
        final Algorithm algorithm = Algorithm.HMAC256("secret"); //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwtalg
        final DecodedJWT jwt = JWT.decode(token);
        algorithm.verify(jwt);
        jwt.getClaims();
        jwt.getClaim("claim");
    }

    public void noVerificationAuth0(final String token)
    {
        final DecodedJWT jwt = JWT.decode(token);
        jwt.getClaims(); //@ JAVA_CRYPTO_MISSING_STEP_JWT-jwmsfn
        jwt.getClaim("claim"); //@ JAVA_CRYPTO_MISSING_STEP_JWT-jwmsfn
    }
}
