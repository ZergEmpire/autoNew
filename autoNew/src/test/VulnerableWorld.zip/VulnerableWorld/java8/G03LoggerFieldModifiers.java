package integration.java8;

import java.util.logging.Logger;

class G03LoggerFieldModifiers { //@ JAVA_LOGGING_LOGGER_NOT_STATIC_FINAL-6938a1

    static Logger loggerNotFinal = Logger.getLogger(G03LoggerFieldModifiers.class.getName());

    static final Logger logger = Logger.getLogger(G03LoggerFieldModifiers.class.getName()); //@ JAVA_LOGGING_MANY_LOGGERS-9f528e
}

class G03LoggerFieldModifiersNotStatic { //@ JAVA_LOGGING_LOGGER_NOT_STATIC_FINAL-6938a1

    final Logger loggerNotStatic = Logger.getLogger(G03LoggerFieldModifiers.class.getName());

    static final Logger logger = Logger.getLogger(G03LoggerFieldModifiers.class.getName()); //@ JAVA_LOGGING_MANY_LOGGERS-9f528e
}

class G03LoggerFieldModifiersStaticFinal {

    static final Logger logger = Logger.getLogger(G03LoggerFieldModifiers.class.getName());
}
