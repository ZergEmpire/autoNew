package integration.java8;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Base64;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

public class JAVA_SSRF {
    public static void JAVA_SSRF_ggha70(HttpServletRequest request) throws IOException
    {

        String url = request.getParameter("url");

        URL taintUrl = new URL(url); //@ JAVA_INJECTION_RESOURCE-08999d

        taintUrl.openConnection(); //@ JAVA_SSRF-ggha70
    }

    public void testInvocation(ServletRequest request) throws IOException
    {
        String mUrl = new String(Base64.getDecoder().decode(request.getParameter("p").trim())); //@ JAVA_OBSOLETE-bts001
        test(mUrl, "floder", "filename");
    }

    public void test(
        String mUrl,
        String folder,
        String filename) throws IOException
    {
        InputStream in = null;
        FileOutputStream out = null;
        URL url = new URL(mUrl); //@ JAVA_INJECTION_RESOURCE-08999d
        URLConnection urlConnection = url.openConnection(); //@ JAVA_SSRF-ggha70
        in = urlConnection.getInputStream();
        File dir = new File(folder);
        if (!dir.exists()) {
            dir.mkdir(); //@ JAVA_UNCHECKED_RETURN_VALUE-j11rv1
        }
        out = new FileOutputStream(folder + File.separator + filename); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        int c;
        byte[] b = new byte[1024];
        while ((c = in.read(b)) != -1) {
            out.write(b, 0, c);
        }
    }
}
