package integration.java8;

import java.io.IOException;
import org.apache.struts.action.ActionForward;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

public class JAVA_FILE_DISCLOSURE extends HttpServlet{

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
        try{
            String returnURL = request.getParameter("returnURL"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2

            /******Struts ActionForward vulnerable code tests******/
            ActionForward forward = new ActionForward(returnURL); //@ JAVA_FILE_DISCLOSURE-3e2b83,JAVA_BACKDOOR_DEAD_CODE-d27d09

            ActionForward forward2 = new ActionForward(returnURL, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_FILE_DISCLOSURE-3e2b83

            ActionForward forward3 = new ActionForward("name", returnURL, true); //@ JAVA_FILE_DISCLOSURE-gtekss,JAVA_BACKDOOR_DEAD_CODE-d27d09

            ActionForward forward4 = new ActionForward("name", returnURL, true, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_FILE_DISCLOSURE-gtekss

            ActionForward forward5 = new ActionForward();
            forward5.setPath(returnURL); //@ JAVA_FILE_DISCLOSURE-a00009


            ActionForward forward6 = new ActionForward(returnURL,"path",true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            /******Spring ModelAndView vulnerable code tests******/
            ModelAndView mv = new ModelAndView(returnURL); //@ JAVA_FILE_DISCLOSURE-7e8e75,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_TRUST_BOUNDARY_VIOLATION-ecab97

            ModelAndView mv2 = new ModelAndView(returnURL, new HashMap()); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_FILE_DISCLOSURE-7e8e75,JAVA_TRUST_BOUNDARY_VIOLATION-ecab97

            ModelAndView mv3 = new ModelAndView(returnURL, "modelName", new Object()); //@ JAVA_FILE_DISCLOSURE-7e8e75,JAVA_TRUST_BOUNDARY_VIOLATION-ecab97,JAVA_BACKDOOR_DEAD_CODE-d27d09

            ModelAndView mv4 = new ModelAndView();
            mv4.setViewName(returnURL); //@ JAVA_FILE_DISCLOSURE-a00010


            ModelAndView mv5 = new ModelAndView("viewName", returnURL, new Object()); //@ JAVA_TRUST_BOUNDARY_VIOLATION-ecab97,JAVA_BACKDOOR_DEAD_CODE-d27d09

        }catch(Exception e){
            System.out.println(e); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }
    }

    public void doGet2(HttpServletRequest request, HttpServletResponse response) throws IOException{
        try{
            String jspFile = request.getParameter("jspFile"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2

            RequestDispatcher requestDispatcher = request.getRequestDispatcher(jspFile);

            requestDispatcher.include(request, response);

            requestDispatcher = request.getServletContext().getRequestDispatcher(jspFile); //@ JAVA_FILE_DISCLOSURE-662967

            requestDispatcher.forward(request, response); //@ JAVA_ESAPI_DEPRECATED-52048c

        }catch(Exception e){
            System.out.println(e); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }
    }
}
