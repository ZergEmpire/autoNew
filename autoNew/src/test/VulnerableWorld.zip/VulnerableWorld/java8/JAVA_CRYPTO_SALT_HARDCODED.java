package integration.java8;

import org.owasp.esapi.Encryptor;
import org.owasp.esapi.errors.EncryptionException;

public class JAVA_CRYPTO_SALT_HARDCODED {

    public void test(Encryptor encryptor) throws EncryptionException
    {
        encryptor.hash("consant1", "constant2"); //@ JAVA_CRYPTO_SALT_HARDCODED-55c7f0
        encryptor.hash("consant1", "constant2", 3); //@ JAVA_CRYPTO_SALT_HARDCODED-55c7f0
    }

}
