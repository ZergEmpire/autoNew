package integration.java8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;

public class JAVA_XSS_REFLECTED_CGI {

    public static void main(String[] args) throws IOException {
        final ServerSocket serverSocket = new ServerSocket(); //@ JAVA_J2EE_DEBUG_CODE-514398,JAVA_J2EE_SOCKETS-34473d
        final InputStream stream = FLAG_WEB.WEB_chp0rr(serverSocket);
        final BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        final String taintedWeb = limitedTimeRead(reader);

        System.out.println("dasdas"); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        System.out.println(taintedWeb); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_XSS_REFLECTED_CGI-rnr007

        System.out.print(taintedWeb); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_XSS_REFLECTED_CGI-rnr007
    }

    public static String limitedTimeRead(BufferedReader in) throws IOException {
        final StringBuilder stringBuilder = new StringBuilder();
        String line = null;
        long t= System.currentTimeMillis();
        long end = t+5000;
        while ((line = in.readLine()) != null) { //@ JAVA_DOS-7adk6b,JAVA_DOS-9ad0eb
            if (System.currentTimeMillis() > end) {
                return "Timeout";
            }
            stringBuilder.append(line);
        }
        return stringBuilder.toString();
    }

}

class Hello {
    private static void doSmth() throws IOException {
        final ServerSocket serverSocket = new ServerSocket(); //@ JAVA_J2EE_SOCKETS-34473d
        final InputStream stream = FLAG_WEB.WEB_chp0rr(serverSocket);
        final BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        final String taintedWeb = JAVA_XSS_REFLECTED_CGI.limitedTimeRead(reader);

        System.out.println("dasdas"); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        System.out.println(taintedWeb); //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        System.out.print(taintedWeb); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_XSS_REFLECTED_CGI-rnr008
    }
}
