package integration.java8;

import com.thoughtworks.xstream.security.NoTypePermission;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.*;
import java.rmi.server.RemoteCall;
import java.util.Base64;
import javax.servlet.ServletRequest;

public class JAVA_UNTRUSTED_DATA_DESERIALIZATION {
    private RemoteCall request;
    InputStream is = (InputStream) request.getInputStream(); //@ JAVA_NULL_DEREFERENCE-j11nd8
    ObjectInputStream ois = new ObjectInputStream(is);
    MyObject obj = (MyObject) ois.readObject(); //@ JAVA_UNTRUSTED_DATA_DESERIALIZATION-j21ud1
    public JAVA_UNTRUSTED_DATA_DESERIALIZATION() throws IOException, ClassNotFoundException
    { }

    @RequestMapping(method = RequestMethod.POST)
    public
    @ResponseBody
    String completed(@RequestParam String taintString) throws IOException {
        XStream xstream = new XStream(new DomDriver()); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        String constantString;
        byte data[];
        Object o;
        Object taint_object;

        constantString = taintString.replace('-' , '+');
        try {
            data = Base64.getDecoder().decode(constantString);
            ois = new ObjectInputStream(new ByteArrayInputStream(data));
        } catch (Exception e) {
            return taintString; //@ JAVA_XSS_REFLECTED-j11xs1
        }
        try {
            o = ois.readObject(); //@ JAVA_UNTRUSTED_DATA_DESERIALIZATION-j21ud1,JAVA_UNTRUSTED_DATA_DESERIALIZATION-j21ud1,JAVA_BACKDOOR_DEAD_CODE-d27d09
        } catch (Exception e) {
            return taintString; //@ JAVA_XSS_REFLECTED-j11xs1
        }
        try {
            taint_object = xstream.fromXML(taintString); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_UNTRUSTED_DATA_DESERIALIZATION-j11ud2
        } catch (Exception e) {
            return taintString; //@ JAVA_XSS_REFLECTED-j11xs1
        }

        return taintString; //@ JAVA_XSS_REFLECTED-j11xs1
    }

    private void test(String filename) throws IOException, ClassNotFoundException {
        new ObjectInputStream(new FileInputStream("filename.txt")).readObject(); //@ JAVA_UNTRUSTED_DATA_DESERIALIZATION-j21ud1,JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
    }

    private void xstreamSafe(@RequestParam String taintString) {
        XStream xstream = new XStream();
        xstream.addPermission(NoTypePermission.NONE);
        xstream.addPermission(NullPermission.NULL);
        xstream.addPermission(PrimitiveTypePermission.PRIMITIVES);
        xstream.allowTypes(new Class<?>[] { MyObject.class });
        xstream.fromXML(taintString);
    }

    private void xstreamUnsafe(@RequestParam String taintString) {
        XStream xstream = new XStream();
        xstream.fromXML(taintString); //@ JAVA_UNTRUSTED_DATA_DESERIALIZATION-j11ud2
    }

    private class MyObject{
    }

    public void test1(ServletRequest request) throws IOException, ClassNotFoundException
    {
        String data = request.getParameter("csrf_token");
        byte[] dataBytes = Base64.getDecoder().decode(data);
        final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(dataBytes);
        final ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
        objectInputStream.readObject(); //@ JAVA_UNTRUSTED_DATA_DESERIALIZATION-j21ud1
    }

}


