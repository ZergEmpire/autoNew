package integration.java8;

import java.io.ObjectStreamField;
import java.io.Serializable;
import java.util.List;

class G01SerialPersistentFields implements Serializable { //@ JAVA_CORRECTNESS_SERIALPERSISTENT_MODIFIER-aab745
    List next;

    public static final ObjectStreamField[] serialPersistentFields = {new ObjectStreamField("next", List.class)};
}

class G01SerialPersistentFieldsPrivate implements Serializable {
    List next;

    private static final ObjectStreamField[] serialPersistentFields = {new ObjectStreamField("next", List.class)};
}

class G01SerialPersistentFieldsNotFinal implements Serializable { //@ JAVA_CORRECTNESS_SERIALPERSISTENT_MODIFIER-aab745
    List next;

    private static ObjectStreamField[] serialPersistentFields = {new ObjectStreamField("next", List.class)};
}

class G01SerialPersistentFieldsNotStatic implements Serializable { //@ JAVA_CORRECTNESS_SERIALPERSISTENT_MODIFIER-aab745
    List next;

    private final ObjectStreamField[] serialPersistentFields = {new ObjectStreamField("next", List.class)};
}
