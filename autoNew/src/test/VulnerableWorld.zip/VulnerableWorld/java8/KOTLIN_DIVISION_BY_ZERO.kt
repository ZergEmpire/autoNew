package integration.java8

fun KOTLIN_DIVISION_BY_ZERO(): Int {
    val a = 5;
    return a / 0; //@ KOTLIN_DIVISION_BY_ZERO-jdbzd
}
