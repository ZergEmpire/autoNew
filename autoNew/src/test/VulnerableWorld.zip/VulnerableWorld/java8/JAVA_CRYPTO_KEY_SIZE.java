package integration.java8;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javacard.security.KeyBuilder;
import javacard.security.RSAPrivateKey;
import org.owasp.esapi.crypto.CipherSpec;
import org.owasp.esapi.crypto.CryptoHelper;
import org.owasp.esapi.errors.EncryptionException;

import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.RSAKeyGenParameterSpec;


public class JAVA_CRYPTO_KEY_SIZE {

    private RSAPrivateKey dhPriv_1;
    private RSAPrivateKey dhPriv_2;
    private RSAPrivateKey dhPriv_3;

    byte[] ivBytes = null;

    private static byte[] CHECK_x11yz2(byte[] raw,byte[] clear) throws Exception {
        SecretKeySpec skeySpec=new SecretKeySpec(raw,"AES"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        Cipher cipher=Cipher.getInstance("AES"); //@ JAVA_CRYPTO_ALGORITHM_BAD_MODE-2ascty
        cipher.init(Cipher.ENCRYPT_MODE,skeySpec);
        byte[] encrypted=cipher.doFinal(clear);
        return encrypted;
    }

    public void CHECK_x11yz3() {

        dhPriv_1 = (RSAPrivateKey) KeyBuilder.buildKey(KeyBuilder.TYPE_RSA_PRIVATE, KeyBuilder.LENGTH_RSA_2048, false);

        dhPriv_2 = (RSAPrivateKey) KeyBuilder.buildKey(KeyBuilder.TYPE_RSA_CRT_PRIVATE, KeyBuilder.LENGTH_RSA_512, false); //@ JAVA_CRYPTO_KEY_SIZE-x11yz3

        dhPriv_3 = (RSAPrivateKey) KeyBuilder.buildKey(KeyBuilder.TYPE_DSA_PRIVATE, KeyBuilder.LENGTH_DSA_1024, false);

    }

    public void CHECK_x11yz4(){


        CipherSpec cipherSpec_1 = new CipherSpec("RSA", 1024); //@ JAVA_CRYPTO_KEY_SIZE-x11yz4,JAVA_BACKDOOR_DEAD_CODE-d27d09

        CipherSpec cipherSpec_2 = new CipherSpec("RSA", 2048); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        CipherSpec cipherSpec_3 = new CipherSpec("AES", 64); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_SIZE-x12yz4

        CipherSpec cipherSpec_4 = new CipherSpec("AES", 128); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

    }

    public void CHECK_x11yz5() throws EncryptionException {

        SecretKey key_1;
        SecretKey key_2;
        SecretKey key_3;
        SecretKey key_4;


        key_1 = CryptoHelper.generateSecretKey("RSA", 1024); //@ JAVA_CRYPTO_KEY_SIZE-x11yz5,JAVA_BACKDOOR_DEAD_CODE-d27d09

        key_2 = CryptoHelper.generateSecretKey("RSA", 2048); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        key_3 = CryptoHelper.generateSecretKey("AES", 64); //@ JAVA_CRYPTO_KEY_SIZE-x12yz5,JAVA_BACKDOOR_DEAD_CODE-d27d09

        key_4 = CryptoHelper.generateSecretKey("AES", 128); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void CHECK_x11yz6(){


        RSAKeyGenParameterSpec spec_1 = new RSAKeyGenParameterSpec(1024, RSAKeyGenParameterSpec.F4); //@ JAVA_CRYPTO_KEY_SIZE-x11yz6,JAVA_BACKDOOR_DEAD_CODE-d27d09

        RSAKeyGenParameterSpec spec_2 = new RSAKeyGenParameterSpec(2048, RSAKeyGenParameterSpec.F4); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public SecretKey weakKeySize() throws NoSuchAlgorithmException {
        KeyGenerator keyGen = KeyGenerator.getInstance("BLOWFISH");

        keyGen.init(96, new SecureRandom()); //@ JAVA_CRYPTO_KEY_SIZE-5bf094

        SecretKey key = keyGen.generateKey();
        return key;
    }

    public SecretKey okKeySize() throws NoSuchAlgorithmException {
        KeyGenerator keyGen = KeyGenerator.getInstance("BLOWFISH");

        keyGen.init(128);

        SecretKey key = keyGen.generateKey();
        return key;
    }

    public void notKeySize() throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(1024); //@ JAVA_CRYPTO_KEY_SIZE-b723d2
    }

    public void goodKeySize() throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
    }

}
