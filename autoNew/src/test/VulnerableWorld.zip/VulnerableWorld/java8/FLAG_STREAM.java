package integration.java8;

import java.io.*;
import java.nio.channels.ReadableByteChannel;
import java.util.Properties;
import java.util.Scanner;
import javax.script.Compilable;
import javax.script.ScriptEngine;
import javax.script.ScriptException;

class FLAG_STREAM {

    public static Scanner STREAM_bder8e (ReadableByteChannel channel) {

        Scanner scanner = new Scanner(channel);
        return scanner;
    }

    public static Properties STREAM_PROPERTIES_STREAM () throws IOException {
        Properties properties = new Properties();

        properties.load(new StringBufferInputStream("string")); //@ JAVA_OBSOLETE-ceb761
        return properties;
    }

    public static Properties STREAM_PROPERTIES_READER (InputStream stream) throws IOException {
        Properties properties = new Properties();

        properties.load(new InputStreamReader(stream));
        return properties;
    }
}
