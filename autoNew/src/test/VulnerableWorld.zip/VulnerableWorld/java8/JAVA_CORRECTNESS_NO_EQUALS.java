package integration.java8;

import java.lang.System;

public class JAVA_CORRECTNESS_NO_EQUALS {
    private int gid;

    public int getGid() {
        return gid;
    }

    public void setGid(int newGid) {
        gid = newGid;
    }

    public boolean compareGroups(JAVA_CORRECTNESS_NO_EQUALS group1, JAVA_CORRECTNESS_NO_EQUALS group2) {

        return group1.equals(group2); //@ JAVA_CORRECTNESS_NO_EQUALS-aafc76
    }

    public void ifCompareGroups(JAVA_CORRECTNESS_NO_EQUALS group1, JAVA_CORRECTNESS_NO_EQUALS group2) {

        if (!group1.equals(group2)) { //@ JAVA_CORRECTNESS_NO_EQUALS-aafc76
            System.out.println("error"); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }
    }
    public boolean equalsOrNot(Object obj){

        if (obj.getClass().equals(JAVA_CORRECTNESS_NO_EQUALS.class)) {
            JAVA_CORRECTNESS_NO_EQUALS n = (JAVA_CORRECTNESS_NO_EQUALS) obj;
            if (n.getGid()!=this.getGid()){
                return false;
            }
            return true;
        }
        return false;
    }
}
