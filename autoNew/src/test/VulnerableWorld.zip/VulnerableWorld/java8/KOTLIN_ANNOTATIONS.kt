package integration.java8

@Suppress("KDocMissingDocumentation")
enum class HashAlgorithm(val code: Byte, val openSSLName: String, val macName: String) {
    NONE(0, "", ""),
    MD5(1, "MD5", "HmacMD5"),
    SHA1(2, "SHA-1", "HmacSHA1"),
    SHA224(3, "SHA-224", "HmacSHA224"),
    SHA256(4, "SHA-256", "HmacSHA256"),
    SHA384(5, "SHA-384", "HmacSHA384"),
    SHA512(6, "SHA-512", "HmacSHA512"),

    INTRINSIC(8, "INTRINSIC", "Intrinsic");

    companion object {
        /**
         * Find hash algorithm instance by it's numeric [code]
         * @throws TLSExtension if no hash algorithm found by code
         */
        fun byCode(code: Byte): HashAlgorithm = values().find { it.code == code }
                ?: throw Exception("Unknown hash algorithm: $code")
    }
}

/**
 * Signature algorithms
 * @property code numeric algorithm codes
 */
@Suppress("KDocMissingDocumentation")
enum class SignatureAlgorithm(val code: Byte) {
    ANON(0),
    RSA(1),
    DSA(2),
    ECDSA(3),

    ED25519(7),
    ED448(8);


    companion object {
        /**
         * Find signature algorithm instance by it's numeric [code]
         * @throws TLSExtension if no hash algorithm found by code
         */
        fun byCode(code: Byte): SignatureAlgorithm? = values().find { it.code == code }
    }
}

