package integration.java8;

import android.webkit.WebSettings;

public class ANDROID_SETJAVASCRIPTENABLED {
    public void enableJSTrue(WebSettings settings) {

        settings.setJavaScriptEnabled(true); //@ ANDROID_SETJAVASCRIPTENABLED_TRUE-1f9237
    }

    public void enableJSUndef(WebSettings settings, Boolean a) {

        settings.setJavaScriptEnabled(a); //@ ANDROID_SETJAVASCRIPTENABLED_UNDEF-5bfe1e
    }
}
