package integration.java8

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import java.io.UnsupportedEncodingException

class KOTLIN_CRYPTO_MISSING_STEP_JWT {
    @Throws(UnsupportedEncodingException::class)
    fun verificationAuth0(token: String?) {
        val algorithm = Algorithm.HMAC256("secret") //@ KOTLIN_CRYPTO_KEY_HARDCODED_JWT-jwtalg
        val verifier = JWT.require(algorithm)
                .withIssuer("auth0")
                .build()
        val jwt = verifier.verify(token)
        jwt.claims
        jwt.getClaim("claim")
    }

    @Throws(UnsupportedEncodingException::class)
    fun verificationWithAlgorithmAuth0(token: String?) {
        val algorithm = Algorithm.HMAC256("secret") //@ KOTLIN_CRYPTO_KEY_HARDCODED_JWT-jwtalg
        val jwt = JWT.decode(token)
        algorithm.verify(jwt)
        jwt.claims
        jwt.getClaim("claim")
    }

    fun noVerificationAuth0(token: String?) {
        val jwt = JWT.decode(token)
        jwt.claims //@ KOTLIN_CRYPTO_MISSING_STEP_JWT-jwmsfn
        jwt.getClaim("claim") //@ KOTLIN_CRYPTO_MISSING_STEP_JWT-jwmsfn
    }
}