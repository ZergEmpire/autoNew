package integration.java8

import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.features.CallLogging
import io.ktor.features.DefaultHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.response.header
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.server.testing.handleRequest
import io.ktor.server.testing.withTestApplication
import org.junit.Test
import kotlin.test.assertEquals

fun Application.main_cors() {
    var pwd: String? //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            call.response.header("Access-Control-Allow-Origin", "*")
        }
    }
}
@Test
fun testSomePostThing() = withTestApplication(Application::main) {
    with(handleRequest(HttpMethod.Post, "/api/v2/processing") {

        addHeader("Access-Control-Allow-Origin", "*")
        body = "param1=cool7&param2=awesome4"
    }) {
        assertEquals(HttpStatusCode.OK, response.status())
    }
}
