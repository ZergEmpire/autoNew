package integration.java8;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class F04FlagsFor {
    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:MKYONG";
    private static final String DB_USER = "user";
    private static final String DB_PASSWORD = "password"; //@ JAVA_PASSWORD_HARDCODED-twgk4w

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PreparedStatement preparedStatement = null;
        Connection dbConnection = null;
        try {

            String username = request.getParameter("username");

            String password = request.getParameter("password"); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin

            String key = request.getParameter("key");

            if (username != null && password != null) {
                request.login(username, password); //@ JAVA_SESSION_FIXATION-rnrd00
            }
            String selectSQL = "SELECT USER_ID, USERNAME FROM DBUSER WHERE USER_ID = ? and PASSWORD = ?";

            dbConnection = getDBConnection();
            preparedStatement = dbConnection.prepareStatement(selectSQL); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1

            int intKey = Integer.parseInt(key);

            preparedStatement.setInt(1, intKey); //@ JAVA_ACCESS_CONTROL_DATABASE-566938
            preparedStatement.setString(2, password);


            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {

                String userid = rs.getString("USER_ID");
                username = rs.getString("USERNAME");

                System.out.println("userid : " + userid); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
                System.out.println("username : " + username); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

            }

        } catch (SQLException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        } catch (ServletException e) {
            e.printStackTrace();
        }
    }
    private static Connection getDBConnection() {

            Connection dbConnection = null;

            try {

                Class.forName(DB_DRIVER);

            } catch (ClassNotFoundException e) {

                System.out.println(e.getMessage()); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

            }

            try {

                dbConnection = DriverManager.getConnection( //@ JAVA_GETCONNECTION-d0810d,JAVA_PASSWORD_HARDCODED-c0d242,JAVA_MISSING_AUTHORIZATION-kts455
                        DB_CONNECTION, DB_USER,DB_PASSWORD);
                return dbConnection;

            } catch (SQLException e) {

                System.out.println(e.getMessage()); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

            }

            return dbConnection;

        }
}
