package integration.java8;

import com.google.common.collect.Maps;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.TextCodec;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

import static java.util.stream.Collectors.toList;

public class JAVA_COOKIE_RELIANCE {

    private Map<String, String> votes = Maps.newHashMap();
    public static final String JWT_PASSWORD = TextCodec.BASE64.encode("victory");

    @GetMapping
    @ResponseBody
    public MappingJacksonValue getVotes(@CookieValue(value = "access_token", required = false) String accessToken) {
        MappingJacksonValue value = new MappingJacksonValue(votes.values().stream().collect(toList()));
        if (StringUtils.isEmpty(accessToken)) { //@ JAVA_COOKIE_RELIANCE-cokiel
            value.setSerializationView(JAVA_COOKIE_RELIANCE.class);
        } else {
            try {
                Jwt jwt = Jwts.parser().setSigningKey(JWT_PASSWORD).parse(accessToken); //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwthar,JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
                Claims claims = (Claims) jwt.getBody();
                String user = (String) claims.get("user");
                if ("Guest".equals(user) || !votes.containsKey(user)) { //@ JAVA_COOKIE_RELIANCE-cokrel,JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97
                    value.setSerializationView(JAVA_COOKIE_RELIANCE.class);
                } else {
                    value.setSerializationView(JAVA_COOKIE_RELIANCE.class);
                }
            } catch (JwtException e) {
                value.setSerializationView(JAVA_COOKIE_RELIANCE.class);
            }
        }
        return value;
    }
}
