package integration.java8;

import net.sf.hibernate.hql.QueryTranslator;
import org.apache.ecs.Element;
import org.apache.ecs.ElementContainer;
import org.apache.ecs.html.H1;
import org.apache.ecs.html.HR;
import org.apache.ecs.html.P;
import org.apache.ecs.html.TD;
import org.apache.ecs.html.TR;
import org.eclipse.jetty.server.NetworkConnector;
import org.eclipse.jetty.server.Server;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JEditorPane;

public class JAVA_XSS_PERSISTENT {
    class SUPER_TEST extends QueryTranslator {
        public final static String __message =
                "0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 \n" +
                        "9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 \n" +
                        "1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 \n" +
                        "0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 \n" +
                        "abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz \n" +
                        "ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ \n" +
                        "Now is the time for all good men to come to the aid of the party.\n" +
                        "How now brown cow.\n" +
                        "The quick brown fox jumped over the lazy dog.\n";
        private Server _server;

        public SUPER_TEST(String queryString) {
            super(queryString);
        }

        public void dsfdf(QueryTranslator tra, ServletOutputStream out, List<String> result) throws Exception {
            Socket socket = new Socket("127.0.0.1", ((NetworkConnector) _server.getConnectors()[0]).getLocalPort()); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_J2EE_SOCKETS-34473d
            List<String> list;
            list = (this).getResultList(result);

            out.write(list.get(0).getBytes()); //@ JAVA_XSS_PERSISTENT-fdadf6
        }
    }
    static public void XSS_PERSISTENT (HttpServletRequest request, OutputStream outPut) throws IOException {

        Scanner scanner = FLAG_FILE_SYSTEM.FILE_SYSTEM_bder8e();

        JEditorPane pane = new JEditorPane(scanner.toString()); //@ JAVA_XSS_PERSISTENT-7fe43a
        Properties properties = FLAG_FILE_SYSTEM.FILE_SYSTEM_PROPERTIES_READER();
        Properties properties1 = FLAG_FILE_SYSTEM.FILE_SYSTEM_PROPERTIES_STREAM();

        pane.setText(properties.toString()); //@ JAVA_XSS_REFLECTED-jxr001,JAVA_XSS_PERSISTENT-jxr901,JAVA_INFORMATION_LEAK_EXTERNAL-cd9503

        pane.setText(properties1.toString()); //@ JAVA_XSS_REFLECTED-jxr001,JAVA_XSS_PERSISTENT-jxr901,JAVA_INFORMATION_LEAK_EXTERNAL-cd9503
    }
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, IOException
    {
        JAVA_XSS_PERSISTENT s = new JAVA_XSS_PERSISTENT();
        String id = request.getParameter("username");
        String dbResult = s.getDbInfo(id, response);
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        String title = "Using GET Method to Read Form Data";
        String docType =
                "<!doctype html public \"-//w3c//dtd html 4.0 " +
                        "transitional//en\">\n";

        out.println(docType + //@ JAVA_XSS_PERSISTENT-rtejle
                "<html>\n" +
                "<head><title>" + title + "</title></head>\n" +
                "<body>\n" +
                "<h1 align=\"center\">" + title + "</h1>\n" +
                "<br><br>\n" +
                "<h2>Result DB query:</h2><br><br>\n" +
                dbResult + "\n</body></html>");
    }
    private String getDbInfo(String queryParam, HttpServletResponse response) throws ServletException, IOException {
        String result = ""; //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        try
        {
            Class.forName("org.sqlite.JDBC");
            String dbPath = "jdbc:sqlite:C:\\Users\\s.gilev\\Documents\\NetBeansProjects\\test2\\web\\test.s3db";
            Connection con = DriverManager.getConnection(dbPath); //@ JAVA_GETCONNECTION-d0810d
            try {
                Statement stmt = con.createStatement(); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd2

                ResultSet rs = stmt.executeQuery("SELECT * FROM phone_numbers WHERE ID=" + queryParam); //@ JAVA_INJECTION_SQL-33d6f1,JAVA_INJECTION_SQL_PARAMETER_TAMPERING-lri484
                ResultSetMetaData metadata = rs.getMetaData();
                int columnCount = metadata.getColumnCount();
                while (rs.next()) {
                    for (int i = 1; i <= columnCount; i++) {
                        result = result + rs.getString(i) + ": ";
                    }
                    result = result + "\n";
                }
                rs.close();
                stmt.close();
            } finally {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
        return result;
    }
    public void DBToNumber(HttpServletResponse response) throws ServletException, SQLException, IOException {
        final String url = "url"; //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        boolean resBoolean = false;
        byte resByte = 0;
        short resShort = 0;
        int resInt = 0;
        long resLong = 0;
        float resFloat = 0;
        double resDouble = 0;

        try {
            Connection connection = DriverManager.getConnection(url); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d

            try {
                Statement stmt = connection.createStatement(); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd2
                ResultSet rs = stmt.executeQuery("SELECT * FROM table WHERE ID=1");

                if (rs.next()) {
                    resBoolean = rs.getBoolean(0);
                    resByte = rs.getByte(0);
                    resShort = rs.getShort(0);
                    resInt = rs.getInt(0);
                    resLong = rs.getLong(0);
                    resFloat = rs.getFloat(0);
                    resDouble = rs.getDouble(0);
                }
                rs.close();
                stmt.close();

            } finally {
                connection.close();
            }

            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            String htmlOutputBoolean = Boolean.toString(resBoolean);
            String htmlOutputByte = Byte.toString(resByte);
            String htmlOutputShort = Short.toString(resShort);
            String htmlOutputInt = Integer.toString(resInt);
            String htmlOutputLong = Long.toString(resLong);
            String htmlOutputFloat = Float.toString(resFloat);
            String htmlOutputDouble = Double.toString(resDouble);

            out.println("<html><body><h1>");
            out.println(htmlOutputBoolean);
            out.println(htmlOutputByte);
            out.println(htmlOutputShort);
            out.println(htmlOutputInt);
            out.println(htmlOutputLong);
            out.println(htmlOutputFloat);
            out.println(htmlOutputDouble);
            out.println("</h1></body></html>");

        } catch (Exception e) {
            throw e;
        }
    }
    private static final long serialVersionUID = 1L;

    public void doGet_(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String param = request.getParameter("BenchmarkTest00375");
        if (param == null) param = "";

        FileInputStream a = new FileInputStream("~/Documents/"); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

        Properties b = new Properties();

        b.load(a);
        Object[] obj_ = { b };

        String bar = "";

        if (param != null) bar = param.split(" ")[0];
        response.setHeader("X-XSS-Protection", "0");
        Object[] obj = { "a", "b" }; //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        response.getWriter().format(java.util.Locale.US,bar,obj_); //@ JAVA_XSS_PERSISTENT-99c3d5,JAVA_INFORMATION_LEAK_EXTERNAL-f9ba68,JAVA_XSS_REFLECTED-99c3d2

        response.getWriter().format(java.util.Locale.US,response.encodeRedirectURL(bar),obj_); //@ JAVA_XSS_REFLECTED-99c3d2,JAVA_XSS_PERSISTENT-99c3d5,JAVA_INFORMATION_LEAK_EXTERNAL-f9ba68,JAVA_ESAPI_DEPRECATED-94fc09

        response.getWriter().printf(java.util.Locale.US,bar,obj_); //@ JAVA_INFORMATION_LEAK_EXTERNAL-f9ba68,JAVA_XSS_REFLECTED-99c3d2,JAVA_XSS_PERSISTENT-99c3d5

        int num = 106;
        bar = (7*42) - num > 200 ? "This should never happen" : param;

        b.load(a);
        response.setHeader("X-XSS-Protection", "0");
        Object[] obj__ = { "a", b };

        response.getWriter().format("Formatted like: %1$s and %2$s.",obj__); //@ JAVA_INFORMATION_LEAK_EXTERNAL-3c11c4,JAVA_XSS_PERSISTENT-99c3d7,JAVA_XSS_REFLECTED-99c3d3

        bar = "alsosafe";
        String bar_ = "alsosafe";

        if (param != null) {
            java.util.List<String> valuesList = new java.util.ArrayList<String>( );
            valuesList.add("safe");
            valuesList.add( param );
            valuesList.add( "moresafe" );

            valuesList.remove(0);

            bar = valuesList.get(0); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
            bar_ = valuesList.get(1); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        }

        b.load(a);
        response.setHeader("X-XSS-Protection", "0");
        Object[] obj00 = { "a", b };

        response.getWriter().format("Formatted like: %1$s and %2$s.",obj00); //@ JAVA_XSS_PERSISTENT-99c3d7,JAVA_XSS_REFLECTED-99c3d3,JAVA_INFORMATION_LEAK_EXTERNAL-3c11c4


        String a2196 = param;
        StringBuilder b2196 = new StringBuilder(a2196);
        b2196.append(" SafeStuff");
        b2196.replace(b2196.length()-"Chars".length(),b2196.length(),"Chars");
        java.util.HashMap<String,Object> map2196 = new java.util.HashMap<String,Object>();
        String a_ = "key2196";
        String b_ = "key124154";
        map2196.put(a_, b2196.toString());
        java.util.HashMap<String,Object> map2197 = new java.util.HashMap<String,Object>();

        FileInputStream a__ = new FileInputStream("~/Documents/");
        b.load(a__);
        String c = "afafqe";
        map2197.put(c, b);
        String c2197 = (String)map2197.get(c);

        response.getWriter().printf(java.util.Locale.US,c2197,obj_); //@ JAVA_INFORMATION_LEAK_EXTERNAL-f9ba68,JAVA_XSS_REFLECTED-99c3d2,JAVA_XSS_PERSISTENT-99c3d5
    }

    String arrSQL[];
    Class Element; //@ JAVA_BACKDOOR_DEAD_CODE-d27d15
    Statement statement;
    protected void concept1() throws SQLException {
        ResultSet rs = statement.executeQuery(arrSQL[0]); //@ JAVA_NULL_DEREFERENCE-j11nd8,JAVA_NULL_DEREFERENCE-j11nd8
        if (rs.next()) {
            TR tr = new TR();

            tr.addElement(new TD("User ID"));
            tr.addElement(new TD("Password"));
            tr.addElement(new TD("SSN"));
            tr.addElement(new TD("Salary"));
            tr = new TR();

            tr.addElement(new TD(rs.getString("userid"))); //@ JAVA_XSS_PERSISTENT-a00011

            tr.addElement(new TD(rs.getString("password"))); //@ JAVA_XSS_PERSISTENT-a00011

            tr.addElement(new TD(rs.getString("ssn"))); //@ JAVA_XSS_PERSISTENT-a00011

            tr.addElement(new TD(rs.getString("salary"))); //@ JAVA_XSS_PERSISTENT-a00011

        }
    }
    public static String getFileText(BufferedReader reader, boolean numbers)
    {
        int count = 0; //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        StringBuffer sb = new StringBuffer();

        try
        {
            String line;

            while ((line = reader.readLine()) != null) //@ JAVA_DOS-7adk6b
            {
                sb.append(line + System.getProperty("line.separator"));
            }
        }
        catch (Exception e)
        {
            System.out.println(e); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        return (sb.toString());
    }
    private Element showDefaceAttempt(String s) throws Exception
    {
        ElementContainer ec = new ElementContainer(); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        ElementContainer ec1 = new ElementContainer();

        String origpath = (
                "WEBGOAT_CHALLENGE" + "_");

        String defaced = getFileText(new BufferedReader(
                new FileReader(origpath)), false);


        ec.addElement(new H1().addElement("Original Website Text"));
        ec.addElement(new HR());
        ec.addElement(new H1().addElement("Defaced Website Text"));

        ec.addElement(new P().addElement(defaced)); //@ JAVA_XSS_REFLECTED-b00666
        ec.addElement(new HR());


        ec1.addElement(new H1().addElement("Original Website Text"));
        ec1.addElement(new HR());
        ec1.addElement(new H1().addElement("Defaced Website Text"));

        ec1.addElement(new P().addElement(defaced)); //@ JAVA_XSS_REFLECTED-b00666
        ec1.addElement(new HR());
        return ec;
    }

    public void test(ResultSet results, ResultSetMetaData resultsMetaData, HttpServletResponse response) throws SQLException, IOException {
        int numColumns = resultsMetaData.getColumnCount();
        results.beforeFirst();
        PrintWriter out = response.getWriter();

        if (results.next()) {
            results.beforeFirst();

            while (results.next()) {

                for (int i = 1; i < (numColumns + 1); i++) {
                    String str = results.getString(i);
                    if (str == null) str = "";
                    out.print(str); //@ JAVA_XSS_PERSISTENT-rtejle
                }

            }
        }
        out.close();
    }
    @RequestMapping(produces = {"application/json"}, method = RequestMethod.GET)
    @ResponseBody
    protected HashMap<Integer, HashMap> getUsers(HttpServletRequest req) {

        try {
            Connection connection = DriverManager.getConnection(""); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2,JAVA_GETCONNECTION-d0810d,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7
            String query = "SELECT * FROM user_data";

            try {
                Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
                        ResultSet.CONCUR_READ_ONLY);
                ResultSet results = statement.executeQuery(query);
                HashMap<Integer,HashMap> allUsersMap = new HashMap<>();

                if ((results != null) && (results.first())) {
                    while (results.next()) {
                        int id = results.getInt(0);
                        HashMap<String,String> userMap = new HashMap<>();
                        userMap.put("first", results.getString(1));
                        userMap.put("last", results.getString(2));
                        userMap.put("cc", results.getString(3));
                        userMap.put("ccType", results.getString(4));
                        userMap.put("cookie", results.getString(5));
                        userMap.put("loginCount",Integer.toString(results.getInt(6)));
                        allUsersMap.put(id,userMap);
                    }
                    return allUsersMap; //@ JAVA_XSS_PERSISTENT-j11xp1

                }
            } catch (SQLException sqle) {
                sqle.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                HashMap errMap = new HashMap() {{
                    put("err",sqle.getErrorCode() + "::" + sqle.getMessage());
                }};

                return new HashMap<Integer,HashMap>() {{
                    put(0,errMap);
                }};
            } catch (Exception e) {
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                HashMap errMap = new HashMap() {{
                    put("err",e.getMessage() + "::" + e.getCause());
                }};
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                return new HashMap<Integer,HashMap>() {{
                    put(0,errMap);
                }};


            } finally {
                try {
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException sqle) {
                    sqle.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                }
            }

        } catch (Exception e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            HashMap errMap = new HashMap() {{
                put("err",e.getMessage() + "::" + e.getCause());
            }};
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            return new HashMap<Integer,HashMap>() {{
                put(0,errMap);
            }};

        }
        return null;
    }
}
