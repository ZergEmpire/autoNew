package integration.java8;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspWriter;
import javax.sql.rowset.spi.SyncFactoryException;

public class JAVA_INFORMATION_LEAK_EXTERNAL {
    private static void leakStacktrace(HttpServletResponse response, MyException myException,
                                       AuthenticationException authException) throws IOException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE MMM d HH:mm:ss Z yyyy");
        String errorMessage = "";
        String errorMessage2 = "";
        try {
            Date tokenDateTime = simpleDateFormat.parse("12:10"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        } catch (ParseException e) {
            errorMessage += "text " + e.toString();
            errorMessage2 = e.toString();
        }
        response.sendError(404, myException.getMessage()); //@ JAVA_INFORMATION_LEAK_EXTERNAL-inflea
        response.sendError(401, authException.getLocalizedMessage()); //@ JAVA_INFORMATION_LEAK_EXTERNAL-inflea

        ServletOutputStream out = response.getOutputStream();

        out.println(errorMessage); //@ JAVA_INFORMATION_LEAK_EXTERNAL-da6aa1

        out.println(errorMessage2); //@ JAVA_INFORMATION_LEAK_EXTERNAL-da6aa1

        PrintWriter out2 = response.getWriter();

        out2.write(errorMessage); //@ JAVA_INFORMATION_LEAK_EXTERNAL-c9497t

        out2.write(errorMessage2); //@ JAVA_INFORMATION_LEAK_EXTERNAL-c9497t
    }

    public void bad(final HttpServletResponse response) throws Throwable {
        response.getWriter().println("Not in path: " + System.getenv("PATH")); //@ JAVA_INFORMATION_LEAK_EXTERNAL-c9497t,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae,JAVA_USE_GETENV-f9b0b0
    }

    public void bad2(final HttpServletResponse response) throws Throwable {
        final String path = System.getenv("PATH"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae,JAVA_USE_GETENV-f9b0b0
        final List<String> strings = Collections.nCopies(2, path);
        response.getWriter().println("Not in path: " + strings); //@ JAVA_INFORMATION_LEAK_EXTERNAL-c9497t
    }

    public static void INFORMATION_LEAK_b53325 (JspWriter jspWriter, OutputStream outputStream) throws SyncFactoryException, IOException {

        jspWriter.print(FLAG_SYSTEM_INFO.SYSTEM_INFO_rw3865()); //@ JAVA_INFORMATION_LEAK_EXTERNAL-cedd63

        outputStream.write(FLAG_SYSTEM_INFO.SYSTEM_INFO_cdw854().getBytes()); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr
    }

    private static class MyException extends RuntimeException {

    }

    @PostMapping("newToken")
    public @ResponseBody
    ResponseEntity newToken(@RequestHeader("Authorization") String token, @RequestBody Map<String, Object> json) {
        String user;
        String refreshToken;
        try {
            Jwt<Header, Claims> jwt = Jwts.parser()
                .setSigningKey(json.toString()) //@ JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
                .parse(token.replace("Bearer ", ""));
            user = (String) jwt.getBody().get("user");
            refreshToken = (String) json.get("refresh_token");
        } catch (ExpiredJwtException e) {
            user = (String) e.getClaims().get("user");
            refreshToken = (String) json.get("refresh_token");
        }

        if (user == null || refreshToken == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        } else {
            return ResponseEntity.ok(user); //@ JAVA_INFORMATION_LEAK_EXTERNAL-admfel,JAVA_XSS_REFLECTED-j11xs1
        }
    }
}
