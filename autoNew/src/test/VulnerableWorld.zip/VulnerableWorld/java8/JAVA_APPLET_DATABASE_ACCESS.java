package integration.java8;

import java.applet.Applet;
import java.sql.SQLData;
import java.sql.SQLException;

public class JAVA_APPLET_DATABASE_ACCESS extends Applet { //@ JAVA_APPLET_DATABASE_ACCESS-f48af9
    public void test(SQLData data) throws SQLException
    {
        data.getSQLTypeName();
    }
}
class JAVA_APPLET_DATABASE_ACCESS_2 {
    public void test(SQLData data) throws SQLException
    {
        data.getSQLTypeName();
    }
}
class JAVA_APPLET_DATABASE_ACCESS_3 extends Applet {
    public void test() throws SQLException
    {
        String a = "a";
    }
}
