package integration.java8;

public class JAVA_CLONE_METHOD_ERROR implements Cloneable{
    public Object clone() {

        return this; //@ JAVA_CLONE_METHOD_ERROR-a07a0f
    }
}

class NOT_CLONE_METHOD_ERROR implements Cloneable {
    public Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
