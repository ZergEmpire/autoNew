package integration.java8;

import org.apache.http.HttpMessage;

import java.net.URLConnection;

public class JAVA_NEGATIVE_CONTENT_LENGTH {

    public void test(URLConnection connection) {
        connection.setRequestProperty("Content-Length", "-1"); //@ JAVA_NEGATIVE_CONTENT_LENGTH-be8744
    }
    public void test(HttpMessage message) {
        message.setHeader("Content-Length", "-1"); //@ JAVA_NEGATIVE_CONTENT_LENGTH-bf9065
    }
}
