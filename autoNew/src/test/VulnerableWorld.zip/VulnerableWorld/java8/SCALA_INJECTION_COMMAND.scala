package integration.java8

import scala.sys.process._
import cats.Eval

class SCALA_INJECTION_COMMAND {
  def injection: Unit = {
    Process("asd") !

    Process("asd") !!

    Process("asd") ##

    Process("asd") #| Process("foo")

    Process("asd") #&& Process("foo")

    Process("asd") #|| Process("foo") !!<

    Process("asd").lineStream

    val env = scala.sys.env("123") //@ SCALA_USE_GETENV-f9b000

    Process(env) ! //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) !! //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) ## //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) #| Process("foo") //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) #&& Process("foo") //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) #|| Process("foo") !!< //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) #| Process(env) //@ SCALA_INJECTION_COMMAND-39bf77

    Process("asd") #&& Process(env) //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env) #|| Process("foo") #&& Process(env) !!< //@ SCALA_INJECTION_COMMAND-39bf77

    Process(env).lineStream //@ SCALA_INJECTION_COMMAND-0ba701,SCALA_INJECTION_COMMAND-39bf77

    Process(env).run //@ SCALA_INJECTION_COMMAND-39bf77

    "find src -name *.scala -exec grep null {} ;" #| "xargs test -z" #&& "echo null-free" #|| "echo null detected" !

    env #| "asd" ! //@ SCALA_INJECTION_COMMAND-ab6c40

    Process(env) #&& "asd" ! //@ SCALA_INJECTION_COMMAND-39bf77

    env #| Process("asd") ! //@ SCALA_INJECTION_COMMAND-ab6c40

    "asd" #| env ! //@ SCALA_INJECTION_COMMAND-ab6c40

    "asd" #| Process(env) ! //@ SCALA_INJECTION_COMMAND-39bf77
  }



















  def toStream: Stream[String] = "echo" #< new java.io.File("fixed.html") lineStream //@ SCALA_INJECTION_COMMAND-0ba701

  def fromStream: Unit ={
    Process(toStream).run //@ SCALA_INJECTION_COMMAND-39bf77
    Process("echo" #< new java.io.File("fixed.html") lineStream).run //@ SCALA_INJECTION_COMMAND-39bf77,SCALA_INJECTION_COMMAND-0ba701
    Process("echo" #< new java.net.URL("https://www.scala-lang.org") lineStream).run //@ SCALA_INJECTION_COMMAND-39bf77,SCALA_INJECTION_COMMAND-0ba701

    val a = "echo" #< new java.io.File("fixed.html")
    a !

    Process(a lineStream).run //@ SCALA_INJECTION_COMMAND-39bf77,SCALA_INJECTION_COMMAND-0ba701

    a lineStream //@ SCALA_INJECTION_COMMAND-0ba701
  }

  val env = scala.sys.env("123") //@ SCALA_USE_GETENV-f9b000

  val eager = Eval.now { //@ SCALA_INJECTION_COMMAND-gsjdkg
    env
  }

  def test(urlString: String): Unit = {
    var taintedHeader: String = FLAG_WEB_SCALA.getResponse(urlString).body

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ SCALA_INJECTION_COMMAND-0ba701,SCALA_INJECTION_COMMAND-39bf77,JAVA_PATH_MANIPULATION-b1b30c
    taintedHeader =  FLAG_WEB_SCALA.getParams(urlString).body(0)._1

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ SCALA_INJECTION_COMMAND-0ba701,JAVA_PATH_MANIPULATION-b1b30c,SCALA_INJECTION_COMMAND-39bf77
    taintedHeader = FLAG_WEB_SCALA.getParamMap(urlString).body.mkString

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ SCALA_INJECTION_COMMAND-39bf77,JAVA_PATH_MANIPULATION-b1b30c,SCALA_INJECTION_COMMAND-0ba701
    taintedHeader = FLAG_WEB_SCALA.getBytes(urlString).body.toString

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ SCALA_INJECTION_COMMAND-39bf77,JAVA_PATH_MANIPULATION-b1b30c,SCALA_INJECTION_COMMAND-0ba701
    taintedHeader = FLAG_WEB_SCALA.getToken(urlString).body.toString

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ SCALA_INJECTION_COMMAND-39bf77,JAVA_PATH_MANIPULATION-b1b30c,SCALA_INJECTION_COMMAND-0ba701
    taintedHeader = FLAG_WEB_SCALA.execute(urlString, FLAG_WEB_SCALA.parse).body

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ SCALA_INJECTION_COMMAND-0ba701,JAVA_PATH_MANIPULATION-b1b30c,SCALA_INJECTION_COMMAND-39bf77
    taintedHeader = FLAG_WEB_SCALA.exec(urlString, FLAG_WEB_SCALA.parse2).body

    Process("echo" #< new java.io.File(taintedHeader) lineStream) //@ JAVA_PATH_MANIPULATION-b1b30c,SCALA_INJECTION_COMMAND-39bf77,SCALA_INJECTION_COMMAND-0ba701
  }
}
