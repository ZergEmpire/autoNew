package integration.java8

import io.ktor.http.Cookie
import io.ktor.http.renderSetCookieHeader
import io.ktor.response.ApplicationResponse
import io.ktor.response.ResponseCookies
import io.ktor.sessions.CookieConfiguration

fun cookieBroadPath(response: ApplicationResponse) {

    val cookie = Cookie(name = "name", value = "value", path = "/", secure = true, httpOnly = true ) //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_COOKIE_BROAD_PATH-2rew87

    ResponseCookies(response, true).append(name = "name", value = "value", path = "/", secure = true, httpOnly = true)

    renderSetCookieHeader(name = "name", value = "value", path = "/", secure = true, httpOnly = true) //@ KOTLIN_COOKIE_BROAD_PATH-werwe7
    val cookieConf = CookieConfiguration()

    cookieConf.path = "/" //@ KOTLIN_COOKIE_BROAD_PATH-rr3899
}
