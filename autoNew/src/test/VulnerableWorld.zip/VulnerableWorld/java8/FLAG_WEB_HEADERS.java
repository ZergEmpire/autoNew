package integration.java8;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

/**
 * this class supplies methods that return Web tainted data from headers of request
 */
public final class FLAG_WEB_HEADERS {

    public static String getWebFromHeaderInt(final int i, final String urlString) throws IOException
    {
        final URL url = new URL(urlString);
        final HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        final String result = conn.getHeaderField(i);
        conn.disconnect();
        return result;
    }

    public static String getWebFromHeaderString(final String key, final String urlString) throws IOException
    {
        final URL url = new URL(urlString);
        final HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        final String result = conn.getHeaderField(key);
        conn.disconnect();
        return result;
    }

    public static Map<String, List<String>> getWebFromHeaders(final String urlString) throws IOException
    {
        final URL url = new URL(urlString);
        final HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        final Map<String, List<String>> result = conn.getHeaderFields();
        conn.disconnect();
        return result;
    }

    public static String getWebFromHeaderKey(final int i, final String urlString) throws IOException
    {
        final URL url = new URL(urlString);
        final HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        final String result = conn.getHeaderFieldKey(i);
        conn.disconnect();
        return result;
    }
}
