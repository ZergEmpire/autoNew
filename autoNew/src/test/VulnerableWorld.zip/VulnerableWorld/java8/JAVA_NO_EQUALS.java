package integration.java8;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data

@ConfigurationProperties(prefix = "qasl.async")
public class JAVA_NO_EQUALS {
    public enum AsyncType {DIRECT, THREAD_POOL}
    private AsyncType type = AsyncType.THREAD_POOL;
}
