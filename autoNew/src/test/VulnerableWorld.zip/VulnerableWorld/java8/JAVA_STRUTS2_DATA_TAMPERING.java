package integration.java8;

import org.apache.struts2.interceptor.ApplicationAware;
import com.opensymphony.xwork2.ActionSupport;
import java.util.Map;

public class JAVA_STRUTS2_DATA_TAMPERING extends ActionSupport implements ApplicationAware { //@ JAVA_STRUTS2_DATA_TAMPERING-0dc106
    Map m;
    public void setApplication(Map m)
    {
        this.m=m;
    }
}

class NOT_STRUTS2_DATA_TAMPERING implements ApplicationAware {
    Map m;
    public void setApplication(Map m)
    {
        this.m=m;
    }
    public String acceptableParameterName (Map name) {
        return name.toString();
    }
}

