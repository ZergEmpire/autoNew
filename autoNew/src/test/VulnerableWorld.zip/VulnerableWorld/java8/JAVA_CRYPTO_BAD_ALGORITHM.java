package integration.java8;

import com.hazelcast.config.SymmetricEncryptionConfig;
import org.owasp.esapi.crypto.KeyDerivationFunction;


public class JAVA_CRYPTO_BAD_ALGORITHM {

    public void init() {
        SymmetricEncryptionConfig symmetricEncryptionConfig = new SymmetricEncryptionConfig();
        symmetricEncryptionConfig.setAlgorithm("DESede"); //@ JAVA_CRYPTO_BAD_ALGORITHM-vfkoel

        KeyDerivationFunction.convertNameToPRF("LolKek"); //@ JAVA_CRYPTO_BAD_ALGORITHM-ow0001

    }
}
