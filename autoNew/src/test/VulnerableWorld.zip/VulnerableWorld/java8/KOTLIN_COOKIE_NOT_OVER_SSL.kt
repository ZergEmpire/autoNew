package integration.java8

import io.ktor.http.Cookie
import io.ktor.http.renderSetCookieHeader
import io.ktor.response.ApplicationResponse
import io.ktor.response.ResponseCookies
import io.ktor.sessions.CookieConfiguration

fun cookieNotOverSSL(response: ApplicationResponse) {

    var cookie = Cookie(name = "name", value = "value" //@ KOTLIN_COOKIE_NOT_OVER_SSL-wwtre0,JAVA_BACKDOOR_DEAD_CODE-d27d09
            , secure = false, httpOnly = true
    )

    cookie = Cookie(name = "name", value = "value", httpOnly = true) //@ KOTLIN_COOKIE_NOT_OVER_SSL-wwtre0

    val responseCookie = ResponseCookies(response, secureTransport = false) //@ KOTLIN_COOKIE_NOT_OVER_SSL-tttre0,JAVA_BACKDOOR_DEAD_CODE-d27d09

    ResponseCookies(response, true).append(name = "name", value = "value", httpOnly = true) //@ KOTLIN_COOKIE_NOT_HTTPONLY-pmtt88,KOTLIN_COOKIE_NOT_OVER_SSL-peru78

    renderSetCookieHeader(name = "name", value = "value", httpOnly = true) //@ KOTLIN_COOKIE_NOT_OVER_SSL-weewmn
    val cookieConf = CookieConfiguration()

    cookieConf.secure = false //@ KOTLIN_COOKIE_NOT_OVER_SSL-fpp877
}
