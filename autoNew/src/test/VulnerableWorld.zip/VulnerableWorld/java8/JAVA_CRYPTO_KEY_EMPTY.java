package integration.java8;

import sun.security.provider.DSAPublicKeyImpl;

import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.kerberos.KerberosKey;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class JAVA_CRYPTO_KEY_EMPTY {

    public String encryptionKey = ""; //@ JAVA_CRYPTO_KEY_EMPTY-keyemp
    private final String secretKey = ""; //@ JAVA_CRYPTO_KEY_EMPTY-keyemp
    private static final String privateKey = ""; //@ JAVA_CRYPTO_KEY_EMPTY-keyemp

    public void bad1() throws Exception {
        String cryptographicKey = ""; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        byte[] key = cryptographicKey.getBytes();

        KerberosKey kerberosKey = new KerberosKey(null, key, 0, 0); //@ JAVA_CRYPTO_KEY_EMPTY-bvnc17,JAVA_BACKDOOR_DEAD_CODE-d27d09

        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "alg"); //@ JAVA_CRYPTO_KEY_EMPTY-bvnc12,JAVA_BACKDOOR_DEAD_CODE-d27d09

        SecretKeySpec secretKeySpec2 = new SecretKeySpec(key, 0, 0, "alg"); //@ JAVA_CRYPTO_KEY_EMPTY-bvnc12,JAVA_BACKDOOR_DEAD_CODE-d27d09

        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(key); //@ JAVA_CRYPTO_KEY_EMPTY-bvnc13,JAVA_BACKDOOR_DEAD_CODE-d27d09

        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_EMPTY-bvnc14,JAVA_CRYPTO_KEY_REUSED-kda765

        KeyRep keyRep = new KeyRep(null, "alg", "format", key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_EMPTY-bvnc15

        DSAPublicKeyImpl publicKey = new DSAPublicKeyImpl(key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_EMPTY-bvnc16
    }

    public void keyStore(Certificate[] certificate) throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableKeyException {
        String pwdStr = ""; //@ JAVA_PASSWORD_EMPTY-76458b
        char[] pwd1 = pwdStr.toCharArray();
        char[] pwd2 = pwd1;
        char[] passphrase2 = {}; //@ JAVA_PASSWORD_EMPTY-76458b
        char[] pass = passphrase2; //@ JAVA_PASSWORD_EMPTY-76458b
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(new FileInputStream("keystore"), pwd2); //@ JAVA_PASSWORD_HARDCODED-twgk4k,JAVA_CRYPTO_KEY_EMPTY-frejkw,JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

        ks.load(new FileInputStream("keystore"), "".toCharArray()); //@ JAVA_CRYPTO_KEY_EMPTY-frejkw
        String passphrase = ""; //@ JAVA_PASSWORD_EMPTY-76458b

        KeyStore.getInstance("JKS").load(new FileInputStream("keystore"), passphrase.toCharArray()); //@ JAVA_CRYPTO_KEY_EMPTY-frejkw
        ks.store(new FileOutputStream("a"), passphrase2); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1,JAVA_PASSWORD_HARDCODED-twgk4k,JAVA_PASSWORD_EMPTY-twgk4d
        ks.setKeyEntry("a", passphrase.getBytes(), certificate); //@ JAVA_PASSWORD_HARDCODED-8ce2fb
        ks.getKey("a", pass); //@ JAVA_PASSWORD_HARDCODED-twgk4k,JAVA_PASSWORD_EMPTY-twgk4d

        SecureRandom random = new SecureRandom();
        ks.setKeyEntry("a", random.generateSeed(1), certificate);
        byte[] bytesRandom = random.generateSeed(2);
        ks.setKeyEntry("a", bytesRandom, certificate);

        byte[] bytes = new byte[bytesRandom.length];
        char[] fromBytes = new char[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            fromBytes[i] = (char) bytes[i];
        }
        ks.load(new FileInputStream("a"), fromBytes);

        char[] fromBytes2 = new char[bytes.length];
        ks.load(new FileInputStream("a"), fromBytes2);

        ks.setKeyEntry("a", bytes, certificate); //@ JAVA_CRYPTO_KEY_HARDCODED-keymhd
    }

}
