package integration.java8

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import io.ktor.client.response.HttpResponse
import org.jetbrains.anko.db.BLOB
import org.jetbrains.anko.db.INTEGER
import org.jetbrains.anko.db.ManagedSQLiteOpenHelper
import org.jetbrains.anko.db.PRIMARY_KEY
import org.jetbrains.anko.db.TEXT
import org.jetbrains.anko.db.UNIQUE
import org.jetbrains.anko.db.createTable
import org.jetbrains.anko.db.dropTable
import org.jetbrains.anko.db.select
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils.create
import org.jetbrains.exposed.sql.SchemaUtils.drop
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.and
import org.jetbrains.exposed.sql.count
import org.jetbrains.exposed.sql.deleteWhere
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.or
import org.jetbrains.exposed.sql.select
import org.jetbrains.exposed.sql.selectAll
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.update
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseBody
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.SQLException
import javax.servlet.http.HttpServletRequest

object Users : Table() {
    val id = varchar("id", 10).primaryKey()
    val name = varchar("name", length = 50)
    val cityId = (integer("city_id") references Cities.id).nullable()
}

object Cities : Table() {
    val id = integer("id").autoIncrement().primaryKey()
    val name = varchar("name", 50)
}



fun main(args: Array<String>, response: HttpResponse, db: SQLiteDatabase) {


    val query = response.receiveContent().toString()



    Database.connect("jdbc:h2:mem:test", driver = "org.h2.Driver")

    transaction {
        create (Cities, Users)

        val saintPetersburgId = Cities.insert {
            it[name] = "St. Petersburg"
        } get Cities.id

        val munichId = Cities.insert {
            it[name] = "Munich"
        } get Cities.id

        Cities.insert {
            it[name] = "Prague"
        }

        Users.insert {
            it[id] = "andrey"
            it[name] = "Andrey"
            it[cityId] = saintPetersburgId
        }

        Users.insert {
            it[id] = "sergey"
            it[name] = "Sergey"
            it[cityId] = munichId
        }

        Users.insert {
            it[id] = "eugene"
            it[name] = "Eugene"
            it[cityId] = munichId
        }

        Users.insert {
            it[id] = "alex"
            it[name] = "Alex"
            it[cityId] = null
        }

        Users.insert {
            it[id] = "smth"
            it[name] = "Something"
            it[cityId] = null
        }

        Users.update({Users.id eq "alex"}) {
            it[name] = "Alexey"
        }

        Users.deleteWhere{Users.name like "%thing"}

        println("All cities:") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        for (city in Cities.selectAll()) {
            println("${city[Cities.id]}: ${city[Cities.name]}") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }

        (Users innerJoin Cities).slice(Users.name, Cities.name).
                select {(Users.id.eq(query) or Users.name.eq(query)) and //@ KOTLIN_INJECTION_SQL-k11is1
                        Users.id.eq("sergey") and Users.cityId.eq(Cities.id)}.forEach {
            println("${it[Users.name]} lives in ${it[Cities.name]}") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }

        println("Join with foreign key:") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d


        (Users innerJoin Cities).slice(Users.name, Users.cityId, Cities.name).
                select {Cities.name.eq("FAF") or Users.cityId.isNull()}.forEach {
            if (it[Users.cityId] != null) {
                println("${it[Users.name]} lives in ${it[Cities.name]}") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
            }
            else {
                println("${it[Users.name]} lives nowhere") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
            }
        }

        println("Functions and group by:") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        ((Cities innerJoin Users).slice(Cities.name, Users.id.count()).selectAll().groupBy(Cities.name)).forEach {
            val cityName = it[Cities.name]
            val userCount = it[Users.id.count()]

            if (userCount > 0) {
                println("$userCount user(s) live(s) in $cityName") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
            } else {
                println("Nobody lives in $cityName") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
            }
        }

        drop (Users, Cities)

    }

    db.select("User", "name")

            .whereArgs("(_id > {userId}) and (name = {userName})", //@ KOTLIN_INJECTION_SQL-k12is1
                    "userName" to query,
                    "userId" to 42)
}

class MyDatabaseOpenHelper(ctx: Context) : ManagedSQLiteOpenHelper(ctx, "MyDatabase", null, 1) {
    companion object {
        private var instance: MyDatabaseOpenHelper? = null

        @Synchronized
        fun getInstance(ctx: Context): MyDatabaseOpenHelper {
            if (instance == null) {
                instance = MyDatabaseOpenHelper(ctx.getApplicationContext())
            }
            return instance!!
        }
    }

    override fun onCreate(db: SQLiteDatabase) {

        db.createTable("Customer", true,
                "id" to INTEGER + PRIMARY_KEY + UNIQUE,
                "name" to TEXT,
                "photo" to BLOB)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        db.dropTable("User", true)
    }


val Context.database: MyDatabaseOpenHelper
    get() = MyDatabaseOpenHelper.getInstance(getApplicationContext())

    @RequestMapping(method = [RequestMethod.POST])
    @ResponseBody
    @Throws(SQLException::class)
    fun completed(@RequestParam userid: String, request: HttpServletRequest): Unit {
        val query = "SELECT * FROM user_data WHERE userid = $userid"
        val statement = DriverManager.getConnection("url").createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,//@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,KOTLIN_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
                ResultSet.CONCUR_READ_ONLY)
        val results = statement.executeQuery(query) //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_INJECTION_SQL-33d6f1,KOTLIN_INJECTION_SQL_PARAMETER_TAMPERING-lri484
    }

}
