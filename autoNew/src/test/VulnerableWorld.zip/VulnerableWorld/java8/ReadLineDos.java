package integration.java8;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

class ReadLineDos {

    void foo(String filename) throws Exception {

        FileInputStream is;

        try {
            is = new FileInputStream(filename); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        } catch (Exception exception) {
            exception.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            return;
        }

        InputStreamReader reader;
        if (35 < 42) {
            reader = new InputStreamReader(is);
        }

        BufferedReader br = new BufferedReader(reader); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        do {
            String line = br.readLine(); //@ JAVA_DOS-9ad0eb
            if (line.isEmpty()) {
                break;
            }
        } while (true);

    }
}
