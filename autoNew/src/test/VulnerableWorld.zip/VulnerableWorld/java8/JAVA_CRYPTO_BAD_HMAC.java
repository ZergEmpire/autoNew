package integration.java8;

import javax.crypto.KeyGenerator;
import java.security.NoSuchAlgorithmException;

public class JAVA_CRYPTO_BAD_HMAC {
    public void bad() throws NoSuchAlgorithmException {
        KeyGenerator.getInstance("HmacSHA1"); //@ JAVA_CRYPTO_BAD_HMAC-cbh000
        KeyGenerator.getInstance("HmacMD5"); //@ JAVA_CRYPTO_BAD_HMAC-cbh000
    }

    public void good() throws NoSuchAlgorithmException {
        KeyGenerator.getInstance("HmacSHA512");
    }
}
