package integration.java8;

import android.app.PendingIntent;
import android.location.LocationListener;
import android.location.LocationManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

public class ANDROID_LOCATION {

    public void test(
        TelephonyManager telephonyManager,
        PhoneStateListener phoneStateListener)
    {
        telephonyManager.listen(phoneStateListener, 1); //@ ANDROID_LOCATION-5015ae
        telephonyManager.getNeighboringCellInfo(); //@ ANDROID_LOCATION-5015ae
    }

    public void test(
        LocationManager locationManager,
        PendingIntent pendingIntent,
        LocationListener listener)
    {
        locationManager.getLastKnownLocation("string"); //@ ANDROID_LOCATION-c296d6
        locationManager.addProximityAlert(1d, 2d, 3f, 1, pendingIntent); //@ ANDROID_LOCATION-c296d6
        locationManager.requestLocationUpdates("string", 1L, 2f, listener); //@ ANDROID_LOCATION-c296d6
        locationManager.isProviderEnabled("string"); //@ ANDROID_LOCATION-c296d6
        locationManager.getProvider("string"); //@ ANDROID_LOCATION-c296d6
    }
}
