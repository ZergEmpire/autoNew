package integration.java8;

import java.io.File;
import java.io.IOException;

public class JAVA_DELETE_ON_EXIT {
    public void deleteOnExit() throws IOException {
        File tempFile = File.createTempFile("temp", "1234"); //@ JAVA_ESAPI_DEPRECATED-rt3s89

        tempFile.deleteOnExit(); //@ JAVA_DELETE_ON_EXIT-f9b0b1
    }
}
