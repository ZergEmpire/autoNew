package integration.java8

import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.client.response.HttpResponse
import io.ktor.client.response.readText
import io.ktor.features.*
import io.ktor.response.*
import io.ktor.routing.*

fun Application.main() {
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
            call.respondText("Hello, World!")
        }
    }
}

class GetResponse(val response: HttpResponse) {
    val someContent = response.receiveContent()
}
