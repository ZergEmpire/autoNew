package integration.java8;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

public class JAVA_INJECTION_SQL  {
    @RequestMapping(method = RequestMethod.POST)
    public
    @ResponseBody
    String completed(@RequestParam String userid, HttpServletRequest request) throws SQLException {
        String sql = "INSERT INTO Products (ProductName, Price) Values (?, ?)";
        String query = "SELECT * FROM user_data WHERE userid = " + userid;
        Connection connection = DriverManager.getConnection("url"); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
                ResultSet.CONCUR_READ_ONLY);
        ResultSet results = statement.executeQuery(query); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_SQL-33d6f1,JAVA_INJECTION_SQL_PARAMETER_TAMPERING-lri484
        PreparedStatement preparedStatement = connection.prepareStatement(sql); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        return injectableQuery(userid); //@ JAVA_XSS_REFLECTED-j11xs1
    }

    protected String injectableQuery(String accountName) {
        try {
            Connection connection = DriverManager.getConnection("url"); //@ JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1,JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7
            String query = "SELECT * FROM user_data WHERE userid = " + accountName;
            try {
                Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
                        ResultSet.CONCUR_READ_ONLY);
                ResultSet results = statement.executeQuery(query); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_SQL-33d6f1,JAVA_INJECTION_SQL_PARAMETER_TAMPERING-lri484
                return query;
            } catch (SQLException sqle) {
                return sqle.getMessage();
            }
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    @ResponseBody
    public String login(@RequestParam String username_login, @RequestParam String password_login) throws Exception {
        Connection connection = DriverManager.getConnection("url"); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1

        CallableStatement cstmt = connection.prepareCall(username_login); //@ JAVA_INJECTION_SQL-1c6b43,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        cstmt.execute();

        PreparedStatement prpBadStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?" + "AND username =" + username_login +";");
        prpBadStmnt.setString(1, password_login);
        prpBadStmnt.executeQuery(); //@ JAVA_INJECTION_SQL-j00injsql1


        PreparedStatement preparedStatement = connection.prepareStatement("select password from " + " where userid = '" + username_login + "' and password = '" + password_login + "'");
        ResultSet resultSet = preparedStatement.executeQuery("select password from " + " where userid = '" + username_login + "' and password = '" + password_login + "'"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_SQL-33d6f0

        Statement simpleStatement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
                ResultSet.CONCUR_READ_ONLY);
        ResultSet simple_resultSet = simpleStatement.executeQuery("select password from " + " where userid = '" + username_login + "' and password = '" + password_login + "'"); //@ JAVA_INJECTION_SQL-33d6f1,JAVA_BACKDOOR_DEAD_CODE-d27d09
        return username_login; //@ JAVA_XSS_REFLECTED-j11xs1
    }

    public void test(ServletRequest request, Connection connection) throws SQLException
    {
        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim(); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin, JAVA_BACKDOOR_DEAD_CODE-d27d09
        String query = "SELECT " + username;
        PreparedStatement pstmt = connection.prepareStatement(query); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        pstmt.executeQuery(); //@ JAVA_INJECTION_SQL-j00injsql1
    }
}
