package integration.java8;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspWriter;
import javax.sql.rowset.spi.SyncFactoryException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JAVA_INFORMATION_LEAK {
}
