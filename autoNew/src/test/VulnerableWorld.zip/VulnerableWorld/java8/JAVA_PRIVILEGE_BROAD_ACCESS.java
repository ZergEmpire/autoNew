package integration.java8;

import java.security.AccessController;
import java.security.PrivilegedAction;

public class JAVA_PRIVILEGE_BROAD_ACCESS {

    public final void test(final PrivilegedAction<Integer> action) {
        AccessController.doPrivileged(action); //@ JAVA_PRIVILEGE_BROAD_ACCESS-e23a23
        AccessController.getContext(); //@ JAVA_PRIVILEGE_BROAD_ACCESS-e23a23
    }

    private void testP(final PrivilegedAction<Integer> action) {
        AccessController.doPrivileged(action);
        AccessController.getContext();
    }
}
