package integration.java8;

import javax.servlet.http.Cookie;

public class JAVA_TIMING_ATTACK {
    private boolean requestContainsWebGoatCookie(Cookie[] cookies, String sessionId) {
        if (cookies != null) {
            for (Cookie c : cookies) {

                if (c.getName().equals("JSESSIONID")) {
                    return true;
                }

                if (c.getName().equals(sessionId)) { //@ JAVA_TIMING_ATTACK-cc081a
                    return true;
                }
            }
        }
        return false;
    }
}

