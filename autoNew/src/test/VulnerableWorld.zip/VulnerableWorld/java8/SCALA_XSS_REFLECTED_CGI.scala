package integration.java8

import java.io.InputStream
import java.net.ServerSocket
import scala.io.Source.fromInputStream

object SCALA_XSS_REFLECTED_CGI  {

  val serverSocket: ServerSocket = new ServerSocket() //@ JAVA_J2EE_SOCKETS-34473d
  val stream: InputStream = FLAG_WEB.WEB_chp0rr(serverSocket)
  val webTaintedString: String = fromInputStream(stream).mkString;

  println(webTaintedString) //@ SCALA_XSS_REFLECTED_CGI-rnr005

  print(webTaintedString) //@ SCALA_XSS_REFLECTED_CGI-rnr005
  val x = "dasd"

  println(x) //@ SCALA_XSS_REFLECTED_CGI-rnr005
}

private object Hello2 {


  println(SCALA_XSS_REFLECTED_CGI.webTaintedString) //@ SCALA_XSS_REFLECTED_CGI-rnr006

  print(SCALA_XSS_REFLECTED_CGI.webTaintedString) //@ SCALA_XSS_REFLECTED_CGI-rnr006
}
