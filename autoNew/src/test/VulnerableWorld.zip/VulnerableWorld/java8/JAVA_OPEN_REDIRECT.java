package integration.java8;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JAVA_OPEN_REDIRECT {
    private static final Pattern mUrlPattern = Pattern.compile("pattern");

    private String getUrl(String pUrl) throws IOException {
        Matcher matcher = this.mUrlPattern.matcher(pUrl);
        return matcher.matches() ? matcher.group(1) + matcher.group(3) : "/";
    }

    public void OPEN_REDIRECT(HttpServletRequest pRequest, HttpServletResponse pResponse) throws IOException {
        String requestURI = pRequest.getRequestURI();
        String url = getUrl(requestURI);

        pResponse.sendRedirect(url); //@ JAVA_OPEN_REDIRECT-73a862,JAVA_ESAPI_DEPRECATED-94fc09
    }
}
