package integration.java8

object SCALA_DIVISION_BY_ZERO {
    def ttt(): Int = {
        val a = 5
        return a / 0 //@ SCALA_DIVISION_BY_ZERO-jdbzd
    }
}
