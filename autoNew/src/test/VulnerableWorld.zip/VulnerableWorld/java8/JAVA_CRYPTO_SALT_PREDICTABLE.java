package integration.java8;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class JAVA_CRYPTO_SALT_PREDICTABLE {

    public byte[] bad() throws NoSuchAlgorithmException, UnsupportedEncodingException
    {
            Random random = new Random();
            MessageDigest hash = MessageDigest.getInstance("SHA-512");
            /* FLAW: SHA512 with a predictable salt */
            hash.update((Integer.toString(random.nextInt())).getBytes("UTF-8")); //@ JAVA_CRYPTO_SALT_PREDICTABLE-saltp1,JAVA_CRYPTO_BAD_RANDOM-c7b353
            return hash.digest("hash me".getBytes("UTF-8"));

    }
}
