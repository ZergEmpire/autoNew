package integration.java8;

import java.io.IOException;
import java.rmi.server.LogStream;
import java.util.Random;
import java.util.stream.IntStream;
import javax.swing.JEditorPane;

public class JAVA_CRYPTO_BAD_SEED {
    LogStream logStream = null;

    public void CRYPTO_BAD_SEED() {
        Random r  = new Random(260379); //@ JAVA_CRYPTO_BAD_SEED-12a33a

        r.setSeed(20); //@ JAVA_CRYPTO_BAD_SEED-810925,JAVA_CRYPTO_BAD_RANDOM-c7b353

        IntStream stream = r.ints(25, 34, 34); //@ JAVA_CRYPTO_BAD_RANDOM-c7b353,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_BAD_SEED-ikene2

        IntStream stream2 = r.ints(25, 34); //@ JAVA_CRYPTO_BAD_SEED-tkene2,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_BAD_RANDOM-c7b353
    }



    public static String createPasswordReset(String username, String key) throws IOException {
        Random random = new Random();
        if (username.equalsIgnoreCase("admin")) { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97

            random.setSeed(key.length()); //@ JAVA_CRYPTO_BAD_RANDOM-c7b353,JAVA_CRYPTO_BAD_SEED-c0a33a
        }
        JEditorPane pane = new JEditorPane(key); //@ JAVA_XSS_REFLECTED-42232f,JAVA_BACKDOOR_DEAD_CODE-d27d09
        return "";
    }



    public static void main (String[] args) {
        String username = args[0]; //@ JAVA_J2EE_DEBUG_CODE-514398,JAVA_ERROR_HANDLING_EMPTY_CATCH-05aea7
        String key = args[1];
        try {
            createPasswordReset(username, key);
        }
        catch (IOException exc) {}

    }
}
