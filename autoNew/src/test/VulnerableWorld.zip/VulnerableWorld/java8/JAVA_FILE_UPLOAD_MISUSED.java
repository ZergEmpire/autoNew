package integration.java8;

import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import java.io.IOException;
import java.net.ServerSocket;

public class JAVA_FILE_UPLOAD_MISUSED {
    public void FILE_UPLOAD_MISUSED(ServerSocket server, FileItemFactory fileItemFactory) throws IOException{

        ServletFileUpload fileUpload = new ServletFileUpload((FileItemFactory) fileItemFactory.createItem(FLAG_WEB.WEB_chp0rr(server).toString(), "contentType", true, "name")); //@ JAVA_FILE_UPLOAD_MISUSED-9b1083,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
