package integration.java8

import org.owasp.esapi.Encoder

class KOTLIN_ENCODING_MISUSED {

    fun encodeForJavaScript(encoder: Encoder, s: String): String {
        return encoder.encodeForJavaScript(s) //@ KOTLIN_ENCODING_MISUSED-9e310d

    }
}