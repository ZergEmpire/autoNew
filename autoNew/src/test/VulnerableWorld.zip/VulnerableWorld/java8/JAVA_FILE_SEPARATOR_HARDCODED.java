package integration.java8;

import java.io.File;

public class JAVA_FILE_SEPARATOR_HARDCODED {
    private void bad1(){
        String a = "/a/b/c";
        File file = new File(a); //@ JAVA_FILE_SEPARATOR_HARDCODED-52kd79,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    private void bad2(){
        String a = "/a/b/c";
        File file = new File("as", a); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_FILE_SEPARATOR_HARDCODED-53kd79
    }

    private void good1(){
        String a = "https://www.google.com/";
        File file = new File(request(a)); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    private String request(String url) {
        return String.valueOf(url.length());
    }
}
