package integration.java8;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.server.LogStream;
import java.util.Locale;

@Slf4j
public class JAVA_LOGGING_LOG_FORGING { //@ JAVA_LOGGING_LOGGER_NOT_STATIC_FINAL-6938a1

    private LocaleResolver localeResolver;

    public void testPrintSafe(PrintWriter pw, String input1, HttpServletRequest req) throws IOException {
        LogStream logStream = null;
        input1 = FLAG_FILE_SYSTEM.FILE_SYSTEM_PROPERTIES_READER().toString();

        pw.print("".equals(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.print(Double.parseDouble(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.print(Integer.parseInt(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.print(Float.parseFloat(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.print(Long.parseLong(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.print("SAFE AGAIN");
        pw.print((Object) "SAFE SAFE SAFE");

        pw.println("".equals(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.println(Double.parseDouble(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.println(Integer.parseInt(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.println(Float.parseFloat(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.println(Long.parseLong(input1)); //@ JAVA_INFORMATION_LEAK_INTERNAL-vnrejr

        pw.println("SAFE AGAIN");
        pw.println((Object) "SAFE SAFE SAFE");

        logStream.println(input1); //@ JAVA_LOGGING_LOG_FORGING-1545a2,JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_NULL_DEREFERENCE-66jnpd

        System.out.println(input1); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_INFORMATION_LEAK_INTERNAL-vnrejr,JAVA_XSS_REFLECTED_CGI-rnr008
    }

    public void testLog(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String user = (String) session.getAttribute("user");
        String user2 = request.getParameter("user");

        log.error("text" + user); //@ JAVA_LOGGING_LOG_FORGING-abb449

        log.error(user + "text"); //@ JAVA_LOGGING_LOG_FORGING-abb449

        log.error("text" + user2); //@ JAVA_LOGGING_LOG_FORGING-abb449

        log.error(user2 + "text"); //@ JAVA_LOGGING_LOG_FORGING-abb449

        log.error("text" + session.getAttribute("user2") + "text"); //@ JAVA_LOGGING_LOG_FORGING-abb449

        log.error("text" + request.getParameter("user2") + "text"); //@ JAVA_LOGGING_LOG_FORGING-abb449
    }

    @GetMapping(path = "URL_LABELS_MVC", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public void fetchLabels(@RequestParam(value = "lang", required = false) String lang,
                        HttpServletRequest request) {
        if (!StringUtils.isEmpty(lang)) {
            Locale locale = Locale.forLanguageTag(lang);
            ((SessionLocaleResolver)localeResolver).setDefaultLocale(locale);

            log2.debug("Language provided: {} leads to Locale: {}", lang, locale); //@ JAVA_LOGGING_LOG_FORGING-logfor
        }
    }

    private static org.apache.log4j.Logger log = Logger.getLogger(JAVA_LOGGING_LOG_FORGING.class);
    private static final org.slf4j.Logger log2 =
            org.slf4j.LoggerFactory.getLogger(JAVA_LOGGING_LOG_FORGING.class);
}
