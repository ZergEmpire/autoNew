package integration.java8;

import org.owasp.esapi.Encoder;

public class JAVA_ENCODING_MISUSED {

    public void encodeForJavaScript(Encoder encoder, String s) {
        encoder.encodeForJavaScript(s); //@ JAVA_ENCODING_MISUSED-9e310d
        encoder.encodeForVBScript(s); //@ JAVA_ENCODING_MISUSED-9e310d
    }
}
