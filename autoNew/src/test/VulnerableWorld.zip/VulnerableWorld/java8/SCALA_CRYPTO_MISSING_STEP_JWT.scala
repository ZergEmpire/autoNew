package integration.java8

import com.auth0.jwt.JWT
import com.auth0.jwt.JWTVerifier
import com.auth0.jwt.algorithms.Algorithm
import com.auth0.jwt.interfaces.DecodedJWT
import java.io.UnsupportedEncodingException


class SCALA_CRYPTO_MISSING_STEP_JWT {
  @throws[UnsupportedEncodingException]
  def verificationAuth0(token: String): Unit = {
    val algorithm = Algorithm.HMAC256("secret") //@ SCALA_CRYPTO_KEY_HARDCODED_JWT-jwtalg
    val verifier = JWT.require(algorithm).withIssuer("auth0").build
    val jwt = verifier.verify(token)
    jwt.getClaims
    jwt.getClaim("claim")
  }

  @throws[UnsupportedEncodingException]
  def verificationWithAlgorithmAuth0(token: String): Unit = {
    val algorithm = Algorithm.HMAC256("secret") //@ SCALA_CRYPTO_KEY_HARDCODED_JWT-jwtalg
    val jwt = JWT.decode(token)
    algorithm.verify(jwt)
    jwt.getClaims
    jwt.getClaim("claim")
  }

  def noVerificationAuth0(token: String): Unit = {
    val jwt = JWT.decode(token)
    jwt.getClaims //@ SCALA_CRYPTO_MISSING_STEP_JWT-jwmsfn

    jwt.getClaim("claim") //@ SCALA_CRYPTO_MISSING_STEP_JWT-jwmsfn
  }
}
