package integration.java8

import org.springframework.web.bind.annotation.RequestParam
import java.sql.DriverManager
import java.sql.SQLException

class KOTLIN_INJECTION_SQL_PARAMETER_TAMPERING {
    fun parameterTampering(@RequestParam username_login: String) {
        try {
            val connection = DriverManager.getConnection("url") //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,KOTLIN_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            val prpStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?") //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            prpStmnt.setString(1, username_login)
            prpStmnt.executeQuery() //@ KOTLIN_INJECTION_SQL_PARAMETER_TAMPERING-fkergm
        } catch (e: SQLException) {
            throw RuntimeException(e)
        }

    }

    fun noParameterTampering(@RequestParam username_login: String) {
        try {
            val connection = DriverManager.getConnection("url") //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,KOTLIN_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            val prpStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?") //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            prpStmnt.setString(0, "login")
            prpStmnt.executeQuery()
            val prpStmnt2 = connection.prepareStatement("SELECT * FROM users WHERE name = ? and password = ?")
            prpStmnt2.setString(0, username_login)
            prpStmnt2.setString(1, "abc")
            prpStmnt2.executeQuery()
        } catch (e: SQLException) {
            throw RuntimeException(e)
        }
    }
}