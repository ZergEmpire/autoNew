package integration.java8;

import com.hazelcast.config.SymmetricEncryptionConfig;

import java.security.KeyStore;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import javax.crypto.spec.PBEKeySpec;
import javax.security.auth.callback.PasswordCallback;

public class JAVA_PASSWORD_HARDCODED {
    private static String PWD1 = "khvfcd"; //@ JAVA_PASSWORD_HARDCODED-twgk4w
    private static char[] PWD2 = {'s', 'e', 'c', 'r', 'e', 't', '5'};
    private char[] PWD3 = {'s', 'e', 'c', 'r', 'e', 't', '5'};
    private String password;
    public void bad6(PasswordCallback callback, String password) throws Exception {
        String pwdStr = "secret6"; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae,JAVA_PASSWORD_HARDCODED-8ce2fb
        char[] pwd1 = pwdStr.toCharArray();
        char[] pwd2 = pwd1;

        Connection connection2 = DriverManager.getConnection("string", "string", pwdStr); //@ JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_PASSWORD_HARDCODED-c0d242,JAVA_MISSING_AUTHORIZATION-kts455

        callback.setPassword(pwd2); //@ JAVA_PASSWORD_HARDCODED-twgk4k,JAVA_PASSWORD_HARDCODED-frekws

        byte[] bytes = new byte[2]; //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        char[] pwd = "secret7".toCharArray();

        new PBEKeySpec(pwd); //@ JAVA_PASSWORD_HARDCODED-d1tt65

        KeyStore.PasswordProtection protection = new KeyStore.PasswordProtection(pwd); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PASSWORD_HARDCODED-awer88

        Connection conn = DriverManager.getConnection("jdbc:mysql://prod.company.com/production"); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d
        Properties properties = new Properties();

        conn = DriverManager.getConnection("url:passwd=dhjsbdj", properties); //@ JAVA_GETCONNECTION-d0810d,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_PASSWORD_HARDCODED-d59fa1

        SymmetricEncryptionConfig symmetricEncryptionConfig = new SymmetricEncryptionConfig();
        symmetricEncryptionConfig.setPassword("lamepassword"); //@ JAVA_PASSWORD_HARDCODED-setpwd
        setPassword("adlf,vdfv"); //@ JAVA_PASSWORD_HARDCODED-setpwd
    }
    public class Foo {

        private static final String password = "secret4"; //@ JAVA_PASSWORD_HARDCODED-twgk4w,JAVA_PRIVACY_VIOLATION_HEAP-heapin
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
