package integration.java8;

import android.net.SSLCertificateSocketFactory;
import android.net.SSLSessionCache;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

public class ANDROID_SSL_SOCKET {

    public void test(SSLCertificateSocketFactory factory, SSLSessionCache cache, InetAddress address, Socket socket) throws IOException
    {
        SSLCertificateSocketFactory.getInsecure(1, cache); //@ ANDROID_SSL_SOCKET-33baac
        factory.createSocket(address, 1); //@ ANDROID_SSL_SOCKET-63144e
        factory.createSocket(address, 1, address, 1); //@ ANDROID_SSL_SOCKET-63144e

        factory.createSocket();
        factory.createSocket(socket, "string", 1, true);
        factory.createSocket("string", 1);
    }
}
