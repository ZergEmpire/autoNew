package integration.java8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class ANDROID_NO_PERMISSION_BROADCASTER {

    public void test(
        Context context,
        Intent intent,
        BroadcastReceiver broadcastReceiver,
        Handler handler,
        Bundle bundle)
    {
        context.sendBroadcast(intent); //@ ANDROID_NO_PERMISSION_BROADCASTER-cfd7ed
        context.sendBroadcast(intent, "string");
        context.sendOrderedBroadcast(intent, "string");
        context.sendOrderedBroadcast(intent, "string", broadcastReceiver, handler, 1, "string", bundle);
    }
}
