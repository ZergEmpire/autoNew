package integration.java8;

import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class JAVA_CRYPTO_KEY_REUSED {

    public void bad1(boolean condition) throws Exception {
        String cryptographicKey = ""; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        byte[] key = cryptographicKey.getBytes();

        if (condition) {
            PKCS8EncodedKeySpec pkcs8EncodedKeySpec2 = new PKCS8EncodedKeySpec(key); //@ JAVA_CRYPTO_KEY_EMPTY-bvnc14
        } else {
            X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_EMPTY-bvnc13
        }
        bad2(key);
    }

    public void bad2(byte[] key) {
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_EMPTY-bvnc14,JAVA_CRYPTO_KEY_REUSED-kda765
        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_EMPTY-bvnc13,JAVA_CRYPTO_KEY_REUSED-kda765
    }
}
