package integration.java8;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;



public class F01FlagsIfElse {
    String name = "myName";

    public static void main(String[] args) throws IOException {
        URLConnection connection = null; //@ JAVA_J2EE_DEBUG_CODE-514398
        String className;
        String otherClassName = "name";
        byte[] buffer = new byte[256];

        try {
            connection = new URL("url").openConnection(); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e
        } catch (IOException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
        connection.setRequestProperty("Accept-Charset", "1"); //@ JAVA_NULL_DEREFERENCE_ON_SOME_PATH-j11nd2

        InputStream response = connection.getInputStream();

        if (response.read(buffer) == 0) {

            className = new String(buffer, StandardCharsets.UTF_8);
        } else {
            className = "name";

            otherClassName = new String(buffer, StandardCharsets.UTF_8);
        }
        try {

            Class cls = Class.forName(className); //@ JAVA_REFLECTION-118f4c

            ClassLoader cLoader = cls.getClassLoader(); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-90a90d

            if (cLoader == null) {
                System.out.println("The default system class was used."); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

                cls = Class.forName(otherClassName); //@ JAVA_REFLECTION-118f4c

                Class[] loaderClass = cls.getClasses(); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-90a90d

                System.out.println("Class associated with ClassLoader = " + //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
                        loaderClass.getClass().getClassLoader()); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-90a90d
            } else {

                Class[] loaderClass = cls.getClasses(); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-90a90d

                System.out.println("Class associated with ClassLoader = " + //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_XSS_REFLECTED_CGI-rnr008
                        loaderClass.getClass().getClassLoader()); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-90a90d
            }
        } catch (ClassNotFoundException e) {

            System.out.println(className); //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }
    }
}

