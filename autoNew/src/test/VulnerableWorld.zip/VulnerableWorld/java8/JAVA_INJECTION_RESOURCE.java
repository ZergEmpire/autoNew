package integration.java8;

import com.google.gwt.user.client.ResponseTextHandler;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.net.*;
import java.util.Arrays;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JAVA_INJECTION_RESOURCE {
    public void INJECTION_RESOURCE(ServerSocket socket, URLStreamHandlerFactory factory) throws IOException{
        try {

            URL url1 = new URL(FLAG_WEB.WEB_chp0rr(socket).toString()); //@ JAVA_INJECTION_RESOURCE-08999d,JAVA_BACKDOOR_DEAD_CODE-d27d09
        } catch (MalformedURLException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }
}

abstract class Test3 implements ContentHandler {
    @Override
    public void characters(
        char[] ch,
        int start,
        int length) throws SAXException
    {
        URL taintUrl = null;
        try {
            taintUrl = new URL(Arrays.toString(ch)); //@ JAVA_INJECTION_RESOURCE-08999d
            taintUrl.openConnection();
        } catch (IOException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }
}

class Test4 implements ResponseTextHandler {
    @Override
    public void onCompletion(String s)
    {
        try {
            URL taintUrl = new URL(s); //@ JAVA_INJECTION_RESOURCE-08999d, JAVA_BACKDOOR_DEAD_CODE-d27d09
        } catch (IOException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }
}

class Test5 extends Action {
    @Override
    public ActionForward execute(
        final ActionMapping mapping,
        final ActionForm form,
        final HttpServletRequest request,
        final HttpServletResponse response) throws Exception
    {
        URL taintUrl = new URL(form.toString()); //@ JAVA_INJECTION_RESOURCE-08999d, JAVA_BACKDOOR_DEAD_CODE-d27d09
        return super.execute(mapping, form, request, response);
    }
}
