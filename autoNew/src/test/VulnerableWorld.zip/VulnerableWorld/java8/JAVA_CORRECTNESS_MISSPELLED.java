package integration.java8;

public class JAVA_CORRECTNESS_MISSPELLED {

    public boolean equal(Object obj) {

        return super.equals(obj); //@ JAVA_CORRECTNESS_NO_EQUALS-aafc76,JAVA_CORRECTNESS_MISSPELLED-458c01
    }

    public int hashCode(int i) {
        return i; //@ JAVA_CORRECTNESS_MISSPELLED-23ad55
    }
}
