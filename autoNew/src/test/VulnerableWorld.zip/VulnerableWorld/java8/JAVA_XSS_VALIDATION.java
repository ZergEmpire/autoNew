package integration.java8;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.List;
import java.util.Properties;

import org.apache.commons.text.StringEscapeUtils;
import org.apache.ecs.html.TD;
import org.apache.ecs.html.TR;
import org.apache.ecs.html.H1;
import org.apache.ecs.html.HR;
import org.apache.ecs.html.P;
import org.apache.ecs.ElementContainer;
import org.eclipse.jetty.server.NetworkConnector;
import org.eclipse.jetty.server.Server;

public class JAVA_XSS_VALIDATION {
    public final static String __message =
            "0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 0123456789 \n"+
                    "9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 9876543210 \n"+
                    "1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 1234567890 \n"+
                    "0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 0987654321 \n"+
                    "abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz \n"+
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ \n"+
                    "Now is the time for all good men to come to the aid of the party.\n"+
                    "How now brown cow.\n"+
                    "The quick brown fox jumped over the lazy dog.\n";
    private static Server _server;

    public void dsfdf(HttpServletRequest tra, ServletOutputStream out, List<String> result) throws Exception{
        Socket socket = new Socket("127.0.0.1",((NetworkConnector)_server.getConnectors()[0]).getLocalPort()); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_J2EE_SOCKETS-34473d
        byte[] buf;
        buf = tra.getRequestURI().toString().getBytes();

        out.write(buf); //@ JAVA_XSS_VALIDATION-0a4130
    }
    static public void XSS_VALIDATION_e079da (HttpServletRequest request, OutputStream outPut) throws IOException {

        String URI = request.getRequestURI();

        outPut.write(URI.getBytes());
    }
    static public void XSS_VALIDATION_ec74ae (HttpServletRequest request, HttpServletResponse response) throws IOException {

        String input1 = request.getParameter("input1");

        response.getWriter().write(input1); //@ JAVA_XSS_REFLECTED-9b81d9

        response.getWriter().write(StringEscapeUtils.escapeHtml3(input1)); //@ JAVA_XSS_VALIDATION-4e647a
        TR tr = new TR();

        tr.addElement(new TD(input1)); //@ JAVA_XSS_REFLECTED-a00666

        tr.addElement(new TD("password"));


        ElementContainer ec3 = new ElementContainer();
        ec3.addElement(new H1().addElement("Original Website Text2"));
        ec3.addElement(new HR());
        ec3.addElement(new H1().addElement("Defaced Website Text2"));

        ec3.addElement(new P().addElement(StringEscapeUtils.escapeHtml3(input1))); //@ JAVA_XSS_VALIDATION-b00777
        ec3.addElement(new HR());
    }
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String param = request.getParameter("BenchmarkTest00375");
        if (param == null) param = "";

        FileInputStream a = new FileInputStream("~/Documents/"); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

        Properties b = new Properties();

        b.load(a);
        Object[] obj_ = { b };

        String bar = "";

        if (param != null) bar = param.split(" ")[0];
        response.setHeader("X-XSS-Protection", "0");

        response.getWriter().format(java.util.Locale.US,response.encodeRedirectURL(bar),obj_); //@ JAVA_INFORMATION_LEAK_EXTERNAL-f9ba68,JAVA_XSS_PERSISTENT-99c3d5,JAVA_XSS_REFLECTED-99c3d2,JAVA_ESAPI_DEPRECATED-94fc09
        Object[] obj = {'a','b'};

        response.getWriter().format(java.util.Locale.US , request.getRequestURL().toString(),obj); //@ JAVA_XSS_VALIDATION-99c3d6

        response.getWriter().printf(java.util.Locale.US, request.getRequestURL().toString(), obj); //@ JAVA_XSS_VALIDATION-99c3d6
        int num = 106;
        bar = (7*42) - num > 200 ? "This should never happen" : param;
        response.setHeader("X-XSS-Protection", "0");
        Object[] obj__ = { request.getRequestURL().toString() , bar };

        response.getWriter().format("Formatted like: %1$s and %2$s.",obj__); //@ JAVA_XSS_VALIDATION-99c3d8


        bar = "alsosafe";
        String bar_ = "alsosafe";

        if (param != null) {
            java.util.List<String> valuesList = new java.util.ArrayList<String>( );
            valuesList.add("safe");
            valuesList.add( param );
            valuesList.add( "moresafe" );

            valuesList.remove(0);

            bar = valuesList.get(0);
            bar_ = valuesList.get(1);
        }


        response.setHeader("X-XSS-Protection", "0");
        Object[] obj01 = { request.getRequestURL().toString(), bar };
        Object[] obj02 = { request.getRequestURL().toString(), bar_ };

        response.getWriter().format("Formatted like: %1$s and %2$s.",obj01); //@ JAVA_XSS_VALIDATION-99c3d8

        response.getWriter().format("Formatted like: %1$s and %2$s.",obj02); //@ JAVA_XSS_VALIDATION-99c3d8


        String a2196 = param;
        StringBuilder b2196 = new StringBuilder(a2196);
        b2196.append(" SafeStuff");
        b2196.replace(b2196.length()-"Chars".length(),b2196.length(),"Chars");
        java.util.HashMap<String,Object> map2196 = new java.util.HashMap<String,Object>();
        String a_ = "key2196";
        String b_ = "key124154";
        map2196.put(a_, b2196.toString());
        java.util.HashMap<String,Object> map2197 = new java.util.HashMap<String,Object>();

        String c = "afafqe";

        Object[] obj03 = { request.getRequestURL().toString(), bar_ };
        map2197.put(c, obj03);
        String c2197 = (String)map2197.get(c);

        response.getWriter().printf(java.util.Locale.US,c2197,obj); //@ JAVA_XSS_VALIDATION-99c3d6
    }
}
