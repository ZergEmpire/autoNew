package integration.java8;

import java.sql.Connection;
import java.sql.DriverManager;

public class JAVA_MISSING_AUTHORIZATION{

	public void test() {
		try{
			String url = "jdbc:mysql://localhost/store";//@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
			String username = "root";
			String password = "password";//@ JAVA_PRIVACY_VIOLATION_HEAP-heapin, JAVA_PASSWORD_HARDCODED-8ce2fb
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();//@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-8981f6
			try (Connection conn = DriverManager.getConnection(url, username, password)){//@ JAVA_MISSING_AUTHORIZATION-kts455, JAVA_GETCONNECTION-d0810d, JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7, JAVA_PASSWORD_HARDCODED-c0d242

				System.out.println("Connection to Store DB succesfull!");//@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
			}
		}
		catch(Exception ex){
			System.out.println("Connection failed...");//@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
			System.out.println(ex);//@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
		}
	}
}