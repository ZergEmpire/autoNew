package integration.java8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.logging.Logger;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

public class JAVA_INFORMATION_LEAK_INTERNAL extends HttpServlet {
    public static void INFORMATION_LEAK_INTERNAL()
    {
        Logger logger = Logger.getLogger("pathcompanion");
        int totalMem = 0;
        NumberFormat nf = NumberFormat.getInstance(Locale.US);

        logger.info("** Total:  " + nf.format(totalMem / 1024. / 1024. / 1024.) + //@ JAVA_INFORMATION_LEAK_INTERNAL-d353dc
                    " GB (low-mem limit " +
                    Runtime.getRuntime().maxMemory() + "GB)");

        long mem = Runtime.getRuntime().maxMemory();

        logger.info("** Total:  " + nf.format(totalMem / 1024. / 1024. / 1024.) + //@ JAVA_INFORMATION_LEAK_INTERNAL-d353dc
                    " GB (low-mem limit " + mem * 0.75 / 1024. / 1024. / 1024. + "GB)");
        InputStream in = null;
        try {
            in = new FileInputStream("name"); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1,JAVA_BACKDOOR_DEAD_CODE-d27d09
        } catch (FileNotFoundException e) {

            System.out.println(e); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_INFORMATION_LEAK_INTERNAL-vnrejr
        }
    }

    public static void INFORMATION_LEAK_INTERNAL_logthr(
        org.apache.log4j.Logger logger,
        HttpServletRequest request)
    {
        logger.debug(FLAG_SYSTEM_INFO.SYSTEM_INFO_e202c6(request)); //@ JAVA_INFORMATION_LEAK_INTERNAL-8e3fcb,JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        try {
            request.changeSessionId();
        } catch (Throwable thr) {
            logger.error("message", thr); //@ JAVA_INFORMATION_LEAK_INTERNAL-logthr
        }
    }

    public void INFORMATION_LEAK_INTERNAL_9576b0(
        HttpServletRequest request,
        org.slf4j.Logger logger)
    {
        try {
            request.changeSessionId(); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        } catch (Throwable thr) {
            thr.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            log(request, thr.getMessage(), logger);
        }
    }

    public void log(
        HttpServletRequest request,
        String message,
        org.slf4j.Logger logger)
    {
        try {
            request.changeSessionId(); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        } catch (Exception thr) {
            thr.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            logger.debug(message); //@ JAVA_INFORMATION_LEAK_INTERNAL-b86021
            logger.error("Error while loading:", thr); //@ JAVA_INFORMATION_LEAK_INTERNAL-logerr
        }
    }
}
