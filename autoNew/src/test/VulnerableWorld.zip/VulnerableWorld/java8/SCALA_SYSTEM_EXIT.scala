package integration.java8

class SCALA_SYSTEM_EXIT {
  def test(): Unit = {
    System.exit(1) //@ SCALA_SYSTEM_EXIT-d8ae59

  }

  def test1(): Unit = {
    Runtime.getRuntime.exit(1) //@ SCALA_SYSTEM_EXIT-d8ae59

  }

  def test2(): Unit = {
    val runtime = Runtime.getRuntime
    val x = 666
    runtime.exit(1) //@ SCALA_SYSTEM_EXIT-d8ae59
  }
}
