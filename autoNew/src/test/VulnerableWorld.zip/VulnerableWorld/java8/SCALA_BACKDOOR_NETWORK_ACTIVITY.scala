package integration.java8

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.stream.ActorMaterializer

import scala.sys.process._

class SCALA_BACKDOOR_NETWORK_ACTIVITY {
  def backdoor: Unit = {
    new java.net.URL("https://www.scala-lang.org") #> new java.io.File("fixed.html") ! //@ SCALA_BACKDOOR_NETWORK_ACTIVITY-sbna00
  }

  def method {
    implicit val system: ActorSystem = ActorSystem()
    implicit val mat: ActorMaterializer = ActorMaterializer()

    val commonRoutes = null

    Http().bindAndHandle(commonRoutes, "8.8.8.8", 9090) //@ SCALA_BACKDOOR_NETWORK_ACTIVITY-sbna01

    Http().bindAndHandle(commonRoutes, "localhost", 9090)
  }
}
