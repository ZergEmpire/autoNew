package integration.java8

import java.sql.{Connection, DriverManager, PreparedStatement, SQLException}

import org.springframework.web.bind.annotation.RequestParam

class SCALA_INJECTION_SQL_PARAMETER_TAMPERING {

  def parameterTampering(@RequestParam username_login: String): Unit = {
    try {
      val connection = DriverManager.getConnection("url") //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,SCALA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
      val prpStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?") //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
      prpStmnt.setString(1, username_login)
      prpStmnt.executeQuery //@ SCALA_INJECTION_SQL_PARAMETER_TAMPERING-fkergm
    } catch {
      case e: SQLException =>
        throw new RuntimeException(e)
    }
  }

  def noParameterTampering(@RequestParam username_login: String): Unit = {
    try {
      val connection = DriverManager.getConnection("url") //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,SCALA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
      val prpStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?") //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
      prpStmnt.setString(0, "login")
      prpStmnt.executeQuery
      val prpStmnt2 = connection.prepareStatement("SELECT * FROM users WHERE name = ? and password = ?")
      prpStmnt2.setString(0, username_login)
      prpStmnt2.setString(1, "abc")
      prpStmnt2.executeQuery
    } catch {
      case e: SQLException =>
        throw new RuntimeException(e)
    }
  }
}
