package integration.java8

import io.ktor.auth.*
import io.ktor.util.decodeBase64
import io.ktor.util.getDigestFunction
import java.security.MessageDigest

fun main(vararg args: String) {

    val userTable = UserHashedTableAuth(getDigestFunction("MD5", salt = "ktor"), mapOf( //@ JAVA_J2EE_DEBUG_CODE-514398,KOTLIN_CRYPTO_SALT_HARDCODED-weeedd,KOTLIN_CRYPTO_BAD_HASH-ww8fdd,JAVA_BACKDOOR_DEAD_CODE-d27d09
            "test" to decodeBase64("VltM4nfheqcJSyH887H+4NEOm2tDuKCl83p5axYXlF0=")
    ))

    val res = AuthenticationPipeline().digestAuthentication(digestAlgorithm="SHA1", //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_CRYPTO_BAD_HASH-rk877d
            userNameRealmPasswordDigestProvider = { s, s1 ->  byteArrayOf(s.toByte(), s1.toByte())})

    val md2Digest = MessageDigest.getInstance("MD2") //@ KOTLIN_CRYPTO_BAD_HASH-b11hs4
    md2Digest.update("123".toByteArray())
    md2Digest.digest()
}
