package integration.java8;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import javax.crypto.spec.SecretKeySpec;

public class JAVA_BACKDOOR_SPECIAL_ACCOUNT {

    private static final String weakAntiCSRF = "2aa14227b9a13d0bede0388a7fba9aa9";

    private final ConcurrentMap<String, String> map = new ConcurrentHashMap<>();

    private void test(String a, String b, String c, int passwordi, Integer passwordt) throws UnsupportedEncodingException {
        String password1 = ""; //@ JAVA_PASSWORD_EMPTY-76458b
        String password2 = ""; //@ JAVA_PASSWORD_EMPTY-76458b
        String password3 = ""; //@ JAVA_PASSWORD_EMPTY-76458b

        if (passwordi == 123) { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97
            a += 1;
        }

        if (123 == passwordi) { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97
            a += 1;
        }

        if (123 == passwordt) { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97
            a += 1;
        }

        if (password2.equals("ASDFEWCwesxax")) { //@ JAVA_PASSWORD_HARDCODED-8ce2fb,JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97
            a += 1;
        }

        if (c.equals(password3)) { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97, JAVA_TIMING_ATTACK-cc081a
            a += 1;
        }


        if (a == "0123456789abbabacabc0123456789ab") { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97, JAVA_CORRECTNESS_STRING_COMPARE-j11cs1
            a += "0123456789abbabacabc0123456789ab";
        }

        String fd = "0123456789abbabacabc0123456789ab";
        if ("0123456789abbabacabc0123456789ab".equals(a)) { //@ JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97
            a += 3;
        }

        boolean vbs = a.equals("0123456789abbabacabc0123456789ab"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_BACKDOOR_SPECIAL_ACCOUNT-62dd97

        final String payload = "0297b5eb43e3b81f9c737b353c3ade45";
        final SecretKeySpec secretKeySpec = new SecretKeySpec("ABCDEFGHABCDEFGH".getBytes("UTF-8"), "AES"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_HARDCODED-bvnc02

        boolean dfge = password1.contains(password2); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    private void map(String b) {
        final String login = "@#$";
        final String password = b; //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        if (map.get(login).equals(password)) { //@ JAVA_TIMING_ATTACK-cc081a
            boolean dfge = false;
        }
    }
}
