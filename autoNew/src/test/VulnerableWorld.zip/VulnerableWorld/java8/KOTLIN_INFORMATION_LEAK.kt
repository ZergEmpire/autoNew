package integration.java8

fun informationLeak(exception: Throwable) {

    println("system_info") //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

    error(exception)
}
