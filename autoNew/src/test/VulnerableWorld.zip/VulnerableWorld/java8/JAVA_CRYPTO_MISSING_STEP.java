package integration.java8;

import javax.crypto.KeyGenerator;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.*;
import com.bumptech.glide.load.Key;

public class JAVA_CRYPTO_MISSING_STEP {
    public void notInit() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");

        keyGenerator.generateKey(); //@ JAVA_CRYPTO_MISSING_STEP-5bf092
    }

    public void init() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128);
        keyGenerator.generateKey();
    }

    public void notUpdate() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");

        messageDigest.digest(); //@ JAVA_CRYPTO_MISSING_STEP-5bf093
    }

    public void update() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
        messageDigest.update((byte) 1);
        messageDigest.digest();
    }

    public void builtInUpdate() throws NoSuchAlgorithmException {
        byte b[] = {1, 2};
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
        messageDigest.digest(b);
    }

    public void glidUpdate(final Key key) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        final MessageDigest instance = MessageDigest.getInstance("SHA-256");
        key.updateDiskCacheKey(instance);
        instance.digest();
    }

    public void reinit() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128);
        keyGenerator.generateKey();
        keyGenerator.generateKey(); //@ JAVA_CRYPTO_MISSING_STEP-5bf0h2

        keyGenerator.init(128);
        keyGenerator.generateKey();
    }

    public void reupdate() throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
        messageDigest.update((byte) 1);
        messageDigest.digest();
        messageDigest.digest(); //@ JAVA_CRYPTO_MISSING_STEP-5bfp93

        messageDigest.update((byte) 1);
        messageDigest.digest();
    }

    public void initPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);

        keyGen.generateKeyPair();
    }

    public void notInitPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.generateKeyPair(); //@ JAVA_CRYPTO_MISSING_STEP-5bf099
    }

    public void digestInputStream(InputStream source) throws NoSuchAlgorithmException {
        MessageDigest md5 = MessageDigest.getInstance("SHA-512");
        DigestInputStream in = new DigestInputStream(source, md5); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        md5.digest();
    }
}
