package integration.java8

class SCALA_USE_GETENV {
  scala.sys.env("123") //@ SCALA_USE_GETENV-f9b000
}
