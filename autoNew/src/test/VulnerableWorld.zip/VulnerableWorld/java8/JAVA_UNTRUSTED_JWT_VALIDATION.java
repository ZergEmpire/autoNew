package integration.java8;

import io.jsonwebtoken.Jwts;

import java.security.Key;

public class JAVA_UNTRUSTED_JWT_VALIDATION {
    public void verification(final Key key) {
        Jwts.parser().setSigningKey(key); //@ JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
    }

}


