package integration.java8;

import com.auth0.jwt.algorithms.Algorithm;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.TextCodec;

import java.io.UnsupportedEncodingException;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;

public class JAVA_CRYPTO_KEY_HARDCODED_JWT {

    public static final String JWT_PASSWORD = TextCodec.BASE64.encode("victory");

    public void test() throws UnsupportedEncodingException
    {
        Jwt jwt = Jwts.parser().setSigningKey(JWT_PASSWORD).parse(""); //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwthar, JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
        Claims claims = (Claims) jwt.getBody();
        String user1 = (String) claims.get("user");
            Claims claims1 =
                Jwts.claims().setIssuedAt(Date.from(Instant.now().plus(Duration.ofDays(10)))); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
            claims.put("admin", "false");
            claims.put("user", user1);
            String token = Jwts.builder()
                .setClaims(claims)
                .signWith(io.jsonwebtoken.SignatureAlgorithm.HS512, JWT_PASSWORD) //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwtkey2
                .compact(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        final Algorithm algorithm = Algorithm.HMAC256("secret"); //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwtalg, JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
