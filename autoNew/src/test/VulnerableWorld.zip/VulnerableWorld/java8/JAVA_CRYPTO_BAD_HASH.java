package integration.java8;

import net.jxta.impl.id.binaryID.DigestTool;
import net.jxta.impl.util.JxtaHash;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JAVA_CRYPTO_BAD_HASH {

    public static String encode(String password) {
        ShaPasswordEncoder encoder = new ShaPasswordEncoder(256); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        String encodedPassword = encoder.encodePassword(password, null);
        return encodedPassword;
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {


        MessageDigest md2Digest = MessageDigest.getInstance("MD2"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4,JAVA_J2EE_DEBUG_CODE-514398
        md2Digest.update("123".getBytes());
        md2Digest.digest();


        MessageDigest md5Digest = MessageDigest.getInstance("MD5"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4
        md5Digest.update("123".getBytes());
        md5Digest.digest();


        MessageDigest sha1Digest = MessageDigest.getInstance("SHA"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4
        sha1Digest.update("123".getBytes());
        sha1Digest.digest();


        MessageDigest sha1Digest2 = MessageDigest.getInstance("SHA1"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4
        sha1Digest2.update("123".getBytes());
        sha1Digest2.digest();


        MessageDigest sha1Digest3 = MessageDigest.getInstance("SHA-1"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4
        sha1Digest3.update("123".getBytes());
        sha1Digest3.digest();


        MessageDigest sha256Digest = MessageDigest.getInstance("SHA256");
        sha256Digest.update("123".getBytes());
        sha256Digest.digest();

        MessageDigest sha512Digest = MessageDigest.getInstance(getDigest()); //@ JAVA_CRYPTO_BAD_HASH-b11hs5
        sha512Digest.update("123".getBytes());
        sha512Digest.digest();

        try {
            MessageDigest md = MessageDigest.getInstance("MD5"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4,JAVA_BACKDOOR_DEAD_CODE-d27d09
        } catch (NoSuchAlgorithmException e){
            throw new IllegalStateException(e.getMessage(), e);
        }

        JxtaHash hash1 = new JxtaHash("lolkek"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_CRYPTO_BAD_HASH-ow0002
        JxtaHash hash2 = new JxtaHash(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_CRYPTO_BAD_HASH-ow0002
        DigestTool tool = new DigestTool(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_CRYPTO_BAD_HASH-ow0005

        apacheApiVariations();
    }

    public static void apacheApiVariations() {

        DigestUtils.getMd2Digest().digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs3

        DigestUtils.getMd5Digest().digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs3

        DigestUtils.getDigest("md2").digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs2

        DigestUtils.getDigest("md5").digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs2

        DigestUtils.md2("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs1

        DigestUtils.md5("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs1

        System.out.println(DigestUtils.md2Hex("123".getBytes())); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_CRYPTO_BAD_HASH-b11hs1

        System.out.println(DigestUtils.md5Hex("123".getBytes())); //@ JAVA_CRYPTO_BAD_HASH-b11hs1,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d


        DigestUtils.getSha1Digest().digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs3

        DigestUtils.getShaDigest().digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs3

        DigestUtils.getDigest("sha1").digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs2

        DigestUtils.getDigest("sha-1").digest("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs2

        DigestUtils.sha1("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs1

        DigestUtils.sha("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs1

        DigestUtils.sha1Hex("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs1

        DigestUtils.shaHex("123".getBytes()); //@ JAVA_CRYPTO_BAD_HASH-b11hs1


        DigestUtils.getDigest("sha256").digest("123".getBytes());
        DigestUtils.getDigest(getDigest()).digest("123".getBytes());
    }

    public static void weakDigestMoreSig() throws NoSuchProviderException, NoSuchAlgorithmException {

        MessageDigest.getInstance("MD5", "SUN"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("MD4", "SUN"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("MD2", "SUN"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("MD5"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("MD4"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("MD2"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("SHA", "SUN"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("SHA1", "SUN"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4

        MessageDigest.getInstance("SHA-1", "SUN"); //@ JAVA_CRYPTO_BAD_HASH-b11hs4
        MessageDigest.getInstance("sha-384","SUN");
        MessageDigest.getInstance("SHA-512", "SUN");

        Signature.getInstance("MD5withRSA");
        Signature.getInstance("MD2withDSA", "X");
        Signature.getInstance("SHA256withRSA");
        Signature.getInstance("uncommon name", "");
    }



    public static String getDigest() {
        return "sha512";
    }
    public static class JAVA_TEST extends HttpServlet {
        public static final String testfileDir = System.getProperty("user.dir") + File.separator + "testfiles"
                + File.separator;
        private static final long serialVersionUID = 1L;

        @Override
        public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            javax.servlet.http.Cookie userCookie = new javax.servlet.http.Cookie("BenchmarkTest00003", "someSecret");
            userCookie.setMaxAge(60*3);
            userCookie.setSecure(true);
            userCookie.setPath(request.getRequestURI());
            response.addCookie(userCookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_ESAPI_DEPRECATED-94fc09
            javax.servlet.RequestDispatcher rd = request.getRequestDispatcher("/hash-00/BenchmarkTest00003.html");
            rd.include(request, response);
        }

        @Override
        public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            response.setContentType("text/html;charset=UTF-8");


            javax.servlet.http.Cookie[] theCookies = request.getCookies();

            String param = "noCookieValueSupplied";
            if (theCookies != null) {
                for (javax.servlet.http.Cookie theCookie : theCookies) {
                    if (theCookie.getName().equals("BenchmarkTest00003")) { //@ JAVA_COOKIE_RELIANCE-cokrel
                        param = java.net.URLDecoder.decode(theCookie.getValue(), "UTF-8");
                        break;
                    }
                }
            }


            try {
                java.util.Properties benchmarkprops = new java.util.Properties();
                benchmarkprops.load(this.getClass().getClassLoader().getResourceAsStream("benchmark.properties"));
                String algorithm = benchmarkprops.getProperty("hashAlg1", "SHA512");

                java.security.MessageDigest md = java.security.MessageDigest.getInstance(algorithm); //@ JAVA_CRYPTO_BAD_HASH-b11hs5,JAVA_BACKDOOR_DEAD_CODE-d27d09
                algorithm = "SHA124124";

                md = java.security.MessageDigest.getInstance(algorithm);

                algorithm = "hashalgorithm";
                md = java.security.MessageDigest.getInstance(algorithm); //@ JAVA_CRYPTO_BAD_HASH-b11hs5

                byte[] input = { (byte)'?' };
                Object inputParam = param;
                if (inputParam instanceof String) input = ((String) inputParam).getBytes();
                if (inputParam instanceof java.io.InputStream) {
                    byte[] strInput = new byte[1000];
                    int i = ((java.io.InputStream) inputParam).read(strInput);
                    if (i == -1) {
                        response.getWriter().println(
                                "This input source requires a POST, not a GET. Incompatible UI for the InputStream source."
                        );
                        return;
                    }
                    input = java.util.Arrays.copyOf(strInput, i);
                }
                md.update(input);

                byte[] result = md.digest();
                java.io.File fileTarget = new java.io.File( //@ JAVA_PATH_MANIPULATION-b1b30c
                        new java.io.File(testfileDir),"passwordFile.txt");
                java.io.FileWriter fw = new java.io.FileWriter(fileTarget,true); //@ JAVA_PATH_MANIPULATION-b1b30c
                fw.write("hash_value=" + org.owasp.esapi.ESAPI.encoder().encodeForBase64(result, true) + "\n");
                fw.close();
                response.getWriter().println( //@ JAVA_PRIVACY_VIOLATION-143b17,JAVA_XSS_VALIDATION-4e647a
                        "Sensitive value '" + org.owasp.esapi.ESAPI.encoder().encodeForHTML(new String(input)) + "' hashed and stored<br/>" //@ JAVA_OBSOLETE-bts001,JAVA_PRIVACY_VIOLATION_HEAP-1a46d2
                );

            } catch (java.security.NoSuchAlgorithmException e) {
                System.out.println("Problem executing hash - TestCase"); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
                throw new ServletException(e);
            }

            response.getWriter().println(
                    "Hash Test java.security.MessageDigest.getInstance(java.lang.String) executed"
            );
        }
    }
}



