package integration.java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class JAVA_MEMORY_ALLOCATION {
    public void alloc() {
        int data;
        String stringNumber = System.getenv("ADD"); //@ JAVA_USE_GETENV-f9b0b0
        data = Integer.parseInt(stringNumber.trim());

        HashMap intHashMap = new HashMap(data); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_MEMORY_ALLOCATION-geooj7

        ArrayList intArrayList = new ArrayList(data); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_MEMORY_ALLOCATION-geooj7

        HashSet intHashSet = new HashSet(data); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_MEMORY_ALLOCATION-geooj7
    }
}
