package integration.java8;

import java.io.*;

public class G02SecurityManagerBypass {
    public static String setBr(BufferedReader br) throws IOException {
        String location;
        do {
            location = br.readLine(); //@ JAVA_DOS-7adk6b
            if (location.isEmpty()) {
                break;
            }
        } while (true);

        InputStream in = Thread.currentThread().getContextClassLoader().getResource(location).openStream(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        Thread badThread = new Thread(new ThreadGroup("name"), location); //@ JAVA_THREADS-c030af,JAVA_THREADS-e05dda

        InputStream badIn = badThread.getContextClassLoader().getResource(location).openStream(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-f95fc0
        return location;
    }
    class G02SecurityManagerBypassInner {
        public void G02SecurityManagerBypassInner() throws FileNotFoundException {
            BufferedReader in = new BufferedReader(new FileReader("foo.in"));
            Thread badThread = null;
            try {
                badThread = new Thread(new ThreadGroup("name"), G02SecurityManagerBypass.setBr(in)); //@ JAVA_THREADS-c030af,JAVA_THREADS-e05dda
            } catch (IOException e) {
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }
            try {

                InputStream badIn = badThread.getContextClassLoader().getResource(G02SecurityManagerBypass.setBr(in)).openStream(); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-f95fc0,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_NULL_DEREFERENCE_ON_SOME_PATH-j11nd2
            } catch (IOException e) {
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }
        }
    }
}
