package integration.java8;

public class JAVA_SYSTEM_EXIT {

    public void test() {
        System.exit(1); //@ JAVA_SYSTEM_EXIT-d8ae59
    }
    public void test1() {
        Runtime.getRuntime().exit(1); //@ JAVA_SYSTEM_EXIT-d8ae59
    }
    public void test2() {
        final Runtime runtime = Runtime.getRuntime();
        int x = 666;
        runtime.exit(1); //@ JAVA_SYSTEM_EXIT-d8ae59
    }
}
