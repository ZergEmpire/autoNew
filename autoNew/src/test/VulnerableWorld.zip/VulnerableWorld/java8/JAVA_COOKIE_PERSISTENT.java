package integration.java8;

import org.springframework.web.util.CookieGenerator;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.ws.rs.core.NewCookie;

public class JAVA_COOKIE_PERSISTENT {
    public void COOKIE_PERSISTENT_b02a4e() {
        Cookie terminate = new Cookie("name", "value");

        terminate.setMaxAge(1000); //@ JAVA_COOKIE_PERSISTENT-b02a4e

        terminate.setMaxAge(0);
    }

    protected void unsafeDoGet(HttpServletRequest req, HttpServletResponse resp) {
        Cookie newCookie = new Cookie("test1", "1234");
        newCookie.setHttpOnly(false);
        HttpServletResponseWrapper cookie = new HttpServletResponseWrapper(resp);
        cookie.addCookie(newCookie); //@ JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_COOKIE_NOT_HTTPONLY-48e556
    }


    protected void safeDoGet(HttpServletRequest req, HttpServletResponse resp) {
        Cookie newCookie = new Cookie("test1", "1234");
        newCookie.setHttpOnly(true);
        newCookie.setSecure(true);
        HttpServletResponseWrapper cookie = new HttpServletResponseWrapper(resp);
        cookie.addCookie(newCookie);
    }

    void test(CookieGenerator cookieGenerator) {
        cookieGenerator.setCookieMaxAge(-1);
        cookieGenerator.setCookieMaxAge(1000); //@ JAVA_COOKIE_PERSISTENT-56974f
    }

    void test2(javax.ws.rs.core.Cookie cookie) {
        NewCookie newCookie1 = new NewCookie(cookie, "val", 1, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        NewCookie newCookie2 = new NewCookie(cookie, "val", 1000, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_COOKIE_PERSISTENT-e6c667
    }
}
