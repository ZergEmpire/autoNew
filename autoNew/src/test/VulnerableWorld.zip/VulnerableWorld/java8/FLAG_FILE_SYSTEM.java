package integration.java8;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Properties;
import java.util.Scanner;

class FLAG_FILE_SYSTEM {

    public static Scanner FILE_SYSTEM_bder8e () throws IOException {
        Path path = FileSystems.getDefault().getPath("logs", "access.log");

        Scanner scanner = new Scanner(path);
        return scanner;
    }

    public static Properties FILE_SYSTEM_PROPERTIES_STREAM () throws IOException {
        Properties properties = new Properties();

        properties.load(new FileInputStream("stream")); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        return properties;
    }

    public static Properties FILE_SYSTEM_PROPERTIES_READER () throws IOException {
        Properties properties = new Properties();

        properties.load(new FileReader("stream")); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        return properties;
    }
}
