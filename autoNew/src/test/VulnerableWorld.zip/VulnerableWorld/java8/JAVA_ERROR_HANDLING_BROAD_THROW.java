package integration.java8;

public class JAVA_ERROR_HANDLING_BROAD_THROW {

    public void a(){
        try {
            Integer.parseInt("Test"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        }
        catch (Exception exception) {
            throw exception;
        }

    }

    public void good() {
        try {
            Integer.parseInt("Test");
        }
        catch (NumberFormatException exception) {
            exception.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }
}
