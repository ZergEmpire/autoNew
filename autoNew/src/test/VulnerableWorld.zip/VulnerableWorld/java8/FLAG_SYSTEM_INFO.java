package integration.java8;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.spi.SyncFactory;
import javax.sql.rowset.spi.SyncFactoryException;
import javax.sql.rowset.spi.SyncProvider;
import java.net.InetAddress;
import java.net.UnknownHostException;

class FLAG_SYSTEM_INFO {
    public static String SYSTEM_INFO_rw3865() throws SyncFactoryException {
        SyncProvider syncProvider = SyncFactory.getInstance("providerID");

        String vendor = syncProvider.getVendor();
        return vendor;
    }
    public static String SYSTEM_INFO_cdw854 () throws UnknownHostException {

        String hostname = InetAddress.getLocalHost().getHostName(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        return hostname;
    }
    public static String SYSTEM_INFO_e202c6 (HttpServletRequest request){
        HttpSession httpSession;
        httpSession = request.getSession(false);

        return httpSession.getId();
    }
}
