package integration.java8

import java.security.Key

class SCALA_PRIVACY_VIOLATION {
  def violation(key: Key): Unit ={
    Console.print("foo")
    Console.print(FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(key)) //@ SCALA_PRIVACY_VIOLATION-prvi00
    print(FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(key)) //@ SCALA_PRIVACY_VIOLATION-prvi01
  }
}
