package integration.java8

import java.io.IOException
import java.net.URL

import javax.servlet.http.{HttpServletRequest, HttpServletResponse}


class SCALA_INFORMATION_LEAK_EXTERNAL {


  @throws[IOException]
  protected def doPost(req: HttpServletRequest, res: HttpServletResponse, url: URL): Unit = {
    val out = res.getWriter
    out.println(scala.sys.env("123")) //@ SCALA_INFORMATION_LEAK_EXTERNAL-c9497t,SCALA_USE_GETENV-f9b000
  }

}
