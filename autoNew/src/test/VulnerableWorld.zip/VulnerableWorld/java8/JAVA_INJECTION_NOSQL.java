package integration.java8;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class JAVA_INJECTION_NOSQL {
    public static void correctNoSql(HttpServletResponse response) throws IOException {
        MongoClient mongoClient = new MongoClient( "localhost" );
        MongoDatabase database = mongoClient.getDatabase("mydb");
        MongoCollection<Document> collection = database.getCollection("test");
        Document myDoc = collection.find().first();

        ServletOutputStream out = response.getOutputStream();
        response.setContentType("text/html");
        out.println("<html><body><h2>");
        out.println(myDoc.toJson());
        out.println("</h2></body></html>");
    }
}
