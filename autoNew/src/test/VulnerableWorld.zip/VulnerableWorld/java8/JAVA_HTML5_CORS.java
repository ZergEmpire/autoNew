package integration.java8;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@EnableAutoConfiguration
public class JAVA_HTML5_CORS {

    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/content",
            method = RequestMethod.GET, produces = "application/json")
    String content() {
        return "hello"; //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/content",
            method = RequestMethod.GET, produces = "application/json")
    String content(String string) {
        return "hello"; //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/content",
            method = RequestMethod.GET, produces = "application/json")
    String content2(String string, Object a) {
        return "hello"; //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/content",
            method = RequestMethod.GET, produces = "application/json")
    String content2(String string, Object a, @RequestHeader("x - Auth -dss") String token) {
        return "hello"; //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin(origins = {"abcd", "dsad12312:///adsas", "*"})
    @RequestMapping(value = "/dsad",
            method = RequestMethod.GET, produces = "application/json")
    Object hey1() {
        return new Object(); //@ JAVA_HTML5_CORS-rnr001
    }



    @CrossOrigin(origins = {"abcd", "dsad12312:///adsas", "*"})
    @RequestMapping(value = "/dsad",
            method = RequestMethod.GET, produces = "application/json")
    Object hey2(@RequestHeader("dsdsad") String a) {
        return new Object(); //@ JAVA_HTML5_CORS-rnr001
    }
    

    @CrossOrigin(allowedHeaders = {"Origin"})
    @RequestMapping(value = "/bbb",
            method = RequestMethod.GET, produces = "application/json")
    Object Method1() {
        return new Object(); //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin(allowedHeaders = {"Origin"})
    @RequestMapping(value = "/bbb",
            method = RequestMethod.GET, produces = "application/json")
    Object Method2(String token) {
        return new Object(); //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin
    @RequestMapping(value = "/ffff",
            method = RequestMethod.GET, produces = "application/json")
    Object Method4() {
        return new Object(); //@ JAVA_HTML5_CORS-rnr001
    }


    @CrossOrigin(allowedHeaders = {"Origin"})
    @RequestMapping(value = "/bbb",
            method = RequestMethod.GET, produces = "application/json")
    Object Method3(@RequestHeader(" x - AUth - token ") String token) {
        return new Object(); //@ JAVA_HTML5_CORS-rnr002
    }


    @CrossOrigin
    @RequestMapping(value = "/ffff",
            method = RequestMethod.GET, produces = "application/json")
    Object Method5(@RequestHeader(" x - AUth - token ") String token) {
        return new Object(); //@ JAVA_HTML5_CORS-rnr002
    }


    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/contents/{id}",
            method = RequestMethod.GET, produces = "application/json")
    Object privateContent2(@RequestParam(value = "id") String token,
                           @RequestHeader(value = "x -Auth-token") String id) {
        if (checkToken(token)) { //@ JAVA_HTML5_CORS-rnr002
            return getFromDB(id);
        }

        return "non auth";
    }


    @CrossOrigin(origins = {"abcd", "https://seregascalaforever.com"})
    @RequestMapping(value = "/fake",
            method = RequestMethod.GET, produces = "application/json")
    Object fakeMethod1() {
        return new Object();
    }


    @CrossOrigin(origins = {"abcd", "https://seregascalaforever.com"})
    @RequestMapping(value = "/fake",
            method = RequestMethod.GET, produces = "application/json")
    Object fakeMethod2(@RequestHeader("x-auth-token") String s) {
        return new Object();
    }


    @CrossOrigin(origins = {"abcd", "https://seregascalaforever.com", "*"})
    @RequestMapping(value = "/",
            method = RequestMethod.GET, produces = "application/json")
    Object fakeMethod3(String s) {
        return new Object();
    }
    
    private Object getFromDB(String id) {
        return new Object();
    }

    private boolean checkToken(String token) {
        return true;
    }
}

@CrossOrigin
class JAVA_HTML5_CORS2 {


    @RequestMapping(value={"/", "/profile"})
    void test1() {
        return; //@ JAVA_HTML5_CORS-rnr003
    }


    @RequestMapping(value={"/"})
    void test2() {
        return;
    }
}

@CrossOrigin(origins = {"*"})
class JAVA_HTML5_CORS3 {


    @RequestMapping(value={"/", "/profile"})
    void test1() {
        return; //@ JAVA_HTML5_CORS-rnr003
    }


    @RequestMapping(value={"/"})
    void test2() {
        return;
    }
}

@CrossOrigin(allowedHeaders = {"Origin"})
class JAVA_HTML5_CORS4 {


    @RequestMapping(value={"/", "/profile"})
    void test1() {
        return; //@ JAVA_HTML5_CORS-rnr003
    }


    @RequestMapping(value={"/"})
    void test2() {
        return;
    }
}

@CrossOrigin(origins = {"*", "abc"})
@RequestMapping(value = {"/"})
class JAVA_HTML5_CORS5 {

    @RequestMapping(value = {"/profile"})
    void test1() {
        return; //@ JAVA_HTML5_CORS-rnr003
    }
}

@CrossOrigin(origins = {"*", "abc"})
@RequestMapping(value = {"/", "/profile"})
class JAVA_HTML5_CORS6 { //@ JAVA_HTML5_CORS-rnr004


    void test1() {
        return; //@ JAVA_HTML5_CORS-rnr004
    }
}
