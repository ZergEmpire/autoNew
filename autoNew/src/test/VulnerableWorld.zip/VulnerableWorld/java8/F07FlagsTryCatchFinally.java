package integration.java8;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

public class F07FlagsTryCatchFinally {
    private void loadPasswordFile(URL url, Boolean userSuppliedPasswordFile, Boolean hasJavaHomePermission ) throws IOException {
        String userPwd = "userpwd"; //@ JAVA_PASSWORD_HARDCODED-8ce2fb
        String pwd = "password"; //@ JAVA_PASSWORD_HARDCODED-8ce2fb,JAVA_PRIVACY_VIOLATION_HEAP-heapin
        String value = null;
        Properties userCredentials;
        Properties userCredentialsTry;
        Properties userCredentialsCatch;
        Properties userCredentialsTryCatch;

        userCredentials = new Properties();
        userCredentialsTry = new Properties();
        userCredentialsCatch = new Properties();
        userCredentialsTryCatch = new Properties();

        userCredentials.setProperty(pwd, userPwd); //@ JAVA_PASSWORD_MANAGEMENT-rt17df
        try {

            userCredentials.setProperty(pwd, userPwd); //@ JAVA_PASSWORD_MANAGEMENT-rt17df

            userCredentialsTry.setProperty("PASSWORD", userPwd); //@ JAVA_PASSWORD_MANAGEMENT-rt17df

            userCredentialsTryCatch.setProperty(pwd, userPwd); //@ JAVA_PASSWORD_MANAGEMENT-rt17df

            value = userCredentials.getProperty("KEY"); //@ JAVA_PRIVACY_VIOLATION-975695

            userCredentials.setProperty("OTHER_KEY", value); //@ JAVA_PASSWORD_MANAGEMENT-rt17df
        } catch (SecurityException e) {
            if (userSuppliedPasswordFile || hasJavaHomePermission) {
                throw e;
            } else {
                userCredentials = new Properties();

                userCredentialsCatch.setProperty("PASSWORD", userPwd); //@ JAVA_PASSWORD_MANAGEMENT-rt17df

                value = userCredentials.getProperty("KEY");

                userCredentials.setProperty("OTHER_KEY", value);

                userCredentialsTryCatch.setProperty("OTHER_KEY", value);
            }
        }
         finally {

            userCredentials.setProperty("OTHER_KEY", value); //@ JAVA_PASSWORD_MANAGEMENT-rt17df

            userCredentialsTry.setProperty("OTHER_KEY", value); //@ JAVA_PASSWORD_MANAGEMENT-rt17df

            userCredentialsTryCatch.setProperty("OTHER_KEY", value); //@ JAVA_PASSWORD_MANAGEMENT-rt17df
        }
    }
}
