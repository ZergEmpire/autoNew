package integration.java8

trait SCALA_DOS_REGEX
{
  val InvalidChars = "[^\\.a-zA-Z0-9!$&'()*+,;=:/?#\\[\\]@-_~]".r
  // Abstract method
  def containsInvalidUriChars(string: String): Boolean = {
    InvalidChars.findFirstIn(string).isDefined //@ SCALA_DOS_REGEX-362f7b
  }
  def check()
}

class SCALA_DOS_REGEX_Class extends SCALA_DOS_REGEX
{
  def check()
  {
    val env = System.getenv("env") //@ SCALA_USE_GETENV-f9b0b0
    containsInvalidUriChars(env)
    containsInvalidUriChars(System.getenv("env")) //@ SCALA_USE_GETENV-f9b0b0
    InvalidChars.findFirstIn(env).isDefined //@ SCALA_DOS_REGEX-362f7b
    InvalidChars.findFirstMatchIn(env) //@ SCALA_DOS_REGEX-362f7b
    InvalidChars.replaceAllIn(env, "foo") //@ SCALA_DOS_REGEX-362f7b
    InvalidChars.findPrefixOf(env) //@ SCALA_DOS_REGEX-362f7b
    InvalidChars.toString()
  }
}
