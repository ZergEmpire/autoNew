package integration.java8;

import javax.xml.XMLConstants;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Source;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import java.io.InputStream;
import java.io.StringWriter;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.*;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.beans.XMLDecoder;
import java.io.*;
import java.net.ServerSocket;
import java.util.Properties;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Schema;


public class JAVA_INJECTION_XXE {
    public void INJECTION_XXE_yp7hkw(ServerSocket serverSocket) throws SAXException, IOException, XPathExpressionException {

        InputSource source = new InputSource(FLAG_WEB.WEB_chp0rr(serverSocket)); //@ JAVA_INJECTION_XXE-yp7hkw
        recXMLStream(FLAG_WEB.WEB_chp0rr(serverSocket), serverSocket);

        XPath xpath = XPathFactory.newInstance().newXPath();
        XPathExpression expr = xpath.compile("query");

        expr.evaluate(source); //@ JAVA_INJECTION_XXE-29cc00
    }

    public void INJECTION_XXE_ndndww(DefaultHandler dh, ServerSocket serverSocket, InputStream inStream) {

        Properties properties = new Properties(); //@ JAVA_ERROR_HANDLING_EMPTY_CATCH-05aea7,JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2,JAVA_BACKDOOR_DEAD_CODE-d27d09
        try {
            SAXParser parser = SAXParserFactory.newInstance().newSAXParser();

            parser.parse(FLAG_WEB.WEB_chp0rr(serverSocket), dh); //@ JAVA_INJECTION_XXE-ndndww
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) throws SAXException, IOException {

        String xmlString = args[0] + "smth"; //@ JAVA_J2EE_DEBUG_CODE-514398


        InputStream is = new ByteArrayInputStream(xmlString.getBytes());

        XMLDecoder xmlDecoder = new XMLDecoder(is); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_XXE-c42bb6,JAVA_INJECTION_XMLDECODER-c078ed
        ServerSocket serverSocket = new ServerSocket(); //@ JAVA_J2EE_SOCKETS-34473d
        recXMLStream(is, serverSocket);
    }


    private static void recXMLStream(InputStream inStream, ServerSocket serverSocket) throws SAXException, IOException {
        XMLReader reader = XMLReaderFactory.createXMLReader();

        reader.parse(new InputSource(FLAG_WEB.WEB_chp0rr(serverSocket))); //@ JAVA_INJECTION_XXE-rwkqsa,JAVA_INJECTION_XXE-yp7hkw

        reader.parse(new InputSource(inStream)); //@ JAVA_INJECTION_XXE-yp7hkw,JAVA_INJECTION_XXE-rwkqsa,JAVA_INJECTION_XXE-rwkqsa,JAVA_INJECTION_XXE-yp7hkw
    }

    public static void INJECTION_XXE_(HttpServletRequest request, String xml2) throws IOException, ParserConfigurationException, SAXException, JAXBException {
        XMLReader reader = XMLReaderFactory.createXMLReader(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        InputStream xml = request.getInputStream();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        InputSource is = new InputSource(xml); //@ JAVA_INJECTION_XXE-yp7hkw

        Document doc = builder.parse(is); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_XXE-ndndww

        JAXBContext.newInstance(JAVA_INJECTION_XXE.class).createUnmarshaller().unmarshal(new StringReader(xml2));
    }


    public void loadXml() throws XMLStreamException, IOException, SAXException, TransformerException {

        String tainted = FLAG_STREAM.STREAM_PROPERTIES_STREAM().toString();
        InputStream in = getClass().getResourceAsStream(tainted);
        if (in == null) System.out.println("Oups file not found."); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        InputStream in2 = getClass().getResourceAsStream("/testcode/xxe/simple_xxe.xml");
        if (in2 == null) System.out.println("Oups XML file not found."); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

        Source source = new StreamSource(in);
        Source source2 = new StreamSource(in2);


        parseXMLwithWrongFlag(in);

        parseXMLwithWrongFlag(in2);


        parseXMLwithWrongFlag2("qwerty", in);

        parseXMLwithWrongFlag2("qwerty", in2);


        parseXMLSafe1(in);

        parseXMLSafe1(in2);


        parseXMLSafe2("qwerty", in);

        parseXMLSafe2("qwerty", in2);


        parseXMLWithWrongFlag3(source);

        parseXMLWithWrongFlag3(source2);


        parseXMLSafe3(source);

        parseXMLSafe3(source2);


        parseXMLwithWrongFlag4(source);

        parseXMLwithWrongFlag4(source2);


        parseXMLSafe4(source);

        parseXMLSafe4(source2);

    }


    public void parseXMLwithWrongFlag(InputStream input) throws XMLStreamException, SAXException {

        XMLInputFactory factory = XMLInputFactory.newFactory();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, true);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, true);
        XMLStreamReader reader = factory.createXMLStreamReader(input); //@ JAVA_INJECTION_XXE-lk34sa
        while (reader.hasNext()) {
            reader.next();
        }
    }


    public void parseXMLSafe1(InputStream input) throws XMLStreamException, SAXException {

        XMLInputFactory factory = XMLInputFactory.newFactory();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        XMLStreamReader reader = factory.createXMLStreamReader(input);
        while (reader.hasNext()) {
            reader.next();
        }
    }


    public void parseXMLwithWrongFlag2(String systemId, InputStream input) throws XMLStreamException {

        XMLInputFactory factory = XMLInputFactory.newFactory();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, true);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, true);
        XMLStreamReader reader = factory.createXMLStreamReader(systemId, input); //@ JAVA_INJECTION_XXE-lk35sa
        while (reader.hasNext()) {
            reader.next();
        }
    }


    public void parseXMLSafe2(String systemId, InputStream input) throws XMLStreamException, SAXException {

        XMLInputFactory factory = XMLInputFactory.newFactory();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        XMLStreamReader reader = factory.createXMLStreamReader(input);
        while (reader.hasNext()) {
            reader.next();
        }
    }


    public void parseXMLWithWrongFlag3(Source input) throws XMLStreamException, TransformerException {

        TransformerFactory factory = TransformerFactory.newInstance();
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "all");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "all");

        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StringWriter outWriter = new StringWriter();
        StreamResult result = new StreamResult(outWriter);

        transformer.transform(input, result); //@ JAVA_INJECTION_XXE-lk36sa
        result.toString();
    }


    public void parseXMLSafe3(Source input) throws XMLStreamException, TransformerException {

        TransformerFactory factory = TransformerFactory.newInstance();
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StringWriter outWriter = new StringWriter();
        StreamResult result = new StreamResult(outWriter);

        transformer.transform(input, result);
        outWriter.toString();
    }


    public void parseXMLwithWrongFlag4(Source input) throws SAXException, IOException {

        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        Schema schema = factory.newSchema();
        Validator validator = schema.newValidator();
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "all");
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "all");

        validator.validate(input); //@ JAVA_INJECTION_XXE-lk37sa

    }


    public void parseXMLSafe4(Source input) throws SAXException, IOException {

        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        Schema schema = factory.newSchema();
        Validator validator = schema.newValidator();
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");

        validator.validate(input);

    }

    static final String CONTENTS = "WebGoat 8.0 rocks... ()";
    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String addComment(@RequestBody String commentStr) throws Exception {
            return parseXml(commentStr); //@ JAVA_XSS_REFLECTED-j11xs1,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
    }

    protected String parseXml(String xml) throws Exception {
        JAXBContext jc = JAXBContext.newInstance(String.class); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae

        XMLInputFactory xif = XMLInputFactory.newFactory();
        xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, true);
        xif.setProperty(XMLInputFactory.IS_VALIDATING, false);

        xif.setProperty(XMLInputFactory.SUPPORT_DTD, true);

        XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(xml)); //@ JAVA_INJECTION_XXE-lk34sa

        Unmarshaller unmarshaller = jc.createUnmarshaller();

        return (String) unmarshaller.unmarshal(xsr); //@ JAVA_INJECTION_XXE-397a16
    }


}
