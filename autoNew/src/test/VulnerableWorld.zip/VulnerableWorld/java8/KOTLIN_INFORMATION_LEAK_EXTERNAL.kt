package integration.java8

import android.app.Activity
import android.content.Context
import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.features.*
import io.ktor.response.*
import io.ktor.routing.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.noButton
import org.jetbrains.anko.toast
import org.jetbrains.anko.yesButton
import javax.sql.rowset.spi.SyncFactory
import javax.sql.rowset.spi.SyncFactoryException

fun Application.ktor_leak_external() {
    var pwd: String? //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            call.respondText("system info")
        }
    }
}

fun Activity.android_leak_external() {

    alert("Hi, I'm Roy", "Have you tried turning it off and on again?") {
        yesButton { toast("Oh…") }
        noButton {}
    }.show()


    alert(SYSTEM_INFO_rw3865()) //@ KOTLIN_INFORMATION_LEAK_EXTERNAL-k11le1
}


@Throws(SyncFactoryException::class)
fun SYSTEM_INFO_rw3865(): String {
    val syncProvider = SyncFactory.getInstance("providerID")

    return syncProvider.vendor
}


