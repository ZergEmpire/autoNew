package integration.java8

import java.io.{File, FileDescriptor, InputStream, Reader}
import java.net.URL

import scala.xml.XML._

class SCALA_INJECTION_XXE {
  def test(url: URL, file: File, is: InputStream, reader: Reader, fd: FileDescriptor): Unit = {
    loadFile(url.getContent.toString) //@ SCALA_INJECTION_XXE-sxxe00
    load(url) //@ SCALA_INJECTION_XXE-sxxe01
    load("asd") //@ SCALA_INJECTION_XXE-sxxe02
    load(is) //@ SCALA_INJECTION_XXE-sxxe01
    load(reader) //@ SCALA_INJECTION_XXE-sxxe01

    loadFile(file) //@ SCALA_INJECTION_XXE-sxxe01
    loadFile(fd) //@ SCALA_INJECTION_XXE-sxxe01
    loadFile(url.getContent.toString) //@ SCALA_INJECTION_XXE-sxxe00
    loadFile("asd") //@ SCALA_INJECTION_XXE-sxxe02

    loadString(url.getContent.toString) //@ SCALA_INJECTION_XXE-sxxe00
    loadString("asd")
  }
}
