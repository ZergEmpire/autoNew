package integration.java8

import cats.Show
import cats.kernel.Monoid
import cats.instances.all._
import cats.MonadError


class SCALA_INFORMATION_LEAK_INTERNAL[A] {
  type ErrorOr[A] = Either[String, A]
  def leak(): Unit ={
    Console.print("foo")
    Console.print(scala.sys.env("123")) //@ SCALA_USE_GETENV-f9b000,SCALA_INFORMATION_LEAK_INTERNAL-inli00
    val bar = scala.sys.env("123") //@ SCALA_USE_GETENV-f9b000
    Console.print(bar) //@ SCALA_INFORMATION_LEAK_INTERNAL-inli00
    Console.print(System.getenv("foo")) //@ SCALA_USE_GETENV-f9b0b0,SCALA_INFORMATION_LEAK_INTERNAL-inli00
    val str = Monoid[String].combine(bar, "there")
    implicit val cat = Show.show[SCALA_INFORMATION_LEAK_INTERNAL[A]] { scala =>
      str
    }
    print(cat) //@ SCALA_INFORMATION_LEAK_INTERNAL-inli01
  }
  def fun(mMonadError: MonadError[ErrorOr, String]): Unit = {
    val foo = scala.sys.env("123") //@ SCALA_USE_GETENV-f9b000
    mMonadError.raiseError(foo) //@ SCALA_INFORMATION_LEAK_INTERNAL-inli02
  }
}
