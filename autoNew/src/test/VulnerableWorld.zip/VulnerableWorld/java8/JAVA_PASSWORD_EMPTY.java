package integration.java8;

import com.hazelcast.config.SymmetricEncryptionConfig;

public class JAVA_PASSWORD_EMPTY {

    private String password = ""; //@ JAVA_PASSWORD_EMPTY-fhwjsd
    public void bad6() {
        String pwdStr = ""; //@ JAVA_PASSWORD_EMPTY-76458b
        char[] pwd1 = pwdStr.toCharArray();

        char[] pwd2 = pwd1; //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        char[] passphrase2 = {}; //@ JAVA_PASSWORD_EMPTY-76458b,JAVA_BACKDOOR_DEAD_CODE-d27d09
        new SymmetricEncryptionConfig().setPassword(""); //@ JAVA_PASSWORD_EMPTY-setpwd2

    }
}
