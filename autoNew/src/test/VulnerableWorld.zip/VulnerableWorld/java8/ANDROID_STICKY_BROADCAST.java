package integration.java8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class ANDROID_STICKY_BROADCAST {

    public void test(
        Context context,
        Intent intent,
        BroadcastReceiver broadcastReceiver,
        Handler handler,
        Bundle bundle)
    {
        context.sendStickyBroadcast(intent); //@ ANDROID_STICKY_BROADCAST-4db408
        context.sendStickyOrderedBroadcast(intent, broadcastReceiver, handler, 1, "string", bundle); //@ ANDROID_STICKY_BROADCAST-4db408
    }

    public void test2(
        ContextWrapper context,
        Intent intent,
        BroadcastReceiver broadcastReceiver,
        Handler handler,
        Bundle bundle)
    {
        context.sendStickyBroadcast(intent); //@ ANDROID_STICKY_BROADCAST-4db408
        context.sendStickyOrderedBroadcast(intent, broadcastReceiver, handler, 1, "string", bundle); //@ ANDROID_STICKY_BROADCAST-4db408
    }
}
