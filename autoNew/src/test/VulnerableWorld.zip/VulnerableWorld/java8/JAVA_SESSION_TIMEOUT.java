package integration.java8;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class JAVA_SESSION_TIMEOUT {
    public void bad(HttpServletRequest request) {
        HttpSession sesssion = request.getSession(true);

        sesssion.setMaxInactiveInterval(-1); //@ JAVA_SESSION_TIMEOUT-f9b0b3

        sesssion.setMaxInactiveInterval(1000); //@ JAVA_SESSION_TIMEOUT-f9b0b3

        sesssion.setMaxInactiveInterval(100);
    }
}
