package integration.java8;

public class JAVA_CORRECTNESS_NONFINAL_PUBLIC_STATIC_FIELD {
    public static boolean bad = false; //@ JAVA_CORRECTNESS_NONFINAL_PUBLIC_STATIC_FIELD-j11cn1

    public final static int good = 1;

    public static Double again = 1d; //@ JAVA_CORRECTNESS_NONFINAL_PUBLIC_STATIC_FIELD-j11cn1

    public static short gdf = 13; //@ JAVA_CORRECTNESS_NONFINAL_PUBLIC_STATIC_FIELD-j11cn1

    private final int a = 5;
}
