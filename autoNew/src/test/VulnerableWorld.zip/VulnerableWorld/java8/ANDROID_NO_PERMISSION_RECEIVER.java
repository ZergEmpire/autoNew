package integration.java8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Handler;

public class ANDROID_NO_PERMISSION_RECEIVER {

    public void test(
        Context context,
        IntentFilter intentFilter,
        BroadcastReceiver broadcastReceiver,
        Handler handler)
    {
        context.registerReceiver(broadcastReceiver, intentFilter); //@ ANDROID_NO_PERMISSION_RECEIVER-4485e9
        context.registerReceiver(broadcastReceiver, intentFilter, "string", handler);
    }
}
