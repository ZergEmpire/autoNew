package integration.java8;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;

import java.security.Key;
import java.util.Properties;

public class JAVA_PRIVACY_VIOLATION_JWT {
    Properties userCredentials;

    public void foo(Key key)
    {
        String password = userCredentials.getProperty("password"); //@ JAVA_NULL_DEREFERENCE-j11nd8,JAVA_PRIVACY_VIOLATION_HEAP-heapin
        Jwt jwt = Jwts.parser().setSigningKey(key).parse("key"); //@ JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
        Claims claims = (Claims) jwt.getBody();
        claims.put("user", password);
        String token = Jwts.builder()
            .setClaims(claims) //@ JAVA_PRIVACY_VIOLATION_JWT-jwtkfn
            .signWith(io.jsonwebtoken.SignatureAlgorithm.HS512, key)
            .compact(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
