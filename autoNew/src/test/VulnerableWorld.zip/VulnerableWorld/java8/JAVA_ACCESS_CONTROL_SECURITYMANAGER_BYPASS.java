package integration.java8;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.security.CodeSource;
import java.security.PermissionCollection;
import java.security.ProtectionDomain;
import java.security.cert.Certificate;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;
import java.sql.DriverManager;

public class JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS {
    private Locale mLocale = Locale.getDefault();
    public void ACCESS_CONTROL_SECURITYMANAGER_BYPASS_75af8f(){

        ResourceBundle bundle = ResourceBundle.getBundle("ApplicationResources", mLocale); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-75af8f
    }
    public void ACCESS_CONTROL_SECURITYMANAGER_BYPASS_518dc7() throws SQLException {

        Driver driverManager = DriverManager.getDriver("url"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7
    }

    public static void main(String[] args) {
        MyClassLoader mcl = new MyClassLoader(); //@ JAVA_J2EE_DEBUG_CODE-514398
        try {

            Class<?> c1 = Class.forName("com.evil.EvilClass", true, mcl); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-97d40l
            Object obj = c1.newInstance();
            System.out.println(obj.getClass().getClassLoader()); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        } catch (ClassNotFoundException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        } catch (IllegalAccessException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        } catch (InstantiationException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }
}

class MyClassLoader extends ClassLoader {
    public MyClassLoader() {
    }

    public MyClassLoader(ClassLoader parent) {
        super(parent);
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        File file = getClassFile(name); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        try {
            byte[] bytes = getClassBytes(file);

            Class<?> c = defineClazz(name, bytes, 0, bytes.length);
            return c;
        } catch (Exception e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        return super.findClass(name);
    }

    protected final Class<?> defineClazz(String name, byte[] b, int off, int len) throws ClassFormatError {
        try {
            PermissionCollection pc = ClassLoader.class.getProtectionDomain().getPermissions(); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2

            ProtectionDomain pd = new ProtectionDomain(new CodeSource(null, (Certificate[]) null),
                    pc, this, null);
            return this.defineClass(name, b, off, len, pd);
        } catch (Exception e) {
            return null;
        }
    }

    private File getClassFile(String name) {
        File file = new File("./" + name + ".class"); //@ JAVA_FILE_SEPARATOR_HARDCODED-52kd79
        return file;
    }

    private byte[] getClassBytes(File file) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        FileChannel fc = fis.getChannel();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        WritableByteChannel wbc = Channels.newChannel(baos);
        ByteBuffer by = ByteBuffer.allocate(1024);

        while (true) {
            int i = fc.read(by);
            if (i == 0 || i == -1) {
                break;
            }

            by.flip();
            wbc.write(by);
            by.clear();
        }
        fis.close();
        return baos.toByteArray();
    }
}
