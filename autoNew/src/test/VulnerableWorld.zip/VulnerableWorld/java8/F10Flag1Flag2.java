package integration.java8;

import java.net.URL;
import java.net.URLConnection;
import java.io.IOException;

public class F10Flag1Flag2 {
    private void addFlag1Flag2(URL url) throws IOException {
        URLConnection urlConnection = url.openConnection(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
