package integration.java8

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.HttpClientEngineFactory
import io.ktor.client.features.cookies.AcceptAllCookiesStorage
import io.ktor.client.features.cookies.ConstantCookieStorage
import io.ktor.client.features.cookies.HttpCookies
import io.ktor.client.features.cookies.cookies
import io.ktor.http.Cookie
import io.ktor.http.renderSetCookieHeader
import io.ktor.response.ApplicationResponse
import io.ktor.response.ResponseCookies
import io.ktor.sessions.CookieConfiguration

fun cookieNotHttpOnly(response: ApplicationResponse) {

    val cookie = Cookie(name = "name", value = "value", secure = true ) //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_COOKIE_NOT_HTTPONLY-wswle7

    ResponseCookies(response, true).append(name = "name", value = "value", secure = true)

    renderSetCookieHeader(name = "name", value = "value", secure = true) //@ KOTLIN_COOKIE_NOT_HTTPONLY-werqqq
    val cookieConf = CookieConfiguration()

    cookieConf.httpOnly = false //@ KOTLIN_COOKIE_NOT_HTTPONLY-ffv892
}
