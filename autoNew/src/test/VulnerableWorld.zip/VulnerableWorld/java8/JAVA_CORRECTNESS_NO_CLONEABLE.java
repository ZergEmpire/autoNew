package integration.java8;


public class JAVA_CORRECTNESS_NO_CLONEABLE {
    public Object clone() {

        return this; //@ JAVA_CLONE_METHOD_ERROR-a07a0f,JAVA_CORRECTNESS_NO_CLONEABLE-0cb849
    }
}
