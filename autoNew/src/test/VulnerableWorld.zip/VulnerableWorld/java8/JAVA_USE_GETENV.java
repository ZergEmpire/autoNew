package integration.java8;

public class JAVA_USE_GETENV {

    public String foo() {
        return System.getenv("vat"); //@ JAVA_USE_GETENV-f9b0b0
    }
}
