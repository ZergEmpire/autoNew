package integration.java8;

import java.io.*;
import java.util.Scanner;

public class JAVA_INJECTION_COMMAND {

    public static void INJECTION_COMMAND_3e45b4 () throws IOException {
        Scanner scanner = FLAG_FILE_SYSTEM.FILE_SYSTEM_bder8e();

        Process process = Runtime.getRuntime().exec(scanner.toString()); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_COMMAND-3e45b4,JAVA_ESAPI_DEPRECATED-su4b2l

        test(scanner.nextLine());
    }

    public void badWithException() throws Exception {
        String data = ""; //@ JAVA_ERROR_HANDLING_EMPTY_CATCH-05aea7,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        File file = new File("data.txt");
        FileInputStream streamFileInput;
        InputStreamReader readerInputStream;
        BufferedReader readerBuffered;
        try {
            streamFileInput = new FileInputStream(file);
            readerInputStream = new InputStreamReader(streamFileInput, "UTF-8");
            readerBuffered = new BufferedReader(readerInputStream); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

            data = readerBuffered.readLine(); //@ JAVA_DOS-9ad0eb
        } catch (IOException ex) {
        }

        Runtime.getRuntime().exec(data); //@ JAVA_INJECTION_COMMAND-3e45b4,JAVA_ESAPI_DEPRECATED-su4b2l
    }

    public static void test(String str) throws IOException
    {
        Runtime runtime = Runtime.getRuntime();
        StringBuilder builder = new StringBuilder();
        builder.append("cmd");
        builder.append(str);
        Process proc = runtime.exec(builder.toString()); //@ JAVA_INJECTION_COMMAND-3e45b4,JAVA_ESAPI_DEPRECATED-su4b2l
        InputStream is = proc.getInputStream();
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1
        String line;
        while ((line = br.readLine()) != null) { //@ JAVA_DOS-7adk6b, JAVA_DOS-9ad0eb
            System.out.println(line); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d, JAVA_XSS_REFLECTED_CGI-rnr008
        }
    }
}
