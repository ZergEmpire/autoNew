package integration.java8;

import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;

public class JAVA_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK {

    public void test(RequestBuilder requestBuilder, RequestCallback callback) throws RequestException
    {
        requestBuilder.send(); //@ JAVA_CSRF-8d409c, JAVA_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK-38f7e5
        requestBuilder.sendRequest("data", callback); //@ JAVA_CSRF-8d409c, JAVA_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK-38f7e5
    }
}
