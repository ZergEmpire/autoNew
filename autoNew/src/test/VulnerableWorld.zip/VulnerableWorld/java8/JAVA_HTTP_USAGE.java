package integration.java8;

import org.apache.jackrabbit.webdav.xml.Namespace;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class JAVA_HTTP_USAGE {

    public URL urlBuilder(String domain) throws MalformedURLException{
        String a = "abc" + "http://";
        String b = "http://" + "abc"; //@ JAVA_HTTP_USAGE-fa824a
        String c = "abc" + "http://" + "abc";

        b.replace("http://", "ws://");
        b.replace("ws://", "http://"); //@ JAVA_HTTP_USAGE-fa824a

        return new URL("http://" + domain); //@ JAVA_HTTP_USAGE-fa824a
    }

    public void HTTP_USAGE() {
        try {
            URL url = new URL("http://www.example.com/comment"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e,JAVA_HTTP_USAGE-fa824a
            try {
                url.openConnection(); //@ JAVA_HTTP_USAGE-fa824b
                HttpURLConnection connection = (HttpURLConnection) url.openConnection(); //@ JAVA_HTTP_USAGE-fa824b,JAVA_BACKDOOR_DEAD_CODE-d27d09

                URLConnection connection1 = this.urlBuilder("example.com").openConnection(); //@ JAVA_HTTP_USAGE-fa824b,JAVA_BACKDOOR_DEAD_CODE-d27d09
            } catch (IOException e) {
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }
        } catch (MalformedURLException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        this.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage");
    }

    private void setProperty(final String s)
    {
    }

    public void testNamespace() {
        Namespace.getNamespace("http://owncloud.org/ns");
    }
    private static final String FEATURE_DISALLOW_DTD = "http://apache.org/xml/features/disallow-doctype-decl";
    private static final String FEATURE_SECURE_PROCESSING = "http://javax.xml.XMLConstants/feature/secure-processing";
    private static final String FEATURE_GENERAL_ENTITIES = "http://xml.org/sax/features/external-general-entities";
    private static final String FEATURE_EXTERNAL_ENTITIES = "http://xml.org/sax/features/external-parameter-entities";
    private static final String PROPERTY_SUPPORT_DTD = "http://javax.xml.XMLConstants/property/accessExternalDTD";

}
