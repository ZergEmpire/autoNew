package integration.java8;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;

public class JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY {

    public void test(final byte[] b) throws IOException
    {
        final byte[] decode = Base64.getDecoder().decode(b);
        Runtime.getRuntime().exec(Arrays.toString(decode)); //@ JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY-kglfor,JAVA_ESAPI_DEPRECATED-su4b2l
    }
    public void test2(final String s) throws IOException
    {
        final byte[] decode = Base64.getDecoder().decode(s);
        Runtime.getRuntime().exec(Arrays.toString(decode)); //@ JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY-kglfor,JAVA_ESAPI_DEPRECATED-su4b2l
    }
    public void test3(final String s) throws IOException
    {
        final byte[] decode = Base64.getDecoder().decode(s.getBytes());
        Runtime.getRuntime().exec(Arrays.toString(decode)); //@ JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY-kglfor,JAVA_ESAPI_DEPRECATED-su4b2l
    }
    public void test4(final String s, final String[] env) throws IOException
    {
        final byte[] decode = Base64.getDecoder().decode(s.getBytes());
        Runtime.getRuntime().exec(Arrays.toString(decode), env); //@ JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY-kglfor,JAVA_ESAPI_DEPRECATED-su4b2l
    }
    public void test5(final String s, final String[] env, final File file) throws IOException
    {
        final byte[] decode = Base64.getDecoder().decode(s.getBytes());
        Runtime.getRuntime().exec(Arrays.toString(decode), env, file); //@ JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY-kglfor,JAVA_ESAPI_DEPRECATED-su4b2l
    }
}
