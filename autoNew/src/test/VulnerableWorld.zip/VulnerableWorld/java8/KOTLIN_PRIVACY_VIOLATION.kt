package integration.java8

import io.ktor.application.Application
import io.ktor.application.ApplicationCall
import io.ktor.application.install
import io.ktor.features.CallLogging
import io.ktor.features.DefaultHeaders
import io.ktor.response.ApplicationResponse
import io.ktor.response.respondText
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.sessions.SessionTransportHeader
import io.ktor.sessions.SessionTransportTransformer
import mu.KotlinLogging

fun Application.informationLeak(
        response: ApplicationResponse,
        builder: StringBuilder,
        transformers: List<SessionTransportTransformer>,
        call: ApplicationCall
) {
    var pswd = "value"
    var somevalue = "value"
    val logger = KotlinLogging.logger{}

    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            somevalue = call.parameters["pwd"].orEmpty()


            logger.info(somevalue) //@ KOTLIN_PRIVACY_VIOLATION-k11pv1,KOTLIN_LOGGING_LOG_FORGING-k11lf1
        }
    }

    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            pswd = call.parameters["pwd"].orEmpty()

            println(pswd) //@ KOTLIN_PRIVACY_VIOLATION-143b17,JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

            call.respondText(pswd) //@ KOTLIN_PRIVACY_VIOLATION-wwr390,KOTLIN_XSS_REFLECTED-kp1388

            builder.appendln(pswd)
        }

        val pwd = SessionTransportHeader("pswd", transformers).receive(call).toString() //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PRIVACY_VIOLATION_HEAP-heapin

        SessionTransportHeader("name", transformers).send(call, pswd)
    }


    logger.info("hola!")

}
