package integration.java8;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

public class FLAG_NUMBER {
    public static Long FLAG_NUMBER_2d3499(HttpServletRequest request, JspWriter out) throws IOException {

        Long number = new Long(request.getAttribute("input1").toString());
        Long number2 = null;

        out.print(number);

        out.print(number2);
        return number;
    }
}
