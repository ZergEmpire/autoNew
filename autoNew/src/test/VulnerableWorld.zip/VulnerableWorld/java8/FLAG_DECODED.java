package integration.java8;

import java.io.IOException;
import java.util.Arrays;

public class FLAG_DECODED {

    private void test() throws IOException
    {
        Base64 base64 = new Base64("string");
        base64.decode(1);

        Runtime.getRuntime().exec(flagDecoded("String")); //@ JAVA_BACKDOOR_HIDDEN_FUNCTIONALITY-kglfor,JAVA_ESAPI_DEPRECATED-su4b2l
    }

    public String flagDecoded(final String string) {
        return Arrays.toString(java.util.Base64.getDecoder().decode(string));
    }

    class Base64 {
        private String string;

        Base64(final String string) {
            this.string = string;
        }

        void decode(final int i) {
            string += i;
        }

        public String getString()
        {
            return string;
        }

        public void setString(final String string)
        {
            this.string = string;
        }
    }
}
