package integration.java8;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;

public class JAVA_INJECTION_XML {
    public static void INJECTION_XML_rwkqsa(final InputStream inStream) throws SAXException, IOException {
        FLAG_XMLPROCESSOR.FLAG_XMLPROCESSOR_erj33q().parse(new InputSource(inStream));
    }
    public static Document loadDoc(ServerSocket path) throws ParserConfigurationException, IOException, SAXException {
        // + XMLPROCESSOR svsss3
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        // + WEB
        InputStream in = FLAG_WEB.WEB_chp0rr(path);

        return builder.parse(in); //@ JAVA_INJECTION_XXE-ndndww
    }
}
