package integration.java8;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;

public class JAVA_UNTRUSTED_DATA_DESERIALIZATION_JSON {

    public void safe(String name) throws IOException
    {
        final ObjectMapper mapper = new ObjectMapper();
        final Person person = mapper.readValue(name, Person.class); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void dangerous(@RequestParam String name) throws IOException
    {
        final ObjectMapper mapper = new ObjectMapper();
        mapper.enableDefaultTyping();
        final Person unsafe = mapper.readValue(name, Person.class); //@ JAVA_UNTRUSTED_DATA_DESERIALIZATION_JSON-3e45cd,JAVA_BACKDOOR_DEAD_CODE-d27d09
        mapper.disableDefaultTyping();
        final Person safe = mapper.readValue(name, Person.class); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public class Person {
        public String name;
    }
}
