package integration.java8;

import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Part;

public class B05This {
    public static void main(String[] args) {

        B05This c = new B05This(); //@ JAVA_J2EE_DEBUG_CODE-514398
        Class cls = c.getClass();

        String className = cls.getCanonicalName();

        if (className.equals("java.MyClass")) //@ JAVA_CORRECTNESS_COMPARE-9cbc9e
        {

        }

        boolean bool = Pattern.matches("regex", Arrays.toString(args)); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

    }

    public void test(Part part, Key key) throws MessagingException
    {
        part.setDescription(FLAG_PRIVATE_DATA.PRIVATE_DATA(key));
        test(new MessageContext(part));
    }

    public void test(MessageContext messageContext) {
        System.out.println(messageContext.getMessage()); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
    }

    public void test3(Key key) {
        List<String> list = new ArrayList<>();
        list.add(FLAG_PRIVATE_DATA.PRIVATE_DATA(key));
        System.out.println(list.toArray()); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
    }

    public void test4(Key key) {
        List<String> list = new ArrayList<>();
        list.add(FLAG_PRIVATE_DATA.PRIVATE_DATA(key));
        System.out.println(list); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        final Object[] clone = list.toArray().clone();
        System.out.println(clone); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
    }
}
