package integration.java8;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class JAVA_PRIVACY_VIOLATION_SCREENSHOT {
    public void screenshot() throws AWTException, IOException {
        Robot robot = new Robot();

        BufferedImage screenCapture = robot.createScreenCapture(new Rectangle(100,100)); //@ JAVA_PRIVACY_VIOLATION_SCREENSHOT-f9b0b2
        ImageIO.write(screenCapture, "jpg", new File("screen.jpg"));
    }
}
