package integration.java8;

import java.io.BufferedWriter;

public class JAVA_THREADS {

    private ThreadLocal<BufferedWriter> partitionOut = new ThreadLocal<BufferedWriter>() {}; //@ JAVA_THREADS-fe7c48

    private static ThreadGroup tg = new ThreadGroup("Chief"); //@ JAVA_THREADS-e05dda

    public static void useThreadGroup()
    {

        tg.activeCount(); //@ JAVA_THREADS-e05dda
    }

    public void test(Thread thread) throws InterruptedException
    {
        thread.interrupt(); //@ JAVA_THREADS-cgl0af
        thread.join(); //@ JAVA_THREADS-cgl0af
        thread.resume(); //@ JAVA_THREADS-cgl0af
        Thread.sleep(1); //@ JAVA_THREADS-cgl0af
        thread.start(); //@ JAVA_THREADS-cgl0af
        thread.stop(); //@ JAVA_THREADS-cgl0af
        thread.suspend(); //@ JAVA_THREADS-cgl0af
        Thread.yield(); //@ JAVA_THREADS-cgl0af
    }
}
