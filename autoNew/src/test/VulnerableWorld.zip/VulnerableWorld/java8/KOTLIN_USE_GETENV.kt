package integration.java8

class KOTLIN_USE_GETENV {

    fun foo(): String {
        return System.getenv("addf") //@ KOTLIN_USE_GETENV-f9b0b0
    }
}
