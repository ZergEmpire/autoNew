package integration.java8;

import java.io.*;
import java.net.ServerSocket;

public class JAVA_POLICY_MANIPULATION {
    final static String homePolicyFile = "grant {\n" +
            "    permission java.io.FilePermission \"<<ALL FILES>>\", \"execute\";\n" +
            "};";
    final static String path = "C:\\Users\\Administrator\\.java.policy";

    public static void bypass() throws IOException {
        FileWriter writer = new FileWriter(path); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs2

        writer.write(homePolicyFile); //@ JAVA_POLICY_MANIPULATION-geooj4
        writer.close();
    }

    public static void bypass2() throws IOException {
        FileOutputStream outputStream = new FileOutputStream(path); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs2
        byte[] strToBytes = homePolicyFile.getBytes();

        outputStream.write(strToBytes); //@ JAVA_POLICY_MANIPULATION-geooj4
        outputStream.close();
    }

    public static void bypass3() throws IOException {
        FileOutputStream fos = new FileOutputStream(path);
        DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos)); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs2

        outStream.writeUTF(homePolicyFile); //@ JAVA_POLICY_MANIPULATION-geooj6
        outStream.close();
    }

    public static void bypass4() throws IOException {
        RandomAccessFile writer = new RandomAccessFile(path, "rw");
        writer.seek(0);

        writer.writeUTF(homePolicyFile); //@ JAVA_POLICY_MANIPULATION-geooj6
        writer.close();
    }

    public static void bypassWeb(ServerSocket socket) throws IOException {
        FileWriter writer = new FileWriter(path); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs2

        writer.write(FLAG_WEB.WEB_chp0rr(socket).toString()); //@ JAVA_POLICY_MANIPULATION-geooj5
        writer.close();
    }
}
