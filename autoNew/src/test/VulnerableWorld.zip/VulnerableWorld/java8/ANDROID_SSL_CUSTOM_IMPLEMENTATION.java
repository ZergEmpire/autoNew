package integration.java8;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class ANDROID_SSL_CUSTOM_IMPLEMENTATION {
    public void test() throws NoSuchAlgorithmException, KeyManagementException
    {
        final TrustManager[] trustManagers = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).getTrustManagers();
        X509TrustManager x509Tm = null;
        for (TrustManager tm : trustManagers) {
            if (tm instanceof X509TrustManager) {
                x509Tm = (X509TrustManager) tm;
                break;
            }
        }
        final X509TrustManager finalTm = x509Tm;
        X509TrustManager customTm = new X509TrustManager() { //@ ANDROID_SSL_CUSTOM_IMPLEMENTATION_CUSTOM-e1c9ce
            @Override
            public X509Certificate[] getAcceptedIssuers()
            {
                return finalTm.getAcceptedIssuers();
            }

            @Override
            public void checkServerTrusted(
                X509Certificate[] chain,
                String authType) throws CertificateException
            {
                finalTm.checkServerTrusted(chain, authType);
            }

            @Override
            public void checkClientTrusted(
                X509Certificate[] chain,
                String authType) throws CertificateException
            {
                finalTm.checkClientTrusted(chain, authType);
            }
        };
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[] {customTm}, null);
        SSLContext.setDefault(sslContext);
    }

    public void test2() throws NoSuchAlgorithmException, KeyManagementException
    {
        final TrustManager[] trustManagers = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).getTrustManagers();
        X509TrustManager x509Tm = null;
        for (TrustManager tm : trustManagers) {
            if (tm instanceof X509TrustManager) {
                x509Tm = (X509TrustManager) tm;
                break;
            }
        }
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[] {x509Tm}, null);
        SSLContext.setDefault(sslContext);
    }

    public void test3() throws NoSuchAlgorithmException, KeyManagementException
    {
        final TrustManager[] trustManagers = new TrustManager[] {
            new X509TrustManager() { //@ ANDROID_SSL_CUSTOM_IMPLEMENTATION_EMPTY-73a33c
                @Override
                public void checkClientTrusted(
                    final X509Certificate[] chain,
                    final String authType) throws CertificateException
                {

                }

                @Override
                public void checkServerTrusted(
                    final X509Certificate[] chain,
                    final String authType) throws CertificateException
                {

                }

                @Override
                public X509Certificate[] getAcceptedIssuers()
                {
                    return new X509Certificate[0];
                }
            }
        };
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustManagers, null);
        SSLContext.setDefault(sslContext);
    }
}
