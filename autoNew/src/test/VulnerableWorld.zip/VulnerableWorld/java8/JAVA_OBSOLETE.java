package integration.java8;

import com.google.gwt.user.client.WindowCloseListener;

public class JAVA_OBSOLETE {
    private String createstrfrombytearray(String str) {
        byte[] str_ = str.getBytes();

        String s = new String(str_); //@ JAVA_OBSOLETE-bts001
        return s;
    }
    String getstring(){
        return createstrfrombytearray("paprica");
    }
    public static void main(String[] args){
        JAVA_OBSOLETE a = new JAVA_OBSOLETE(); //@ JAVA_J2EE_DEBUG_CODE-514398
        String b = a.getstring(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}

class TT implements WindowCloseListener {

    @Override
    public String onWindowClosing()
    {
        return null;
    }

    @Override
    public void onWindowClosed()
    {
        onWindowClosing(); //@ JAVA_OBSOLETE-13a63f
    }
}
