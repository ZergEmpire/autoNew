void main() {
  // <yes> <report> DART_PASSWORD_HARDCODED nu7fkd
  const password = 'secret';
  // <yes> <report> DART_PASSWORD_HARDCODED 83bfkd
  var pass123 = 'password123';
  // <yes> <report> DART_PASSWORD_HARDCODED yd9kst
  String password = "hardcoded password";
  // <yes> <report> DART_PASSWORD_HARDCODED nu7fkd
  int password = 1234;
  // <yes> <report> DART_PASSWORD_HARDCODED 83bfkd
  var smth_password = 1234567;
  // <yes> <report> DART_PASSWORD_HARDCODED 8sg3nf
  var smth_password = "pass hard";

  var passw;
  // <yes> <report> DART_PASSWORD_HARDCODED ppqy89
  passw = 'sec ret';

  String pass;
  // <yes> <report> DART_PASSWORD_HARDCODED 1n0fhr
  pass = 'pass word1';

  int password_smth;
  // <yes> <report> DART_PASSWORD_HARDCODED 2bdp09
  password_smth = 109876;

  int password;
  // <yes> <report> DART_PASSWORD_HARDCODED 4s2h9k
  password = 00000;

}