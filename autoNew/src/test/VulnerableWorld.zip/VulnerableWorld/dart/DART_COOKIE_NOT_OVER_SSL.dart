void main() {
  // <yes> <report> DART_COOKIE_NOT_OVER_SSL cv4gr8
  var cookie = new Cookie.fromSetCookieValue("name=val; domain=example.com; path=/admin; HttpOnly; expires=Sat, 08 Sep 2018 16:54:31 GMT");
  // <yes> <report> DART_COOKIE_NOT_OVER_SSL 001gbc
  final Cookie cookie = Cookie.fromSetCookieValue("name=val; domain=example.com; path=/admin; HttpOnly");

  var cookie_1 = new Cookie("name", "value");
  // <yes> <report> DART_COOKIE_NOT_OVER_SSL nn5hoi
  cookie_1.secure = false;

  // <no> <report>
  final Cookie cookie = Cookie.fromSetCookieValue("name=val; domain=example.com; path=/admin; HttpOnly; Secure");
}