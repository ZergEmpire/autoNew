void main(){
  // <yes> <report> DART_HTTP_USAGE nwivci
  var url1 = 'http://url.url';
  // <yes> <report> DART_HTTP_USAGE 8qye56
  final url2 = 'http://localhost';
  // <yes> <report> DART_HTTP_USAGE 8qye56
  const url3 = 'http://localhost';

  // <yes> <report> DART_HTTP_USAGE lsnfje
  final response = await http.get('http://url.url');
  // <yes> <report> DART_HTTP_USAGE lsnfje
  final httpRequest = await HttpRequest.request('http://url.url', method: _postMethod, sendData: buffer);

  var httpRequest = new HttpRequest();
  // <yes> <report> DART_HTTP_USAGE mm7dhe
  httpRequest.open('GET', 'http://localhost');
}