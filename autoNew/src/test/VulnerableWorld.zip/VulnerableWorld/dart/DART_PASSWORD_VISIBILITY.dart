import 'package:flutter/material.dart';

Widget _buildPasswordTextField() {
  // <yes> <report> DART_PASSWORD_VISIBILITY gr0051
  return TextField(
    obscureText: false,
    decoration: InputDecoration(
      labelText: 'password',
      hintText: 'Enter your password',
      prefixIcon: Icon(Icons.security),
      suffixIcon: IconButton(
        icon: Icon(
          Icons.remove_red_eye,
          color: Colors.grey,
        ),
      ),
    ),
  );
}

Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: Theme.of(context).secondaryHeaderColor,
    body: Center(
      // <yes> <report> DART_PASSWORD_VISIBILITY gr0051
      child: TextFormField(
        obscureText: false,
        decoration: InputDecoration(
          hintText: 'Enter your password',
          suffix: InkWell(
            onTap: _togglePasswordView,
            child: Icon( Icons.visibility),
          ),
        ),
      ),
    ),
  );
}

Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: Theme.of(context).secondaryHeaderColor,
    body: Center(
      // <no> <report>
      child: TextFormField(
        obscureText: true,
        decoration: InputDecoration(
          hintText: 'Enter your password',
          suffix: InkWell(
            onTap: _togglePasswordView,
            child: Icon( Icons.visibility),
          ),
        ),
      ),
    ),
  );
}