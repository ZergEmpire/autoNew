void main() {
  // <yes> <report> DART_BACKDOOR_SPECIAL_ACCOUNT gr0052
  if (password == "qwerty") {
    print('Hello, World!');
  }
  // <no> <report>
  if (password == true) {
    print('Hello, World!');
  }
  // <yes> <report> DART_BACKDOOR_SPECIAL_ACCOUNT gr0053
  if (hash == "8743b52063cd84097a65d1633f5c74f5") {
    print('Hello, World!');
  }
  // <no> <report>
  if (password == "") {
    print('Hello, World!');
  }
}