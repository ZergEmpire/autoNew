void main() {
  // <yes> <report> DART_PASSWORD_NULL n5l02h
  String userPassword;
  // <yes> <report> DART_PASSWORD_NULL 1230ll
  int pass = null;
  // <yes> <report> DART_PASSWORD_NULL 925462
  var smth_password = null;

  var password_1;
  // <yes> <report> DART_PASSWORD_HARDCODED 2bdp09
  password_1 = 123948;
}