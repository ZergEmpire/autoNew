package main

import "net/http"

func main() {
	expire := time.Now().Add(15 * time.Minute) // Expires in 15 minutes
	// <yes> <report> GO_COOKIE_PERSISTENT gtrlkd
	cookie = http.Cookie{Name: "secureusername", Value: "secureuser", Path: "/path", Domain: "www.example.com", Expires: expire, MaxAge: 86400, HttpOnly: true, Secure: true}
	// <yes> <report> GO_COOKIE_PERSISTENT 32nmww
	cookie3 := http.Cookie{"test", "tcookie", "/path", "www.domain.com", expire, expire.Format(time.UnixDate), 86400, true, true, "test=tcookie", []string{"test=tcookie"}}
	http.SetCookie(w, &cookie)
	// <yes> <report> GO_COOKIE_PERSISTENT poejwn
	session.Options = &sessions.Options{
		Path:     "/path",
		Domain: "secure.example.com",
		MaxAge:   3000,
		HttpOnly: true,
		Secure: true,
	}
}