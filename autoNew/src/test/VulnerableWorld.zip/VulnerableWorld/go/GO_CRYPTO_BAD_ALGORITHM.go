package main

import (
    "crypto/rc4"
)

func main() {
    
    key := []byte{ 1, 2, 3, 4, 5, 6, 7 }
    // <yes> <report> GO_CRYPTO_BAD_ALGORITHM 000001
    c, err := rc4.NewCipher(key)

    if err != nil {
    log.Fatalf("Failed to encrypt message %v", err)
    return nil, err
    }
}