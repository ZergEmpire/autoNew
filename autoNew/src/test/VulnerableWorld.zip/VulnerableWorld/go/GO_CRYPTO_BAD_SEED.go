package main

import "fmt"
import "math/rand"

func main() {
    // <yes> <report> GO_CRYPTO_BAD_SEED 000005 <yes> <report> GO_CRYPTO_BAD_RANDOM 000004
    s1 := rand.NewSource(123)
    // <yes> <report> GO_CRYPTO_BAD_RANDOM 000004 <no> <report> GO_CRYPTO_BAD_SEED 000005
    s1 := rand.NewSource(time.Now().UnixNano())
    // <yes> <report> GO_CRYPTO_BAD_SEED 000006 <yes> <report> GO_CRYPTO_BAD_RANDOM 000004
    rand.Seed(42);
}
