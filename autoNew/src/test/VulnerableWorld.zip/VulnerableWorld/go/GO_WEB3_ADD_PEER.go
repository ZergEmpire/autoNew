package main

import (
    "github.com/ethereum/go-ethereum/admin"
)

func main() {
    var res bool
    // <yes> <report> GO_WEB3_ADD_PEER bnm642
    res, _ = admin.AddPeer(stringArg)
}
