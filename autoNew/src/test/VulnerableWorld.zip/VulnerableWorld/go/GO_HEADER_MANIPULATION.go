package main

import (
	"net/http"
)

func main(r *http.Request, request interface{}) {
	headerer, ok := request.(Headerer)
	//<yes> <report> GO_HEADER_MANIPULATION 700000
	r.Header.Set(0, headerer.Headers().Get(0))
}
