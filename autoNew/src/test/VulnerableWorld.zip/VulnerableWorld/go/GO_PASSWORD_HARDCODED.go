package main

import (
    "golang.org/x/crypto/bcrypt"
    "fmt"
)

func main() {

    // <yes> <report> GO_PASSWORD_HARDCODED 100007
    pass := []byte("mypassword")
    // <yes> <report> GO_PASSWORD_HARDCODED 100007
    password := []byte("gkg,gf")

    // <yes> <report> GO_PASSWORD_HARDCODED 000lk9
    hash, err := bcrypt.GenerateFromPassword("password", bcrypt.DefaultCost)
    // <yes> <report> GO_PASSWORD_HARDCODED 000lkt
    hash, err := bcrypt.GenerateFromPassword("pass word", bcrypt.DefaultCost)
    if err != nil {
        panic(err)
    }
    fmt.Println(string(hashedPassword))

    // <yes> <report> GO_PASSWORD_HARDCODED 000008
    err = bcrypt.CompareHashAndPassword(hashedPassword, "password")
    // <yes> <report> GO_PASSWORD_HARDCODED 00008t
    err = bcrypt.CompareHashAndPassword(hashedPassword, "pas sword")
    fmt.Println(err) // nil means it is a match
    
    // It needs type propogation
    req, err := http.NewRequest("GET", url, nil)
    // <yes> <report> GO_PASSWORD_HARDCODED 000010
    req.SetBasicAuth("username", "password")
    // <yes> <report> GO_PASSWORD_HARDCODED 00010t
    req.SetBasicAuth("username", "passw ord")
    // <yes> <report> GO_PASSWORD_HARDCODED 000020
    dk, err := scrypt.Key([]byte("somepassword"), salt, 1<<15, 8, 1, 32)
    // <yes> <report> GO_PASSWORD_HARDCODED 00020t
        dk, err := scrypt.Key([]byte("some password"), salt, 1<<15, 8, 1, 32)

    newPasswd := pbkdf2.Key([]byte(u.Passwd), []byte(u.Salt), 10000, 50, sha256.New)
    // <yes> <report> GO_PASSWORD_HARDCODED 000007
    newPasswd := "acskmkad"
    // <yes> <report> GO_PASSWORD_HARDCODED 00007t
    newPasswd := "acs kmkad"
    passwordModifyRequestValue := ber.Encode(ber.ClassUniversal, ber.TypeConstructed, ber.TagSequence, nil, "Password Modify Request")
}

func TestCostValidationInHash(t *testing.T) {
	if testing.Short() {
		return
	}
    // <yes> <report> GO_PASSWORD_HARDCODED 100007
	pass := []byte("mypassword")
	// <yes> <report> GO_PASSWORD_HARDCODED 10007t
    pass := []byte("mypas sword")
}