package main

import "crypto/hmac"

func main() {
    // <yes> <report> GO_CRYPTO_KEY_EMPTY 000028
    mac := hmac.New(sha256.New, "")
    mac.Write(message)
    expectedMAC := mac.Sum(nil)
    // <yes> <report> GO_CRYPTO_KEY_EMPTY 000031
    bf, _ := blowfish.NewCipher("")
    return hmac.Equal(messageMAC, expectedMAC)
    // <yes> <report> GO_CRYPTO_KEY_EMPTY frelsd
    var store = sessions.NewCookieStore(securecookie.GenerateRandomKey(),
	[]byte(""))
}
