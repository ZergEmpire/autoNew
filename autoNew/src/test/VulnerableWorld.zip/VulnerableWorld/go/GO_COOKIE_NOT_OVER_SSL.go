package main

import "net/http"

func main() {
	expire := time.Now().Add(15 * time.Minute) // Expires in 15 minutes
	// <yes> <report> GO_COOKIE_NOT_OVER_SSL rekwsn
	cookie = http.Cookie{Name: "secureusername", Value: "secureuser", Path: "/path", Domain: "site.example.com", Expires: expire, MaxAge: 50, HttpOnly: true, Secure: false}
	// <yes> <report> GO_COOKIE_NOT_OVER_SSL eqkall
	cookie2 = http.Cookie{Name: "secureusername", Value: "secureuser", Path: "/path", Domain: "site.example.com", Expires: expire, MaxAge: 50, HttpOnly: true}
	// <yes> <report> GO_COOKIE_NOT_OVER_SSL 4h2kes
	cookie3 := http.Cookie{"test", "tcookie", "/path", "www.domain.com", expire, expire.Format(time.UnixDate), 50, true, false, "test=tcookie", []string{"test=tcookie"}}
	http.SetCookie(w, &cookie)
	// <yes> <report> GO_COOKIE_NOT_OVER_SSL olrwks
	session.Options = &sessions.Options{
		Path:     "/path",
		Domain: "secure.example.com",
		MaxAge:   100,
		HttpOnly: true,
		Secure: false,
	}
	// <yes> <report> GO_COOKIE_NOT_OVER_SSL ojrnsd
	csrf.Protect([]byte("32-byte-long-auth-key"), csrf.Secure(false))(r)
}