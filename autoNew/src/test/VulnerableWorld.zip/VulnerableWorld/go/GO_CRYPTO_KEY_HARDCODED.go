package main

import "crypto/hmac"

func main() {
    // <yes> <report> GO_CRYPTO_KEY_HARDCODED 000029
    mac := hmac.New(sha256.New, "key")
    mac.Write(message)
    expectedMAC := mac.Sum(nil)
    // <yes> <report> GO_CRYPTO_KEY_HARDCODED 000032
    bf, _ := blowfish.NewCipher("key")
    return hmac.Equal(messageMAC, expectedMAC)
    // <yes> <report> GO_CRYPTO_KEY_HARDCODED uhrwks
    var store = sessions.NewCookieStore(securecookie.GenerateRandomKey(),
	[]byte("new-encryption-key"))
}
