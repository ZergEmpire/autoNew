package main

import "net/http"
import "github.com/gorilla/handlers"

func main() {
	// <yes> <report> GO_HTML5_CORS tgnews
	c := cors.New(cors.Options{
		AllowedOrigins: []string{"*"},
		AllowedMethods: []string{"GET", "POST", "DELETE"},
		AllowCredentials: true,
	})
	// <yes> <report> GO_HTML5_CORS rtj3kw
	corsObj:=handlers.AllowedOrigins([]string{"*"})
	// <yes> <report> GO_HTML5_CORS rtj3kr
	w.Header().Set("Access-Control-Allow-Origin", "*")
}