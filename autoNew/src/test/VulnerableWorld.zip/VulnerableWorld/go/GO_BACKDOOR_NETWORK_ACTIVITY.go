package main
import (
	"fmt"
	"net/http"
	"net"
)
func main() {
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004 <yes> <report> GO_BIND_ALL_INTERFACES 400001
	listener, err := net.Listen("tcp", ":4545")
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00008
	conn, err := net.Dial("tcp", "golang.org:80")

	http.get(url)
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url1 := "https://example.com/"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne001
	url2 := "https://localhost"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url3 := "5.4.3.2"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url4 := "https://1.1.1.1/"
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne002
    MyStruct{Url: "https://schema.url"}
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url4 := "https://1.1.1.1/sards"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url4 := "https://[::1]"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url4 := "https://[fe80::219:7eff:fe46:6c42]"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url4 := "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]"
    //<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	url4 := "https://[::00:192.168.10.184]"

}
