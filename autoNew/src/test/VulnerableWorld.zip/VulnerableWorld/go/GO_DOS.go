package main

import (
	"net/http"
	"time"
	"flag"
	"strings"
)

func main(r *http.Request) {
	//<yes> <report> GO_DOS 800000
	for _, cType := range r.Header[headerContentType] {
	}
	//<no> <report>
	for _, cType := range r.NotHeader[headerContentType] {
	}
	//<yes> <report> GO_DOS 800001
	time.Sleep(delay)
	//<no> <report>
	time.Sleep(10)
	//<yes> <report> GO_DOS 800002
	for _, arg := range flag.Args() {
	}
	//<yes> <report> GO_DOS 800003
	for _, s := range strings.Split(os.Getenv("DSTDEBUG"), ",") {
	}
}
