package main

import "net/http"

func main() {
	expire := time.Now().Add(15 * time.Minute) // Expires in 15 minutes
	// <yes> <report> GO_COOKIE_NOT_HTTPONLY gjrkws
	cookie = http.Cookie{Name: "secureusername", Value: "secureuser", Path: "/path", Domain: "site.example.com", Expires: expire, MaxAge: 50, HttpOnly: false, Secure: true}
	// <yes> <report> GO_COOKIE_NOT_HTTPONLY gejl3w
	cookie2 = http.Cookie{Name: "secureusername", Value: "secureuser", Path: "/path", Domain: "site.example.com", Expires: expire, MaxAge: 50, Secure: true}
	// <yes> <report> GO_COOKIE_NOT_HTTPONLY uin3ws
	cookie3 := http.Cookie{"test", "tcookie", "/path", "www.domain.com", expire, expire.Format(time.UnixDate), 50, false, true, "test=tcookie", []string{"test=tcookie"}}
	http.SetCookie(w, &cookie)
	// <yes> <report> GO_COOKIE_NOT_HTTPONLY opwkms
	session.Options = &sessions.Options{
		Path:     "/path",
		Domain: "secure.example.com",
		MaxAge:   100,
		HttpOnly: false,
		Secure: true,
	}
	// <yes> <report> GO_COOKIE_NOT_HTTPONLY o8iejs
	csrf.Protect([]byte("32-byte-long-auth-key"), csrf.HttpOnly(false))(r)
}