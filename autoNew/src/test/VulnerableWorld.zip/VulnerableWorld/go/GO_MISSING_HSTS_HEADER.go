package main

func hookHandler(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Strict-Transport-Security", "max-age=31536000")
	go generateHTML()
	w.Write(doneResp)
}

func hookHandler(w http.ResponseWriter, r *http.Request) {
//<yes> <report> GO_MISSING_HSTS_HEADER ptcn12
    w.Header().Set("Strict-Transport-Security", "max-age=3136000")
	go generateHTML()
	w.Write(doneResp)
}

//<yes> <report> GO_MISSING_HSTS_HEADER ptcn11
func hookHandler(w http.ResponseWriter, r *http.Request) {
	go generateHTML()
	w.Write(doneResp)
}