package main

import "net/http"

func main() {
	expire := time.Now().Add(15 * time.Minute) // Expires in 15 minutes
	// <yes> <report> GO_COOKIE_BROAD_PATH frejwk
	cookie = http.Cookie{Name: "secureusername", Value: "secureuser", Path: "/", Domain: "site.example.com", Expires: expire, MaxAge: 50, HttpOnly: true, Secure: true}
	// <yes> <report> GO_COOKIE_BROAD_PATH rgkele
	cookie3 := http.Cookie{"test", "tcookie", "/", "www.domain.com", expire, expire.Format(time.UnixDate), 50, true, true, "test=tcookie", []string{"test=tcookie"}}
	http.SetCookie(w, &cookie)
	// <yes> <report> GO_COOKIE_BROAD_PATH iowjns
	session.Options = &sessions.Options{
		Path:  "/",
		Domain: "secure.example.com",
		MaxAge:   100,
		HttpOnly: true,
		Secure: true,
	}
	// <yes> <report> GO_COOKIE_BROAD_PATH 7uehww
	csrf.Protect([]byte("32-byte-long-auth-key"), csrf.Path("/"))(r)
}