package main

import (
// <yes> <report> GO_UNSAFE_PACKAGE_USAGE fjekss
    "unsafe"
    "fmt"
)

func main() {}