package main

import (
	"golang.org/x/crypto/pbkdf2"
)


func main() {
	// <yes> <report> GO_CRYPTO_BAD_ITERATION_COUNT 500000 <yes> <report> GO_PASSWORD_HARDCODED 00020t
	dk := pbkdf2.Key([]byte("some text"), salt, 4096, 32, sha256.New)
}