package main

import "fmt"

func main() {
//<yes> <report> GO_LOGGING_SYSTEM_OUTPUT a00003
fmt.Println("abc")
}