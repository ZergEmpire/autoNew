package main

import (
	"bytes"
	"net/http"
)


func main() *httptest.Server  {
	mux := http.NewServeMux()
	//<yes> <report> GO_MISSING_HSTS_HEADER ptcn11
	mux.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" {
			w.Header().Set("Content-Type", "text/html")
			//<yes> <report> GO_XSS_REFLECTED 900000
			w.Write([]byte(r.FormValue("name")))
			//<no> <report>
			w.Write("name")
		}
	})
}