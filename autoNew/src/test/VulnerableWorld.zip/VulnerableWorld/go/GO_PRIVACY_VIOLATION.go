package main

import "net/url"

func ExampleURL_String() {
    u := &url.URL{
		Scheme:   "https",
		// <yes> <report> GO_PRIVACY_VIOLATION fwjkww
		User:     url.UserPassword("me", "pass"),
		Host:     "example.com",
		Path:     "foo/bar",
	    RawQuery: "x=1&y=2",
	    Fragment: "anchor",
    }
    fmt.Println(u.String())
    // Output:
    // https://me:pass@example.com/foo/bar?x=1&y=2#anchor
}