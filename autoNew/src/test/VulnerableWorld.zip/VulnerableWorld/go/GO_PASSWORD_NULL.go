package main

import (
    "golang.org/x/crypto/bcrypt"
    "fmt"
)

func main() {
    // <yes> <report> GO_PASSWORD_NULL 000015
    password := nil

    // <yes> <report> GO_PASSWORD_NULL 000017
    hash, err := bcrypt.GenerateFromPassword(nil, bcrypt.DefaultCost)
    if err != nil {
        panic(err)
    }
    fmt.Println(string(hashedPassword))

    // <yes> <report> GO_PASSWORD_NULL 000016
    err = bcrypt.CompareHashAndPassword(hashedPassword, nil)
    fmt.Println(err) // nil means it is a match
    
    // It needs type propogation
    req, err := http.NewRequest("GET", url, nil)
    // <yes> <report> GO_PASSWORD_NULL 000018
    req.SetBasicAuth("username", nil)
    // <yes> <report> GO_PASSWORD_NULL 000022
    dk, err := scrypt.Key(nil, salt, 1<<15, 8, 1, 32)
}