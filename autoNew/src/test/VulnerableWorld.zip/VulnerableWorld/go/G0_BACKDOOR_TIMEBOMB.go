package main

import "time"

func main() {
	//<yes> <report> GO_BACKDOOR_TIMEBOMB a00001
	timer1 := time.NewTimer(time.Second*100)
	//<yes> <report> GO_BACKDOOR_TIMEBOMB a00001
	timer2 := time.NewTicker(time.Second*100)
	//<yes> <report> GO_BACKDOOR_TIMEBOMB aa0002
	if time.Now() == time.Date(2009, 11, 17, 20, 34, 58, 651387237, time.UTC) {
	}
	//<yes> <report> GO_BACKDOOR_TIMEBOMB aa0002
	if times == time.Date(2009, 11, 17, 20, 34, 58, 651387237, time.UTC) {
	}
	//<yes> <report> GO_BACKDOOR_TIMEBOMB aa0002
	if times > time.Date(2009, 11, 17, 20, 34, 58, 651387237, time.UTC) {
	}
	//<yes> <report> GO_BACKDOOR_TIMEBOMB aa0002
	if "1" == time.Date(2009, 11, 17, 20, 34, 58, 651387237, time.UTC) {
	}
	//<no> <report>
	if times == "1" {
	}
}