package main

import (
    "golang.org/x/crypto/bcrypt"
    "fmt"
)

func main() {
    // <yes> <report> GO_PASSWORD_EMPTY 100017
    password := []byte("")

    // <yes> <report> GO_PASSWORD_EMPTY 000013
    hash, err := bcrypt.GenerateFromPassword("", bcrypt.DefaultCost)
    if err != nil {
        panic(err)
    }
    fmt.Println(string(hashedPassword))

    // <yes> <report> GO_PASSWORD_EMPTY 000012
    err = bcrypt.CompareHashAndPassword(hashedPassword, "")
    fmt.Println(err) // nil means it is a match
    
    // It needs type propogation
    req, err := http.NewRequest("GET", url, nil)
    // <yes> <report> GO_PASSWORD_EMPTY 000014
    req.SetBasicAuth("username", "")
    // <yes> <report> GO_PASSWORD_EMPTY 000021
    dk, err := scrypt.Key("", salt, 1<<15, 8, 1, 32)
}