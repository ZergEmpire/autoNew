package main

import (
	"crypto/md5"
	"fmt"
	"io"
)

func main() {
	// <yes> <report> GO_CRYPTO_BAD_HASH 000002
	h := md5.New()
	// io.WriteString(h, "The fog is getting thicker!")
}