package integration.java11

import io.ktor.application.call
import io.ktor.response.header
import io.ktor.routing.get
import io.ktor.routing.routing
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import java.net.URLEncoder
import java.nio.charset.Charset

fun main(args: Array<String>) {
    embeddedServer(Netty, 8080) {//@ JAVA_J2EE_DEBUG_CODE-514398
        routing {
            get("/") {//@ JAVA_BACKDOOR_DEAD_CODE-d27d09
                val env = System.getenv("env") //@ KOTLIN_USE_GETENV-f9b0b0
                call.response.headers.append("Name", env) //@ KOTLIN_HEADER_MANIPULATION-mfjjgr
                call.response.headers.append("Name", URLEncoder.encode(env, Charset.defaultCharset()))
                call.response.header("Name", env) //@ KOTLIN_HEADER_MANIPULATION-nfjswl
                call.response.header("Name", URLEncoder.encode(env, Charset.defaultCharset()))
            }
        }
    }.start(wait = true)
}
