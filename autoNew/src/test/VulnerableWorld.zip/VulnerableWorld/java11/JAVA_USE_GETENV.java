package integration.java11;

import java.util.stream.Stream;

public class JAVA_USE_GETENV {

    public Stream<String> foo() {
        return System.getenv("vat").lines(); //@ JAVA_USE_GETENV-f9b0b0
    }
}
