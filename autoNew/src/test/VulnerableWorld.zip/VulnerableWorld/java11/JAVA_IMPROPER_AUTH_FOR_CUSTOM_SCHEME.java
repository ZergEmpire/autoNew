package newIntegration;

import java.net.URL;

public class JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME {

    String userData;

    public class WebView {
        final Object webView = new Object();
    }

    public JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME(String text) {
        this.userData = text;
    }

    public void writeDataToView(WebView a, String b) {
    }

    public boolean shouldOverrideUrlLoading(WebView view, URL url) {
        if (url.toString().substring(0,14).equalsIgnoreCase("examplescheme:")) { //@ JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME-fjstnd,JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
            if(url.toString().substring(14,25).equalsIgnoreCase("getUserInfo")) { //@ JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME-fjstnd,JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
                this.writeDataToView(view, this.userData);
                return false;
            } else {
                return true;
            }
        }
        return true;
    }
}
