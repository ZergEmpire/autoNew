package integration.java11

import io.ktor.application.call
import io.ktor.response.respondRedirect
import io.ktor.routing.get
import io.ktor.routing.routing
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty

fun main(args: Array<String>) {
    embeddedServer(Netty, 8080) {//@ JAVA_J2EE_DEBUG_CODE-514398
        routing {
            get("/") {//@ JAVA_BACKDOOR_DEAD_CODE-d27d09
                call.parameters["q"]?.let { it1 -> call.respondRedirect(it1) } //@ JAVA_OPEN_REDIRECT-mfjdke
                call.respondRedirect(args[0]) //@ JAVA_OPEN_REDIRECT-mfjdke
            }
        }
    }.start(wait = true)
}
