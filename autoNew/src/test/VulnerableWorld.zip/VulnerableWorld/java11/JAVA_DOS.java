package newIntegration;

import java.net.http.HttpClient;
import java.time.Duration;

public class JAVA_DOS {

    public void test() {
        var tainted = Integer.parseInt(System.getenv("env")); //@ JAVA_USE_GETENV-f9b0b0
        HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(tainted)) //@ JAVA_DOS-ngjfdl
            .build();
    }
}
