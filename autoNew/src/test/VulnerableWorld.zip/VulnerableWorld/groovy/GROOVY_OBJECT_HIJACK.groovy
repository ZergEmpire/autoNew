class GROOVY_OBJECT_HIJACK implements Cloneable{
    class GROOVY_OBJECT_HIJACK_ implements Cloneable{
        private char[] filename;
        private Boolean shared = false;
        private String accnum = "0000xF";
        SensitiveClass(String filename) {
            this.filename = filename.toCharArray();
        }
        //<yes><report> GROOVY_OBJECT_HIJACK asfgr4
        public Object clone(String accnum) throws CloneNotSupportedException{
            Object returnMe = new GROOVY_OBJECT_HIJACK(this.filename);
            returnMe.shared = this.shared;
            returnMe.accnum = accnum;
            return returnMe;
        }

        final void replace() {
            if (!shared) {
                for(int i = 0; i < filename.length; i++) {
                    filename[i]= 'x' ;}
            }
        }

        final String get() {
            if (!shared) {
                shared = true;
                return String.valueOf(filename);
            } else {
                throw new IllegalStateException("Failed to get instance");
            }
        }

        final void printFilename() {
            System.out.println(String.valueOf(filename));
        }
    }
    class GROOVY_OBJECT_HIJACK__ implements Cloneable{
        private char[] filename;
        private Boolean shared = false;
        private String accnum = "0000xF";
        SensitiveClass(String filename) {
            this.filename = filename.toCharArray();
        }

        final Object clone(String accnum) throws CloneNotSupportedException{
            Object returnMe = new GROOVY_OBJECT_HIJACK(this.filename);
            returnMe.shared = this.shared;
            returnMe.accnum = accnum;
            return returnMe;
        }

        final void replace() {
            if (!shared) {
                for(int i = 0; i < filename.length; i++) {
                    filename[i]= 'x' ;}
            }
        }

        final String get() {
            if (!shared) {
                shared = true;
                return String.valueOf(filename);
            } else {
                throw new IllegalStateException("Failed to get instance");
            }
        }

        final void printFilename() {
            System.out.println(String.valueOf(filename));
        }
    }

    class GROOVY_OBJECT_HIJACK_0 implements Cloneable{
        private char[] filename;
        private Boolean shared = false;
        private String accnum = "0000xF";
        SensitiveClass(String filename) {
            this.filename = filename.toCharArray();
        }

        public final Object clone(String accnum) throws CloneNotSupportedException{
            Object returnMe = new GROOVY_OBJECT_HIJACK(this.filename);
            returnMe.shared = this.shared;
            returnMe.accnum = accnum;
            return returnMe;
        }

        final void replace() {
            if (!shared) {
                for(int i = 0; i < filename.length; i++) {
                    filename[i]= 'x' ;}
            }
        }

        final String get() {
            if (!shared) {
                shared = true;
                return String.valueOf(filename);
            } else {
                throw new IllegalStateException("Failed to get instance");
            }
        }

        final void printFilename() {
            System.out.println(String.valueOf(filename));
        }
    }


    class GROOVY_OBJECT_HIJACK_1 implements Cloneable{
        private char[] filename;
        private Boolean shared = false;
        private String accnum = "0000xF";
        SensitiveClass(String filename) {
            this.filename = filename.toCharArray();
        }

        final public Object clone(String accnum) throws CloneNotSupportedException{
            Object returnMe = new GROOVY_OBJECT_HIJACK(this.filename);
            returnMe.shared = this.shared;
            returnMe.accnum = accnum;
            return returnMe;
        }

        final void replace() {
            if (!shared) {
                for(int i = 0; i < filename.length; i++) {
                    filename[i]= 'x' ;}
            }
        }

        final String get() {
            if (!shared) {
                shared = true;
                return String.valueOf(filename);
            } else {
                throw new IllegalStateException("Failed to get instance");
            }
        }

        final void printFilename() {
            System.out.println(String.valueOf(filename));
        }
    }


    private char[] filename;
    private Boolean shared = false;
    private String accnum = "0000xF";
    SensitiveClass(String filename) {
        this.filename = filename.toCharArray();
    }
    //<yes><report> GROOVY_OBJECT_HIJACK asfgr4
    Object clone(String accnum) throws CloneNotSupportedException{
        Object returnMe = new GROOVY_OBJECT_HIJACK(this.filename);
        returnMe.shared = this.shared;
        returnMe.accnum = accnum;
        return returnMe;
    }

    final void replace() {
        if (!shared) {
            for(int i = 0; i < filename.length; i++) {
                filename[i]= 'x' ;}
        }
    }

    final String get() {
        if (!shared) {
            shared = true;
            return String.valueOf(filename);
        } else {
            throw new IllegalStateException("Failed to get instance");
        }
    }

    final void printFilename() {
        System.out.println(String.valueOf(filename));
    }
    static public void main(String[] args){
        GROOVY_OBJECT_HIJACK a = new GROOVY_OBJECT_HIJACK();
        return;
    }
}