class GROOVY_INTEGER_OVERFLOW {
    public static void main(String[] args) {
        int a = -5;
        a = 5;
        //<yes><report> GROOVY_INTEGER_OVERFLOW asfgr6
        a = a + Integer.MAX_VALUE;
        //<yes><report> GROOVY_INTEGER_OVERFLOW asfgr5
        a = 5 + Integer.MAX_VALUE;
        //<no><report>
        a = -5 + Integer.MAX_VALUE;
        //<no><report> FN
        a = -(-5) + Integer.MAX_VALUE;
        return;
    }
}