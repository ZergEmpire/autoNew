class GROOVY_CRYPTO_KEY_NULL {
    def key() {
    	// <yes> <report> GROOVY_CRYPTO_KEY_NULL pmm436
        SecretKeySpec signingKey = new SecretKeySpec(null, 
                                                    "HmacSHA256");
        // <yes> <report> GROOVY_CRYPTO_KEY_NULL jjd433
        ciphertext = "someplaintext".bytes.encrypt(null)
    }
}