class GROOVY_CRYPTO_IV_NULL {
    def cryptoIVHardcoded() {
    	// <yes> <report> GROOVY_CRYPTO_IV_NULL tthgh0
        ciphertext = "some plaintext".bytes.encrypt(key: key, initializationVector: null, 
                                        prependIvToCipherText: true)
    }
}