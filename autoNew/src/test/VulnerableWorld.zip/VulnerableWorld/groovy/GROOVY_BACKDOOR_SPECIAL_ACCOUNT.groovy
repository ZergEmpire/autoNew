class GROOVY_BACKDOOR_SPECIAL_ACCOUNT {

	def specialAccount() {

		//<yes> <report> GROOVY_BACKDOOR_SPECIAL_ACCOUNT g11sa1
		if (password == "qwerty") {
			println "backdoor"
		}

		//<no> <report>
		if (password == true) {
			println "no report"
		}

		//<no> <report>
		if (password == false) {
			println "no report"
		}

		//<no> <report>
		if (password == null) {
			println "no report"
		}

		//<no> <report>
		if (loginNum == 123) {
			println "no report"
		}
	}
}