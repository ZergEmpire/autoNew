class GROOVY_CRYPTO_BAD_RANDOM {
    private def value
    private Random randomGen = new Random()

    GROOVY_CRYPTO_BAD_RANDOM() {
        // <yes> <report> GROOVY_CRYPTO_BAD_RANDOM jpks99
        this.value = randomGen.nextInt()
    }
    // <yes> <report> GROOVY_CRYPTO_BAD_RANDOM jpks99
    Math.abs(new Random().nextInt() % 600) + 1;
}
