class GROOVY_BACKDOOR_HIDDEN_FUNCTIONALITY{
    public static void main(String[] args){
        // <yes> <report> GROOVY_BACKDOOR_HIDDEN_FUNCTIONALITY gbh001
       ("sdaf").decodeBase64.execute();
        // <yes> <report> GROOVY_BACKDOOR_HIDDEN_FUNCTIONALITY gbh001
       "sdaf".decodeBase64.execute();

       ProcessBuilder a = new ProcessBuilder("ls -a");
       // <yes> <report> GROOVY_BACKDOOR_HIDDEN_FUNCTIONALITY gbh003
       Process b = a.start();
       // <yes> <report> GROOVY_BACKDOOR_HIDDEN_FUNCTIONALITY gbh002
       b = new ProcessBuilder(Base64.decodebase64("myCommand"), "myArg").start();
    }
}