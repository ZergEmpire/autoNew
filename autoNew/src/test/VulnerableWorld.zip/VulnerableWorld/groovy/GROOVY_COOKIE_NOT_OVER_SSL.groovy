import javax.servlet.http.Cookie

class GROOVY_COOKIE_NOT_OVER_SSL {
    def setCookieValue(name, value) {
        // <yes> <report> GROOVY_COOKIE_NOT_OVER_SSL tth399
        grails.plugins.cookie.secure.default = false
    }
}