import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class GROOVY_COOKIE_BROAD_DOMAIN {

    def setCookieValue(name, value) {
        def cookie = new Cookie(name, value)
        // <yes> <report> GROOVY_COOKIE_BROAD_DOMAIN rypc4t
        cookie.domain = '.example.com'
        // <yes> <report> GROOVY_COOKIE_BROAD_DOMAIN jwwr39
        cookie.setDomain('.example.com')
    }

}