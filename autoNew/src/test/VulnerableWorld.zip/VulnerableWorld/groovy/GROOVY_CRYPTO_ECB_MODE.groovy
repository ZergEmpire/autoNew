class GROOVY_CRYPTO_ECB_MODE {
    def cryptoECBMode() {
    // <yes> <report> GROOVY_CRYPTO_ECB_MODE wehgx3
    ciphertext = "some plaintext".padRight(16).bytes.encrypt(key: key, 
                                                            padding: 'NoPadding', 
                                                            mode: 'ECB')
    }
}
