class GROOVY_CRYPTO_BAD_HASH {
    def cryptoBadHash() {
    	// <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        "some string".encodeAsSHA1()
    	// <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        "some string".encodeAsSHA1Hex()
    	// <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        "some string".encodeAsMD5()
    	// <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        "some string".encodeAsMD5Hex()
        // <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        String hashFromContent = claimedContent.encodeAsMD5();
        // <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        byte[] passwordHash = params.password.encodeAsMD5Bytes()
        // <yes> <report> GROOVY_CRYPTO_BAD_HASH tt2ssw
        byte[] passwordHash = params.password.encodeAsSHA1Bytes()
        // <yes> <report> GROOVY_CRYPTO_BAD_HASH zzvv43
        grails.plugin.springsecurity.password.algorithm = 'MD5'
        // <yes> <report> GROOVY_CRYPTO_BAD_HASH wff087
        "Hello World!".bytes.md5().encodeHex()
        // <yes> <report> GROOVY_CRYPTO_BAD_HASH wff087
        def sha1 = new URL(jarLocation).openConnection().inputStream.sha1().encodeHex().toString()
    }
}
