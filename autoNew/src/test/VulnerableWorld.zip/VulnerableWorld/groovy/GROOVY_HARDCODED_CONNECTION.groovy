package java.sql;
class GROOVY_HARDCODED_CONNECTION {


    public static void Main() {
        String url = "jdbc:qwi39u1";
        //<yes> <report> GROOVY_PASSWORD_EMPTY fejrks
        def db_ = [url: 'hsqldb:mem:testDB', user: 'sa', password: '', driver: 'org.hsqldb.jdbc.JDBCDriver'];
        //<yes> <report> GROOVY_PASSWORD_EMPTY fejrks
        def db = [url: 'hsqldb:mem:testDB', user: 'sa', password: '', driver: 'org.hsqldb.jdbc.JDBCDriver'];
        def sql = Sql.newInstance(db.url, db.user, db.password, db.driver);
        //<no> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (this.dbms.equals("mysql")) {
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna006
            conn = DriverManager.getConnection(
                    "jdbc:" + this.dbms + "://" +
                            this.serverName +
                            ":" + this.portNumber + "/",
                    connectionProps);
        }

        String this_ = "jdbc:";
        //<no> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (this.dbms.equals("mysql")) {
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna007
            conn = DriverManager.getConnection(this_);
        }

        this_ = "jdbc:";
        //<no> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (this.dbms.equals("mysql")) {
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna007
            conn = DriverManager.getConnection(this_);
        }
        this_ = "jd";
        //<no> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (this.dbms.equals("mysql")) {
            // FALSE POSITIVE
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna007
            conn = DriverManager.getConnection(this_);
        }
        url = "jdbc:124";
        //<yes> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if ( true ) {
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna005
            def sql_ = Sql.newInstance(url, db.user, db.password, db.driver);
        }
        url = "jdbc: wf";
        String url_ = "jdbc:";
        //<yes> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if ( true ) {
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna005
            def sql_ = Sql.newInstance(url_, db.user, db.password, db.driver);
        }

        String url__ = "jdbc:arewff";
        //<yes> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if ( true ) {
            sql = Sql.new(url, db.user, db.password, db.driver);
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna005
            def sql_ = Sql.newInstance(url__, db.user, db.password, db.driver);
        }
        url_ = "jdbc:";
        url = "jdbc: wf";
        //<yes> <report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if ( true ) {
            //<yes> <report> GROOVY_HARDCODED_CONNECTION bna005
            def sql_ = Sql.newInstance(url_, db.user, db.password, db.driver);
        }
        //<yes> <report> GROOVY_HARDCODED_CONNECTION bna004
        def sql__ = Sql.newInstance("jdbc:liabilities", db.user, db.password, db.driver);
    }
}