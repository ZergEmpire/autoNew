class GROOVY_HTML5_CORS {
    def cors() {
        // <yes> <report> GROOVY_HTML5_CORS ss2227
        cors.headers = ['Access-Control-Allow-Origin': '*']
        // <yes> <report> GROOVY_HTML5_CORS st2hh1
        resp.addHeader("Access-Control-Allow-Origin", "*");
        // <yes> <report> GROOVY_HTTP_USAGE g11hu1 
        cors.headers = ['Access-Control-Allow-Origin': 'http://app.example.com',
    					'My-Custom-Header': 'some value']
    }
}