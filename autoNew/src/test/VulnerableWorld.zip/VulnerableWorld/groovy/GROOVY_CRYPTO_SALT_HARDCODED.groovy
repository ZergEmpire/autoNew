class GROOVY_CRYPTO_SALT_HARDCODED {
    def salt() {
        // <yes> <report> GROOVY_CRYPTO_SALT_HARDCODED pgh447
        KeySpec spec = new PBEKeySpec(pwd.toCharArray(), "salt", 20000, 128)
    	// <yes> <report> GROOVY_CRYPTO_SALT_HARDCODED jdd421
        SecretKeySpec secret = generateKey("salt")
        // <yes> <report> GROOVY_CRYPTO_SALT_HARDCODED ffg221
        key = 'some phrase'.toKey(salt: 'some salt'.bytes)
    }
}