class GROOVY_PRIVACY_VIOLATION_HEAP{
    //<yes> <report> GROOVY_PRIVACY_VIOLATION_HEAP pa2414
    String password;
    //<yes> <report> GROOVY_PRIVACY_VIOLATION_HEAP pa2414
    String passwd;
    //<yes> <report> GROOVY_PRIVACY_VIOLATION_HEAP pc2144
    String passwdAugh;
    //<yes> <report> GROOVY_PRIVACY_VIOLATION_HEAP pc2144
    String Aughpasswd;
    //<yes> <report> GROOVY_PRIVACY_VIOLATION_HEAP pc2144
    String passdfef;
    //<no> <report>
    String asfdscdsgpas
    public static void main(String[] args){
        //<yes> <report> GROOVY_PRIVACY_VIOLATION_HEAP pa2414
        String password;
    }

}