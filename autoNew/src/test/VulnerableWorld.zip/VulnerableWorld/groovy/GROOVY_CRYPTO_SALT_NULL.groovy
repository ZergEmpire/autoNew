class GROOVY_CRYPTO_SALT_NULL {
    def key() {
        // <yes> <report> GROOVY_CRYPTO_SALT_NULL pcc411
        KeySpec spec = new PBEKeySpec(pwd.toCharArray(), null, 20000, 128)
        // <no> <report> GROOVY_CRYPTO_SALT_NULL
        KeySpec spec = new PBEKeySpec(pwd.toCharArray(), salt, 20000, 128)
    	// <yes> <report> GROOVY_CRYPTO_SALT_NULL ssd455
        SecretKeySpec secret = generateKey(null)
        // <yes> <report> GROOVY_CRYPTO_SALT_NULL fcc233
        key = 'some phrase'.toKey(salt: null)
    }
}