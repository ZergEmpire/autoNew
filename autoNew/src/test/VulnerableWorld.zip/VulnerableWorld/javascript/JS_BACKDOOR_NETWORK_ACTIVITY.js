'use strict';
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://url.url";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001
var url2 = "https://localhost";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "1.1.1.1";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
const url4 = "https://1.1.1.1";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001
let url5 = "https://localhost";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001
const url6 = "https://localhost";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
maker.baker('https://good.com/Schema', schema, () => {});
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne003
maker.baker('https://localhost/Schema', schema, () => {});
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne004
config.web_console.whi_ip = '1.3.4.6/12';
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY 4d7dls
if (url == "http://www.example.com/wpstyle/?p=364")
{ alert("hello") ; }
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY 4c7015
if (ip == "127.0.0.1")
{ alert("hello") ; }

let url3 = "1.1.1.1.1.1";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "1.1.1.1/path";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "https://[::1]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "https://[1762:0:0:0:0:B03:1:AF18]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "https://[fe80::219:7eff:fe46:6c42]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "https://[::00:192.168.10.184]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "https://[2001:db8::ff00:42:8329]";
// <no> <report>
let nn = "::";
// <no> <report>
let t = "Types::abc";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "[2001:0db8:0000:0000:0000:ff00:0042:8329]";
// <no> <report>
let url4 = "::Collection";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url5 = "2001:0db8:0000:0000:0000:ff00:0042:8329";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url3 = "[2001:0db8:0000:0000:0000:ff00:0042:8329]/path";

// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne003
server.listen(8000,'127.0.0.1',function(){});
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://url.url";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
let url2 = "https://1.1.1.1";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne001
const url3 = "https://localhost";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
cl("https://1.1.1.1");
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
cl.lc("https://1.1.1.1");
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://1.1.1.1/dns";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://[1762:0:0:0:0:B03:1:AF18]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://[::1]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://[fe80::219:7eff:fe46:6c42]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://[::00:192.168.10.184]";
// <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne000
var url1 = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]";
