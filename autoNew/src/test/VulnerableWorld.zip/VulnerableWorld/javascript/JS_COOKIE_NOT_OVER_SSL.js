// <yes> <report> JS_COOKIE_NOT_OVER_SSL 405015
document.cookie ='cookie1=test; expires=Fri, 3 Aug 2001 20:47:11 UTC'
// <no> <report>
document.cookie ='cookie1=test; expires=Fri, 3 Aug 2001 20:47:11 UTC; secure'
// <yes> <report> JS_COOKIE_NOT_OVER_SSL 405016 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('name', 'tobi', { domain: 'example.com', path: '/admin', secure: false });
// <yes> <report> JS_COOKIE_NOT_OVER_SSL 405016 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('name', 'tobi', { domain: 'example.com', path: '/admin'});
// <no> <report>
res.cookie('name', 'tobi', { domain: 'example.com', path: '/admin', secure: true, httpOnly: true});

import Cookies = require("js-cookie");
// <yes> <report> JS_COOKIE_NOT_OVER_SSL tcnos0
Cookies.set('name', 'value', { expires: 7, path: '', domain: '', secure: false });
// <yes> <report> JS_COOKIE_NOT_OVER_SSL tcnos0
Cookies.set('name', 'value', { secure: false });
// <no> <report>
Cookies.set('name', 'value', { secure: true });