// <yes> <report> JS_BACKDOOR_DEADCODE 405x03
if(false) {
	function funcDecl() {}
}
switch (result) {
    case FAILED:
        printf("Security check failed!\n");
        exit(-1);
    case PASSED:
        printf("Security check passed.\n");
    break;
    default:
        printf("Unknown error (%d), exiting...\n",result);
        exit(-1);
}

// <yes> <report> JS_BACKDOOR_DEADCODE 405x01
if(a==a){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x02
if(false==true){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x01
if(true == true){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x02
if("sdcsddasfqef" == "sdcsdd"){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x03
if(true){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x03
if(false){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x03
if("const"){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x03
if(1){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <no> <report> JS_BACKDOOR_DEADCODE 405x03
if(a){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <no> <report> JS_BACKDOOR_DEADCODE 405x02
if(a=="dscdsc"){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x02
if("adc" == "dscdsc" | a == b){
 console.log("Do something");
}
else{
    console.log("Do something");
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x03
if(1 | a==b){
doSomthing();
}
else{
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x01
if(true > true){
doSomthing();
}
else{
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x02
if(true >= false){
doSomthing();
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if(a && a){
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if(a || a){
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
 if (lblElelemtn.text === "Change text") {
        lblElelemtn.text = btnElement.text = textFieldElement.text = textViewElement.text = "Text changed";
    } else {
        lblElelemtn.text = btnElement.text = textFieldElement.text = textViewElement.text = "Change text";
    }
// <no> <report> JS_BACKDOOR_DEADCODE
if (!validate(false) || !vscode.window.activeTextEditor) {
		return;
	}
// <no> <report> JS_BACKDOOR_DEADCODE
if (!fn.match(/fourslash.ts$/i)) {
        testList.push(fn);
    }
// <no> <report> JS_BACKDOOR_DEADCODE
if (haystack[i] !== needle[i]) {
			return false;
		}
// <no> <report> JS_BACKDOOR_DEADCODE
if (!args['language']) {
		args['language'] = editor.document.languageId;
	}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x01
if(a.v[1] == a.v[1]){
doSomthing();
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if(a.v[2] == a.v[1]){
doSomthing();
}
else{
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x01
if(a[3][1] == a[3][1]){
doSomthing();
}
else{
}
// <yes> <report> JS_BACKDOOR_DEADCODE 405x01
if(a[1].v == a[1].v){
doSomthing();
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if(a[2].v == a[1].v){
doSomthing();
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if(a[4][1] == a[3][1]){
doSomthing();
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if(a[3][2] == a[3][1]){
doSomthing();
}
else{
}
// <no> <report> JS_BACKDOOR_DEADCODE
if (3 in a) {

}