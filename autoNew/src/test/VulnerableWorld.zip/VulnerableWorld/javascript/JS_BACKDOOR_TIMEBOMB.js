// <yes> <report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.now() == 10) {
    alert("timebomb");
}

var now = new Date();
var Jan02_1970 = new Date(3600 * 24 * 1000);
var d = new Date(2013, 0, 32);
d.getFullYear();
// <yes> <report> JS_BACKDOOR_TIMEBOMB ngjrle
if (now.valueOf() == d.valueOf()) {
    alert('timebomb');
}
// <yes> <report> JS_BACKDOOR_TIMEBOMB ngjrle
if (now.valueOf() == smth) {
    alert('timebomb');
}
// <yes> <report> JS_BACKDOOR_TIMEBOMB gnjdel
if (new Date() == 123) {
    alert('timebomb');
}

// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if(Date.now() == 10){
 DoSomthing();
};
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if(10 == Date.now()){
 DoSomething();
};
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.parse('2Mon, 25 Dec 1995 13:30:00 GMT')==120413){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.parse('March 7, 2014')<Date.now()){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.parse('2014-03-07')<Date.now()){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.parse('2014/03/07')==Date.now()){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.parse('10 06 2014')>=Date.now()){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.now() > Date.parse('2014:03:07')){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.parse('2011-10-10T14:48:00')==Date.now()){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.prototype.getDate() > 30){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.prototype.getDay() > 3){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.prototype.getFullYear() > 2020){
  DoSomething();
}
// <yes><report> JS_BACKDOOR_TIMEBOMB gnjdel
if (Date.prototype.getHours() > 10){
  DoSomething();
}
