// grammar does not parse this code
// JS_CORRECTNESS_PROMISE_ASYNC d1fqe7
//const result = new Promise(async (resolve, reject) => {
//  readFile('foo.txt', function(err, result) {
//    if (err) {
//      reject(err);
//    } else {
//      resolve(result);
//    }
//  });
//});
//
//function getRoomInfo(roomId) {
////no report
//	return new Promise((resolve/*, reject*/) => {
//request.get(api('channels.info'))
//			.set(credentials)
//			.query({
//				roomId: roomId
//			})
//			.end((err, req) => {
//				resolve(req.body);
//			});
//	});
//}