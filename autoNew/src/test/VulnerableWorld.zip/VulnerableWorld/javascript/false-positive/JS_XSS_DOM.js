document.writeln('smth');
location.hash = location.href;
// <yes> <report> JS_OPEN_REDIRECT adf764
location.hash = window.location;
style.background = 'smth';
jQuery.after('smth');
$.append('smth');
