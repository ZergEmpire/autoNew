smth.getDirectory('smth');
smth.moveTo('smth', 'smth');
