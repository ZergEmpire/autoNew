location.assign('smth');
window.open('smth');
history.current = 'smth';
history.go('smth');
document.URL = 'smth';
window.location = 'smth';