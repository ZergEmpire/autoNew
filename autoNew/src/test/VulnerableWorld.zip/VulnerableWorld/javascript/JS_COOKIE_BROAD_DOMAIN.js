// <yes> <report> JS_COOKIE_BROAD_DOMAIN 107090 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('name', 'tobi', {domain: '.example.com', path: '/admin', secure: true });
// <yes> <report> JS_COOKIE_BROAD_DOMAIN 107091 
document.cookie ='cookie1=test; secure=true; domain=.abc.abc'

