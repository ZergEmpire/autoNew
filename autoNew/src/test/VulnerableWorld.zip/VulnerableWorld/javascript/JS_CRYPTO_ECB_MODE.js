var cipher = CryptoJS.AES.encrypt(message, hash(key), {
    iv: iv1,
    // <yes> <report> JS_CRYPTO_ECB_MODE leru77
    mode: CryptoJS.mode.ECB,
    keySize: 256 / 32,
    padding: CryptoJS.pad.Pkcs7
});