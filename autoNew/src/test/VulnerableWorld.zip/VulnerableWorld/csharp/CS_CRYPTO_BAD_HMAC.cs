namespace Tests
{
    class CS_CRYPTO_BAD_HMAC
    {
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_BAD_HMAC 4ntj3w
            HMACMD5 hmac = new HMACMD5(key);
        }
    }
}