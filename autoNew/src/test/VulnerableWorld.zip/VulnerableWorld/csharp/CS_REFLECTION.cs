namespace Tests
{
    class CS_REFLECTION
    {
        static void Main()
        {
            ResultTable table = new ResultTable(); 
           // +DATABASE to return
               string tainted = table.GetString(10);
            ConstructorInfo magicConstructor = magicType.GetConstructor(Type.EmptyTypes);
            // <yes> <report> CS_REFLECTION fgkejw
            object magicClassObject = magicConstructor.Invoke(smth, tainted);
            // <yes> <report> CS_REFLECTION fwerww 
            Type magicType = Type.GetType(tainted);
            // <yes> <report> CS_REFLECTION csr000
            MethodInfo magicMethod = magicType.GetMethod("ItsMagic");
            // <yes> <report> CS_REFLECTION ktlrym
            var refl = Interaction.CallByName(tainted);
            System.Type t;
            // <yes> <report> CS_REFLECTION csr000
            t.GetFields (BindingFlags.Public);
        }
    }
}