namespace Tests
{
    class CS_INJECTION_JSON
    {
        static void Main()
        {
        Application app = new Application();
        string b = app.GetCookie();
        StringBuilder sb = new StringBuilder();
        StringWriter sw = new StringWriter(sb);

        using (JsonWriter writer = new JsonTextWriter(sw))
        {
            writer.WritePropertyName("b");
            //<yes> <report> CS_INJECTION_JSON 52kewk
            writer.WriteRawValue("\"" + b + "\"");
        }

        JSON fastJSON = new fastJSON.JSON();
        //<yes> <report> CS_INJECTION_JSON 52kewo
        fastJSON.Parse(b);
        }
    }
}