using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OWASP.WebGoat.NET.App_Code;
using OWASP.WebGoat.NET.App_Code.DB;

namespace OWASP.WebGoat.NET
{
    public partial class ForgotPassword : System.Web.UI.Page
    {
        protected void ButtonRecoverPassword_Click(object sender, EventArgs e, HttpContext context)
        {
            try
            {
            }
            // <yes> <report> CS_ERROR_HANDLING_BROAD_CATCH 150938
            catch (Exception ex)
            {
                // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL il0000
                labelMessage.Text = "An unknown error occurred - Do you have cookies turned on? Further Details: " + ex.Message;
                // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL il0000
                labelMessage.Text = ex.Message;
                // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL gffb4g
                context.Response.Write(ex.Message);
            }
        }
    }
}