namespace Tests
{
    class CS_CRYPTO_KEY_EMPTY
    {
        // <yes> <report> CS_CRYPTO_KEY_EMPTY regerj
        private string encryptionKey = "";
        // <yes> <report> CS_CRYPTO_KEY_EMPTY ebrttt
        private const string publicKey = "";
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_KEY_EMPTY t45ele
            string cryptoKey = "";
            // <yes> <report> CS_CRYPTO_KEY_EMPTY obktmr
            byte[] myCryptoKey = enc.GetBytes("");
        }
    }
}