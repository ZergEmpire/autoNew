namespace Tests
{
    class CS_SSRF
    {
        static void Main()
        {
        Application app = new Application();
        string b = app.GetCookie();

        SerialPort serialPort = new SerialPort();
        serialPort.PortName = b;
        //<yes> <report> CS_SSRF f2pewp
        serialPort.Open();
        }
    }
}