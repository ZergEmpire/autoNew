namespace Tests
{
    class CS_XAMARIN_SETJAVASCRIPTENABLED_TRUE
    {
        static void Main()
        {
             bool b = true;
             WebView myWebView = FindViewById<WebView>(Resource.Id.LoginText);
             // <yes> <report> CS_XAMARIN_SETJAVASCRIPTENABLED_UNDEF cxsjsu
             myWebView.Settings.JavaScriptEnabled = b;

        }
    }
}