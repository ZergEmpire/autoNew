using System.Xml;

namespace Tests
{
    class CsInjectionXxe
    {
        static void Main()
        {
            var taintedUri = ctx.Request.QueryString["document"];
            XmlReader reader = new XmlReader(); // does not propagate class if var is used
            // <yes> <report> CS_INJECTION_XXE 264aca
            XPathDocument document = new XPathDocument(taintedUri);
            // <no> <report>
            XPathDocument document = new XPathDocument(reader, taintedUri);
            // <yes> <report> CS_INJECTION_XXE 264aca
            XmlTextReader reader = new XmlTextReader(taintedUri);
        }
    }
}