using System.Web.UI;

namespace Tests
{
    class CsUnminifiedCode
    {
        static void Main()
        {
            Type cstype = this.GetType();
            ClientScriptManager cs = Page.ClientScript;
            // <yes> <report> CS_UNMINIFIED_CODE 0178fa
            cs.RegisterClientScriptInclude("bar", "/ajax/libs/jqueryui/1.7.2/jquery-ui.js");
            // <yes> <report> CS_UNMINIFIED_CODE 0178fa
            cs.RegisterClientScriptInclude(cstype, "bar", "/ajax/libs/jqueryui/1.7.2/jquery-ui.js");
            // <no> <report>
            cs.RegisterClientScriptInclude("bar", "/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js");
        }
    }
}