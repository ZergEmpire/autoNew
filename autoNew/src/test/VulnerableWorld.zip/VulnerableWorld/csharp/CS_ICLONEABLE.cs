namespace Tests
{
    // <yes> <report> CS_ICLONEABLE a7189c
    class CS_ICLONEABLE : ICloneable
    {
        public object Clone()
      {
         return this.MemberwiseClone();
      }
    }
}