namespace Tests
{
    class CS_OPEN_REDIRECT
    {
        static void Main()
        {
            // <yes> <report> CS_OPEN_REDIRECT opred1
            ctx.Response.Redirect(ctx.Request.QueryString["page"]);
            // <yes> <report> CS_OPEN_REDIRECT 12kse4
            Response.Redirect(ViewState["PreviousPage"].ToString());
            FileInfo fi1 = new FileInfo(path);
            RouteData rd = new RouteData();
            path2 = rd.GetRequiredString();
            // <yes> <report> CS_OPEN_REDIRECT 12kse4
            Response.Redirect(path2); // Redirect|RedirectPermanent methods
            // <yes> <report> CS_OPEN_REDIRECT 12kse4
            Response.RedirectToRoute(path2, new { productid = "1", category = "widgets" }); // RedirectToRoute|RedirectToRoutePermanent methods
            // <yes> <report> CS_OPEN_REDIRECT lekse4
            Response.RedirectLocation = path2; // RedirectLocation|Status|StatusDescription property
            // <yes> <report> CS_OPEN_REDIRECT p2kse4
            SPUtility.Redirect(path2, flags, context);
            // <yes> <report> CS_OPEN_REDIRECT olrj43
            RedirectResult redirect = new RedirectResult(path2);
            // <yes> <report> CS_OPEN_REDIRECT eerj43
            routes.Add(new Route(path2, new CategoryRouteHandler()));
            Route route = new Route("Category/{action}/{categoryName}", new CategoryRouteHandler());
            // <yes> <report> CS_OPEN_REDIRECT op4se4
            route.URL = path2;
            DataPointCustomProperties customProp = new DataPointCustomProperties();
            // <yes> <report> CS_OPEN_REDIRECT ip4se4
            customProp.LegendUrl = path2;
            listSettingsUrl = string.Concat(SPContext.Current.Web.Url, "/_layouts/15/ listedit.aspx?", Request.QueryString);
            // <yes> <report> CS_OPEN_REDIRECT 12kse4
            Response.Redirect(listSettingsUrl);
            HyperLink HyperLink1 = new HyperLink();
            // <yes> <report> CS_OPEN_REDIRECT redler <yes> <report> CS_PATH_MANIPULATION pathma
            HyperLink1.NavigateUrl = listSettingsUrl;
            protected void ButtonOK_Click(object sender, EventArgs e)
            {
                SetSurveySettings();
                LinkJStoForms();
                Response.Redirect(listSettingsUrl);
            }
        }
    }
}