namespace Tests
{
    class CS_INJECTION_XQUERY
    {
        static void Main()
        {
            string query = Request.QueryString["query"];
            XQueryCompiler compiler = processor.NewXQueryCompiler();
            // <yes> <report> CS_INJECTION_XQUERY gvghgv
            compiler.Compile(query);
        }
    }
}