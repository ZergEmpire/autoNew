using System.Web.UI;

namespace Tests
{
    class CsExternalCdn
    {
        static void Main()
        {
            // <yes> <report> CS_EXTERNAL_CDN 493b64
            ScriptManager.EnableCdn(true);
            // <yes> <report> CS_EXTERNAL_CDN 493b65
            ScriptManager.EnableCdn(1);  
            // <yes> <report> CS_EXTERNAL_CDN 493b66 
            ScriptManager.EnableCdn = true;    
            
            Type cstype = this.GetType();
            ClientScriptManager cs = Page.ClientScript;
            // <yes> <report> CS_EXTERNAL_CDN 623a11
            cs.RegisterClientScriptInclude(cstype, "foo", "https://ajax.microsoft.com/ajax/beta/0911/MicrosoftAjax.js");
            
            // <yes> <report> CS_EXTERNAL_CDN 623a11
            cs.RegisterClientScriptInclude("bar", "https://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js");
            // <no> <report>
            cs.RegisterClientScriptInclude("bar", "/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js");
        }
    }
}