using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Tests
{
    class CS_PASSWORD_CRYPTO
    {
        static void Main()
        {
            // <yes> <report> CS_PASSWORD_CRYPTO vtnekw
            DirectoryEntry de = new DirectoryEntry("s1","s2", Convert.FromBase64String(password).ToString());
            // <yes> <report> CS_PASSWORD_CRYPTO rekr33
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(Convert.FromBase64String(password).ToString(), salt, "sha256", 100000);
            // <yes> <report> CS_PASSWORD_CRYPTO grejkw
            NetworkCredential nc1 = new NetworkCredential("",Convert.FromBase64String(password).ToString());
            // <yes> <report> CS_PASSWORD_CRYPTO grt333
            nc1.Password = Convert.FromBase64String(password).ToString();
            ConnectionString conString = new ConnectionString();
            // <yes> <report> CS_PASSWORD_CRYPTO frejnw
            conString.Password = Convert.FromBase64String(password).ToString();
        }
    }
}