using System;

namespace Tests
{
    class CsErrorHandling
    {
        static void Main() {
            // Exception, SystemException, ApplicationException

            // <yes> <report> CS_ERROR_HANDLING_BROAD_THROW d317e4
            throw new ApplicationException();

            SystemException se = new SystemException();
            // <yes> <report> CS_ERROR_HANDLING_BROAD_THROW d317e4
            throw se;
            
            try {
                // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("Hello World!");
            }
            // <yes> <report> CS_ERROR_HANDLING_EMPTY_CATCH 63438e
            catch (SomeSpecificException se) {
                // empty catch
            }

            // <no> <report>
            catch(ThreadInterruptedException e) {
                //empty catch
            }

            try {
            }
            // <no> <report> CS_ERROR_HANDLING_BROAD_CATCH 150938
            catch (Exception ex) {
                // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("SystemException! Not re-throwing");
            }
            // <yes> <report> CS_ERROR_HANDLING_CATCH_NULLPOINTEREXCEPTION 768728
            catch (NullReferenceException ex) {
                // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("NRE");
            }
            // <yes> <report> CS_ERROR_HANDLING_EMPTY_CATCH 63428e
            catch {
                //empty
            }
        }

        static void Function() {
            try {
            //smth
            }
            // <yes> <report> CS_ERROR_HANDLING_BROAD_CATCH 150938
            catch (Exception ex) {
                // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("SystemException! Not re-throwing");
            }
            // <yes> <report> CS_ERROR_HANDLING_BROAD_CATCH 150938
            catch (Exception ex) {
                // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("SystemException! Not re-throwing");
                throw;
            }
            // <yes> <report> CS_ERROR_HANDLING_BROAD_CATCH 150938
            catch (Exception ex) {
                // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("SystemException! Not re-throwing");
                throw new MyApplicationException();
            }
        }
    }
}