public class CertificateValidation : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            // <yes> <report> CS_CERTIFICATE_VALIDATION cscv00
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
            // <yes> <report> CS_CERTIFICATE_VALIDATION cscv00
            ServicePointManager.ServerCertificateValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;

        }
    }
