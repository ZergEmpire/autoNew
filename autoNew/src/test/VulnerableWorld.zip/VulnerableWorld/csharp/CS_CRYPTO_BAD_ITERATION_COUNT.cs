namespace Tests
{
    class CS_CRYPTO_BAD_ITERARION_COUNT
    {
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_BAD_ITERATION_COUNT 4th3jw
            Rfc2898DeriveBytes rdb = new Rfc2898DeriveBytes(password, salt, 500);
            // <yes> <report> CS_CRYPTO_BAD_ITERATION_COUNT gejkww
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, salt, "sha256", 1000);
            // <yes> <report> CS_CRYPTO_BAD_ITERATION_COUNT 4jjwws
            rdb.IterationCount = 999;
            // <yes> <report> CS_CRYPTO_BAD_ITERATION_COUNT fhrtje
            Rfc2898DeriveBytes rdb = new Rfc2898DeriveBytes(password, salt);
            // <yes> <report> CS_CRYPTO_BAD_ITERATION_COUNT frejkw
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, salt, "sha256");
        }
    }
}