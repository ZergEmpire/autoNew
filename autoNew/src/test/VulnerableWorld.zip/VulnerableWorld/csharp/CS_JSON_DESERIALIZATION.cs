namespace Tests
{
    class CS_JSON_DESERIALIZATION
    {
        static void Main()
        {
        JSON fastJSON = new fastJSON.JSON();
        //<yes> <report> CS_JSON_DESERIALIZATION g2kewo
        fastJSON.ToObject(smth);
        }
    }
}