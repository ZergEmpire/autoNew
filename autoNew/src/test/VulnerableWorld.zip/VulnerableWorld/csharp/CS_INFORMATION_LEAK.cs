namespace Tests
{
    class CS_INFORMATION_LEAK
    {
        static void Main()
        {
            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            // <yes> <report> CS_INFORMATION_LEAK a6abc6
            smb.HttpsGetEnabled = true;
            var file = MemoryMappedFile.CreateFromFile(...);
            Exception e = new Exception();
            MemoryMappedViewAccessor accessor = file.CreateViewAccessor();
            // <yes> <report> CS_INFORMATION_LEAK 55er43
            accessor.Write(e.ToString());

            BinaryWriter writer = new BinaryWriter();
            // <yes> <report> CS_INFORMATION_LEAK 15er43
            writer.Write(e.ToString());
            FileStream stream = new FileStream("path", FileMode.Create);
            // <yes> <report> CS_INFORMATION_LEAK 151r43
            stream.WriteByte(e.ToString());

            StreamWriter sw = new StreamWriter("CDriveDirs.txt");
            // <yes> <report> CS_INFORMATION_LEAK 251r43
            sw.WriteLine(e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK lrm2k4
            Exception ex = new Exception(e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK 12abc6
            ex.HelpLink = e.ToString();
        }
    }
}

