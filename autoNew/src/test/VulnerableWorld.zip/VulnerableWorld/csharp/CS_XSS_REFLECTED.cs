namespace Tests 
{
    class CS_XSS_REFLECTED
        {
            static void Main()
            {
                // +WEB to return
                string icsMsg = Request.QueryString["IcsMessage"];
                // <yes> <report> CS_XSS_REFLECTED jernw3
                Response.Write(icsMsg);
                WebClient client = new WebClient ();
                Stream myStream = client.OpenRead(uriString);
                // abstract class
                HttpWorkerRequest wr = new HttpWorkerRequest();
                string url = wr.GetRawUrl();
                byte[] content = wr.GetQueryStringRawBytes();

                Application app = new Application();
                string cookie = app.GetCookie(url);

                RouteData rt = new RouteData();
                string str = rt.GetRequiredString(val);

                HtmlTextWriter text = new HtmlTextWriter();
                // <yes> <report> CS_XSS_REFLECTED be5b28
                text.Write(str);

                var hh = new HtmlHelper();
                // <yes> <report> CS_XSS_REFLECTED be5b43
                hh.Raw(url);

                // <yes> <report> CS_XSS_REFLECTED be5r43
                FileContentResult result = new FileContentResult(content, "application/octet-stream");
                // <yes> <report> CS_XSS_REFLECTED be5r41
                FileStreamResult result2 = new FileStreamResult(myStream, "application/pdf");

                DataBoundLiteralControl boundLiteralControl = (DataBoundLiteralControl)Controls[0]; 
                // <yes> <report> CS_XSS_REFLECTED bttb43
                boundLiteralControl.SetDataBoundString(5, url);

                ClientScriptManager cs = Page.ClientScript;
                // <yes> <report> CS_XSS_REFLECTED bttb48
                cs.RegisterStartupScript(cstype, csname1, url);
                HtmlTextWriter writer = new HtmlTextWriter(TextWriter);
                // <yes> <report> CS_XSS_REFLECTED bntb48
                writer.AddAttribute(str, "alert('Hello');" );
                // <yes> <report> CS_XSS_REFLECTED bntb4f
                writer.AddAttribute(HtmlTextWriterAttribute.Alt, str , false);
                AttributeCollection attributes;
                // <yes> <report> CS_XSS_REFLECTED gntb4f
                attributes.Add(str ,"Color.Red");
                var response = new HttpResponse(memWriter);
                // <yes> <report> CS_XSS_REFLECTED gntb4g
                response.Write(str);

                JavaScriptResult res = new JavaScriptResult();
                // <yes> <report> CS_INJECTION_RESOURCE c91ah1
                Socket s = new Socket(endPoint.Address.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
                byte[] msg = new Byte[256];
                s.ReceiveFrom(msg, ref senderRemote);
                // <yes> <report> CS_XSS_REFLECTED klr415
                res.Script = msg; 

                ContentResult content = new ContentResult();
                // <yes> <report> CS_XSS_REFLECTED 22r415
                content.Content = msg;

                DataPointCustomProperties prop = new DataPointCustomProperties();

                TextBox textBox1 = new TextBox();
                string domain = textBox1.GetLineText(5);
                // <yes> <report> CS_XSS_REFLECTED 226415
                prop.LegendMapAreaAttributes = domain;
                DataList list = new DataList();
                // <yes> <report> CS_XSS_REFLECTED 84503m
                list.DataSource = msg;
            }

            public void ProcessRequest(HttpContext ctx)
            {
                // <yes> <report> CS_XSS_REFLECTED gntb4g
                ctx.Response.Write("The page \"" + ctx.Request.QueryString["page"] + "\" was not found.");
            }
        }
}
