namespace Tests
{
    class CS_PATH_MANIPULATION
    {
        static void Main()
        {
            Application app = new Application();
            string b = app.GetCookie();

            XDocument doc = new XDocument();
            // <yes> <report> CS_PATH_MANIPULATION ab5b29
            doc.Load(b, smth);
            // <yes> <report> CS_PATH_MANIPULATION ab5b28
            var mmf = MemoryMappedFile.CreateFromFile(b, FileMode.Open,"ImgA");

            FileInfo fi1 = new FileInfo(path);
            RouteData rd = new RouteData();
            path2 = rd.GetRequiredString();
            // <yes> <report> CS_PATH_MANIPULATION ab5b27
            fi1.CopyTo(path2);
            // <yes> <report> CS_PATH_MANIPULATION ab5b26
            fi1.Replace(path, path2);
            // <yes> <report> CS_PATH_MANIPULATION ab5b25 <yes> <report> CS_INJECTION_XXE 264aca
            XPathDocument xpath = new XPathDocument(b);
            // <yes> <report> CS_PATH_MANIPULATION ab5b24
            StreamWriter sw = File.CreateText(path2);
            // <yes> <report> CS_PATH_MANIPULATION ab5b23
            File.AppendAllLines(path2, MarchMondays);
            // <yes> <report> CS_PATH_MANIPULATION ab5b22
            File.Copy(Path.Combine(sourceDir, fName), path2);
            // <yes> <report> CS_PATH_MANIPULATION ab5b21
            Directory.Move(path2, @"C:\destination");
            // <yes> <report> CS_PATH_MANIPULATION ab5b20
            File.Replace(FileToMoveAndDelete, FileToReplace, path2, false);
            // <yes> <report> CS_PATH_MANIPULATION ab5b19
            FileStream fileStream = new FileStream(b, FileMode.Create);
            DirectoryInfo di = new DirectoryInfo(@"c:\MyDir");
            // <yes> <report> CS_PATH_MANIPULATION ab5b18 
            di.CreateSubdirectory(path2);
            // <yes> <report> CS_PATH_MANIPULATION ab5b17
            new FilePathResult(path2, "application/octet-stream");
            RouteCollection rc = new RouteCollection();
            // <yes> <report> CS_PATH_MANIPULATION ab5b16
            rc.MapPageRoute("", "", path2);
            HttpResponse response = new HttpResponse(text);
            // <yes> <report> CS_PATH_MANIPULATION ab5b15 <yes> <report> CS_INFORMATION_LEAK_EXTERNAL 67189c
            response.WriteFile(b);
            // <yes> <report> CS_PATH_MANIPULATION jernt8
            Response.WriteFile(b);
            SPWeb oWebsite = SPContext.Current.Web;
            // <yes> <report> CS_PATH_MANIPULATION a33b15
            SPFile file = oWebsite.GetFile(path2);
            
            Assembly SampleAssembly;
            // <yes> <report> CS_PATH_MANIPULATION a23b15
            SampleAssembly = Assembly.LoadFrom(path2);

            ResourceManager rm = new ResourceManager(b, SampleAssembly);
            // <yes> <report> CS_PATH_MANIPULATION a13b15
            rm.GetString("resource");

            Page p = new Page();
            // <yes> <report> CS_PATH_MANIPULATION a03b15
            string abspath = p.MapPath(path2);
            // <yes> <report> CS_PATH_MANIPULATION er35n4
            ActiveRecordStarter.GenerateDropScripts(path2);

            WebClient myWebClient = new WebClient();
            // <yes> <report> CS_PATH_MANIPULATION ab5b00
            myWebClient.DownloadFile(b, fileName);

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(b);
            // <yes> <report> CS_PATH_MANIPULATION ab5000
            var response = await client.GetAsync(smth);

            ICloudBlob blob = new ICloudBlob();
            // <yes> <report> CS_PATH_MANIPULATION ab5001
            blob.DownloadToFileAsync(outputFileName, FileMode.Append);

            SocketAsyncEventArgs args = new SocketAsyncEventArgs();
            // <yes> <report> CS_PATH_MANIPULATION ab5002
            args.RemoteEndPoint = b;

            TcpClient tcpClient = new TcpClient();
            // <yes> <report> CS_PATH_MANIPULATION ab5003
            tcpClient.Connect(b);
            // <yes> <report> CS_PATH_MANIPULATION csfm00
            new FileInfo(b);

            DirectoryInfo di = new DirectoryInfo(Server.MapPath("~/Downloads"));
            HyperLink HL = new HyperLink();
            foreach(FileInfo fi in di.GetFiles()) {
                // <yes> <report> CS_PATH_MANIPULATION pathma <yes> <report> CS_OPEN_REDIRECT redler
                HL.NavigateUrl = Request.FilePath + "?filename="+fi.Name;
            }
        }
    }
}
