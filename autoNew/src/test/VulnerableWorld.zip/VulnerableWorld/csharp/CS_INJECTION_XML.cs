namespace Tests
{
    class CS_INJECTION_XML
    {
        static void Main()
        {
            string tainted = "tainted";
            XmlWriter xw = new XmlWriter();
            // <yes> <report> CS_INJECTION_XML 2e5b3a
            xw.WriteProcessingInstruction("smth", tainted);
            // <yes> <report> CS_INJECTION_XML 2e5b3b
            xw.WriteDocType("smth", tainted);

            UnmanagedMemoryStream readStream = new UnmanagedMemoryStream(memBytePtr, message.Length, message.Length, FileAccess.Read);
            // +FILE_SYSTEM to arg = 0
            readStream.Read(outMessage, 0, message.Length);
            // <yes> <report> CS_INJECTION_XML jsj43a
            XDocument doc = XDocument.Parse(outMessage);
            // <yes> <report> CS_INJECTION_XML jsj43a
            XElement xmlTree = XElement.Parse(outMessage);

            XmlWriter writer = null;
            writer = XmlWriter.Create("data.xml", settings);
            // <yes> <report> CS_INJECTION_XML 1e5b39
            writer.WriteStartElement(outMessage);
            // <yes> <report> CS_INJECTION_XML 2e5bre
            writer.WriteElementString(tainted, "urn:samples", "hardcover");
            // <yes> <report> CS_INJECTION_XML 1w5bre
            writer.WriteAttributeString("xmlns", outMessage, null, "urn:samples");
            // <yes> <report> CS_INJECTION_XML 235b39
            writer.WriteStartElement(prefix, tainted, "urn:samples");
            // <yes> <report> CS_INJECTION_XML 1e5b3b
            xw.WriteDocType("smth", "smth", outMessage);


            XmlDocument doc = new XmlDocument();
            XmlDocumentType doctype;
            // <yes> <report> CS_INJECTION_XML jsj412
            doctype = doc.CreateDocumentType("book", null, null, outMessage);

            XmlProcessingInstruction newPI;
            // <yes> <report> CS_INJECTION_XML jsj413
            newPI = doc.CreateProcessingInstruction("xml-stylesheet", outMessage);
            // <yes> <report> CS_INJECTION_XML jsjrew
            newPI.Data = outMessage;

            XmlNode attr = doc.CreateNode(XmlNodeType.Attribute, "genre", ns);
            // <yes> <report> CS_INJECTION_XML jsjrev
            attr.Value = outMessage;

        }

        public void ProcessRequest(HttpContext ctx) {
            string employeeName = ctx.Request.QueryString["employeeName"];

            using (XmlWriter writer = XmlWriter.Create("employees.xml"))
            {
                writer.WriteStartDocument();
                // <yes> <report> CS_INJECTION_XML 1e5b39
                writer.WriteRaw("<employee><name>" + employeeName + "</name></employee>");
                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
          }
    }
}