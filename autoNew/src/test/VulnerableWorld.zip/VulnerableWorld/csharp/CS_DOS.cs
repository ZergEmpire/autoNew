namespace Tests
{
    class CS_DOS
    {
        static void Main()
        {
            var filename = Request.QueryString["filename"];
            // <yes> <report> CS_INJECTION_RESOURCE c92ae1 <yes> <report> CS_PATH_MANIPULATION ab5b24
            StreamReader tr = File.OpenText(filename);
            // <yes> <report> CS_DOS ab71da
            tr.ReadLine();
            XmlReaderSettings settings = new XmlReaderSettings();
            // <yes> <report> CS_DOS 67a89c
            settings.DtdProcessing = DtdProcessing.Parse;
            // <yes> <report> CS_DOS 69a89c
            settings.ProhibitDtd = false;


            SqlDataRecord record;    
            record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("Column1", SqlDbType.NVarChar, 12), 
                                                  new SqlMetaData("Column2", SqlDbType.Int), 
                                                  new SqlMetaData("Column3", SqlDbType.DateTime) });
            int usrInput = record.GetInt32(5);
            int usrInput2 = Int32.Parse(usrInput);
            // <yes> <report> CS_DOS lds89c
            Thread.Sleep(usrInput2);
            // <yes> <report> CS_DOS 3k4hwc
            MemoryMappedFile mmf = MemoryMappedFile.CreateFromFile(@"c:\ExtremelyLargeImage.data", FileMode.Open,"ImgA", usrInput2);
            // <yes> <report> CS_DOS 3371da
            var stream = mmf.CreateViewStream(offset, usrInput2);
            FileStream fs = File.Create(path)
            // <yes> <report> CS_DOS 9k4hwc
            var file = MemoryMappedFile.CreateFromFile (fs, "name", usrInput2, FileMode.Open, sec, inherit, true);
            BinaryReader reader = new BinaryReader();
            // <yes> <report> CS_DOS jtk53n <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9473
            int n = reader.Read(buf, num, usrInput2);
            // <yes> <report> CS_DOS 12k53n
            fs.BeginRead(buf, 4, usrInput2, callback, state);
            TextReader sr = new TextReader();
            // <yes> <report> CS_DOS 22k53n <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9473
            int y = sr.ReadBlock(buf, num, usrInput2);
            RouteCollection routes = new RouteCollection();
            // <yes> <report> CS_DOS jtm43k
            routes.Ignore(usrInput2);
            XmlSerializer serializer = new XmlSerializer(typeof(OrderedItem));
            // <yes> <report> CS_DOS 22m43k
            i = (OrderedItem)serializer.Deserialize(usrInput2);
            CustomBinding bind = new CustomBinding();
            // <yes> <report> CS_DOS 54jnk3
            bind.CloseTimeout= usrInput2;

        }
    }
}