namespace Tests
{
    class CS_CORRECTNESS_MISSPELLED 
    {
        // argument not object (no interface IEqualityComparer)
        // <yes> <report> CS_CORRECTNESS_MISSPELLED b15966
        public override bool Equals(string obj) 
        {
            return true;
        }
        // <yes> <report> CS_CORRECTNESS_MISSPELLED a15966
        public override bool Equal(Object obj) 
        {
            return true;
        }
        // <no> <report>
        public bool Equals(string obj)
        {
            return true;
        }
        // <yes> <report> CS_CORRECTNESS_MISSPELLED a15966
        public override int HashCode() 
        {
            return 0;
        }
        // (GetHashCode|Finalize) with argument (no interface IEqualityComparer)
        // <yes> <report> CS_CORRECTNESS_MISSPELLED c15966
        public override int GetHashCode(string x) 
        {
            return 0;
        }
        //Equals with two arguments (no interface IEqualityComparer)
        // <yes> <report> CS_CORRECTNESS_MISSPELLED d15966
        public override bool Equals(Object obj1, Object obj2) 
        {
            return true;
        }
    }
}