namespace Tests
{
    class CS_PRIVACY_VIOLATION_HEAP
    {
        // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
        string password;
        static void Main()
        {

            IntPtr intPtr = Marshal.SecureStringToBSTR(secureString);
            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP lekrfj
            string outStr = Marshal.PtrToStringBSTR(intPtr);
            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string password;
        }

        // <yes> <report> CS_PRIVACY_VIOLATION_HEAP lekrf0
        public string Password {}
        // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap00
        public void CreateUser (string username, string password) {}
    }
}

namespace OWASP.WebGoat.NET {
	public partial class AddNewUser {
        // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
		protected System.Web.UI.WebControls.TextBox Password;
	}
}