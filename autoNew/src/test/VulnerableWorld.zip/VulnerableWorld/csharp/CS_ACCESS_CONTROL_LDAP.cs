using System.Data.Common;
using System.Data;

namespace Tests
{
    class CS_ACCESS_CONTROL_LDAP
    {
        static void Main()
        {
            DirectorySearcher search = new DirectorySearcher();
            // +LDAP to return
            SearchResult res = Convert.ToInt32(search.FindOne());
            DirectoryEntry myDE = new DirectoryEntry(strPath);
            DirectoryEntries entries = new DirectoryEntries();
            // <yes> <report> CS_ACCESS_CONTROL_LDAP a218ca
            DirectoryEntry myDirectoryEntry = entries.Add(Convert.ToInt32(Encoder.LdapDistinguishedNameEncode(res)), myDE.SchemaClassName);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP 1e44bc
            DirectoryEntry myDirectoryEntry2 = new DirectoryEntry(Encoder.LdapDistinguishedNameEncode(res));
            // <yes> <report> CS_ACCESS_CONTROL_LDAP ff1fds
            myDE.MoveTo(myDirectoryEntry2);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP p42fds <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9475
            bool exist = DirectoryEntry.Exists(myDirectoryEntry2);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP eenns3
            myDE.Path = Encoder.LdapDistinguishedNameEncode(res);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP 2344bc
            DirectorySearcher ds3 = new DirectorySearcher(myDirectoryEntry2);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP llnns3
            ds3.SearchRoot = Encoder.LdapDistinguishedNameEncode(res);
            DirectoryServicesPermissionAccess access = new DirectoryServicesPermissionAccess();
            // <yes> <report> CS_ACCESS_CONTROL_LDAP 1234bc
            DirectoryServicesPermissionEntry dspe = new DirectoryServicesPermissionEntry(access, Encoder.LdapDistinguishedNameEncode(res));
            // <yes> <report> CS_ACCESS_CONTROL_LDAP llnns3
            ds3.Filter = Encoder.LdapDistinguishedNameEncode(res);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP 6644bc
            DirectorySearcher ds3 = new DirectorySearcher(search, Encoder.LdapDistinguishedNameEncode(res));
        }
    }
}