using System.Web.UI;

namespace Tests
{
    class CS_ASP_DOTNET_MISCONFIGURATION_TRACE_OUTPUT
    {
        static void Main()
        {
            // <yes> <report> CS_OBSOLETE bb6f4e
            strcpy();
            // <yes> <report> CS_OBSOLETE bb6f4e
            lstrcatn();
            // <yes> <report> CS_OBSOLETE bb6f4e
            StrNCpyW();
            // <yes> <report> CS_OBSOLETE bb6f4e
            CharToOemBuffW();
            DataAdapter da = new DataAdapter();
            // <yes> <report> CS_OBSOLETE bc678a
            da.CloneInternals();
            // <yes> <report> CS_OBSOLETE 2e5b30
            SqlClientPermission scp2 = new SqlClientPermission(1, false);
            // <yes> <report> CS_OBSOLETE 333b34
            SqlClientPermission scp3 = new SqlClientPermission();
            // <yes> <report> CS_OBSOLETE 2e5b31
            QueryCommand qc = new QueryCommand("string");
        }
    }
}