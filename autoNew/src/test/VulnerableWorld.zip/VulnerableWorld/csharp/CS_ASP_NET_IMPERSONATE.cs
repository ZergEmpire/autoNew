using System.Security.Principal;

namespace Tests
{
    class CS_ASP_NET_IMPERSONATE
    {
        static void Main()
        {
            //Get the identity of the current user
            IIdentity contextId = HttpContext.Current.User.Identity;
            WindowsIdentity userId = (WindowsIdentity)contextId;
            // <yes> <report> CS_ASP_NET_IMPERSONATE impreo
            WindowsImpersonationContext imp = userId.Impersonate();

        }
    }
}