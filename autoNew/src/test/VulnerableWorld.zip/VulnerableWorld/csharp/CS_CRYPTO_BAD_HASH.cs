namespace Tests
{
    class CS_CRYPTO_BAD_HASH
    {
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_BAD_HASH f8ad5a
            MD5 hash = new MD5();
            // <yes> <report> CS_CRYPTO_BAD_HASH ab72da
            MD5.Create();
            // <yes> <report> CS_CRYPTO_BAD_HASH 1222dc
            HashAlgorithm.Create("MD2");
            AsymmetricSignatureDeformatter fm = new AsymmetricSignatureDeformatter();
            // <yes> <report> CS_CRYPTO_BAD_HASH 1372dc
            fm.HashAlgorithm = "MD2";
            // <yes> <report> CS_CRYPTO_BAD_HASH a8bc5a
            CngAlgorithm ca = new CngAlgorithm("SHA1");
            // <yes> <report> CS_CRYPTO_BAD_HASH ab32da
            CngAlgorithm.MD5;
        }
    }
}