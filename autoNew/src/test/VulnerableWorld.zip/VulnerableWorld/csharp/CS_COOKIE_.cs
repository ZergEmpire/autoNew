/*
    .NET has (at least) 2 classes for cookies.
    See http://stackoverflow.com/a/13112392/5752262
*/
using System.Web.HttpCookie;
using System.Net.Cookie;

namespace Tests
{
    class CsCookie
    {
        static void Main()
        {
            Cookie cookie = new Cookie();
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY ht4pdk
            HttpCookie httpCookie = new HttpCookie("ExampleCookie");
            CookieHeaderValue chv = new CookieHeaderValue();
            
            // <yes> <report> CS_COOKIE_BROAD_DOMAIN 597de5
            cookie.Domain = ".example.com";
            // <yes> <report> CS_COOKIE_BROAD_DOMAIN 598de5
            httpCookie.Domain = ".example.com";
            // <yes> <report> CS_COOKIE_BROAD_DOMAIN hejk43
            chv.Domain = ".example.com";
            
            // <yes> <report> CS_COOKIE_BROAD_PATH a646e4
            cookie.Path = "/";
            // <yes> <report> CS_COOKIE_BROAD_PATH a656e4
            httpCookie.Path = "/";
            // <yes> <report> CS_COOKIE_BROAD_PATH a666e4
            chv.Path = "/";
            
            boolean notTrue = false;
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY 522acc
            cookie.HttpOnly = false;
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY 523acc
            httpCookie.HttpOnly = notTrue;
            // <no> <report>
            cookie.HttpOnly = true;
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY 524acc
            chv.HttpOnly = false;
            
            // <yes> <report> CS_COOKIE_NOT_OVER_SSL f69546
            cookie.Secure = notTrue;
            // <yes> <report> CS_COOKIE_NOT_OVER_SSL f60546
            httpCookie.Secure = false;
            // <yes> <report> CS_COOKIE_NOT_OVER_SSL f60547
            chv.Secure = false;

            // max 15 min
            // <yes> <report> CS_COOKIE_PERSISTENT 080707
            cookie.Expires = DateTime.Now.AddMilliSeconds(900001);
            // <yes> <report> CS_COOKIE_PERSISTENT 982032
            cookie.Expires = DateTime.Now.AddSeconds(901);
            // <yes> <report> CS_COOKIE_PERSISTENT ddb40a
            cookie.Expires = DateTime.Now.AddMinutes(16.4);
            // <yes> <report> CS_COOKIE_PERSISTENT ed9d81
            httpCookie.Expires = DateTime.Now.AddHours(0.27);
            // <yes> <report> CS_COOKIE_PERSISTENT d5d7c7
            httpCookie.Expires = DateTime.Now.AddDays(0.0105);
            // <yes> <report> CS_COOKIE_PERSISTENT e71ae4
            cookie.Expires = DateTime.Now.AddMonths(3);
            // <yes> <report> CS_COOKIE_PERSISTENT e71ae4
            cookie.Expires = DateTime.Now.AddYears(1);
            // <yes> <report> CS_COOKIE_PERSISTENT 53jk2w
            chv.Expires = DateTime.Now.AddMilliSeconds(900001);

            
        }

        void nothttponly() {
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY ht4pdk
            HttpCookie cookie = new HttpCookie("1", "2");
        }

        void nothttponly2() {
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY ht4pdk
            var cookie = new HttpCookie(TEMP_DATA_COOKIE_NAME) { HttpOnly = false, Value = cookieValue };
        }

        void httponly() {
            // <no> <report>
            HttpCookie cookie = new HttpCookie("2", "3");
            cookie.HttpOnly = true;
        }

        void httponly2() {
            HttpCookie cookie = new HttpCookie("2", "3");
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY 523acc
            cookie.HttpOnly = true && false;
        }

        void httponly3() {
            // <no> <report>
            var cookie = new HttpCookie(TEMP_DATA_COOKIE_NAME) { HttpOnly = true, Value = cookieValue };
        }
    }
}