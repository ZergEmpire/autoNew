using System.Web.UI;

namespace Tests
{
    class CS_ASP_NET_MISCONFIG_MAC
    {
        static void Main()
        {
            Page p = new Page();
            // <yes> <report> CS_ASP_NET_MISCONFIG_MAC c1e435
            p.EnableViewStateMac = false;
        }
    }
}