namespace Tests
{
    class CS_HIDDEN_FIELD
    {
        static void Main()
        {
            // <yes> <report> CS_HIDDEN_FIELD a6abc5
            HtmlInputControl hic = new HtmlInputControl("hidden");
            // <yes> <report> CS_HIDDEN_FIELD 2e5b2c
            HtmlInputHidden hih = new HtmlInputHidden();
        }
    }
}

