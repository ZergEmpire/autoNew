namespace Tests
{
    class CS_HTML5_CORS
    {
        static void Main()
        {
            HttpResponse hr = new HttpResponse();
            // <yes> <report> CS_HTML5_CORS 2e5b2e
            hr.AppendHeader("Access-Control-Allow-Origin","*");
            WebHeaderCollection whc = new WebHeaderCollection();
            // <yes> <report> CS_HTML5_CORS 2e5b2f
            whc.AddWithoutValidate("Access-Control-Allow-Origin","*");
        }

        // <yes> <report> CS_HTML5_CORS chc000
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public int function(int i)
        {
           return i;
        }

        // <no> <report>
        [EnableCors(origins: "https://myclient.azurewebsites.net", headers: "*", methods: "*")]
        public int function(int i)
        {
            return i;
        }
    }
}