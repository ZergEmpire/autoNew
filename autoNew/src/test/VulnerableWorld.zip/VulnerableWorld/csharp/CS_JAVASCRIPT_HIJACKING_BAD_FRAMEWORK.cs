using System.Web.Mvc;
namespace Tests
{
    class CS_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK
    {
        static void Main()
        {
            // <yes> <report> CS_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK 2e5b2d
            ScriptManager sm = new ScriptManager();
        }
        // <yes> <report> CS_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK d915f1
        [AcceptVerbs(HttpVerbs.Get)] 
        public JsonResult GetData()
        {
            var list = new List<ListItem>() {
                new ListItem() { Text = "a" },
                new ListItem() { Text = "b" },
                new ListItem() { Text = "c" }
            };

            return Json(list, JsonRequestBehavior.AllowGet);
        }
        // <yes> <report> CS_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK d925f1    
        [HttpGet] 
        public JsonResult GetData()
        {
            var list = new List<ListItem>() {
                new ListItem() { Text = "d" },
                new ListItem() { Text = "e" },
                new ListItem() { Text = "f" }
            };

            JsonResult jr = Json(list, JsonRequestBehavior.AllowGet);
            jr.doSmth();
            return jr;

        var req = new XMLHttpRequest();
        // <yes> <report> CS_JAVASCRIPT_HIJACKING_BAD_FRAMEWORK 265b2d
        req.open("GET", "/object.json",true);
        }
    }
}