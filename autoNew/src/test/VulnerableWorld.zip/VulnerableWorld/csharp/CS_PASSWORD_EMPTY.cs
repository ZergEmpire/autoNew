using System.DirectoryServices;

namespace Tests
{
    class CS_PASSWORD_MANAGEMENT_EMPTY_PASSWORD
    {
        // <yes> <report> CS_PASSWORD_EMPTY a72d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap22
        public string MyPassword = "";
        // <yes> <report> CS_PASSWORD_EMPTY a71d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
        private string password = "";
        static void Main()
        {
            // <yes> <report> CS_PASSWORD_EMPTY b72d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap21
            string StoredPassword = "";
            // <yes> <report> CS_PASSWORD_EMPTY b71d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string Password = "";
            // <yes> <report> CS_PASSWORD_EMPTY c72d5b
            byte[] Mypassword = enc.GetBytes("");
            // <yes> <report> CS_PASSWORD_EMPTY c71d5b
            byte[] password = enc.GetBytes("");
            // <yes> <report> CS_PASSWORD_EMPTY b72d5b
            char[] PasswordCharArray = "".ToCharArray;
            // <yes> <report> CS_PASSWORD_EMPTY b71d5b
            char[] Password = "".ToCharArray;
            // <yes> <report> CS_PASSWORD_EMPTY d76d5b
            Password.Equals("");
            // <yes> <report> CS_PASSWORD_EMPTY d77d5b
            "".Equals(Password);
            // <yes> <report> CS_PASSWORD_EMPTY d78d5b
            Compare("", Password, true);
            // <yes> <report> CS_PASSWORD_EMPTY d79d5b
            Compare(Password, "", false);

            // <yes> <report> CS_PASSWORD_EMPTY 7546d6
            DirectoryEntry de = new DirectoryEntry("s1","s2","");
            // <yes> <report> CS_PASSWORD_EMPTY 77acf0
            de.Password = "";
            ConnectionString cs = new ConnectionString();
            // <yes> <report> CS_PASSWORD_EMPTY 77bcf0
            cs.Password = "";
            // <yes> <report> CS_PASSWORD_EMPTY c12b34
            NetworkCredential nc1 = new NetworkCredential("","");
            // <yes> <report> CS_PASSWORD_EMPTY 77ccf0
            nc1.Password = "";
            // <yes> <report> CS_PASSWORD_EMPTY a82c5b
            PasswordDeriveBytes pdb = new PasswordDeriveBytes("", salt, "sha256", 100000);
            // <yes> <report> CS_PASSWORD_EMPTY 13m42k
            string connectionstring="Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=;Encrypt=yes";
            // <yes> <report> CS_PASSWORD_EMPTY 19382k
            System.Data.SqlClient.SqlConnection  conn = new SqlConnection("Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=;Encrypt=yes");
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            // <yes> <report> CS_PASSWORD_EMPTY 52kewm
            builder.Add("Password", "");
            // <yes> <report> CS_PASSWORD_EMPTY tjk32s
            builder["password"] = "";

            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP lekrf0
            public string Password { get; set; }
            protected void Page_Load(object sender, EventArgs e)
            {
            // <yes> <report> CS_PASSWORD_EMPTY passwe1
                Password = "";
            }
        }
    }
}