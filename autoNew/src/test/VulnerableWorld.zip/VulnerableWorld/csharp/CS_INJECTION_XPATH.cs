namespace Tests
{
    class CS_INJECTION_XPATH
    {
        static void Main()
        {
            string tainted = "tainted";

            RouteData rd = HttpContext.Request.RequestContext.RouteData;
            string xpath = rd.GetRequiredString("xpath");

            XDocument xd = new XDocument();
            // <yes> <report> CS_INJECTION_XPATH 2e5b3c
            xd.XPathEvaluate(node, xpath);
            // <yes> <report> CS_INJECTION_XPATH 2e5b3c
            xd.XPathSelectElement(node, xpath);
            XElement xe = new XElement();
            // <yes> <report> CS_INJECTION_XPATH 2e5b3d
            xe.XPathEvaluate(node, xpath);
            // <yes> <report> CS_INJECTION_XPATH 2e5b3d
            xe.XPathSelectElement(node, xpath);
            XmlNode xn = new XmlNode();
            // <yes> <report> CS_INJECTION_XPATH 2e5b3f
            xn.SelectNodes(xpath);
            // <yes> <report> CS_INJECTION_XPATH 2e5b3f
            xn.SelectSingleNode(xpath);
            XPathDocument docNav = new XPathDocument(myXml);
            XPathNavigator nav = docNav.CreateNavigator();
            // <yes> <report> CS_INJECTION_XPATH lkfb3f
            nav.Evaluate(xpath);
            XPathCompiler compiler = processor.NewXPathCompiler();
            // <yes> <report> CS_INJECTION_XPATH egreww
            compiler.Compile(xpath);
            // <yes> <report> CS_INJECTION_XPATH xpath0
            XPathBinder.Eval(container, xpath, resolver);

            string userName = ctx.Request.QueryString["userName"];
            string badXPathExpr = "//users/user[login/text()='" + userName + "']/home_dir/text()";
            // <yes> <report> CS_INJECTION_XPATH xpath3
            XPathExpression.Compile(badXPathExpr);

            // XPath expression uses variables to refer to parameters
            string xpathExpression = "//users/user[login/text()=$username]/home_dir/text()";
            // <no> <report> CS_INJECTION_XPATH xpath3
            XPathExpression xpath = XPathExpression.Compile(xpathExpression);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["state"] != null)
            {
                FindSalesPerson(Request.QueryString["state"]);
            }
        }

        private void FindSalesPerson(string state)
        {
            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml(xml);
            XmlNodeList list = xDoc.SelectNodes("//salesperson[state='" + state + "']");
            // <yes> <report> CS_INJECTION_XPATH 2e5b3f
            XmlNodeList list2 = xDoc.SelectNodes("//salesperson[state='" + Request.QueryString["state"] + "']");
            if (list.Count > 0)
            {

            }

        }
    }
}