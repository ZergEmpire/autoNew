namespace Tests
{
    class CS_CRYPTO_KEY_SIZE
    {
        static void Main()
        {
            Aes a = new Aes();
            // <yes> <report> CS_CRYPTO_KEY_SIZE 1372ac
            a.KeySize = 64;
            RSA r = new RSA();
            // <yes> <report> CS_CRYPTO_KEY_SIZE 1373ac
            r.KeySize = 1024;
            // <yes> <report> CS_CRYPTO_KEY_SIZE a8bb5a
            RSACryptoServiceProvider r2 = new RSACryptoServiceProvider(1024);
        }
    }
}