namespace Tests
{
    class CS_INJECTION_LDAP
    {
        static void Main()
        {
            System.String some_string = Request.QueryString["some_string"];
            // <yes> <report> CS_INJECTION_LDAP 7134bc
            DirectorySearcher ds1 = new DirectorySearcher(some_string);
            // <yes> <report> CS_INJECTION_LDAP 1291fa
            ds1.Filter = some_string;
            DirectoryEntry de = new DirectoryEntry();
            // <yes> <report> CS_INJECTION_LDAP ldk8ac
            DirectorySearcher ds2 = new DirectorySearcher(de,some_string);

            // +WEB to return
            string MyCookie = Application.GetCookie(remoteUri);
            // <yes> <report> CS_INJECTION_LDAP 7134bc
            DirectorySearcher ds3 = new DirectorySearcher(MyCookie);
            // <yes> <report> CS_INJECTION_LDAP 1291fa
            ds3.Filter = MyCookie;

        }

        public void ProcessRequest(HttpContext ctx)
        {
            string userName = ctx.Request.QueryString["username"];
            string organizationName = ctx.Request.QueryString["organization_name"];
            // BAD: User input used in DN (Distinguished Name) without encoding
            string ldapQuery = "LDAP://myserver/OU=People,O=" + organizationName;
            // <yes> <report> CS_LDAP_MANIPULATION 1244bc
            using (DirectoryEntry root = new DirectoryEntry(ldapQuery))
            {
                // <yes> <report> CS_INJECTION_LDAP ldk8ac
                DirectorySearcher ds = new DirectorySearcher(root, "username=" + userName);

                SearchResult result = ds.FindOne();
                if (result != null)
                {
                    using (DirectoryEntry user = result.getDirectoryEntry())
                    {
                        ctx.Response.Write(user.Properties["type"].Value)
                    }
                }
            }

            // GOOD: Organization name is encoded before being used in DN
            string safeOrganizationName = Encoder.LdapDistinguishedNameEncode(organizationName);
            string safeLDAPQuery = "LDAP://myserver/OU=People,O=" + safeOrganizationName;
            using (DirectoryEntry root = new DirectoryEntry(safeLDAPQuery))
            {
                // GOOD: User input is encoded before being used in search filter
                string safeUserName = Encoder.LdapFilterEncode(userName);
                DirectorySearcher ds = new DirectorySearcher(root, "username=" + safeUserName);

                SearchResult result = ds.FindOne();
                if (result != null)
                {
                    using (DirectoryEntry user = result.getDirectoryEntry())
                    {
                        ctx.Response.Write(user.Properties["type"].Value)
                    }
                }
            }
        }
    }
}