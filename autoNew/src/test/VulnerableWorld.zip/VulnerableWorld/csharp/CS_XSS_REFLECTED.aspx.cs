using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using OWASP.WebGoat.NET.App_Code.DB;
using OWASP.WebGoat.NET.App_Code;

namespace OWASP.WebGoat.NET
{
    public partial class ReflectedXSS : System.Web.UI.Page
    {

        void LoadCity (String city)
        {
            // <yes> <report> CS_XSS_REFLECTED xssr01 <yes> <report> CS_VALUE_SHADOWING 2e6b33
            lblOutput.Text = "Here are the details for our " + Request["city"] + " Office";
            // <yes> <report> CS_XSS_REFLECTED xssr00 <yes> <report> CS_VALUE_SHADOWING 2e6b33
            lblOutput.Text = Request["city"];
        }

        void FixedLoadCity (String city)
        {
            // <yes> <report> CS_VALUE_SHADOWING 2e6b33
            string city = Request["city"];
            // <yes> <report> CS_XSS_VALIDATION xssv00
            lblOutput.Text = "Here are the details for our " + Server.HtmlEncode(city) + " Office";
        }

        public void ProcessRequest(HttpContext context)
         {
            // <yes> <report> CS_VALUE_SHADOWING jren45
            string query = context.Request["query"];
            // <yes> <report> CS_XSS_REFLECTED gntb4g
            context.Response.Write(query);
         }

         void LoadComments()
         {
            // <yes> <report> CS_VALUE_SHADOWING 2e6b33
            string id = Request["productNumber"];
            DataSet ds = du.GetProductDetails(id);
            foreach (DataRow prodRow in ds.Tables["products"].Rows)
            {
                output += "<hr/>" + prodRow["productDescription"].ToString() + "<br/>";
                hiddenFieldProductID.Value = prodRow["productCode"].ToString();
            }
            context.Response.Write(output);
         }
    }
}