namespace Tests
{
    class CS_CRYPTO_KEY_HARDCODED
    {
        // <yes> <report> CS_CRYPTO_KEY_HARDCODED 32rdnm
        private string encryptionKey = "hardcoded";
        // <yes> <report> CS_CRYPTO_KEY_HARDCODED scdefm
        private const string publicKey = "ApzdknBmkbpVA_PYZJJa9TT0hvTmUSQFKYyf1uyYoSwccUEYu7rfJpXTltrnBJD9";
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_KEY_HARDCODED wfmwl3
            string cryptoKey = "hardcoded";
            // <yes> <report> CS_CRYPTO_KEY_HARDCODED ckh000
            new X509Certificate2("certificate.pfx", "password");
            // <no> <report>
            new X509Certificate2("certificate.pfx", not_literal);
        }
    }
}