using Microsoft.VisualBasic;

namespace Tests
{
    class CS_INSECURE_RANDOMNESS
    {
        static void Main()
        {
            VBMath vbm = new VBMath();
            // <yes> <report> CS_CRYPTO_BAD_RANDOM 54addd
            vbm.Rnd();
            // <yes> <report> CS_CRYPTO_BAD_RANDOM 2acb43
            Random.NextSmth();
            // <yes> <report> CS_CRYPTO_BAD_RANDOM 2acb4a
            VBMath.Rnd();
            Random random = new Random();
            // <yes> <report> CS_CRYPTO_BAD_RANDOM 54addp
            random.Next();
        }
    }
}