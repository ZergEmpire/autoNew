namespace Tests
{
    class CS_PRIVACY_VIOLATION
    {  
        static void Main()
        {
            Chart c = new Chart();
            // <yes> <report> CS_PRIVACY_VIOLATION 2e5b29
            c.ImageStorageMode = 1;
            MyClient client = new MyClient();
            string creditcard = client.GetCreditCardNum();
            EventLog myLog = new EventLog();
            // <yes> <report> CS_PRIVACY_VIOLATION krfgn3
            myLog.WriteEntry(creditcard);
            BinaryWriter writer = new BinaryWriter();
            // <yes> <report> CS_PRIVACY_VIOLATION jgrn34
            writer.Write(creditcard);
            StreamWriter stream = new StreamWriter();
            // <yes> <report> CS_PRIVACY_VIOLATION ewf3jj
            stream.Write(creditcard);
            // <yes> <report> CS_PRIVACY_VIOLATION rop432
            Response.Write(creditcard);
            // <yes> <report> CS_PRIVACY_VIOLATION rop332
            FileContentResult res = new FileContentResult(creditcard, smth);
            DataPointCustomProperties custprop = new DataPointCustomProperties();
            // <yes> <report> CS_PRIVACY_VIOLATION def23q
            custprop.LegendMapAreaAttributes = creditcard;
            HtmlTextArea area = new HtmlTextArea();
            // <yes> <report> CS_PRIVACY_VIOLATION 32f23q
            area.Value = creditcard;
            HtmlAnchor anchor = new HtmlAnchor();
            // <yes> <report> CS_PRIVACY_VIOLATION erfwfq
            anchor.Title = creditcard;
            // <yes> <report> CS_PRIVACY_VIOLATION sdf3es
            anchor.InnerHtml = creditcard;
            AdRotator rot = new AdRotator();
            // <yes> <report> CS_PRIVACY_VIOLATION wer2ws
            rot.Target = creditcard;
            CustomValidator valid = new CustomValidator();
            // <yes> <report> CS_PRIVACY_VIOLATION mfmfks
            valid.ClientValidationFunction = creditcard;
            DetailsView view = new DetailsView();
            // <yes> <report> CS_PRIVACY_VIOLATION fkrn53
            view.Caption = creditcard;
            HyperLink link = new HyperLink();
            // <yes> <report> CS_PRIVACY_VIOLATION pv0000
            link.Text = creditcard;
            ListItem Item = new ListItem();
            // <yes> <report> CS_PRIVACY_VIOLATION pv0000
            Item.Text = creditcard;
            RegularExpressionValidator validate = new RegularExpressionValidator();
            // <yes> <report> CS_PRIVACY_VIOLATION fnrelw
            validate.ValidationExpression = creditcard;
            TextBox tbox = new TextBox();
            // <yes> <report> CS_PRIVACY_VIOLATION pv0000
            tbox.Text = creditcard;
            Xml xml = new Xml();
            // <yes> <report> CS_PRIVACY_VIOLATION iknewb
            xml.DocumentContent = creditcard;
            AttributeCollection myAttributeCollection = new AttributeCollection(ViewState);
            // <yes> <report> CS_PRIVACY_VIOLATION 33rn34
            myAttributeCollection.Add(creditcard ,"Color.Red");
            Control myControl = new Control();
            // <yes> <report> CS_PRIVACY_VIOLATION jflsnm
            myControl.ID = creditcard;
            StringWriter writer = new StringWriter();
            // <yes> <report> CS_PRIVACY_VIOLATION ddfwsz
            Server.HtmlEncode(creditcard, writer);
            // <yes> <report> CS_PRIVACY_VIOLATION 3dfwsz
            Clipboard.SetDataObject(creditcard);
            // <yes> <report> CS_PRIVACY_VIOLATION 3llwsz <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.Write(creditcard);
            // <yes> <report> CS_PRIVACY_VIOLATION rr5b29
            Exception ex = new Exception(creditcard);
            // <yes> <report> CS_PRIVACY_VIOLATION yeujwe
            ex.HelpLink = creditcard;
            // <yes> <report> CS_PRIVACY_VIOLATION tjekq3 
            Logger.SetContextItem(creditcard, myComponent.SessionId);
            Logger logger = LogManager.GetCurrentClassLogger();
            // <yes> <report> CS_PRIVACY_VIOLATION threkl
            logger.Trace(creditcard);
            Socket s = new Socket();
            // <yes> <report> CS_PRIVACY_VIOLATION ab5g00
            s.SendFile(creditcard);
            IClientTransport transport = new IClientTransport();
            // <yes> <report> CS_PRIVACY_VIOLATION ewf00j
            transport.Send(creditcard);

            ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

            // <yes> <report> CS_PRIVACY_VIOLATION prida1
            log.WarnFormat(format, "User " + email + " attempted to log in with password " + getPassword(txtEmail.Text));

            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap21
            Label labelPassword = new Label();
            // <yes> <report> CS_PRIVACY_VIOLATION pv0000
            labelPassword.Text = "Security Question Challenge Successfully Completed! <br/>Your password is: " + getPassword(txtEmail.Text);
            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap21
            TextBox txtPassword = new TextBox();
            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string pwd = txtPassword.Text;
            // <yes> <report> CS_PRIVACY_VIOLATION prida0 <yes> <report> CS_LOGGING_LOG_FORGING lkad17
            log.Info("User " + email + " attempted to log in with password " + pwd);
        }
    }
}

