using System.Xml;

namespace Tests
{
    class CsInjectionXml
    {
        static void Main()
        {
            // 1. missing validation
            TextReader tr = File.OpenText(xmlfile);
            // <yes> <report> CS_INJECTION_XML_NO_VALIDATION 7e323f
            XmlReader reader = XmlReader.Create(tr);
            
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(schema);
            settings.ValidationType = ValidationType.Schema;
            // <no> <report>
            XmlReader reader = XmlReader.Create(sr, settings);
            XmlTextReader reader = new XmlTextReader(new StringReader(existingAssociation.AssociationData));
            
            // 2. ...
            Stream readStream;
                try
                {
                    readStream = File.Open(input, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                }
                catch (IOException e)
                {
                    ConsoleApplication.WriteMessage(LogLevel.Error, String.Format("The input file '{0}' could not be loaded. The error is: {1}", input, e.Message));
                    return (1);
                }
                catch (UnauthorizedAccessException e)
                {
                    ConsoleApplication.WriteMessage(LogLevel.Error, String.Format("The input file '{0}' could not be loaded. The error is: {1}", input, e.Message));
                    return (1);
                }
                // <yes> <report> CS_INJECTION_XML_NO_VALIDATION 7e323f
                using (XmlReader reader = XmlReader.Create(readStream))
        }
    }
}