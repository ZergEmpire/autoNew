namespace Tests 
{
    class CS_XSS_VALIDATION
        {
            static void Main()
            {
                // +WEB to return
                string tainted = Request.RawUrl;
                // +POOR_VALIDATION to return
                string encoded_string = AntiXssEncoder.HtmlEncode(tainted, true);
                TextField textField = new TextField();
                // <yes> <report> CS_XSS_VALIDATION xssv00
                textField.Text = encoded_string;
                HttpWriter writer  = new HttpWriter();
                // <yes> <report> CS_XSS_VALIDATION greb4g
                writer.Write(encoded_string);
                // <yes> <report> CS_XSS_VALIDATION dfklw3
                Response.BinaryWrite(encoded_string);
                HtmlHelper helper = new HtmlHelper();
                // <yes> <report> CS_XSS_VALIDATION weo24m
                helper.Raw(encoded_string);
                DataPointCustomProperties prop = new DataPointCustomProperties();
                // <yes> <report> CS_XSS_VALIDATION owrjnr
                prop.LegendMapAreaAttributes = encoded_string;
                HtmlAnchor anchor = new HtmlAnchor();
                // <yes> <report> CS_XSS_VALIDATION opwe2n
                anchor.InnerHtml = encoded_string;
                HtmlSelect sel = new HtmlSelect();
                // <yes> <report> CS_XSS_VALIDATION tgenlw
                sel.DataSource = encoded_string;
                HtmlTitle title = new HtmlTitle();
                // <yes> <report> CS_XSS_VALIDATION wrij3w
                title.Name = encoded_string;
                GenericWebPart webPart = new GenericWebPart();
                // <yes> <report> CS_XSS_VALIDATION njre22
                webPart.Title = encoded_string;
                AdRotator ad = new AdRotator();
                // <yes> <report> CS_XSS_VALIDATION wefw33
                ad.Target = encoded_string;
                ChangePassword pass = new ChangePassword();
                // <yes> <report> CS_XSS_VALIDATION rgb321
                pass.ChangePasswordButtonText = encoded_string;
                HyperLink link = new HyperLink();
                // <yes> <report> CS_XSS_VALIDATION xssv00
                link.Text = encoded_string;
                DataBoundLiteralControl control = new DataBoundLiteralControl();
                // <yes> <report> CS_XSS_VALIDATION jent3w
                control.SetDataBoundString(4, encoded_string);
                ClientScriptManager cs = Page.ClientScript;
                // <yes> <report> CS_XSS_VALIDATION 5tnk3s
                cs.RegisterClientScriptBlock(csType, csName, encoded_string);
                HtmlTextWriter writer = new HtmlTextWriter();
                // <yes> <report> CS_XSS_VALIDATION retkee
                writer.AddAttribute(encoded_string, attr);
            }
        }
}