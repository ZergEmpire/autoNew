using System.Text.RegularExpressions;

namespace Tests
{
    class CS_FILE_INCLUSION
    {
        static void Main()
        {
            string url = Request.RawUrl;
            ClientScriptManager cs = Page.ClientScript;
            // <yes> <report> CS_FILE_INCLUSION rwtjn4
            cs.RegisterClientScriptInclude(cstype, csname, url);
        }
    }
}