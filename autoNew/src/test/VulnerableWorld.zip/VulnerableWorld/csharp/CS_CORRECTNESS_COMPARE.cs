namespace Tests
{
    class CS_CORRECTNESS_COMPARE
    {
        static void Main()
        {
            Type t = typeof(String);
            // <yes> <report> CS_CORRECTNESS_COMPARE erjnws
            if (t.AssemblyQualifiedName == "class")
            {
                // dosmth
            }
            // <yes> <report> CS_CORRECTNESS_COMPARE erjnws <yes> <report> CS_CORRECTNESS_COMPARE erjn5s
            if (inputReader.GetType().AssemblyQualifiedName == "class")
            {
                // dosmth
            }
            string className = t.AssemblyQualifiedName;
            // <yes> <report> CS_CORRECTNESS_COMPARE erj333
            if (className.Equals("class"))
            {
                // dosmth
            }
            // <yes> <report> CS_CORRECTNESS_COMPARE rehb3s
            if ("className".Equals(className))
            {
                // dosmth
            }
            // <no> <report>
            if (inputReader.GetType().AssemblyQualifiedName == null)
            {
                // dosmth
            }
        }
    }
}