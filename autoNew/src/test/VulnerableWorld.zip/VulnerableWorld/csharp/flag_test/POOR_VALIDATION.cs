namespace Tests
{
    class POOR_VALIDATION
    {
        static void Main()
        {
            // +URL_ENCODE +POOR_VALIDATION to return 
            var encodedString = WebUtility.UrlEncode("string");
        }
     }
}


