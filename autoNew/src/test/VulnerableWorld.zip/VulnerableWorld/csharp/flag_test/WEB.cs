namespace Tests
{
    class WEB
    {
        static void Main()
        {
            DirectoryEntry entry = new DirectoryEntry();
            // +WEB to return
            var obj = entry.Invoke("method", "args");
            // <yes> <report> CS_INJECTION_RESOURCE c91ah1
            Socket s = new Socket(endPoint.Address.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
            byte[] msg = new Byte[256];
            // +WEB to arg = 0
            s.ReceiveFrom(msg, ref senderRemote);

            TcpClient client = new TcpClient(server, port);
            // +WEB to return
            NetworkStream stream = client.GetStream();

            WebClient client = new WebClient();
            string remoteUri = Console.ReadLine();
            // +WEB to return
            byte[] data = client.DownloadData(remoteUri);
            // +WEB to return
            string MyCookie = Application.GetCookie(remoteUri);

            TextBox textBox1 = new TextBox();
            // +WEB to return
            string domain = textBox1.GetLineText(5);
            HttpWebRequest request = WebRequest.Create("smth");
            // +WEB to rerurn
            IEnumerable<string> headerValues = request.Headers.GetValues("MyCustomID");
            // +WEB to return
            string Msg = Request.QueryString["Message"];
            // +WEB to return
            string redirectUrl = Request.RawUrl;
            // +WEB to return
            // <yes> <report> CS_VALUE_SHADOWING 2e6b33
            object o = Request["Text"];
            MailMessage message = new MailMessage("jane@contoso.com", "ben@contoso.com", "Quarterly data report.", "See the attached spreadsheet.");
            // +WEB to return
            var attachments = message.Attachments;
            WebResponse myWebResponse = myWebRequest.GetResponse();
            // +WEB to return
            var length = myWebResponse.ContentLength;
            RouteValueDictionary dict = RouteValueDictionary();
            // +WEB to return
            object item = dict["string"];
            HtmlTextArea area = new HtmlTextArea();
            // +WEB to return
            var value = area.Value;
            TextBox box = new TextBox();
            // +WEB to return
            var tainted = box.Text;
            // +WEB to return
            string source = BrowserInteropHelper.Source;
            RichTextBox rtb = new RichTextBox();
            // +WEB to return
            FlowDocument rtbContents = rtb.Document;
            PasswordBox pwdBox = new PasswordBox();
            // +WEB to return
            var pwd = pwdBox.Password;
            // +WEB to return from arg0
            string returnUrl = Server.UrlDecode(Request.QueryString["url"]);

            ClientWebSocket webSocket = new ClientWebSocket();
            // +WEB to arg0
            var receivedData = webSocket.ReceiveAsync(buf, token);

            SerialPort serialPort = new SerialPort();
            // +WEB to return
            int bytes = serialPort.ReadByte();
        }
    }
}