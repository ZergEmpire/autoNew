namespace Tests
{
    class DATABASE
    {
        static void Main()
        {
           ResultTable table = new ResultTable(); 
           // +DATABASE to return
           string p = table.GetString(10);
           //
           object item = table[3];

           SqlCommand command = new SqlCommand();
           // +DATABASE to return
           XmlReader reader = command.ExecuteXmlReader();
                 // +DATABASE to return
           var myQuery  = SqlHelper.ExecuteScalar(constr, CommandType.Text, query, parameters.ToArray());

          string strQuery = "SELECT * FROM employees WHERE id=999";
          ObjectContext context = new ObjectContext();
          // +DATABASE to return
          var services = context.ExecuteStoreQuery<T>(strQuery, "employees", System.Data.Objects.MergeOption.AppendOnly);
          HtmlTextWriter writer;
          string str;
          // +DATABASE to return from arg1 (passthrough)
          using (var attribute = writer.EncodeAttributeValue(str, services))
          {
            if(smth == true)
            {
              using (TextReader reader = Text.Create(smth))
              {
                // +DATABASE to return from arg0 (passthrough)
                var tainted = reader.Synchronized(attribute);
              }
            }
            else
            {
              // +DATABASE to return from arg0 (passthrough)
              var tainted2 = File.Combine(attribute);
            }
          }
          Color c = (Color) (new Random()).Next(0, 3);
          switch (c)
          {
            case Color.Red:
            // +DATABASE to return from arg0 (passthrough)
              Paragraph para = new Paragraph(tainted2);
              break;
            case Color.Green:
            // no flag
              Paragraph para = new Paragraph(not_tainted);
              break;
            case Color.Blue:
            // +DATABASE to return from arg0 (passthrough)
              Paragraph para = new Paragraph(tainted); 
              break;
            default:
            // no flag
              Paragraph para = new Paragraph();
              break;   
        }
        // +DATABASE to return
        var state = ViewState["previous_page"].ToString();
        ModelState model = new ModelState();
        // +DATABASE to return
        var value = model.Value;
        ViewPage page = ViewPage();
        // +DATABASE to return
        var mod = page.Model;
        DataListItem list = new DataListItem();
        // +DATABASE to return
        var item2 = list.DataItem;
        DataBoundLiteralControl boundLiteralControl = (DataBoundLiteralControl)Controls[0];
        // +DATABASE to return
        String text = boundLiteralControl.Text;
        LinkedListNode<String> lln = new LinkedListNode<String>( "orange" );
        // +DATABASE to this
        lln.Value = item2;
        // from args to return
        StringBuilder stringBuilder = new StringBuilder(text, capacity);

        }
    }
}