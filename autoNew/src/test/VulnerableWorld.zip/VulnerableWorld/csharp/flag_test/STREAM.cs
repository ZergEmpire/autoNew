namespace Tests
{
    class STREAM
    {
        static void Main()
        {
            using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
            {
                // +STREAM to this
                reader.FillBuffer(123);
                // +STREAM to return
                int b = reader.PeekChar();
                // +STREAM to arg pos=0
                // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9473
                int r = reader.Read(verifyArray, 0, arrayLength);
                // +STREAM to return
                var output = Response.OutputStream;
                // +STREAM to return
                string queryString = ApplicationDeployment.CurrentDeployment.ActivationUri.Query;
            }

        }
    }
}