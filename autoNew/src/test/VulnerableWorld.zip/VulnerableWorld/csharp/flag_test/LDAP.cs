namespace Tests
{
    class LDAP
    {
        static void Main()
        {
            DirectorySearcher search = new DirectorySearcher();
            // +LDAP to return
            SearchResult res = search.FindOne();
        }
    }
}