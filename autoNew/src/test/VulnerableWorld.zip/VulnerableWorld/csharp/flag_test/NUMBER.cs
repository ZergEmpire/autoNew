namespace Tests
{
    class WEB
    {
        static void Main()
        {
            FtpWebResponse response = (FtpWebResponse) request.GetResponse();
            // +WEB and +NUMBER to return
            var code = response.StatusCode;
        }
    }
}