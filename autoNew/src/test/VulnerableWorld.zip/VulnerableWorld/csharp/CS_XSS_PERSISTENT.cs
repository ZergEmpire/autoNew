namespace Tests 
{
    class CS_XSS_PERSISTENT
    {
        static void Main()
        {
            DbContext a = new DbContext();
            var b = a.Set(type);
            ObjectContext context = new ObjectContext("name=AdventureWorksEntities");
            var query = context.CreateObjectSet();
            
            HtmlTextWriter text = new HtmlTextWriter();
            // <yes> <report> CS_XSS_PERSISTENT ae5b28
            text.Write(b);
            // abstract class, поэтому реализуется с помощью наследования в реальных программах
            HttpResponseBase resp = new HttpResponseBase();
            // <yes> <report> CS_XSS_PERSISTENT aezb28
            resp.BinaryWrite(b);

            ListItemCollection item = new ListItemCollection();
            // <yes> <report> CS_XSS_PERSISTENT mezba8
            item.Add(b);

            DataBoundLiteralControl data = new DataBoundLiteralControl(1,2);
            // <yes> <report> CS_XSS_PERSISTENT m1zba8
            data.SetDataBoundString(10, b);

            ClientScriptManager cs = Page.ClientScript;
            // <yes> <report> CS_XSS_PERSISTENT q1zba8
            cs.RegisterClientScriptBlock(cstype, csname2, b.ToString(), false);

            HtmlTextWriter writer = new HtmlTextWriter(TextWriter);
            // <yes> <report> CS_XSS_PERSISTENT q1zba1
            writer.AddAttribute(b, "alert('Hello');" );

            var attributes = new AttributeCollection();
            // <yes> <report> CS_XSS_PERSISTENT q11ba1
            attributes.Add(query, "value1");

            HttpResponse response = new HttpResponse(text);
            // <yes> <report> CS_XSS_PERSISTENT q11la1
            response.BinaryWrite(b);

            Stream stream1 = new Stream();
            XmlDocument doc = new XmlDocument();
            ok = doc.Load("booksData.xml");
            bad = doc.Load(stream1);
            

            RequestValidator rv = new RequestValidator();
            rv.IsValidRequestString(context, val,
            requestValidationSource,
            collectionKey, out validationFailureIndex);

            Stream stream2 = new Stream();
            XmlTextReader reader = new XmlTextReader(stream2, schema);

            IPAddress ip = new IPAddress();
            n = ip.Parse(b);
            // <no> <report>
            data.SetDataBoundString(10, n);
            // <yes> <report> CS_XSS_PERSISTENT q11lm1
            FileContentResult fcr = new FileContentResult(reader, str);

            JavaScriptResult res = new JavaScriptResult();
            // <yes> <report> CS_XSS_PERSISTENT rlr415
            res.Script = query;

            ContentResult content = new ContentResult();
            // <yes> <report> CS_XSS_PERSISTENT 12r415
            content.Content = query;

            DataPointCustomProperties prop = new DataPointCustomProperties();

            DirectorySearcher search = new DirectorySearcher();
            SearchResult sr = search.FindOne();
            // <yes> <report> CS_XSS_PERSISTENT 126415
            prop.LegendMapAreaAttributes = sr;
            System.Web.UI.HtmlControls.HtmlAnchor dataBinding;
            // <yes> <report> CS_XSS_PERSISTENT 188415
            dataBinding.HRef = global::System.Convert.ToString(DataBinder.Eval(Container.DataItem,"Url"));
            DataList list = new DataList();
            // <yes> <report> CS_XSS_PERSISTENT regst5
            list.DataSource = sr;
            target.SetDataBoundString(0, global::System.Convert.ToString(Eval("TVTitle"), global::System.Globalization.CultureInfo.CurrentCulture));
            target.SetDataBoundString(1, global::System.Convert.ToString(Eval("TVDescription"), global::System.Globalization.CultureInfo.CurrentCulture));

            var editor = new Label { Text = "loading...", HeightRequest = 300};
            var assembly = IntrospectionExtensions.GetTypeInfo(typeof(LoadResourceText)).Assembly;
            Stream stream = assembly.GetManifestResourceStream("WorkingWithFiles.LibTextResource.txt");
            string text = "";
            using (var reader2 = new StreamReader(stream))
            {
                text = reader2.ReadToEnd ();
            }
            // <yes> <report> CS_XSS_PERSISTENT xssp00
            editor.Text = text;

            protected virtual object Eval(string expression) {
                    return global::System.Web.UI.DataBinder.Eval(this.Page.GetDataItem(), expression);
            }
        }
    }
}
