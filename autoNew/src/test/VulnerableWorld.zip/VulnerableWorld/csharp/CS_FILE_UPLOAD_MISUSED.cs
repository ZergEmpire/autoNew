using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Tests
{
    class CsFileUloadMisused
    {
        static void Main()
        {
            FileUpload FileUpload1 = new FileUpload();
            // file1 is obtained e.g. from an HTML form via HtmlInpitFile control
            HttpPostedFile file1 = new HttpPostedFile();
            string filename = Path.GetFileName(FileUpload1.FileName);
            // <yes> <report> CS_FILE_UPLOAD_MISUSED d915f3
            file1.SaveAs(filename);
            FileUpload file2 = new FileUpload();
            // <yes> <report> CS_FILE_UPLOAD_MISUSED d915f5
            file2.SaveAs(filename);
            // <yes> <report> CS_FILE_UPLOAD_MISUSED d915f5
            FileUpload1.SaveAs(filename);
            // <yes> <report> CS_FILE_UPLOAD_MISUSED 2e5b2a
            HttpPostedFile hpf = HtmlInputFile.PostedFile;
            // <yes> <report> CS_FILE_UPLOAD_MISUSED d915f3
            hpf.SaveAs(filename);

            string filename = Path.GetFileName(FileUpload1.FileName);
            // <yes> <report> CS_FILE_UPLOAD_MISUSED d915f5
            FileUpload1.SaveAs(Server.MapPath("~/WebGoatCoins/uploads/") + filename);
        }   
        // <yes> <report> CS_FILE_UPLOAD_MISUSED d915f7
        public FileResult Upload(HttpPostedFileBase photo)
        {
            return View();
        }
    }
}