namespace Tests
{
    class CS_BACKDOOR_TIMEBOMB
    {
        string date = "2011-10-12";
        string date2;
        string date3;
        string date4;

        static void Main()
        {
            // <no> <report>
            dateTimestamp == DateTime.Parse(date);

            // <no> <report>
            dateTimestamp1 == DateTime.Parse("2001-01-01");

            // <no> <report>
            dateTimestamp2 <= DateTime.Parse("2008-09-01");

            // <no> <report>
            dateTimestamp3 >= DateTime.Parse("1995-24-07");

            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t11
            if (date2 == DateTime.Parse("2008-09-01 12:35:45"))
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17 
                Console.WriteLine("backdoor!");
            }

            // <no> <report>
            DateTime.Now == 123;

            // <no> <report>
            DateTime.Second >= 123.2;

            // <no> <report>
            DateTime.TimeOfDay > 1;

            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb7
            Assert(DateTime.UtcNow < 1);
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb7
            Assert.IsTrue(DateTime.UtcNow < 1);
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb8
            Assert.IsTrue(DateTime.UtcNow == 1);
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t15
            DateTime.TimeOfDay > 1 ? true : false;
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t17
            dateTimestamp1 > DateTime.Parse("2001-01-01") ? true : false;
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t16
            dateTimestamp1 == DateTime.Parse("2001-01-01") ? true : false;
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t12
            DateTime.TimeOfDay == 1 ? true : false;
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb9
            if (DateTime.TimeOfDay > 1) { true; }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t10
            if (DateTime.TimeOfDay == 1) { true; }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t13
            switch (DateTime.TimeOfDay) {
                case 1:
                    true;
                    break;
            }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t10
            while (DateTime.Now == 123) { true; }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb9
            while (DateTime.Now > 123) { true; }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t11
            while (dateTimestamp1 == DateTime.Parse("2001-01-01")) { true; }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb9
            for (int i = 0; i < DateTime.Second; i++) { true; }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11tb9
            do { true; } while (DateTime.Now > 12);
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t11
            do { true; } while (dateTimestamp1 == DateTime.Parse("2001-01-01"));
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t14
            do { true; } while (dateTimestamp1 > DateTime.Parse("2001-01-01"));
            // <no> <report>
            if (_requestParameters.Date == null || _requestParameters.Date == null) {
                return;
            }
            // <no> <report>
            if (null == _requestParameters.Date) {
                return;
            }
            // <yes> <report> CS_BACKDOOR_TIMEBOMB b11t10
            if ("2021-02-12" == _requestParameters.Date) {
                return;
            }
        }
    }
}