namespace Tests
{
    class CS_INFORMATION_LEAK_EXTERNAL
    {
        static void Main()
        {
            HttpResponseBase rb = new HttpResponseBase();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL 67189c
            rb.WriteFile();
            
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL 67189c
            rb.TransmitFile();
            Exception ex = new Exception();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL qwer43
            rb.Write(ex.ToString());
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL qwer43
            Response.Write(ex.ToString());

            Exception myException = new Exception("This is an exception test");
            // +SYSTEM_INFO to return
            string e = myException.ToString();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL k23r43
            FileContentResult result = new FileContentResult(e, "application/octet-stream");
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL k23r43
            var result = new FileStreamResult(e, "application/zip") 
                    { FileDownloadName = "hey.zip" };
            var content = new ContentResult();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL kkdfgn
            content.Content = e;
            HtmlAnchor a = new HtmlAnchor();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL 23dfgn
            a.Title = e;
            HtmlSelect mHtmlSelect = new HtmlSelect();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL 13dfgn
            mHtmlSelect.DataSource = e;
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL ldkfge
            mHtmlSelect.InnerText = e;
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL qwer43
            Response.AppendToLog(e);
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL ldd89c
            Response.WriteFile(e);

            HttpResponse response = httpContext.Response;
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL qwer43
            response.Write(e);
            AttributeCollection myAttributeCollection = new AttributeCollection(ViewState);
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL dfer43
            myAttributeCollection.Add(e);
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL see2k4
            Server.UrlEncode(e, writer);
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL sde2k4
            HttpUtility.HtmlAttributeEncode(e, writer);
            Control myControl = new Control();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL kfjren
            myControl.ID = e;
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL 111111
            ltError.Text = ex.Message + " " + ex.StackTrace;
            PrintDialog pDialog = new PrintDialog();
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL abkjt0
            pDialog.PrintDocument(e);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            // <yes> <report> CS_INFORMATION_LEAK_EXTERNAL ile000
            app.UseDeveloperExceptionPage();
        }
    }
}