namespace Tests
{
    // <no> <report>
    [System.Web.Services.WebServiceBindingAttribute(Name="DataProvider", Namespace="http://very.good/namespace")]
    public partial class PublicPartialClass : System.Web.Services.Protocols.SoapHttpClientProtocol {
    }

    class CS_HTTP_USAGE
    {

        // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa7
        private const string Host = "http://host.net/";
        // <yes> <report> CS_HTTP_USAGE gregj2 <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY bl1sa7
        private const string localHost = "http://localhost/";
        static void Main()
        {
            // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string host = "http://net.va";
            // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa6
            host = "http://va.net";
            // <yes> <report> CS_HTTP_USAGE gre3jk
            var message = Smth.Get("переходи по ссылке http://sberbank.ru/appfriends");

            // <no> <report>
            var message = Smth.Get("http://apache.org/xml/");
            // <no> <report>
            var message = Smth.Get("http://xml.org/sax");
            // <no> <report>
            var message = Smth.Get("http://javax.xml.XMLConstants");

            XmlNamespaceManager nsmgr = new XmlNamespaceManager();
            // <no> <report>
            nsmgr.AddNamespace("wx", "http://schemas.microsoft.com/office/word/2010/wordml");

            // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string hostAgain = "http://net.va";
            // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa6
            hostAgain = "http://va.net";
        }
    }

    // <no> <report>
    [System.Web.Services.WebServiceBindingAttribute(Name="DataProvider", Namespace="http://very.good/namespace")]
    public partial class PublicPartialClass2 : System.Web.Services.Protocols.SoapHttpClientProtocol {
    }
}