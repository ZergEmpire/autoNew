namespace Tests
{
    class CS_INSECURE_TRANSPORT
    {
        public static void EnableSslTrue(string server)
        {
            string to = "jane@contoso.com";
            string from = "ben@contoso.com";
            MailMessage message = new MailMessage(from, to);
            message.Subject = "Using the new SMTP client.";
            message.Body = @"Using this new feature, you can send an e-mail message from an application very easily.";
            SmtpClient client = new SmtpClient(server);
            // Credentials are necessary if the server requires the client 
            // to authenticate before it will send e-mail on the client's behalf.
            client.UseDefaultCredentials = true;
            client.EnableSsl = true;
            client.Send(message);
        }
        public static void NotEnablessl(string server)
        {
            string to = "jane@contoso.com";
            string from = "ben@contoso.com";
            MailMessage message = new MailMessage(from, to);
            message.Subject = "Using the new SMTP client.";
            message.Body = @"Using this new feature, you can send an e-mail message from an application very easily.";
            SmtpClient client2 = new SmtpClient(server);
            // <yes> <report> CS_INSECURE_TRANSPORT fjng54
            client2.Send(message);
        }
        public static void EnableSslFalse(string server)
        {
            string to = "jane@contoso.com";
            string from = "ben@contoso.com";
            MailMessage message = new MailMessage(from, to);
            message.Subject = "Using the new SMTP client.";
            message.Body = @"Using this new feature, you can send an e-mail message from an application very easily.";
            SmtpClient client3 = new SmtpClient(server);
            // Credentials are necessary if the server requires the client 
            // to authenticate before it will send e-mail on the client's behalf.
            client3.UseDefaultCredentials = true;
            client3.EnableSsl = false;
            // <yes> <report> CS_INSECURE_TRANSPORT fjng54
            client3.Send(message);
        }
        public static void DifficultEnableSsl()
        {
            var smtp = new SmtpClient
            {
                EnableSsl = true
            };

            using (var message = new MailMessage(fromAddress.Address, toAddress)
            {
                Subject = subject,
                Body = body,
                IsBodyHtml = true
            })
            {
                // <no> <report>
                smtp.Send(message);
            }
        }
    }
}