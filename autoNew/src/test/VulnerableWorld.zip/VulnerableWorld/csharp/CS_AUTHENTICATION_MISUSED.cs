namespace Tests
{
    class CS_AUTHENTICATION_MISUSED
    {
        static void Main()
        {
            Dns d = new Dns();
            // <yes> <report> CS_AUTHENTICATION_MISUSED ab71dc
            d.BeginGetHostByName();
        }
    }
}