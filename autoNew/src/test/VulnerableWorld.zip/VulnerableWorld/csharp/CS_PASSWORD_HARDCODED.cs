
using System.DirectoryServices;

namespace Tests
{
    class CS_PASSWORD_MANAGEMENT_HARDCODED_PASSWORD
    {
        // <yes> <report> CS_PASSWORD_HARDCODED a62d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap22
        public string MyPassword = "hardcoded";
        // <yes> <report> CS_PASSWORD_HARDCODED a62d5t <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap22
                public string MyPassword = "hard coded";
        // <yes> <report> CS_PASSWORD_HARDCODED a61d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
        private string password = "hardcoded";
        // <yes> <report> CS_PASSWORD_HARDCODED a61d5t <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
        private string password = "hard coded";
        static void Main()
        {
            // <yes> <report> CS_PASSWORD_HARDCODED b62d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap21
            string StoredPassword = "hardcoded";
            // <yes> <report> CS_PASSWORD_HARDCODED b62d5t <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap21
            string StoredPassword = "hard coded";
            // <yes> <report> CS_PASSWORD_HARDCODED b61d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string Password = "hardcoded";
            // <yes> <report> CS_PASSWORD_HARDCODED b61d5t <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string Password = "hard coded";
            // <yes> <report> CS_PASSWORD_HARDCODED c62d5b
            byte[] Mypassword = enc.GetBytes("string");
            // <yes> <report> CS_PASSWORD_HARDCODED c62d5t
            byte[] Mypassword = enc.GetBytes("st ring");
            // <yes> <report> CS_PASSWORD_HARDCODED c61d5b
            byte[] password = enc.GetBytes("string");
            // <yes> <report> CS_PASSWORD_HARDCODED c61d5t
            byte[] password = enc.GetBytes("str ing");
            // <yes> <report> CS_PASSWORD_HARDCODED b62d5b
            char[] PasswordCharArray = "hardcoded".ToCharArray;
            // <yes> <report> CS_PASSWORD_HARDCODED b62d5t
            char[] PasswordCharArray = "hard coded".ToCharArray;
            // <yes> <report> CS_PASSWORD_HARDCODED d62d5b <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b12sa1 
            StoredPassword.Equals("realpassword");
            // <yes> <report> CS_PASSWORD_HARDCODED d62d5t <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b12sa1
            StoredPassword.Equals("realpas sword");
            // <yes> <report> CS_PASSWORD_HARDCODED d66d5b <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b12sa1 
            Password.Equals("realpassword");
            // <yes> <report> CS_PASSWORD_HARDCODED d66d5t <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b12sa1
            Password.Equals("real password");
            // <yes> <report> CS_PASSWORD_HARDCODED d63d5b
            "UserPwd".Equals(StoredPassword);
            // <yes> <report> CS_PASSWORD_HARDCODED d63d5t
            "User Pwd".Equals(StoredPassword);
            // <yes> <report> CS_PASSWORD_HARDCODED d64d5b
            Compare("qwerty", StoredPassword, true);
            // <yes> <report> CS_PASSWORD_HARDCODED d64d5t
            Compare("qwe rty", StoredPassword, true);
            // <yes> <report> CS_PASSWORD_HARDCODED d68d5b
            Compare("qwerty", Password, true);
            // <yes> <report> CS_PASSWORD_HARDCODED d68d5t
            Compare("qwe rty", Password, true);
            // <yes> <report> CS_PASSWORD_HARDCODED d65d5b
            Compare(StoredPassword, "qwerty", false);
            // <yes> <report> CS_PASSWORD_HARDCODED d65d5t
            Compare(StoredPassword, "qwe rty", false);
            // <yes> <report> CS_PASSWORD_HARDCODED d67d5b
            "UserPwd".Equals(Password);
            // <yes> <report> CS_PASSWORD_HARDCODED d67d5t
            "User Pwd".Equals(Password);
            // <yes> <report> CS_PASSWORD_HARDCODED d69d5b
            Compare(Password, "qwerty", false);
            // <yes> <report> CS_PASSWORD_HARDCODED d69d5t
            Compare(Password, "qwe rty", false);
            // <yes> <report> CS_PASSWORD_HARDCODED 7254d0
            DirectoryEntry de = new DirectoryEntry("s1","s2","s3");
            // <yes> <report> CS_PASSWORD_HARDCODED 87acf0
            de.Password = "s4";
            // <yes> <report> CS_PASSWORD_HARDCODED 87acft
            de.Password = "s 4";
            ConnectionStringSettings css = new ConnectionStringSettings();
            // <yes> <report> CS_PASSWORD_HARDCODED df9cb6
            css.ConnectionString = "pwd";
            // <yes> <report> CS_PASSWORD_HARDCODED 10b23c
            ConnectionString cs = new ConnectionString("pwd");
            // <yes> <report> CS_PASSWORD_HARDCODED 87bcf0
            cs.Password = "pass";
            // <yes> <report> CS_PASSWORD_HARDCODED 87bcft
            cs.Password = "pa ss";
            DBDataPermissionAttribute dpa = new DBDataPermissionAttribute();
            // <yes> <report> CS_PASSWORD_HARDCODED df8cb6
            dpa.ConnectionString = "pwd";
/* интерфейс задается по-другому, когда будем отслеживать supers надо будет переделать паттерн
            <yes> <report> CS_PASSWORD_HARDCODED 781bca
            IDbConnection idc = new IDbConnection("pwd");
            <yes> <report> CS_PASSWORD_HARDCODED df9cb6
            idc.ConnectionString = "pwd";
*/
            // <yes> <report> CS_PASSWORD_HARDCODED f8cd5a
            NetworkCredential nc1 = new NetworkCredential("","hardcoded_password");
            // <no> <report>
            new NetworkCredential(usernameAndPassword[0], usernameAndPassword[1]);
            // <yes> <report> CS_PASSWORD_HARDCODED 87ccf0
            nc1.Password = "hardcoded_password";
            // <yes> <report> CS_PASSWORD_HARDCODED 87ccft
            nc1.Password = "hardcoded_ password";
            // <yes> <report> CS_PASSWORD_HARDCODED a82c5c
            PasswordDeriveBytes pdb = new PasswordDeriveBytes("hardcoded_password", salt, "sha256", 100000);
            // <yes> <report> CS_PASSWORD_HARDCODED 2e5c26
            SqlHelper.ExecuteReader("smthPWDsmth");
            // <yes> <report> CS_PASSWORD_HARDCODED 2e5a26
            SqlHelperParameterCache.GetCachedParameterSet("smthPWDsmth");
            // <yes> <report> CS_PASSWORD_HARDCODED r3m42k
            string connectionstring="Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=adminadmin;Encrypt=yes";
            // <yes> <report> CS_PASSWORD_HARDCODED r3m42t
            string connectionstring="Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=admin admin;Encrypt=yes";
            // <yes> <report> CS_PASSWORD_HARDCODED r3m42k
            string connStr="Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=adminadmin;Encrypt=yes";
            // <yes> <report> CS_PASSWORD_HARDCODED r3m42t
            string connStr="Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=admin admin;Encrypt=yes";
            // <yes> <report> CS_PASSWORD_HARDCODED 59382k
            System.Data.SqlClient.SqlConnection  conn = new SqlConnection("Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=adminadmin;Encrypt=yes");
            // <yes> <report> CS_PASSWORD_HARDCODED 59382t
            System.Data.SqlClient.SqlConnection  conn = new SqlConnection("Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=admin admin;Encrypt=yes");
            StringBuilder builder = new StringBuilder(connectionString);
            // <yes> <report> CS_PASSWORD_HARDCODED gejkws
            DbConnectionStringBuilder.AppendKeyValuePair(builder, "password", "123456");
             // <yes> <report> CS_PASSWORD_HARDCODED gejkwt
            DbConnectionStringBuilder.AppendKeyValuePair(builder, "password", "12 3456");
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            // <yes> <report> CS_PASSWORD_HARDCODED g3jksd
            builder.ConnectionString ="Value1=10;password=20;Value3=30;Value4=40";
            // <yes> <report> CS_PASSWORD_HARDCODED kejfws
            builder.Add("Password", "hardcoded");
            // <yes> <report> CS_PASSWORD_HARDCODED kejfwt
            builder.Add("Password", "hardc oded");
            // <yes> <report> CS_PASSWORD_HARDCODED tg4lew
            builder["password"] = "hardcoded";
            // <yes> <report> CS_PASSWORD_HARDCODED tg4let
            builder["password"] = "hard coded";
            // <yes> <report> CS_PASSWORD_HARDCODED g3jksd
            Application["connStrHI"] = "Initial Catalog=SomeDb;Server=SomeSqlSrv;Integrated Security=false;Encrypt=true;User ID=ReadOnlyUser;Password=RouPwd";
            // <yes> <report> CS_PASSWORD_HARDCODED g3jkst
            Application["connStrHI"] = "Initial Catalog=SomeDb;Server=SomeSqlSrv;Integrated Security=false;Encrypt=true;User ID=ReadOnlyUser;Password=Rou Pwd";
            // <yes> <report> CS_PASSWORD_HARDCODED g3j00d
            new CmsUser(){Password = "password"};
            // <no> <report>
            PanelPasswordStep3.Visible = true;

            string.Format("SERVER={0};PORT={1};DATABASE={2};UID={3};PWD={4};Encrypt=true",
                                                              configFile.Get(DbConstants.KEY_HOST),
                                                              configFile.Get(DbConstants.KEY_PORT),
                                                              configFile.Get(DbConstants.KEY_DATABASE),
                                                              configFile.Get(DbConstants.KEY_UID),
                                                              configFile.Get(DbConstants.KEY_PWD));
        }

            // <yes> <report> CS_PRIVACY_VIOLATION_HEAP lekrf0
            public string Password { get; set; }
            protected void Page_Load(object sender, EventArgs e)
            {
            // <yes> <report> CS_PASSWORD_HARDCODED passwd1
                Password = "123456";
            // <yes> <report> CS_PASSWORD_HARDCODED passw1t
                Password = "123 456";

                labelPassword.Text = "Security Question Challenge Successfully Completed! <br/>Your password is: " + getPassword(txtEmail.Text);
            }


    }
}