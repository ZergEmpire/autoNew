namespace Tests
{
    class CS_XAMARIN_WORLD_READABLE_WRITEABLE
    {
        static void Main()
        {
             // <yes> <report> CS_XAMARIN_WORLD_READABLE_WRITEABLE cswrw0
             GetPreferences(FileCreationMode.WorldReadable);
             // <yes> <report> CS_XAMARIN_WORLD_READABLE_WRITEABLE cswrw0
             GetPreferences(FileCreationMode.WorldWriteable);
        }
    }
}