namespace Tests
{
    class CS_INFORMATION_LEAK_SIGNALR
    {
        public static void secure()
        {
            var hubConfiguration = new HubConfiguration();
            hubConfiguration.EnableJavaScriptProxies = false;
            app.MapSignalR(hubConfiguration);
        }
        public static void secure()
        {
            var hubConfiguration = new HubConfiguration();
            // <yes> <report> CS_INFORMATION_LEAK_SIGNALR fwnej2
            app.MapSignalR(hubConfiguration);
        }
    }
}