using System.Web;

namespace Tests
{
    class CS_VALUE_SHADOWING
    {
        static void Main()
        {
            HttpRequestBase hrb = new HttpRequestBase();
            // <yes> <report> CS_VALUE_SHADOWING 2e5b26
            hrb.Item("HTTP_qwerty");
            // <yes> <report> CS_VALUE_SHADOWING 2e5b26
            hrb.Item("ALL_HTTPALL_RAW");
            // <yes> <report> CS_VALUE_SHADOWING 2e5b27
            hrb.Item("smth else");
            // <yes> <report> CS_VALUE_SHADOWING lkdb26
            if (Request["HTTP_REFERER"].StartsWith("https://www.website.com"))
            ProvideContent();
            // <yes> <report> CS_VALUE_SHADOWING jren45
            Page.Request["smth_else"];
            // <no> <report>
            Request.QueryString["smth"];
            // <yes> <report> CS_VALUE_SHADOWING 2e6b33
            Request["smth else"];
            // <yes> <report> CS_VALUE_SHADOWING jren45
            string query = context.Request["query"];
        }
    }
}