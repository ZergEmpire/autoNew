namespace Tests
{
    class CS_EQUALS_OR_HASHCODE_DEF
    {
        public override bool Equals(Object obj) 
        {
            return true;
        }
        public override int GetHashCode() 
        {
            return 0;
        }
    }
    // <yes> <report> CS_EQUALS_OR_HASHCODE_UNDEF 15a938
    class CS_HASHCODE_UNDEF
    {
        
        public override bool Equals(Object obj) 
        {
            return true;
        }  
        public string Test()
        {
            return "hello";
        }

    }
    // <yes> <report> CS_EQUALS_OR_HASHCODE_UNDEF 15b938
    class CS_EQUALS_UNDEF
    {  
        public override int GetHashCode() 
        {
            return 0;
        }  
    }
}