using System.Web.Mvc;
namespace Tests
{
    class CS_CSRF
    {
        // <no> <report>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public int function(int i)
        {
              return i;
        }
        // <yes> <report> CS_CSRF 1623f4
        [HttpPost]
        public int function(int i)
        {
              return i;
        }
    }

    public class XSRF
    {
            public void foo(SqliteConnection connection, HttpRequest Request)
            {
                    string input = Request.QueryString["user"];
                    string sql = "insert into Comments(comment) values (@user)";
                    MySqlCommand cmd = new MySqlCommand(sql, connection);
                	cmd.AddWithValue(@user, input);
                	connection.Open();
                	// <yes> <report> CS_CSRF sdfteq
                	SqlDataReader reader = cmd.ExecuteReader();
            }
    }

    public class XSRFFixed
    {
            public void foo(SqliteConnection connection, AntiXsrf AntiXsrfTokenKey, HttpRequest Request)
            {
                    string input = AntiXsrfTokenKey.Validate(Request.QueryString["user"]);
                    string sql = "insert into Comments(comment) values (@user)";
                    MySqlCommand cmd = new MySqlCommand(sql, connection);
                	cmd.AddWithValue(@user, input);
                	connection.Open();
                	// <yes> <report> CS_CSRF sdfteq
                	cmd.ExecuteReader();
            }
    }
}