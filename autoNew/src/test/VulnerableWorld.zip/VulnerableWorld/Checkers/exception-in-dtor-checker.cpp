// RUN: iccheck++ -c %s

class C
{
public:
    ~C() // expected-warning{{C_DTOR_EXCEPTION}}
    {
        throw;
    }
};

class D
{
public:
    ~D() // expected-warning{{C_DTOR_EXCEPTION}}
    {
        try {
            throw -1;
        } catch (double) {
        }
    }
};

class E
{
public:
    ~E()
    {
        try {
            throw -1;
        } catch (int) {
        }
    }
};

void
f()
{
    C c;
    c.~C();
}

void
f2()
{
    throw;
}

void
f3()
{
    D d;
    d.~D();
}

void
f4()
{
    E e;
    e.~E();
}
