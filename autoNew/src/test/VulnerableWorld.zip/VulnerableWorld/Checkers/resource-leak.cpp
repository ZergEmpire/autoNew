// RUN: iccheck++ -c %s

#include "system-header-simulator-cxx.h"

void workload();

void
pass()
{
    std::thread t(workload);
    std::thread t2(workload);
    std::thread empty_thread;
    t.join();
    t2.detach();
} // OK

void
pass_move()
{
    std::thread t1(workload);
    auto t2 = std::move(t1);
    t2.detach();
}

void
fail_move()
{
    std::thread t1(workload);
    auto t2 = std::move(t1);
    t1.detach(); // expected-warning{{C_USE_AFTER_MOVE}}
} // expected-warning{{C_STD_THREAD}}

void
fail_no_call()
{
    std::thread t(workload);
} // expected-warning{{C_STD_THREAD}}

void
fail_call()
{
    std::thread t(workload);
    t.joinable();
} // expected-warning{{C_STD_THREAD}}

class ThreadContainer final
{
public:
    ThreadContainer() : thread(workload) {}
    void release() { thread.join(); }
    ~ThreadContainer();

private:
    std::thread thread;
};

void
thread_in_class()
{
    ThreadContainer container;
} // expected-warning{{C_STD_THREAD}}
