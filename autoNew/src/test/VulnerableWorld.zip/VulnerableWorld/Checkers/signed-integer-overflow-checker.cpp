// RUN: iccheck++ -c %s

void
testIntegerOverflowShift(int a)
{
    if (a == 1) {
        a << 31; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
        a << 30;
    } else if (a == 2) {
        a << 30; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    }
}

void
testUnsignedOverflowShift(unsigned a)
{
    if (a == 2) {
        a << 30;
    }
}

void
testLongIntegerOverflowShift(long long a)
{
    if (a == 1) {
        a << 63; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
        a << 62;
    } else if (a == 2) {
        a << 62; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    }
}
