// RUN: iccheck++ -c %s
// XFAIL: *

const int INT_MAX = 2147483647;
const int INT_MIN = -2147483648;
const unsigned UNSIGNED_MAX = ~(0U);

void
test_not_work()
{
    long long b;
    int a;
    unsigned ua;
    // +=
    a = 0, b = INT_MAX;
    a += b + 1; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    ua = 0, b = UNSIGNED_MAX;
    ua += b + 1; // expected-warning{{C_PRECISION_LOSS}}

    // -=
    a = 0, b = INT_MAX;
    a -= b + 2; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    ua = 0;
    ua -= 1; // expected-warning{{C_PRECISION_LOSS}}

    // *= INT_MAX + 1
    a = 1, b = INT_MAX;
    a *= (b + 1); // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    ua = 1, b = UNSIGNED_MAX;
    ua *= (b + 1); // expected-warning{{C_PRECISION_LOSS}}

    // *= INT_MIN - 1
    a = 1, b = INT_MIN;
    a *= (b - 1); // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}

    //++
    a = INT_MAX;
    ++a; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    ua = UNSIGNED_MAX;
    ++ua; // expected-warning{{C_PRECISION_LOSS}}

    //--
    a = INT_MIN;
    --a; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
    ua = 0;
    --ua; // expected-warning{{C_PRECISION_LOSS}}
}
