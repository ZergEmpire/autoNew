// RUN: iccheck++ -c %s

@interface UITextField;
- (void)iccheck_get_taint:(int)x;
- (void)iccheck_add_taint:(int)x;
- (void)iccheck_delete_taint:(int)x;

@end

void
test()
{
    UITextField* tf = [[UITextField alloc] init];
    
    int x = 1;
    [tf iccheck_get_taint:x]; // no-warn

    [tf iccheck_add_taint:x];
    [tf iccheck_get_taint:x]; // expected-warning{{ICCHECK_MOCK_REPORT}}


    [tf iccheck_delete_taint:x];
    [tf iccheck_get_taint:x]; // no-warn

    [tf release];
}
