// RUN: iccheck++ -c %s

namespace std {

class error_code
{
public:
    operator bool() const;

private:
    int data; // We need to add member field, or no MemRegion may be created.
};
}

std::error_code get_error_code();

int
func_1()
{
    const auto a = get_error_code();
    const auto b = get_error_code(); // expected-warning{{C_UNCHECKED_RETURN_VALUE}}

    if (a)
        return 1;

    if (b)
        return 2;

    return 4;
}

int
func_2()
{
    const auto a = get_error_code();
    const auto c = get_error_code();

    if (a == c || !a)
        return 3;

    return 4;
}

void
func_3()
{
    []() {
        char a[] = {1, 2, 3};
        for (const auto i : a);
    }();

    int a = 1 / 0; // expected-warning{{C_DIVISION_BY_ZERO}}
                   // expected-warning@-1{{C_DEAD_STORE}}
                   // expected-warning@-2{{C_UNDEFINED_RESULT}}
}
