// RUN: iccheck++ -c %s

const int INT_MAX = 2147483647;
const int INT_MIN = -2147483648;

void
test_ok()
{
    long long b = INT_MAX;
    int a = 0;
    a = b; // expected-warning{{C_DEAD_STORE}}
}

void
test_err()
{
    long long b = INT_MAX;
    int a = 0;
    a = b + 1; // expected-warning{{C_DEAD_STORE}}
               // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
test_underflow_err()
{
    long long b = INT_MIN;
    int a = 0;
    a = b - 1; // expected-warning{{C_DEAD_STORE}}
               // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
f_int(int x)
{}

void
test_calling_f_int_ok()
{
    long long b = INT_MAX;
    f_int(b);
}

void
test_calling_f_int_err()
{
    long long b = INT_MAX;
    f_int(++b); // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
test_underflow_calling_f_int_err()
{
    long long b = INT_MIN;
    f_int(--b); // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
f_char(char x)
{}

void
test_calling_f_char_ok()
{
    f_char(100);
}

void
test_calling_f_char_err()
{
    f_char(300); // expected-warning{{C_PRECISION_LOSS}}
                 // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
test_under_flow_calling_f_char_err()
{
    f_char(-300); // expected-warning{{C_PRECISION_LOSS}}
                  // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
test_assign_undef_val(long long b)
{
    int a = b;
}

int
test_return_val()
{
    long long b = INT_MAX;
    return b + 1; // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
test_unsigned_assign_negative()
{
    unsigned b = -1; // expected-warning{{C_PRECISION_LOSS}}
}

void
test_signed_assign_unsigned()
{
    unsigned b = INT_MAX;
    b += 1;
    int a = b; // expected-warning{{C_DEAD_STORE}}
               // expected-warning@-1{{C_PRECISION_LOSS}}
               // expected-warning@-2{{C_SIGNED_INTEGER_OVERFLOW}}
}

void
test_unsigned_overflow()
{
    unsigned b = 1ULL << 32; // expected-warning{{C_PRECISION_LOSS}}
                             // expected-warning@-1{{C_PRECISION_LOSS}}
}

void
test_unsigned_assign_ok()
{
    unsigned long long t = 100;
}

void
test_signed_assign_ok()
{
    long long t = INT_MIN;
}

void
test1(signed S, unsigned U)
{
    if (S > 10) {
        if (U < S) {
        }
    }
}

void
test_assign_unsigned_to_sign()
{
    unsigned kek = 1;
    signed p = kek; // expected-warning{{C_DEAD_STORE}}
}

// signed
void
testim()
{
    int a;
    long long b;

    a = INT_MIN, b = -1;
    a /= b; // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    a = 1, b = INT_MIN;
    b -= 10;
    a += b; // underflow // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    a = 1, b = INT_MAX;
    a += b; // overflow // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    a = -1, b = INT_MIN;
    a += b; // underflow // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    a = -1, b = INT_MAX;
    a += b + 10; // overflow // expected-warning{{C_DEAD_STORE}}
                 // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    unsigned ua;

    ua = 0, b = 1LL << 32;
    ua += b - 1 + 1; // expected-warning{{C_DEAD_STORE}}
                     // expected-warning@-1{{C_PRECISION_LOSS}}

    ua = 0, b = -1;
    ua += b; // expected-warning{{C_DEAD_STORE}}
             // expected-warning@-1{{C_PRECISION_LOSS}}

    ua = 0;
    ua -= 1; // expected-warning{{C_DEAD_STORE}}
             // expected-warning@-1{{C_PRECISION_LOSS}}

    a = INT_MIN;
    a -= 1; // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    unsigned long long ull = ~0ULL;
    ull += 1; // expected-warning{{C_DEAD_STORE}}
              // expected-warning@-1{{C_PRECISION_LOSS}}

    a = 1, b = INT_MIN;
    a -= b; // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    a = 2, b = -1;
    a -= b; // ok // expected-warning{{C_DEAD_STORE}}

    a = -100, ull = 1000;
    a += ull; // ok // expected-warning{{C_DEAD_STORE}}

    a = -100, ull = INT_MAX;
    ull += 100;       // ok
    a += ull - 1 + 1; // ok // expected-warning{{C_DEAD_STORE}}

    a = -100, ull = INT_MAX;
    ull += 101;       // ok
    a += ull - 1 + 1; // report // expected-warning{{C_DEAD_STORE}}
                      // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    ull = 1, a = -1;
    ull += a; // expected-warning{{C_DEAD_STORE}}
              // expected-warning@-1{{C_PRECISION_LOSS}}
              // expected-warning@-2{{C_PRECISION_LOSS}}

    ull = 1;
    ull -= 1; // expected-warning{{C_DEAD_STORE}}

    a = INT_MIN;
    char c = 1;
    a -= c; // expected-warning{{C_DEAD_STORE}}
            // expected-warning@-1{{C_SIGNED_INTEGER_OVERFLOW}}

    // ++ -- signed

    a = INT_MIN;
    ++a; // ok

    a = INT_MIN;
    --a; // bad // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}

    a = INT_MAX;
    --a; // ok

    a = INT_MAX;
    ++a; // bad // expected-warning{{C_SIGNED_INTEGER_OVERFLOW}}

    // ++ -- unsigned

    ua = 0;
    ua--; // bad // expected-warning{{C_PRECISION_LOSS}}

    ua = 1;
    ua--; // ok

    ua = ~0U - 1;
    ua++; // ok
    ua++; // bad // expected-warning{{C_PRECISION_LOSS}}

    ua = 0, b = 1LL << 32;
    ua += b - 1 + 1; // expected-warning{{C_DEAD_STORE}}
                     // expected-warning@-1{{C_PRECISION_LOSS}}
}
