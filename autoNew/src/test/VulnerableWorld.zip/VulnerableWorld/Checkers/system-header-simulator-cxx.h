#pragma clang system_header

typedef __typeof(sizeof(int)) size_t;

namespace std {

template <class CharT>
class basic_string
{
public:
    class iterator;

    basic_string();
    basic_string(const CharT *s);
    basic_string(const basic_string &other);
    basic_string(basic_string &&other) noexcept;
    basic_string &assign(const CharT *s);
    basic_string &assign(const basic_string &str);
    basic_string &assign(basic_string &&str);
    basic_string &operator=(const CharT *s);
    basic_string &operator=(const basic_string &str);
    basic_string &operator=(basic_string &&str);
    CharT &at(size_t pos);
    CharT &operator[](size_t pos);
    CharT &front();
    CharT &back();
    CharT *data();
    const CharT *c_str();
    basic_string &insert(size_t index, size_t count, const CharT ch);
    basic_string &insert(size_t index, const CharT *s);
    basic_string &insert(size_t index, const basic_string &str);
    basic_string &erase(size_t index, size_t count);
    void push_back(CharT ch);
    basic_string &append(size_t count, CharT ch);
    basic_string &append(const basic_string &str);
    basic_string &append(const CharT *s);
    basic_string &operator+=(CharT ch);
    basic_string &operator+=(const basic_string &str);
    basic_string &operator+=(const CharT *s);
    size_t copy(CharT *dest, size_t count, size_t pos) const;
    basic_string substr(size_t pos, size_t count) const;
    basic_string &replace(size_t pos, size_t count, const basic_string &str);
    basic_string &replace(size_t pos, size_t count, const CharT *cstr);

private:
    CharT *data_; // Class instance with no data will not be assigned to any memory region
};

template <class CharT>
basic_string<CharT> operator+(basic_string<CharT> &lhs, CharT *s);
template <class CharT>
basic_string<CharT> operator+(basic_string<CharT> &lhs, CharT ch);
template <class CharT>
basic_string<CharT> operator+(basic_string<CharT> &lhs, basic_string<CharT> &rhs);
template <class CharT>
basic_string<CharT> operator+(CharT *s, basic_string<CharT> &lhs);
template <class CharT>
basic_string<CharT> operator+(CharT ch, basic_string<CharT> &lhs);

template <class CharT>
class basic_streambuf
{
private:
    CharT *data;
};

template <class CharT>
class basic_stringbuf : public std::basic_streambuf<CharT>
{};

class ios_base
{
private:
    int data;
};

template <class CharT>
class basic_ios : public ios_base
{
public:
    basic_streambuf<CharT> *rdbuf() const;
    basic_streambuf<CharT> *rdbuf(basic_streambuf<CharT> *sb);
};

template <class CharT>
class basic_istream : virtual public basic_ios<CharT>
{
public:
    explicit basic_istream(basic_streambuf<CharT> *sb);
    basic_istream &operator>>(short &value);
    basic_istream &operator>>(unsigned short &value);
    basic_istream &operator>>(int &value);
    basic_istream &operator>>(unsigned int &value);
    basic_istream &operator>>(long &value);
    basic_istream &operator>>(unsigned long &value);
    basic_istream &operator>>(long long &value);
    basic_istream &operator>>(unsigned long long &value);
    basic_istream &operator>>(float &value);
    basic_istream &operator>>(double &value);
    basic_istream &operator>>(long double &value);
    basic_istream &operator>>(bool &value);
    basic_istream &operator>>(void *&value);
    basic_istream &operator>>(ios_base &(*func)(ios_base &));
    basic_istream &operator>>(basic_ios<CharT> &(*func)(basic_ios<CharT> &));
    basic_istream &operator>>(basic_istream &(*func)(basic_istream &));
    basic_istream &operator>>(basic_streambuf<CharT> *sb);
    int get();
    basic_istream &get(char &ch);
    basic_istream &get(char *s, int count);
    basic_istream &unget();
    basic_istream &putback(char ch);
    int peek();
    basic_istream &getline(char *s, int count);
    basic_istream &ignore(int count = 1, int delim = 0);
    basic_istream &read(char *s, int count);
    int readsome(char *s, int count);
    int gcount() const;
    basic_istream &seekg(int pos);
};

template <class CharT>
class basic_ifstream : public basic_istream<CharT>
{
public:
    explicit basic_ifstream();
    explicit basic_ifstream(const char *filename);
    explicit basic_ifstream(const std::basic_string<CharT> &filename);
    void open(const char *filename);
    void open(const std::basic_string<CharT> &filename);
};

template <class CharT>
class basic_istringstream : public basic_istream<CharT>
{
public:
    basic_istringstream(basic_istringstream &&other);
    explicit basic_istringstream(const basic_string<CharT> &str);
    basic_stringbuf<CharT> *rdbuf() const;
    basic_string<CharT> str() const;
    void str(const basic_string<CharT> &new_str);
    basic_istringstream &operator=(basic_istringstream &&other);
};

template <class CharT>
basic_istream<CharT> &operator>>(basic_istream<CharT> &st, CharT *s);

template <class CharT>
basic_istream<CharT> &operator>>(basic_istream<CharT> &st, CharT &ch);

typedef basic_string<char> string;
typedef basic_istringstream<char> istringstream;
typedef basic_ifstream<char> ifstream;
typedef basic_istream<wchar_t> wistream;
typedef basic_istream<char> istream;
typedef basic_istream<wchar_t> wistream;

extern istream cin;
extern wistream wcin;

class thread final
{
public:
    thread();

    template <class Function, class... Args>
    explicit thread(Function &&f, Args &&... args)
    {}

    thread(thread &&other) = default;
    thread(const thread &other) = delete;

    ~thread();

    thread &operator=(thread &&other) = default;
    thread &operator=(const thread &other) = delete;

    bool joinable() const noexcept;
    void join();
    void detach();

private:
    int region;
};

template <class T>
struct remove_reference
{
    typedef T type;
};
template <class T>
struct remove_reference<T &>
{
    typedef T type;
};
template <class T>
struct remove_reference<T &&>
{
    typedef T type;
};
template <class T>
constexpr typename std::remove_reference<T>::type &&
move(T &&t) noexcept
{
    return static_cast<typename std::remove_reference<T>::type &&>(t);
}

} // end of namespace std
