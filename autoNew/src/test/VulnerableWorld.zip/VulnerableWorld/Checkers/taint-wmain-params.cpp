// RUN: iccheck++ -target x86_64-pc-win32 -c %s

int
wmain(int argc, char **argv, char **envp)
{
    1 / (12 - argc);       // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - argv[0][1]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - argv[0][0]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - argv[7][0]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - envp[1][0]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    return 0;
}
