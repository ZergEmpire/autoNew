// RUN: iccheck++ -c %s

#include "system-header-simulator-c.h"
#include "system-header-simulator-cxx.h"

// --------
//  memcpy
// --------

void
memcpy_simple_correct_case()
{
    auto data = new int[10];
    int source[15] = {0};

    memcpy(data, source, 10 * sizeof(int));
    delete[] data;
}

void
memcpy_too_small_data_array()
{
    auto data = new int[10];
    int source[15] = {0};

    memcpy(data, source, 15 * sizeof(int)); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
                                            // expected-warning@-1{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
memcpy_too_small_source_array()
{
    auto data = new int[20];
    int source[15] = {0};

    memcpy(data, source, 20 * sizeof(int)); // Flaw // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
                                            // expected-warning@-1{{C_READ_OUT_OF_BOUNDS}}
    delete[] data;
}

struct CharVoid
{
    char char_first[16];
    void *void_second;
    void *void_third;
};

void
memcpy_bad_intrastructural()
{
    const char *src_str = "0123456789abcdef0123456789abcde";
    auto char_void_pointer = new CharVoid;
    char_void_pointer->void_second = (void *)src_str;
    memcpy(char_void_pointer->char_first, src_str,
           sizeof(CharVoid)); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                              // expected-warning@-2{{C_BUFFER_OVERFLOW}}
    delete char_void_pointer;
}

void
memcpy_good_intrastructural()
{
    const char *src_str = "0123456789abcdef0123456789abcde";
    auto char_void_pointer = new CharVoid;
    char_void_pointer->void_second = (void *)src_str;
    memcpy(char_void_pointer->char_first, src_str, sizeof(char_void_pointer->char_first));
    delete char_void_pointer;
}

void
memcpy_bad_char_array()
{
    auto data = new char[10];
    char source[10 + 1] = "AAAAAAAAAA";
    memcpy(data, source,
           (strlen(source) + 1) * sizeof(char)); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
                                                 // expected-warning@-2{{C_BUFFER_OVERFLOW}}
                                                 // expected-warning@-3{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
memcpy_good_char_array()
{
    auto data = new char[10 + 1];
    char source[10 + 1] = "AAAAAAAAAA";
    memcpy(data, source,
           (strlen(source) + 1) * sizeof(char)); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    delete[] data;
}

void
memcpy_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    memcpy(data + 1, source, (10 - 1) * sizeof(long long));
    memcpy(data + 1, source,
           (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                                              // expected-warning@-2{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
memcpy_different_types_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    auto data_twin = (char *)data;
    ++data_twin;
    memcpy(data_twin, source, 10 * sizeof(long long) - sizeof(char));
    memcpy(data_twin, source,
           10 * sizeof(long long)); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                                    // expected-warning@-2{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
memcpy_nonarray_case()
{
    auto data = new int;
    int source[15] = {0};

    memcpy(data, source, sizeof(int));
    memcpy(data, source, sizeof(int) + 1); // expected-warning{{C_BUFFER_OVERFLOW}}
                                           // expected-warning@-1{{C_BUFFER_OVERFLOW}}
    delete data;
}

void
memcpy_nonarray_different_types_case()
{
    auto data = new long long;
    long long source[15] = {0};

    auto data_twin = (char *)data;
    ++data_twin;
    memcpy(data_twin, source, sizeof(long long) - sizeof(char));
    memcpy(data_twin, source, sizeof(long long)); // expected-warning{{C_BUFFER_OVERFLOW}}
                                                  // expected-warning@-1{{C_BUFFER_OVERFLOW}}
    delete data;
}

void
memcpy_buffer_to_buffer_case()
{
    int data[10] = {0};
    int source[15] = {0};

    memcpy(data, source, 10 * sizeof(int));
    memcpy(data, source, 10 * sizeof(int) + 1); // Flaw; // expected-warning{{C_BUFFER_OVERFLOW}}
                                                // expected-warning@-1{{C_BUFFER_OVERFLOW}}
}

void
memcpy_tainted_destintaion_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    memcpy(data + num, source,
           10 * sizeof(int)); // expected-warning@-1{{C_BUFFER_OVERFLOW_TAINTED}}
                              // expected-warning@-2{{C_BUFFER_UNDERFLOW_TAINTED}}
    delete[] data;
}

void
memcpy_tainted_source_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    memcpy(data, source + num,
           10 * sizeof(int)); // expected-warning@-1{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

void
memcpy_tainted_num_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    memcpy(data, source,
           sizeof(int) + num); // expected-warning@-1{{C_BUFFER_OVERFLOW_TAINTED}}
                               // expected-warning@-2{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

// --------
//  memset
// --------

void
memset_simple_correct_case()
{
    auto data = new int[10];

    memset(data, '-', 10 * sizeof(int));
    delete[] data;
}

void
memset_too_small_data_array()
{
    auto data = new int[10];

    memset(data, '-', 15 * sizeof(int)); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
                                         // expected-warning@-1{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
memset_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    memset(data + 1, '-', (10 - 1) * sizeof(long long));
    memset(data + 1, '-',
           (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                                              // expected-warning@-2{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
memset_user_defined_structure_case()
{
    CharVoid a;

    memset(&a, '-', sizeof(CharVoid));
    memset(&a, '-', sizeof(CharVoid) + 1); // expected-warning{{C_BUFFER_OVERFLOW}}
                                           // expected-warning@-1{{C_BUFFER_OVERFLOW}}
}

void
memset_tainted_num_case()
{
    auto data = new int[10];

    int num;
    std::cin >> num;

    memset(data, '-', sizeof(int) + num); // Flaw; // expected-warning{{C_BUFFER_OVERFLOW_TAINTED}}
    delete[] data;
}

// ---------
//  memmove
// ---------

void
memmove_simple_correct_case()
{
    auto data = new int[10];
    int source[15] = {0};

    memmove(data, source, 10 * sizeof(int));
    delete[] data;
}

void
memmove_too_small_data_array()
{
    auto data = new int[10];
    int source[15] = {0};

    memmove(data, source, 15 * sizeof(int)); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
                                             // expected-warning@-1{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
memmove_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    memmove(data + 1, source, (10 - 1) * sizeof(long long));
    memmove(data + 1, source,
            (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                                               // expected-warning@-2{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
memmove_tainted_num_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    memmove(data, source,
            10 * sizeof(int) + num); // expected-warning@-1{{C_BUFFER_OVERFLOW_TAINTED}}
                                     // expected-warning@-2{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

// --------
//  memcmp
// --------

void
memcmp_simple_correct_case()
{
    auto data = new int[10];
    int source[15] = {0};

    memcmp(data, source, 10 * sizeof(int));
    delete[] data;
}

void
memcmp_too_small_data_array()
{
    auto data = new int[10];
    int source[15] = {0};

    memcmp(data, source, 15 * sizeof(int)); // Flaw // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
                                            // expected-warning@-1{{C_READ_OUT_OF_BOUNDS}}
    delete[] data;
}

void
memcmp_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    memcmp(data + 1, source, (10 - 1) * sizeof(long long));
    memcmp(data + 1, source,
           (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                              // expected-warning@-2{{C_READ_OUT_OF_BOUNDS}}

    delete[] data;
}

void
memcmp_tainted_num_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    memcmp(data, source,
           10 * sizeof(int) + num); // expected-warning@-1{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

// --------
//  memchr
// --------

void
memchr_simple_correct_case()
{
    auto data = new int[10];

    memchr(data, '?', 10 * sizeof(int));
    delete[] data;
}

void
memchr_too_small_data_array()
{
    auto data = new int[10];

    memchr(data, '?', 15 * sizeof(int)); // Flaw // expected-warning{{C_READ_OUT_OF_BOUNDS}}
    delete[] data;
}

void
memchr_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    memchr(data + 1, '?', (10 - 1) * sizeof(long long));
    memchr(data + 1, '?',
           (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_READ_OUT_OF_BOUNDS}}

    delete[] data;
}

void
memchr_tainted_num_case()
{
    auto data = new int[10];

    int num;
    std::cin >> num;

    memchr(data, '?',
           10 * sizeof(int) + num); // expected-warning@-1{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

// ---------
//  mempcpy
// ---------

void
mempcpy_simple_correct_case()
{
    auto data = new int[10];
    int source[15] = {0};

    mempcpy(data, source, 10 * sizeof(int));
    delete[] data;
}

void
mempcpy_too_small_data_array()
{
    auto data = new int[10];
    int source[15] = {0};

    mempcpy(data, source, 15 * sizeof(int)); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
                                             // expected-warning@-1{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
mempcpy_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    mempcpy(data + 1, source, (10 - 1) * sizeof(long long));
    mempcpy(data + 1, source,
            (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                                               // expected-warning@-2{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
mempcpy_tainted_num_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    mempcpy(data, source,
            10 * sizeof(int) + num); // expected-warning@-1{{C_BUFFER_OVERFLOW_TAINTED}}
                                     // expected-warning@-2{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

// ---------
//  memccpy
// ---------

void
memccpy_simple_correct_case()
{
    auto data = new int[10];
    int source[15] = {0};

    memccpy(data, source, '\n', 10 * sizeof(int));
    delete[] data;
}

void
memccpy_too_small_data_array()
{
    auto data = new int[10];
    int source[15] = {0};

    memccpy(data, source, '-', 15 * sizeof(int)); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
memccpy_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    memccpy(data + 1, source, '-', (10 - 1) * sizeof(long long));
    memccpy(data + 1, source, '-',
            (10 - 1) * sizeof(long long) + 1); // expected-warning@-1{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
memccpy_tainted_num_case()
{
    auto data = new int[10];
    int source[15] = {0};

    int num;
    std::cin >> num;

    memccpy(data, source, '\n',
            10 * sizeof(int) + num); // expected-warning@-1{{C_BUFFER_OVERFLOW_TAINTED}}
                                     // expected-warning@-2{{C_BUFFER_OVERFLOW_TAINTED}}
                                     // expected-warning@-3{{C_READ_OUT_OF_BOUNDS_TAINTED}}
    delete[] data;
}

// -------
//  write
// -------

void
write_simple_case(int fd)
{
    int data[15] = {0};

    write(fd, data, 15 * sizeof(int));
    write(fd, data + 1, 14 * sizeof(int));
    write(fd, data + 1, 14 * sizeof(int) + 1); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
}

void
write_tainted_num_case(int fd)
{
    int data[15] = {0};

    int num;
    std::cin >> num;

    write(fd, data,
          15 * sizeof(int) + num); // expected-warning@-1{{C_BUFFER_OVERFLOW_TAINTED}}
}

// ------
//  read
// ------

void
read_simple_case(int fd)
{
    int data[15] = {0};

    read(fd, data, 15 * sizeof(int));
    read(fd, data + 1, 14 * sizeof(int));
    read(fd, data + 1, 14 * sizeof(int) + 1); // Flaw // expected-warning{{C_READ_OUT_OF_BOUNDS}}
}

void
read_tainted_num_case(int fd)
{
    int data[15] = {0};

    int num;
    std::cin >> num;

    read(fd, data,
         15 * sizeof(int) + num); // expected-warning@-1{{C_READ_OUT_OF_BOUNDS_TAINTED}}
}

void
builtin_memcpy_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    __builtin_memcpy(data + 1, source, (10 - 1) * sizeof(long long));
    __builtin_memcpy(data + 1, source,
                     (10 - 1) * sizeof(long long) +
                         1); // expected-warning@-2{{C_BUFFER_OVERFLOW}}
                             // expected-warning@-3{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
casts()
{
    int *data = new int[10];

    memset((int *)((char *)data + 1), 0, 10 * sizeof(int) - sizeof(char));
    memset((int *)((char *)data + 1), 0,
           10 * sizeof(int)); // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                              // expected-warning@-2{{C_BUFFER_OVERFLOW}}
    delete[] data;
}

void
complicated_casts()
{
    long long *data = new long long[10];

    memset((long long *)((int *)((char *)data + 1) + 1), 0,
           10 * sizeof(long long) - sizeof(char) - sizeof(int));
    memset((long long *)((int *)((char *)data + 1) + 1),
           0, // expected-warning@-1{{C_BUFFER_OVERFLOW}}
              // expected-warning@-2{{C_BUFFER_OVERFLOW}}
           10 * sizeof(long long) - sizeof(char) - sizeof(int) + 1);
    delete[] data;
}

// This test only works with an advanced solver which is not
// configured now

// void unknown_function(int &n);

// void
// simple_symbolic_offset_case()
// {
//     int *data = new int[100];
//     int num;
//     unknown_function(num);
//     memset(data + num, 0, 100 * sizeof(int) - num * sizeof(int));
//     memset(data + num, 0, 100 * sizeof(int) - num * sizeof(int) + 1); // Flaw

//     delete[] data;
// }

void
simple_negative_offset()
{
    int *data = new int[10];

    auto data_twin = data + 1;
    memset(data_twin - 1, '0', 1);
    memset(data - 1, '0', 1); // Flaw // expected-warning{{C_BUFFER_OVERFLOW}}
                              // expected-warning@-1{{C_BUFFER_UNDERFLOW}}
    delete[] data;
}

void
both_borders_are_violated()
{
    int *data = new int[10];

    memset(data - 1, '0', 12 * sizeof(int)); // expected-warning{{C_BUFFER_OVERFLOW}}
                                             // expected-warning@-1{{C_BUFFER_OVERFLOW}}
                                             // expected-warning@-2{{C_BUFFER_UNDERFLOW}}
    delete[] data;
}

void
builtin_memset_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    __builtin_memset(data + 1, '-', (10 - 1) * sizeof(long long));
    __builtin_memset(data + 1, '-',
                     (10 - 1) * sizeof(long long) +
                         1); // expected-warning@-2{{C_BUFFER_OVERFLOW}}
                             // expected-warning@-3{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
builtin_memcmp_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    __builtin_memcmp(data + 1, source, (10 - 1) * sizeof(long long));
    __builtin_memcmp(data + 1, source,
                     (10 - 1) * sizeof(long long) +
                         1); // expected-warning@-2{{C_ARRAY_OUT_OF_BOUNDS}}
                             // expected-warning@-3{{C_READ_OUT_OF_BOUNDS}}

    delete[] data;
}

void
builtin_memchr_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    __builtin_memchr(data + 1, '?', (10 - 1) * sizeof(long long));
    __builtin_memchr(data + 1, '?',
                     (10 - 1) * sizeof(long long) +
                         1); // expected-warning@-2{{C_READ_OUT_OF_BOUNDS}}

    delete[] data;
}

void
builtin_memmove_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    __builtin_memmove(data + 1, source, (10 - 1) * sizeof(long long));
    __builtin_memmove(data + 1, source,
                      (10 - 1) * sizeof(long long) +
                          1); // expected-warning@-2{{C_BUFFER_OVERFLOW}}
                              // expected-warning@-3{{C_BUFFER_OVERFLOW}}

    delete[] data;
}

void
builtin_mempcpy_offset_case()
{
    auto data = new long long[10];
    long long source[15] = {0};

    __builtin_mempcpy(data + 1, source, (10 - 1) * sizeof(long long));
    __builtin_mempcpy(data + 1, source,
                      (10 - 1) * sizeof(long long) +
                          1); // expected-warning@-2{{C_BUFFER_OVERFLOW}}
                              // expected-warning@-3{{C_BUFFER_OVERFLOW}}

    delete[] data;
}
