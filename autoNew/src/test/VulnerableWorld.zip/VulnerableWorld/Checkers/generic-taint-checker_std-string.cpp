// RUN: iccheck++ -c %s

#include "system-header-simulator-c.h"
#include "system-header-simulator-cxx.h"

int some_random();

char
test_constructor()
{
    char buf[10];
    scanf("%s", buf);
    std::string s(buf);
    if (some_random()) {
        return 1 / s.at(0); // expected-warning{{C_DIVISION_BY_TAINTED}}
                            // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        std::string s1(s);
        return 1 / s1.at(0); // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

char
test_assignment()
{
    char buf[10];
    scanf("%s", buf);
    std::string s;
    s = buf;
    std::string s1;
    switch (some_random()) {
    case 0:
        return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                         // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1: {
        s1 = s;
        return 1 / s1[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                          // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
    case 2:
        if (some_random()) {
            s1.operator=(s);
            return 1 / s1[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                              // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s1.operator=(s)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                       // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 3:
        if (some_random()) {
            return 1 / s1.assign(s)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                        // expected-warning@-1{{C_UNDEFINED_RESULT}}
        } else if (some_random()) {
            s1.assign(s);
            return 1 / s1[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                              // expected-warning@-1{{C_UNDEFINED_RESULT}}
        } else {
            return 1 / s.assign(s1)[0];
        }
    default:
        return 0;
    }
}

char
test_access_methods()
{
    char buf[10];
    scanf("%s", buf);
    std::string s(buf);
    switch (some_random()) {
    case -1:
        return 1 / s[1]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                         // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 0:
        return 1 / s.at(1); // expected-warning{{C_DIVISION_BY_TAINTED}}
                            // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        return 1 / s.operator[](1); // expected-warning{{C_DIVISION_BY_TAINTED}}
                                    // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        return 1 / s.front(); // expected-warning{{C_DIVISION_BY_TAINTED}}
                              // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 3:
        return 1 / s.back(); // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 4:
        return 1 / s.data()[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 5:
        return 1 / s.c_str()[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                 // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

char
test_insert()
{
    char buf[10];
    scanf("%s", buf);
    char c;
    scanf("%c", &c);
    std::string s;
    std::string st(buf);
    switch (some_random()) {
    case 0:
        if (some_random()) {
            s.insert(0, 1, c);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.insert(0, 1, c)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                         // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        if (some_random()) {
            s.insert(0, buf);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.insert(0, buf)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                        // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        if (some_random()) {
            s.insert(0, st);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.insert(0, st)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                       // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

char
test_erase()
{
    char buf[10];
    scanf("%s", buf);
    std::string s(buf);
    return 1 / s.erase(0, 1)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                 // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

char
test_pushback()
{
    char c;
    scanf("%c", &c);
    std::string s;
    s.push_back(c);
    return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                     // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

char
test_append()
{
    char buf[10];
    scanf("%s", buf);
    char c;
    scanf("%c", &c);
    std::string s;
    std::string st(buf);
    switch (some_random()) {
    case 0:
        if (some_random()) {
            s.append(0, c);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.append(0, c)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        if (some_random()) {
            s.append(buf);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.append(buf)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                     // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        if (some_random()) {
            s.append(st);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.append(st)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                    // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

char
test_addition_assignment()
{
    char buf[10];
    scanf("%s", buf);
    char c;
    scanf("%c", &c);
    std::string s;
    std::string st(buf);
    switch (some_random()) {
    case 0:
        if (some_random()) {
            s += c;
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / (s += c)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        if (some_random()) {
            s += buf;
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / (s += buf)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        if (some_random()) {
            s += st;
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / (s += st)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                 // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

char
test_addition_assignment_explicit()
{
    char buf[10];
    scanf("%s", buf);
    char c;
    scanf("%c", &c);
    std::string s;
    std::string st(buf);
    switch (some_random()) {
    case 0:
        if (some_random()) {
            s.operator+=(c);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.operator+=(c)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                       // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        if (some_random()) {
            s.operator+=(buf);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.operator+=(buf)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                         // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        if (some_random()) {
            s.operator+=(st);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.operator+=(st)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                        // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

char
test_substr()
{
    char buf[10];
    scanf("%s", buf);
    std::string s(buf);
    std::string s1 = s.substr(0, 1);
    return 1 / s1[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

char
test_replace()
{
    char buf[10];
    scanf("%s", buf);
    std::string s;
    std::string st(buf);
    switch (some_random()) {
    case 1:
        if (some_random()) {
            s.replace(0, 1, buf);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.replace(0, 1, buf)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                            // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        if (some_random()) {
            s.replace(0, 1, st);
            return 1 / s[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
        }

        return 1 / s.replace(0, 1, st)[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

char *get_char_ptr();

char
test_copy()
{
    char buf[3];
    scanf("%s", buf);
    std::string s(buf);
    char *buf1 = get_char_ptr();
    s.copy(buf1, 0, 1);
    return 1 / buf1[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                        // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

char
test_addition()
{
    char buf[3];
    scanf("%s", buf);
    char c;
    scanf("%s", &c);
    char c1 = 'a';
    std::string s(buf);
    std::string s1;
    std::string tmp;
    switch (some_random()) {
    case 0:
        tmp = s + c1;
        return 1 / tmp[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        tmp = c1 + s;
        return 1 / tmp[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        tmp = s1 + c;
        return 1 / tmp[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 3:
        tmp = s1 + s;
        return 1 / tmp[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 4:
        tmp = s + s1;
        return 1 / tmp[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}
