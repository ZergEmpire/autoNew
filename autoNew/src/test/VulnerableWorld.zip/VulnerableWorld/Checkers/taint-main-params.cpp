// RUN: iccheck++ -c %s

int
main(int argc, char **argv)
{
    1 / (12 - argc);       // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - argv[0][1]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - argv[0][0]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - argv[7][0]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    return 0;
}
