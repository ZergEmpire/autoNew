// RUN: iccheck++ -c %s

int arr[10];
int *ptr;

int conjure_index();

int *
test_element_index_lifetime()
{
    do {
        int x = conjure_index();
        ptr = arr + x;
        if (x != 20)
            return arr;
    } while (0);
    return ptr; // expected-warning{{C_BUFFER_OVERFLOW}}
}

int *
test_element_index_lifetime_with_local_ptr()
{
    int *local_ptr;
    do {
        int x = conjure_index();
        local_ptr = arr + x;
        if (x != 20)
            return arr;
    } while (0);
    return local_ptr; // expected-warning{{C_BUFFER_OVERFLOW}}
}

int *
f()
{
    return arr + 15; // expected-warning{{C_BUFFER_OVERFLOW}}
}

int
test_no_interrupt_after_report()
{
    int *ptr = f(); // expected-warning{{C_DEAD_STORE}}
    int a;
    int b;
    return a + b; // expected-warning{{C_UNDEFINED_VALUE}}
}
