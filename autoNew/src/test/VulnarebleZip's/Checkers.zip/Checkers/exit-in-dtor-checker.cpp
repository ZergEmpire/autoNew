// RUN: iccheck++ -c %s

void abort();
void exit(int code);
void quick_exit(int code);

void
f0()
{
    abort(); // expected-warning{{C_NORETURN_DTOR}}
}
void
f1()
{
    exit(0); // expected-warning{{C_NORETURN_DTOR}}
}
void
f2()
{
    quick_exit(0); // expected-warning{{C_NORETURN_DTOR}}
}

class A0
{
    ~A0() { f0(); }
};
class A1
{
    ~A1() { f1(); }
};
class A2
{
    ~A2() { f2(); }
};

class B0
{
    ~B0()
    {
        abort(); // expected-warning{{C_NORETURN_DTOR}}
    }
};
class B1
{
    ~B1()
    {
        exit(0); // expected-warning{{C_NORETURN_DTOR}}
    }
};
class B2
{
    ~B2()
    {
        quick_exit(0); // expected-warning{{C_NORETURN_DTOR}}
    }
};

class C0
{
public:
    ~C0()
    {
        abort(); // expected-warning{{C_NORETURN_DTOR}}
    }
};
class C1
{
public:
    ~C1()
    {
        exit(0); // expected-warning{{C_NORETURN_DTOR}}
    }
};
class C2
{
public:
    ~C2()
    {
        quick_exit(0); // expected-warning{{C_NORETURN_DTOR}}
    }
};

void
f3()
{
    C0 c;
    c.~C0();
}
void
f4()
{
    C1 c;
    c.~C1();
}
void
f5()
{
    C2 c;
    c.~C2();
}

void
f6()
{
    C0 c;
}
void
f7()
{
    C1 c;
}
void
f8()
{
    C2 c;
}
