// RUN: iccheck++ -c %s
// XFAIL: *

namespace std {

class error_code // expected-warning{{C_SELF_ASSIGNMENT}}
{
public:
    operator bool() const;

private:
    int data; // We need to add member field, or no MemRegion may be created.
};
}

std::error_code get_error_code();

std::error_code
get_error_code(int x)
{
    std::error_code tmp;
    if (x)
        return tmp; // this is not reported
    else
        return tmp; // expected-warning{{C_UNCHECKED_RETURN_VALUE}}
}

void
f(int x)
{
    const auto d = get_error_code(x);
}

int
f()
{
    if (get_error_code()) // this is reported, but should not be
        return 1;
    else
        return 0;
}

void
f1()
{
    get_error_code(); // this is not reported, but should be
}
