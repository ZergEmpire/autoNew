// RUN: iccheck++ -target x86_64-pc-win32 -c %s

#define HINSTANCE int

int
DllMain(HINSTANCE hinstDLL, int fdwReason, int lpvReserved)
{
    1 / (12 - fdwReason); // expected-warning{{C_DIVISION_BY_TAINTED}}
                          // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - hinstDLL);
    1 / (12 - lpvReserved);
    return 0;
}
