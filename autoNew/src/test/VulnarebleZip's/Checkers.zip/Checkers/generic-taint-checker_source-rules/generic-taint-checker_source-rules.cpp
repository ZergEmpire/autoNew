// RUN: iccheck++ -c %s

void iccheck_show_taint_tag(int x);

int getpass(int &arg0);
void pread64(int &arg0, int &arg1);
int readline(int &arg0);
int fgets(int &arg0, int &arg1);
int fgetc(int &arg0);
int getchar(int &arg0);
int dlerror(int &arg0);
int mmap(int &arg0, int &arg1);
int gets(int &arg0, int &arg1);
int gethostbyname(int &arg0);
void uname(int &arg0, int &arg1);
void fread(int &arg0, int &arg1);
int getuid(int &arg0);
int secure_getenv(int &arg0);
void getdelim(int &arg0, int &arg1);
int localtime(int &arg0, int &arg1);
int getppid(int &arg0);
int getenv_s(int &arg0);
int CommandLineToArgvW(int &arg0, int &arg1);
void regGetValueW(int &arg0, int &arg1, int &arg2, int &arg3, int &arg4, int &arg5);
void GetComputerNameW(int &arg0, int &arg1);
void ReadFileEx(int &arg0, int &arg1);
int GetCommandLineW(int &arg0);
void GetCurrentDirectory(int &arg0, int &arg1);

void
test_getpass()
{
    int arg0 = 0;
    int ret = getpass(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{NO_NEW_LINE}}
                                 // expected-warning@-1{{PRIVATE}}
                                 // expected-warning@-2{{STDIN}}
                                 // expected-warning@-3{{NULL_TERMINATED}}
    iccheck_show_taint_tag(arg0);
}

void
test_pread64()
{
    int arg0 = 0, arg1 = 0;
    pread64(arg0, arg1);
    iccheck_show_taint_tag(arg0);
    iccheck_show_taint_tag(arg1); // expected-warning{{NOT_NULL_TERMINATED}}
                                  // expected-warning@-1{{STREAM}}
}

void
test_readline()
{
    int arg0 = 0;
    int ret = readline(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{NO_NEW_LINE}}
                                 // expected-warning@-1{{STDIN}}
    iccheck_show_taint_tag(arg0);
}

void
test_fgets()
{
    int arg0 = 0, arg1 = 0;
    int ret = fgets(arg0, arg1);
    iccheck_show_taint_tag(ret);  // expected-warning{{NO_NEW_LINE}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
                                  // expected-warning@-2{{STREAM}}
                                  // expected-warning@-3{{ARGS}}
                                  // expected-warning@-4{{ENVIRONMENT}}
                                  // expected-warning@-5{{FILE_SYSTEM}}
                                  // expected-warning@-6{{FORMAT_STRING}}
                                  // expected-warning@-7{{PATH_MANIPULATION}}
                                  // expected-warning@-8{{STDIN}}
    iccheck_show_taint_tag(arg0); // expected-warning{{NO_NEW_LINE}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
                                  // expected-warning@-2{{STREAM}}
                                  // expected-warning@-3{{ARGS}}
                                  // expected-warning@-4{{ENVIRONMENT}}
                                  // expected-warning@-5{{FILE_SYSTEM}}
                                  // expected-warning@-6{{FORMAT_STRING}}
                                  // expected-warning@-7{{PATH_MANIPULATION}}
                                  // expected-warning@-8{{STDIN}}
    iccheck_show_taint_tag(arg1);
}

void
test_fgetc()
{
    int arg0 = 0;
    int ret = fgetc(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{STREAM}}
    iccheck_show_taint_tag(arg0);
}

void
test_getchar()
{
    int arg0 = 0;
    int ret = getchar(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{NOT_NULL_TERMINATED}}
                                 // expected-warning@-1{{STDIN}}
                                  // expected-warning@-2{{ARGS}}
                                  // expected-warning@-3{{ENVIRONMENT}}
                                  // expected-warning@-4{{FILE_SYSTEM}}
                                  // expected-warning@-5{{FORMAT_STRING}}
                                  // expected-warning@-6{{PATH_MANIPULATION}}
                                  // expected-warning@-7{{STREAM}}
    iccheck_show_taint_tag(arg0);
}

void
test_dlerror()
{
    int arg0 = 0;
    int ret = dlerror(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{EXCEPTIONINFO}}
                                 // expected-warning@-1{{SYSTEMINFO}}
    iccheck_show_taint_tag(arg0);
}

void
test_mmap()
{
    int arg0 = 0, arg1 = 0;
    int ret = mmap(arg0, arg1);
    iccheck_show_taint_tag(ret);  // expected-warning{{NOT_NULL_TERMINATED}}
                                  // expected-warning@-1{{STREAM}}
    iccheck_show_taint_tag(arg0); // expected-warning{{NOT_NULL_TERMINATED}}
                                  // expected-warning@-1{{STREAM}}
    iccheck_show_taint_tag(arg1);
}

void
test_gets()
{
    int arg0 = 0, arg1 = 0;
    int ret = gets(arg0, arg1);
    iccheck_show_taint_tag(ret);  // expected-warning{{NO_NEW_LINE}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
                                  // expected-warning@-2{{STDIN}}
                                  // expected-warning@-3{{ARGS}}
                                  // expected-warning@-4{{ENVIRONMENT}}
                                  // expected-warning@-5{{FILE_SYSTEM}}
                                  // expected-warning@-6{{FORMAT_STRING}}
                                  // expected-warning@-7{{PATH_MANIPULATION}}
                                  // expected-warning@-8{{STREAM}}
    iccheck_show_taint_tag(arg0); // expected-warning{{NO_NEW_LINE}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
                                  // expected-warning@-2{{STDIN}}
                                  // expected-warning@-3{{ARGS}}
                                  // expected-warning@-4{{ENVIRONMENT}}
                                  // expected-warning@-5{{FILE_SYSTEM}}
                                  // expected-warning@-6{{FORMAT_STRING}}
                                  // expected-warning@-7{{PATH_MANIPULATION}}
                                  // expected-warning@-8{{STREAM}}
    iccheck_show_taint_tag(arg1);
}

void
test_gethostbyname()
{
    int arg0 = 0;
    int ret = gethostbyname(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{DNS}}
                                 // expected-warning@-1{{NO_NEW_LINE}}
                                 // expected-warning@-2{{NULL_TERMINATED}}
    iccheck_show_taint_tag(arg0);
}

void
test_uname()
{
    int arg0 = 0, arg1 = 0;
    uname(arg0, arg1);
    iccheck_show_taint_tag(arg0); // expected-warning{{NULL_TERMINATED}}
                                  // expected-warning@-1{{SYSTEMINFO}}
    iccheck_show_taint_tag(arg1);
}

void
test_fread()
{
    int arg0 = 0, arg1 = 0;
    fread(arg0, arg1);
    iccheck_show_taint_tag(arg0); // expected-warning{{NOT_NULL_TERMINATED}}
                                  // expected-warning@-1{{STREAM}}
    iccheck_show_taint_tag(arg1);
}

void
test_getuid()
{
    int arg0 = 0;
    int ret = getuid(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{NO_NEW_LINE}}
                                 // expected-warning@-1{{SYSTEMINFO}}
    iccheck_show_taint_tag(arg0);
}

void
test_secure_getenv()
{
    int arg0 = 0;
    int ret = secure_getenv(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{ENVIRONMENT}}
                                 // expected-warning@-1{{NULL_TERMINATED}}
    iccheck_show_taint_tag(arg0);
}

void
test_getdelim()
{
    int arg0 = 0, arg1 = 0;
    getdelim(arg0, arg1);
    iccheck_show_taint_tag(arg0); // expected-warning{{NO_NEW_LINE}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
                                  // expected-warning@-2{{STREAM}}
                                  // expected-warning@-3{{ARGS}}
                                  // expected-warning@-4{{ENVIRONMENT}}
                                  // expected-warning@-5{{FILE_SYSTEM}}
                                  // expected-warning@-6{{FORMAT_STRING}}
                                  // expected-warning@-7{{PATH_MANIPULATION}}
                                  // expected-warning@-8{{STDIN}}
    iccheck_show_taint_tag(arg1);
}

void
test_localtime()
{
    int arg0 = 0, arg1 = 0;
    int ret = localtime(arg0, arg1);
    iccheck_show_taint_tag(ret);  // expected-warning{{LOW_ENTROPY}}
    iccheck_show_taint_tag(arg0); // expected-warning{{LOW_ENTROPY}}
    iccheck_show_taint_tag(arg1);
}

void
test_getppid()
{
    int arg0 = 0;
    int ret = getppid(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{LOW_ENTROPY}}
    iccheck_show_taint_tag(arg0);
}

void
test_getenv_s()
{
    int arg0 = 0;
    int ret = getenv_s(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{ENVIRONMENT}}
                                 // expected-warning@-1{{NULL_TERMINATED}}
    iccheck_show_taint_tag(arg0);
}

void
test_CommandLineToArgvW()
{
    int arg0 = 0, arg1 = 0;
    int ret = CommandLineToArgvW(arg0, arg1);
    iccheck_show_taint_tag(ret); // expected-warning{{ARGS}}
                                 // expected-warning@-1{{NULL_TERMINATED}}
    iccheck_show_taint_tag(arg0);
    iccheck_show_taint_tag(arg1); // expected-warning{{ARGS}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
}

void
test_regGetValueW()
{
    int arg0 = 0, arg1 = 0, arg2 = 0, arg3 = 0, arg4 = 0, arg5 = 0;
    regGetValueW(arg0, arg1, arg2, arg3, arg4, arg5);
    iccheck_show_taint_tag(arg0);
    iccheck_show_taint_tag(arg1);
    iccheck_show_taint_tag(arg2);
    iccheck_show_taint_tag(arg3);
    iccheck_show_taint_tag(arg4);
    iccheck_show_taint_tag(arg5);
}

void
test_GetComputerNameW()
{
    int arg0 = 0, arg1 = 0;
    GetComputerNameW(arg0, arg1);
    iccheck_show_taint_tag(arg0); // expected-warning{{SYSTEMINFO}}
    iccheck_show_taint_tag(arg1);
}

void
test_ReadFileEx()
{
    int arg0 = 0, arg1 = 0;
    ReadFileEx(arg0, arg1);
    iccheck_show_taint_tag(arg0);
    iccheck_show_taint_tag(arg1); // expected-warning{{FILE_SYSTEM}}
                                  // expected-warning@-1{{NOT_NULL_TERMINATED}}
}

void
test_GetCommandLineW()
{
    int arg0 = 0;
    int ret = GetCommandLineW(arg0);
    iccheck_show_taint_tag(ret); // expected-warning{{ARGS}}
                                 // expected-warning@-1{{NULL_TERMINATED}}
    iccheck_show_taint_tag(arg0);
}

void
test_GetCurrentDirectory()
{
    int arg0 = 0, arg1 = 0;
    GetCurrentDirectory(arg0, arg1);
    iccheck_show_taint_tag(arg0);
    iccheck_show_taint_tag(arg1); // expected-warning{{FILE_SYSTEM}}
                                  // expected-warning@-1{{NULL_TERMINATED}}
}
