// RUN: iccheck++ -c %s
extern void __assert_fail(__const char *__assertion, __const char *__file, unsigned int __line,
                          __const char *__function) __attribute__((__noreturn__));
#define assert(expr) ((expr) ? (void)(0) : __assert_fail(#expr, __FILE__, __LINE__, __func__))
void
f0()
{
    assert(0); // expected-warning{{C_REACHABLE_ASSERTION}}
}

void
f_0and1()
{
    assert(0 && 1); // expected-warning{{C_REACHABLE_ASSERTION}}
}

void
f_1and0()
{
    assert(1 && 0); // expected-warning{{C_REACHABLE_ASSERTION}}
}

void
f_0and0()
{
    assert(0 && 0); // expected-warning{{C_REACHABLE_ASSERTION}}
}

void
f_0or0()
{
    assert(0 || 0); // expected-warning{{C_REACHABLE_ASSERTION}}
}

void
f_1()
{
    assert(1);
}

void
f_1or0()
{
    assert(1 || 0);
}

void
f_0or1()
{
    assert(0 || 1);
}

void
f_1or1()
{
    assert(1 || 1);
}

void
f_1and1()
{
    assert(1 && 1);
}

int
f_ret1()
{
    return 1;
}

void
f_call_ret1()
{
    assert(f_ret1());
}

int
f_ret0()
{
    return 0;
}

void
f_call_ret0()
{
    assert(f_ret0()); // expected-warning{{C_REACHABLE_ASSERTION}}
}

void
f_call_ret0_or_ret1()
{
    assert(f_ret0() || f_ret1());
}

void
f_call_ret0_and_ret1()
{
    assert(f_ret0() && f_ret1()); // expected-warning{{C_REACHABLE_ASSERTION}}
}
