// RUN: iccheck++ -c %s

int iccheck_sudo_raise_privileges();

int iccheck_sudo_lower_privileges();

int iccheck_raise_privileges();

int iccheck_lower_privileges();

int iccheck_run_unprivileged_code();

void
ok_flr(int raise, int low)
{
    iccheck_run_unprivileged_code();
    if (iccheck_raise_privileges()) {
        iccheck_run_unprivileged_code(); // ok
    } else {
        if (iccheck_sudo_lower_privileges()) {
            // expected-warning@-1{{C_IDENTICAL_EXPRESSIONS}}
            iccheck_run_unprivileged_code(); // ok
        } else {
            iccheck_run_unprivileged_code(); // ok
        }
    }
}

void
error()
{
    iccheck_raise_privileges();
    iccheck_run_unprivileged_code();
    // expected-warning@-1{{C_EXCESSIVE_PRIVILEGES}}
}

void
sudo_low()
{
    iccheck_raise_privileges();
    iccheck_sudo_lower_privileges();
    iccheck_run_unprivileged_code(); // ok
}

void
error_low()
{
    iccheck_raise_privileges();
    iccheck_lower_privileges();
    iccheck_run_unprivileged_code();
    // expected-warning@-1{{C_EXCESSIVE_PRIVILEGES}}
}

void
ok_low()
{
    iccheck_raise_privileges();
    iccheck_sudo_lower_privileges();
    iccheck_run_unprivileged_code();
}

void
ok_low2()
{
    iccheck_lower_privileges();
    iccheck_run_unprivileged_code(); // ok
}

void
sudo_raise()
{
    if (iccheck_sudo_raise_privileges()) {
        // expected-warning@-1{{C_IDENTICAL_EXPRESSIONS}}
        iccheck_run_unprivileged_code();
        // expected-warning@-1{{C_EXCESSIVE_PRIVILEGES}}
    } else {
        iccheck_run_unprivileged_code();
        // expected-warning@-1{{C_EXCESSIVE_PRIVILEGES}}
    }
}
