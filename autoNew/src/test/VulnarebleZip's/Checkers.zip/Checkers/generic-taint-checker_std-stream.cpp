// RUN: iccheck++ -c %s

#include "system-header-simulator-c.h"
#include "system-header-simulator-cxx.h"

int some_random();
void *get_ptr();

namespace testns {

class basic_ifstream
{
public:
    void operator>>(int &arg);
};
}

const char *filename;

int
test_ifstream()
{
    std::ifstream ifstrm(filename);
    int t, t2;
    ifstrm >> t >> t2;
    if (some_random()) {
        return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        return 1 / t2; // expected-warning{{C_DIVISION_BY_TAINTED}}
                       // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

int
test_cin()
{
    int t;
    std::cin >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

char
test_non_member_operator()
{
    char t, t1;
    std::cin >> t >> t1;
    if (some_random()) {
        return 1 / t1; // expected-warning{{C_DIVISION_BY_TAINTED}}
                       // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

int
test_wcin()
{
    int t;
    std::wcin >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_namespace()
{
    int t;
    testns::basic_ifstream stream;
    stream >> t;
    return 1 / t;
}

int
test_chain()
{
    int t1, t2;
    std::cin >> t1 >> t2;
    return 1 / t2; // expected-warning{{C_DIVISION_BY_TAINTED}}
                   // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_explicit_operator()
{
    int t1;
    std::cin.operator>>(t1);
    return 1 / t1; // expected-warning{{C_DIVISION_BY_TAINTED}}
                   // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_rdbuf()
{
    std::istream istr(std::cin.rdbuf());
    int t;
    istr >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_rdbuf_nowarn()
{
    std::istream istr(std::cin.rdbuf());
    std::istringstream isstr("12");
    istr.rdbuf(isstr.rdbuf());
    int test;
    istr >> test;
    test = 1 / test;
    std::cin.rdbuf(isstr.rdbuf());
    std::cin >> test;
    return 1 / test;
}

int
test_get()
{
    char c;
    int t;
    std::cin.get(c) >> t;
    if (some_random()) {
        return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        return 1 / c; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

int
test_unget()
{
    int c;
    std::cin.unget() >> c;
    return 1 / c; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_putback()
{
    int c;
    char ch = 0;
    std::cin.putback(ch) >> c;
    return 1 / c; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_peek()
{
    return 1 / std::cin.peek(); // expected-warning{{C_DIVISION_BY_TAINTED}}
                                // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_getline()
{
    char buf[10];
    int t;
    std::cin.getline(buf, 10) >> t;
    if (some_random()) {
        return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        return 1 / buf[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

int
test_ignore()
{
    int t;
    std::cin.ignore() >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_read()
{
    char buf[10];
    int t;
    std::cin.read(buf, 10) >> t;
    if (some_random()) {
        return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        return 1 / buf[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

int
test_readsome()
{
    char buf[10];
    int t = std::cin.readsome(buf, 10);
    if (some_random()) {
        return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    } else {
        return 1 / buf[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                           // expected-warning@-1{{C_UNDEFINED_RESULT}}
    }
}

int
test_gcount()
{
    return 1 / std::cin.gcount(); // expected-warning{{C_DIVISION_BY_TAINTED}}
                                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_seekg()
{
    int t;
    std::cin.seekg(1) >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_string()
{
    char c[10];
    scanf("%s", c);
    std::string s1(c);
    std::string s2(s1);
    std::istringstream sstr(s2);
    std::istream istr(sstr.rdbuf());
    int t;
    istr >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_tainted_stringstream()
{
    char buf[10];
    scanf("%s", buf);
    std::istringstream str1(buf);
    std::istringstream str2("123");
    str2.str(str1.str());
    int t;
    str2 >> t;
    return 1 / t; // expected-warning{{C_DIVISION_BY_TAINTED}}
                  // expected-warning@-1{{C_UNDEFINED_RESULT}}
}

int
test_member_non_member()
{
    char c_arr[100];
    char *c_ptr = (char *)get_ptr();
    char c;
    int i;
    switch (some_random()) {
    case 0:
        std::cin >> c_arr;   // expected-warning{{C_BUFFER_OVERFLOW}}
        return 1 / c_arr[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 1:
        std::cin >> c_ptr;   // expected-warning{{C_BUFFER_OVERFLOW}}
        return 1 / c_ptr[0]; // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
    case 2:
        std::cin >> c;
        return 1 / c; // expected-warning{{C_DIVISION_BY_TAINTED}}
                      // expected-warning@-1{{C_UNDEFINED_RESULT}}
    default:
        return 0;
    }
}

std::istream &operator>>(std::istream &in, testns::basic_ifstream &val);

void
test_own_operator()
{
    testns::basic_ifstream test_ifs;
    std::cin >> test_ifs;
}

void
test_path_manipulation()
{
    char buf[128];
    std::cin >> buf; // expected-warning{{C_BUFFER_OVERFLOW}}
    std::basic_ifstream<char> fstream;
    if (some_random()) {
        std::basic_ifstream<char> fstream(buf); // expected-warning{{C_PATH_MANIPULATION}}
    } else {
        fstream.open(buf); // expected-warning{{C_PATH_MANIPULATION}}
    }
    std::string tainted_string(buf);
    fstream.open(tainted_string); // expected-warning{{C_PATH_MANIPULATION}}
}
