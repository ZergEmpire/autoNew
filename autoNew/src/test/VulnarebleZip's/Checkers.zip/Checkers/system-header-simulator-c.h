typedef __typeof(sizeof(int)) size_t;
typedef long ssize_t;

void *memcpy(void *destination, const void *source, size_t num);
void *memset(void *ptr, int value, size_t num);
void *memmove(void *destination, const void *source, size_t num);
const void *memchr(const void *ptr, int value, size_t num);
void *memchr(void *ptr, int value, size_t num);
int memcmp(const void *ptr1, const void *ptr2, size_t num);
void *memccpy(void *destination, const void *source, int ch, size_t num);
void *mempcpy(void *destination, const void *source, size_t num);
ssize_t write(int fd, const void *buffer, size_t num);
ssize_t read(int fd, void *buf, size_t num);

size_t strlen(const char *string);

int scanf(const char *format, ...);
