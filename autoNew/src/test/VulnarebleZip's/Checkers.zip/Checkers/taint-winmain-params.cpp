// RUN: iccheck++ -target x86_64-pc-win32 -c %s

#define HINSTANCE int
#define PSTR const char *

int
WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, int nCmdShow)
{
    1 / (12 - lpCmdLine[3]); // expected-warning{{C_DIVISION_BY_TAINTED}}
                             // expected-warning@-1{{C_UNDEFINED_RESULT}}
    1 / (12 - hInstance);
    1 / (12 - hPrevInstance);
    1 / (12 - nCmdShow);
    return 0;
}
