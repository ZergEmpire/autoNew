// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

void
testPassword()
{
    NSString *password = @"hardcoded"; // expected-warning{{OBJC_PASSWORD_HARDCODED}}
}
