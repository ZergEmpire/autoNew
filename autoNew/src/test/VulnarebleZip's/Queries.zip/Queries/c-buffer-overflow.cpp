// RUN: iccheck++ -c %s

#include "system-header-simulator-cxx.h"

void
overflow()
{
    char cbuf[12];
    std::cin >> cbuf; // expected-warning{{C_BUFFER_OVERFLOW}}
    wchar_t wbuf[17];
    std::wcin >> wbuf; // expected-warning{{C_BUFFER_OVERFLOW}}
}
