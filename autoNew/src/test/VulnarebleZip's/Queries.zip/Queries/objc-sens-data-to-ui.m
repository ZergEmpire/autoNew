// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

@class NSTextContainer;

void
testPassword()
{
    CGRect *frame = CGRectMake(0, 0, 100, 100);
    NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:frame.size];
    UITextView *a = [UITextView initWithFrame:frame andTextContainer:textContainer];
    // expected-warning@-1{{OBJC_MEMORY_LEAK}}
    NSString *key = @"supersecretkey"; // expected-warning{{OBJC_CRYPTO_KEY_HARDCODED}}
    a.text = key;                      // expected-warning{{OBJC_SENSITIVE_DATA_TO_UI}}
}

void
testPassword1(NSString *key)
{
    CGRect *frame = CGRectMake(0, 0, 100, 100);
    NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:frame.size];
    UITextView *a = [UITextView initWithFrame:frame andTextContainer:textContainer];
    // expected-warning@-1{{OBJC_MEMORY_LEAK}}
    a.text = key; // expected-warning{{OBJC_SENSITIVE_DATA_TO_UI}}
}
