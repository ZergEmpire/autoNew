// RUN: iccheck -c %p/objc-backdoor-special-account.m

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

@class NSString;

void
testBsa(NSString *password, int pass)
{
    if ([password // expected-warning{{OBJC_BACKDOOR_SPECIAL_ACCOUNT}}
            isEqualToString:@"Some String"]) {
    }
    if ([@"some string" // expected-warning{{OBJC_BACKDOOR_SPECIAL_ACCOUNT}}
            isEqualToString:password]) {
    }

    if (pass == 123) {
    }
}

void
testBsaWithRegex(NSString *passwd)
{
    if ([passwd // expected-warning{{OBJC_BACKDOOR_SPECIAL_ACCOUNT}}
            isEqualToString:@"Some String"]) {
    }
    if ([@"some string" // expected-warning{{OBJC_BACKDOOR_SPECIAL_ACCOUNT}}
            isEqualToString:passwd]) {
    }
}
