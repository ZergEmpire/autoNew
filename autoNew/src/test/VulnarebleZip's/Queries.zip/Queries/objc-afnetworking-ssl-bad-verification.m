// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef signed char BOOL;

@interface AFSecurityPolicy
@property(nonatomic, assign) BOOL allowInvalidCertificates;
@end

void
testUnsafeSSL()
{
    AFSecurityPolicy *sp;
    [sp setAllowInvalidCertificates:
            YES]; // expected-warning@-1{{OBJC_AFNETWORKING_SSL_BAD_VERIFICATION}}
                  // expected-warning@-2{{OBJC_INCORRECT_FUNC_CALL}}
    [sp setAllowInvalidCertificates:NO];
}
