// RUN: iccheck -target x86_64-unknown-linux -c %s

#include "system-header-simulator-c.h"

char *strtok(char *string, const char *delim);

void
test_strtok()
{
    char *string;
    const char *delim;

    char *result = strtok(string, delim); // expected-warning{{C_DEPRECATED}}
                                          // expected-warning@-1{{C_DEAD_STORE}}
                                          // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct in_addr_t
{};

struct in_addr_t inet_addr(const char *cp);

void
test_inet_addr()
{
    const char *cp;

    struct in_addr_t result = inet_addr(cp); // expected-warning{{C_DEPRECATED}}
                                             // expected-warning@-1{{C_DEAD_STORE}}
                                             // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct in_addr_t __inet_addr(const char *cp);

void
test___inet_addr()
{
    const char *cp;

    struct in_addr_t result = __inet_addr(cp); // expected-warning{{C_DEPRECATED}}
                                               // expected-warning@-1{{C_DEAD_STORE}}
                                               // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

void bzero(void *s, size_t n);

void
test_bzero()
{
    void *s;
    size_t n;

    bzero(s, n); // expected-warning{{C_DEPRECATED}}
                 // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
                 // expected-warning@-2{{C_OBSOLETE}}
}

void __bzero(void *s, size_t n);

void
test___bzero()
{
    void *s;
    size_t n;

    __bzero(s, n); // expected-warning{{C_DEPRECATED}}
                   // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
}

void bcopy(const void *src, void *dest, size_t n);

void
test_bcopy()
{
    const void *src;
    void *dest;
    size_t n;

    bcopy(src, dest, n); // expected-warning{{C_DEPRECATED}}
                         // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
                         // expected-warning@-2{{C_OBSOLETE}}
}

struct BOOL
{};

struct VOID
{};

struct UINT_PTR
{};

struct BOOL IsBadReadPtr(const struct VOID *lp, struct UINT_PTR ucb);

void
test_IsBadReadPtr()
{
    const struct VOID *lp;
    struct UINT_PTR ucb;

    struct BOOL result = IsBadReadPtr(lp, ucb); // expected-warning{{C_DEPRECATED}}
                                                // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                // expected-warning@-2{{C_DEAD_STORE}}
                                                // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
}

struct LPVOID
{};

struct BOOL IsBadWritePtr(struct LPVOID lp, struct UINT_PTR ucb);

void
test_IsBadWritePtr()
{
    struct LPVOID lp;
    struct UINT_PTR ucb;

    struct BOOL result = IsBadWritePtr(lp, ucb); // expected-warning{{C_DEPRECATED}}
                                                 // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                 // expected-warning@-2{{C_ARRAY_OUT_OF_BOUNDS}}
                                                 // expected-warning@-3{{C_DEAD_STORE}}
}

struct UINT
{};

struct BOOL IsBadHugeReadPtr(const struct VOID *lp, struct UINT ucb);

void
test_IsBadHugeReadPtr()
{
    const struct VOID *lp;
    struct UINT ucb;

    struct BOOL result = IsBadHugeReadPtr(lp, ucb); // expected-warning{{C_DEPRECATED}}
                                                    // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                    // expected-warning@-2{{C_DEAD_STORE}}
                                                    // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
}

struct BOOL IsBadHugeWritePtr(struct LPVOID ptr, struct UINT_PTR size);

void
test_IsBadHugeWritePtr()
{
    struct LPVOID ptr;
    struct UINT_PTR size;

    struct BOOL result = IsBadHugeWritePtr(ptr,
                                           size); // expected-warning@-1{{C_DEPRECATED}}
                                                  // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                  // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                                  // expected-warning@-4{{C_DEAD_STORE}}
}

struct LPCTSTR
{};

struct BOOL IsBadStringPtr(struct LPCTSTR lpsz, struct UINT ucchMax);

void
test_IsBadStringPtr()
{
    struct LPCTSTR lpsz;
    struct UINT ucchMax;

    struct BOOL result = IsBadStringPtr(lpsz,
                                        ucchMax); // expected-warning@-1{{C_DEPRECATED}}
                                                  // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                  // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                                  // expected-warning@-4{{C_DEAD_STORE}}
}

struct FARPROC
{};

struct BOOL IsBadCodePtr(struct FARPROC lpfn);

void
test_IsBadCodePtr()
{
    struct FARPROC lpfn;

    struct BOOL result = IsBadCodePtr(lpfn); // expected-warning{{C_DEPRECATED}}
                                             // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                             // expected-warning@-2{{C_DEAD_STORE}}
}

struct LPCSTR
{};

struct BOOL IsBadStringPtrA(struct LPCSTR lpsz, struct UINT_PTR ucchMax);

void
test_IsBadStringPtrA()
{
    struct LPCSTR lpsz;
    struct UINT_PTR ucchMax;

    struct BOOL result = IsBadStringPtrA(lpsz,
                                         ucchMax); // expected-warning@-1{{C_DEPRECATED}}
                                                   // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-4{{C_DEAD_STORE}}
}

struct LPCWSTR
{};

struct BOOL IsBadStringPtrW(struct LPCWSTR lpsz, struct UINT_PTR ucchMax);

void
test_IsBadStringPtrW()
{
    struct LPCWSTR lpsz;
    struct UINT_PTR ucchMax;

    struct BOOL result = IsBadStringPtrW(lpsz,
                                         ucchMax); // expected-warning@-1{{C_DEPRECATED}}
                                                   // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-4{{C_DEAD_STORE}}
}

char *getpass(const char *str);

void
test_getpass()
{
    const char *str;

    char *result = getpass(str); // expected-warning{{C_DEPRECATED}}
                                 // expected-warning@-1{{C_DEAD_STORE}}
                                 // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

char *cuserid(char *string);

void
test_cuserid()
{
    char *string;

    char *result = cuserid(string); // expected-warning{{C_DEPRECATED}}
                                    // expected-warning@-1{{C_DEAD_STORE}}
                                    // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct uid_t
{};

int getpw(struct uid_t uid, char *buf);

void
test_getpw()
{
    struct uid_t uid;
    char *buf;

    int result = getpw(uid, buf); // expected-warning{{C_DEPRECATED}}
                                  // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
}

void *valloc(size_t size);

void
test_valloc()
{
    size_t size;

    void *result = valloc(size); // expected-warning{{C_DEPRECATED}}
                                 // expected-warning@-1{{C_DEAD_STORE}}
                                 // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct BYTE
{};

struct DWORD
{};

struct ULONG_PTR
{};

void keybd_event(struct BYTE bVk, struct BYTE bScan, struct DWORD dwFlags,
                 struct ULONG_PTR dwExtraInfo);

void
test_keybd_event()
{
    struct BYTE bVk;
    struct BYTE bScan;
    struct DWORD dwFlags;
    struct ULONG_PTR dwExtraInfo;

    keybd_event(bVk, bScan, dwFlags, dwExtraInfo); // expected-warning{{C_DEPRECATED}}
                                                   // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-2{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-4{{C_ARRAY_OUT_OF_BOUNDS}}
}

struct HFILE
{};

struct LPOFSTRUCT
{};

struct HFILE OpenFile(struct LPCSTR lpFileName, struct LPOFSTRUCT lpReOpenBuff, struct UINT uStyle);

void
test_OpenFile()
{
    struct LPCSTR lpFileName;
    struct LPOFSTRUCT lpReOpenBuff;
    struct UINT uStyle;

    struct HFILE result = OpenFile(lpFileName, lpReOpenBuff,
                                   uStyle); // expected-warning@-1{{C_DEPRECATED}}
                                            // expected-warning@-2{{C_ARRAY_OUT_OF_BOUNDS}}
                                            // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                            // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                            // expected-warning@-5{{C_DEAD_STORE}}
}

int WSACancelBlockingCall();

void
test_WSACancelBlockingCall()
{
    int result = WSACancelBlockingCall(); // expected-warning{{C_DEPRECATED}}
                                          // expected-warning@-1{{C_DEAD_STORE}}
}

struct BOOL WSAIsBlocking();

void
test_WSAIsBlocking()
{
    struct BOOL result = WSAIsBlocking(); // expected-warning{{C_DEPRECATED}}
                                          // expected-warning@-1{{C_DEAD_STORE}}
}

struct FARPROC WSASetBlockingHook(struct FARPROC lpBlockFunc);

void
test_WSASetBlockingHook()
{
    struct FARPROC lpBlockFunc;

    struct FARPROC result = WSASetBlockingHook(
        lpBlockFunc); // expected-warning@-1{{C_DEPRECATED}}
                      // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                      // expected-warning@-3{{C_DEAD_STORE}}
}

int WSAUnhookBlockingHook();

void
test_WSAUnhookBlockingHook()
{
    int result = WSAUnhookBlockingHook(); // expected-warning{{C_DEPRECATED}}
                                          // expected-warning@-1{{C_DEAD_STORE}}
}

struct DWORD LoadModule(struct LPCSTR lpModuleName, struct LPVOID lpParameterBlock);

void
test_LoadModule()
{
    struct LPCSTR lpModuleName;
    struct LPVOID lpParameterBlock;

    struct DWORD result = LoadModule(
        lpModuleName, lpParameterBlock); // expected-warning@-1{{C_DEPRECATED}}
                                         // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                         // expected-warning@-2{{C_ARRAY_OUT_OF_BOUNDS}}
                                         // expected-warning@-4{{C_DEAD_STORE}}
}

struct UINT SetHandleCount(struct UINT uNumber);

void
test_SetHandleCount()
{
    struct UINT uNumber;

    struct UINT result = SetHandleCount(uNumber); // expected-warning{{C_DEPRECATED}}
                                                  // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                  // expected-warning@-2{{C_DEAD_STORE}}
}

struct LONG
{};

struct HWND
{};

struct GUID
{};

struct LONG WinVerifyTrust(struct HWND hwnd, struct GUID *pgActionID, struct LPVOID pWVTData);

void
test_WinVerifyTrust()
{
    struct HWND hwnd;
    struct GUID *pgActionID;
    struct LPVOID pWVTData;

    struct LONG result = WinVerifyTrust(hwnd, pgActionID,
                                        pWVTData); // expected-warning@-1{{C_DEPRECATED}}
                                                   // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-3{{C_ARRAY_OUT_OF_BOUNDS}}
                                                   // expected-warning@-4{{C_DEAD_STORE}}
                                                   // expected-warning@-5{{C_INCORRECT_FUNC_CALL}}
}

struct HRESULT
{};

struct WINTRUST_DATA
{};

struct HRESULT WinVerifyTrustEx(struct HWND hwnd, struct GUID *pgActionID,
                                struct WINTRUST_DATA *pWinTrustData);

void
test_WinVerifyTrustEx()
{
    struct HWND hwnd;
    struct GUID *pgActionID;
    struct WINTRUST_DATA *pWinTrustData;

    struct HRESULT result = WinVerifyTrustEx(
        hwnd, pgActionID, pWinTrustData); // expected-warning@-1{{C_DEPRECATED}}
                                          // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                          // expected-warning@-3{{C_DEAD_STORE}}
                                          // expected-warning@-4{{C_INCORRECT_FUNC_CALL}}
}

size_t mbstowcs(wchar_t *dst, const char *src, size_t len);

void
test_mbstowcs()
{
    wchar_t *dst;
    const char *src;
    size_t len;

    size_t result = mbstowcs(dst, src, len); // expected-warning{{C_DEPRECATED}}
                                             // expected-warning@-1{{C_DEAD_STORE}}
                                             // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct _locale_t
{};

size_t _mbstowcs_l(wchar_t *wcstr, const char *mbstr, size_t count, struct _locale_t locale);

void
test__mbstowcs_l()
{
    wchar_t *wcstr;
    const char *mbstr;
    size_t count;
    struct _locale_t locale;

    size_t result = _mbstowcs_l(wcstr, mbstr, count,
                                locale); // expected-warning@-1{{C_DEPRECATED}}
                                         // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
                                         // expected-warning@-3{{C_DEAD_STORE}}
                                         // expected-warning@-4{{C_INCORRECT_FUNC_CALL}}
}
