// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef signed char BOOL;

@class NSString;

typedef NSString *UIPasteboardName;

@interface UIPasteboard
@property(nonatomic, readonly) UIPasteboard *generalPasteboard;
+ (UIPasteboard *)pasteboardWithName:(UIPasteboardName)pasteboardName create:(BOOL)create;
+ (UIPasteboard *)pasteboardWithUniqueName;
@end

const UIPasteboardName UIPasteboardNameGeneral;

void
testPasteboard()
{
    UIPasteboard *pb1 = [UIPasteboard generalPasteboard]; // expected-warning{{OBJC_CLIPBOARD}}
                                                          // expected-warning@-1{{C_DEAD_STORE}}
    UIPasteboard *pb2 = [UIPasteboard
        pasteboardWithName:UIPasteboardNameGeneral // expected-warning@-1{{OBJC_CLIPBOARD}}
                    create:NO];                    // expected-warning@-2{{C_DEAD_STORE}}

    UIPasteboard *pb3 =
        [UIPasteboard pasteboardWithUniqueName]; // expected-warning{{OBJC_CLIPBOARD}}
                                                 // expected-warning@-2{{C_DEAD_STORE}}
}
