// RUN: iccheck -c %s


#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"


void
testKey()
{

        NSData *salt = [@"salt" dataUsingEncoding:NSUTF8StringEncoding];
        unsigned int keySize = kCCKeySizeAES128;
        const int rounds = 30000;

        NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
        NSData *keyData = [@"hardcoded" dataUsingEncoding:NSUTF8StringEncoding];
        CCKeyDerivationPBKDF(kCCPBKDF2, keyData.bytes, keyData.length, salt.bytes, salt.length, // expected-warning{{OBJC_CRYPTO_BAD_ITERATION_COUNT}}
                             kCCPRFHmacAlgSHA1, 2048, derivedKey.mutableBytes, derivedKey.length);
}
