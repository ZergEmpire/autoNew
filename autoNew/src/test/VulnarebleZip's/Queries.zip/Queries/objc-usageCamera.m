// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

@class UIImagePickerController;

UIImagePickerController *
takePhoto()
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] // expected-warning{{OBJC_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION}}
        init];
    return picker;
}