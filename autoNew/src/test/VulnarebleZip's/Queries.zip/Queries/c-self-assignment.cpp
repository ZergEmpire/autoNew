// RUN: iccheck++ -c %s

class A
{
public:
    A(int a) : a(a), b(0), c(0) {} // ok
    A(const A& o) : a(o.a), b(o.b), c(o.c) {} // ok
    A(int a, int b_) : a(a), b(b), c(0) {} // expected-warning{{C_SELF_ASSIGNMENT}}
    A(int a_, int b_, int c_) : a(b), b(b_), c(c_) {} // ok

private:
    int a, b, c;
};
