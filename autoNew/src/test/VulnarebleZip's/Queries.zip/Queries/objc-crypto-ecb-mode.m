// RUN: iccheck -c %s

#include "system-header-simulator-osx.h"

void
OBJC_CRYPTO_ECB_MODE()
{
    CCCryptorRef cryptor;
    CCCryptorCreate(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128,
                    0, // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0,
                            kCCKeySizeAES128, // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                              // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                              // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);
}
