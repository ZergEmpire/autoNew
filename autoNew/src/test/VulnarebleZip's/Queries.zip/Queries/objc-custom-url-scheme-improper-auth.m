// RUN: iccheck -c %s

#include "system-header-simulator-objc.h"

@class UIWebView, UIWebViewNavigationType, NSURL, FileObject, UIApplication;

@implementation Complex
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    if (!url) {
        return NO;
    }
    NSString *action = [url host];
    NSDictionary *a = [self doNothing:[url query]]; // expected-warning{{C_DEAD_STORE}}
    NSDictionary *dict = [self // expected-warning{{OBJC_CUSTOM_URL_SCHEME_IMPROPER_AUTH}}
        parseQueryStringExampleFunction:[url query]];
    NSDictionary *b = [self // expected-warning{{C_DEAD_STORE}}
        parseQueryStringExampleFunction:[self query]];
    if ([action isEqualToString:@"replaceFileText"]) {
        FileObject *objectFile = [self // expected-warning{{C_DEAD_STORE}}
                                       // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}
                                       // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
            writeToFile:[dict objectForKey:@"file"]
               withText:[dict objectForKey:@"text"]];
    }
    return YES;
}

- (FileObject *)writeToFile:(NSString *)file:(NSString *)withText
{
    return NULL;
}

- (NSDictionary *)parseQueryStringExampleFunction:(NSString *)query
{
    return @{@1 : @2, @2 : @1};
}
@end
