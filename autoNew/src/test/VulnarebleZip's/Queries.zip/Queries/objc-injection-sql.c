// RUN: iccheck -c %s

typedef struct sqlite3_
{
} sqlite3;

typedef struct sqlite3_stmt_
{
} sqlite3_stmt;

int sqlite3_prepare(sqlite3 *db, const char *zSql, int nByte, sqlite3_stmt **ppStmt,
                    const char **pzTail);

void
testSqlInjection(const char *sql)
{
    sqlite3 *database;
    sqlite3_stmt *sqlStatement;
    int inj = sqlite3_prepare(database, sql, -1, &sqlStatement,
                              (void *)0); // expected-warning@-1{{OBJC_INJECTION_SQL}}
                                          // expected-warning@-2{{C_DEAD_STORE}}
                                          // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    int sec = sqlite3_prepare(database, "SELECT ID,NAME FROM CUSTOMERS", -1,
                              &sqlStatement, // expected-warning@-1{{C_DEAD_STORE}}
                              (void *)0);
}
