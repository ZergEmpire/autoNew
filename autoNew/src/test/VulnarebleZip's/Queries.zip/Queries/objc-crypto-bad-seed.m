// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
crypto_bad_seed()
{
    srand48(0); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    erand48(12345); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    nrand48(4567); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    jrand48(34534534); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    srandom(3453); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    lcong48(5353); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    seed48(353); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    srand(345345); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}
    rand_r(53453); // expected-warning{{OBJC_CRYPTO_BAD_SEED}}

    int a = (int)time(NULL);
    srand(a);
}