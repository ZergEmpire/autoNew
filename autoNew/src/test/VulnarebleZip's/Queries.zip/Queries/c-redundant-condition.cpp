// RUN: iccheck++ -c %s

void do_something();
void do_something_else();

void
redundant(int param, int other_param)
{
    if (param) {
        if (param && other_param > 10) { // expected-warning{{C_REDUNDANT_CONDITION}}
            do_something();
            return;
        }

        do_something_else();
    }

    if (param)
        do_something();
}
