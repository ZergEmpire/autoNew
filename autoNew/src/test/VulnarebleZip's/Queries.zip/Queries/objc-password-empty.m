// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

void
testPassword()
{
    NSString *mypassword = @""; // expected-warning{{OBJC_PASSWORD_EMPTY}}
}
