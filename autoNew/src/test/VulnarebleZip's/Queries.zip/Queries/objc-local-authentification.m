// RUN: iccheck -c %s

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface LAContext : NSObject
@end

void
testLocalAuthentication()
{
    LAContext *myContext = [[LAContext alloc]
        init]; // expected-warning@-1{{OBJC_LOCAL_AUTHENTICATION}}
               // expected-warning@-2{{OBJC_LOCAL_AUTHENTICATION}}
               // expected-warning@-3{{C_DEAD_STORE}}
} // expected-warning{{OBJC_MEMORY_LEAK}}
