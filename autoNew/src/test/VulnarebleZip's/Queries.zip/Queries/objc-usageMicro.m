// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

@class AVAudioEngine, AVAudioSession;

AVAudioEngine *
testBrightness()
{
    AVAudioEngine *engine = [[AVAudioEngine alloc] init]; // expected-warning{{OBJC_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION}}
    [[AVAudioSession sharedInstance] setActive:YES];
    return engine;
}