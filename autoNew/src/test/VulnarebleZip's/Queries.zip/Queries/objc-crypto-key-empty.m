// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
testKey()
{
    const char *dataIn = "Data";
    char dataOut[512];
    unsigned int numBytesEncrypted;
    unsigned char out[1024];
    CCCryptorRef cryptor;

    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "", 0, (void *)0,
            dataIn, // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}
                    // expected-warning@-2{{OBJC_CRYPTO_NULL_IV}}
            sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "still_empty", 0,
            (void *)0, // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}
                       // expected-warning@-2{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}
    CCCryptorCreate(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, "", kCCKeySizeDES,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_EMPTY}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, "",
                            kCCKeySizeDES, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                           // expected-warning@-2{{OBJC_CRYPTO_KEY_EMPTY}}
                                           // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);

    NSString *encryptKey = @""; // expected-warning{{OBJC_CRYPTO_KEY_EMPTY}}

    CCHmac(kCCHmacAlgSHA256, "", 5, dataOut, sizeof(dataOut),
           out); // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}
    CCHmac(kCCHmacAlgSHA256, "still_empty", 0, dataOut, sizeof(dataOut),
           out); // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA256, "", 0); // expected-warning{{OBJC_CRYPTO_KEY_EMPTY}}
    CCHmacInit(&context, kCCHmacAlgSHA256, "still_empty",
               0); // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}

    if ([encryptKey isEqualToString:@""]) { // expected-warning{{OBJC_CRYPTO_KEY_EMPTY}}
    }

    NSData *salt = [@"salt" dataUsingEncoding:NSUTF8StringEncoding];
    unsigned int rounds = 2048;
    unsigned int keySize = kCCKeySizeAES128;

    NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
    NSData *keyData = [@"hardcoded" dataUsingEncoding:NSUTF8StringEncoding];
    CCKeyDerivationPBKDF(kCCPBKDF2, keyData.bytes, 0, salt.bytes, salt.length,
                         kCCPRFHmacAlgSHA1, // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}
                         rounds, derivedKey.mutableBytes, derivedKey.length);
    CCKeyDerivationPBKDF(kCCPBKDF2, "", 0, salt.bytes, salt.length, kCCPRFHmacAlgSHA1,
                         rounds, // expected-warning@-1{{OBJC_CRYPTO_KEY_EMPTY}}
                         derivedKey.mutableBytes, derivedKey.length);
}
