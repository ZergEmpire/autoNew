// RUN: iccheck -c %s

@class NSString;

void NSLog(NSString *format, ...);

void
testNSLog()
{
    NSLog(@"Log message..."); // expected-warning{{OBJC_NSLOG}}

#ifdef DEBUG
#define NSLog(...) NSLog(__VA_ARGS__)
#else
#define NSLog(...) (void)0
#endif

    NSLog(@"Log message...");

#undef NSLog

    NSLog(@"Log message..."); // expected-warning{{OBJC_NSLOG}}
}
