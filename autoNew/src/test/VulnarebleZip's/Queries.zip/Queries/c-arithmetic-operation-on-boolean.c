// RUN: iccheck -c %s

#define bool _Bool
#define true 1
#define false 0

void
f()
{
    bool x = true;
    bool y = false;

    x + y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x - y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x *y;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    y / x; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    y % x; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}

    int i = 1;

    i + y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i - y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i *y;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i / x; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i % x; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}

    x + i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x - i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x *i;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x / i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x % i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}

    x == i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x != i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x <= i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x >= i; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x < i;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    x > i;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i == y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i != y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i <= y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i >= y; // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i < y;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
    i > y;  // expected-warning{{C_ARITHMETIC_OPERATION_ON_BOOLEAN}}
}

void
f2(bool x, bool y)
{
    x <= y; // expected-warning{{C_REDUNDANT_CONDITION}}
    x >= y; // expected-warning{{C_REDUNDANT_CONDITION}}
    y <= x; // expected-warning{{C_REDUNDANT_CONDITION}}
    y >= x; // expected-warning{{C_REDUNDANT_CONDITION}}
}
