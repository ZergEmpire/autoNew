// RUN: iccheck -c %s

void error(int status, int errnum, const char *format, ...);

void
test_error()
{
    int status;
    int errnum;
    const char *format;

    error(status, errnum, format); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
                                   // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
}

void error_at_line(int status, int errnum, const char *filename, unsigned int linenum,
                   const char *format, ...);

void
test_error_at_line()
{
    int status;
    int errnum;
    const char *filename;
    unsigned int linenum;
    const char *format;

    error_at_line(status, errnum, filename, linenum,
                  format); // expected-warning@-1{{C_INFORMATION_LEAK_INTERNAL}}
                           // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

void __error_at_line(int status, int errnum, const char *filename, unsigned int linenum,
                     const char *format, ...);

void
test___error_at_line()
{
    int status;
    int errnum;
    const char *filename;
    unsigned int linenum;
    const char *format;

    __error_at_line(status, errnum, filename, linenum,
                    format); // expected-warning@-1{{C_INFORMATION_LEAK_INTERNAL}}
                             // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct JNIEnv
{
    void (*ExceptionDescribe)(struct JNIEnv *);
};

void
test_ExceptionDescribe()
{
    struct JNIEnv *env;

    env->ExceptionDescribe(env); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
                                 // expected-warning@-1{{C_UNDEFINED_VALUE}}
}
