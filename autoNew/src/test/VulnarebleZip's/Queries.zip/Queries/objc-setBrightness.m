// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

@class UIScreen;

void
testBrightness()
{
    [[UIScreen mainScreen] setBrightness:1]; // expected-warning{{OBJC_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION}}
}
