// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
test_file_protection()
{
    NSString *NSFileProtectionNone;
    NSString *NSFileProtectionKey;
    NSString *NSDataWritingFileProtectionNone;
    NSString *NSFileProtectionCompleteUntilFirstUserAuthentication;
    NSString *NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication;
    NSString *kSecAttrAccessible;
    NSString *kSecAttrAccessibleAfterFirstUnlock;
    NSString *kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;

    NSMutableDictionary *dict = [NSMutableDictionary dictionary];

    [dict setObject:(__bridge id)NSFileProtectionNone
             forKey:(__bridge id)
                        NSFileProtectionKey]; // expected-warning@-2{{OBJC_LACKING_FILE_PROTECTION}}
                                              // expected-warning@-3{{OBJC_INCORRECT_FUNC_CALL}}
    [dict
        setObject:
            (__bridge id)
                NSDataWritingFileProtectionNone // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
           forKey:(__bridge id)NSFileProtectionKey];
    [dict
        setObject:
            (__bridge id)
                NSFileProtectionCompleteUntilFirstUserAuthentication // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
           forKey:(__bridge id)NSFileProtectionKey];
    [dict // expected-warning{{OBJC_LACKING_FILE_PROTECTION}}
        setObject:(__bridge id)NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication
           forKey:(__bridge id)NSFileProtectionKey];

    [dict // expected-warning{{OBJC_LACKING_FILE_PROTECTION}}
        dictionaryWithObjectsAndKeys:(__bridge id)NSFileProtectionKey,
                                     (__bridge id)NSFileProtectionNone, nil];
    [dict // expected-warning{{OBJC_LACKING_FILE_PROTECTION}}
        dictionaryWithObjectsAndKeys:(__bridge id)NSFileProtectionKey,
                                     (__bridge id)NSDataWritingFileProtectionNone, nil];
    [dict dictionaryWithObjectsAndKeys:
              (__bridge id)
                  kSecAttrAccessible, // expected-warning@-2{{OBJC_LACKING_FILE_PROTECTION}}
                                      // expected-warning@-3{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAfterFirstUnlock, nil];
    [dict // expected-warning{{OBJC_LACKING_FILE_PROTECTION}}
          // expected-warning@-1{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
        dictionaryWithObjectsAndKeys:(__bridge id)kSecAttrAccessible,
                                     (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
                                     nil];

    [dict // expected-warning{{OBJC_LACKING_FILE_PROTECTION}}
        dictionaryWithObject:(__bridge id)NSFileProtectionNone
                      forKey:(__bridge id)NSFileProtectionKey];
    [dict
        dictionaryWithObject:
            (__bridge id)
                NSDataWritingFileProtectionNone // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
                      forKey:(__bridge id)NSFileProtectionKey];
    [dict
        dictionaryWithObject:
            (__bridge id)
                kSecAttrAccessibleAfterFirstUnlock // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
                                                   // expected-warning@-4{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
                      forKey:(__bridge id)kSecAttrAccessible];
    [dict
        dictionaryWithObject:
            (__bridge id)
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
                                                                 // expected-warning@-4{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
                      forKey:(__bridge id)kSecAttrAccessible];
}

void
testSet()
{
    NSError *error;
    NSString *docsDir;
    NSDictionary *NSFileProtectionNone;
    NSDictionary *NSDataWritingFileProtectionNone;
    NSDictionary *kSecAttrAccessibleAfterFirstUnlock;
    NSDictionary *kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;
    [[NSFileManager defaultManager]
        setAttributes:NSFileProtectionNone // expected-warning@-1{{OBJC_FILE_SYSTEM_MISUSED}}
                                           // expected-warning@-2{{OBJC_LACKING_FILE_PROTECTION}}
                                           // expected-warning@-3{{OBJC_INCORRECT_FUNC_CALL}}
         ofItemAtPath:docsDir
                error:&error];
    [[NSFileManager defaultManager]
        setAttributes:
            NSDataWritingFileProtectionNone // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                                            // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
         ofItemAtPath:docsDir
                error:&error];
    [[NSFileManager defaultManager]
        setAttributes:
            kSecAttrAccessibleAfterFirstUnlock // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                                               // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
         ofItemAtPath:docsDir
                error:&error];
    [[NSFileManager defaultManager]
        setAttributes:
            kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                                                             // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
         ofItemAtPath:docsDir
                error:&error];
}

enum
{
    NSFileProtectionNone,
    NSDataWritingFileProtectionNone,
    kSecAttrAccessibleAfterFirstUnlock,
    kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
};

void
testWriteToFile()
{
    NSString *path = @"/privateData.txt";
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error;
    [data writeToFile:@"foo.png"
              options:NSFileProtectionNone
                error:&error]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
                               // expected-warning@-4{{OBJC_LACKING_FILE_PROTECTION}}
    [data writeToFile:@"foo.png"
              options:NSDataWritingFileProtectionNone
                error:&error]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
                               // expected-warning@-4{{OBJC_LACKING_FILE_PROTECTION}}
    [data writeToFile:@"foo.png"
              options:kSecAttrAccessibleAfterFirstUnlock
                error:&error];   // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                                 // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
                                 // expected-warning@-4{{OBJC_LACKING_FILE_PROTECTION}}
    [data writeToFile:@"foo.png" // expected-warning{{OBJC_FILE_SYSTEM_MISUSED}}
                                 // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}
                                 // expected-warning@-2{{OBJC_LACKING_FILE_PROTECTION}}
              options:kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
                error:&error];
}
