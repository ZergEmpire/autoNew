// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

enum
{
    NSOrderedAscending = -1L,
    NSOrderedDescending = 1L,
    NSOrderedSame = 0L
};

void
testTimebombBackdoor(NSDate *startDate, NSDate *endDate)
{
    if ([startDate compare:endDate] == // expected-warning{{OBJC_BACKDOOR_TIMEBOMB}}
        NSOrderedDescending) {
    }
    if ([startDate compare:endDate] == // expected-warning{{OBJC_BACKDOOR_TIMEBOMB}}
        NSOrderedAscending) {
    }
    if ([startDate compare:endDate] == // expected-warning{{OBJC_BACKDOOR_TIMEBOMB}}
        NSOrderedSame) {
    }
}
