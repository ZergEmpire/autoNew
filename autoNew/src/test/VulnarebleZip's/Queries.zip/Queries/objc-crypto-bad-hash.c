// RUN: iccheck -c %s

unsigned char *MD2(const unsigned char *d, unsigned long n, unsigned char *md);

void
test_MD2()
{
    const unsigned char *d;
    unsigned long n;
    unsigned char *md;

    unsigned char *result = MD2(d, n, md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                                           // expected-warning@-1{{C_DEAD_STORE}}
                                           // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct MD2_CTX
{};

int MD2_Init(struct MD2_CTX *c);

void
test_MD2_Init()
{
    struct MD2_CTX *c;

    int result = MD2_Init(c); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                              // expected-warning@-1{{C_DEAD_STORE}}
                              // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

unsigned char *MD4(const unsigned char *d, unsigned long n, unsigned char *md);

void
test_MD4()
{
    const unsigned char *d;
    unsigned long n;
    unsigned char *md;

    unsigned char *result = MD4(d, n, md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                                           // expected-warning@-1{{C_DEAD_STORE}}
                                           // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct MD4_CTX
{};

int MD4_Init(struct MD4_CTX *c);

void
test_MD4_Init()
{
    struct MD4_CTX *c;

    int result = MD4_Init(c); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                              // expected-warning@-1{{C_DEAD_STORE}}
                              // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

unsigned char *MD5(const unsigned char *d, unsigned long n, unsigned char *md);

void
test_MD5()
{
    const unsigned char *d;
    unsigned long n;
    unsigned char *md;

    unsigned char *result = MD5(d, n, md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                                           // expected-warning@-1{{C_DEAD_STORE}}
                                           // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct MD5_CTX
{};

int MD5_Init(struct MD5_CTX *c);

void
test_MD5_Init()
{
    struct MD5_CTX *c;

    int result = MD5_Init(c); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                              // expected-warning@-1{{C_DEAD_STORE}}
                              // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

unsigned char *SHA1(const unsigned char *d, unsigned long n, unsigned char *md);

void
test_SHA1()
{
    const unsigned char *d;
    unsigned long n;
    unsigned char *md;

    unsigned char *result = SHA1(d, n, md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                                            // expected-warning@-1{{C_DEAD_STORE}}
                                            // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}

struct SHA_CTX
{};

int SHA1_Init(struct SHA_CTX *c);

void
test_SHA1_Init()
{
    struct SHA_CTX *c;

    int result = SHA1_Init(c); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
                               // expected-warning@-1{{C_DEAD_STORE}}
                               // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
}
