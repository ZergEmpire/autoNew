// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

@class CLLocationManager, CLLocationManagerDelegate;

@interface UIViewController <__covariant ObjectType> {
}

@end

@interface yourController : UIViewController <CLLocationManagerDelegate *> {
    CLLocationManager *locationManager; // expected-warning{{OBJC_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION}}
}

@end