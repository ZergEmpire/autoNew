// RUN: iccheck -c %s

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface UIWebView : NSObject
@end

void
testDeprecated()
{
    UIWebView *webView = [[UIWebView alloc] init]; // expected-warning{{OBJC_DEPRECATED}}
                                                   // expected-warning@-1{{OBJC_DEPRECATED}}
                                                   // expected-warning@-2{{C_DEAD_STORE}}
} // expected-warning{{OBJC_MEMORY_LEAK}}
