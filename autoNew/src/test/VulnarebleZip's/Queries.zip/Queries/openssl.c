// RUN: iccheck -c %s

#define SHA_DIGEST_LENGTH 20
#define MD2_DIGEST_LENGTH 16
#define MD4_DIGEST_LENGTH 16
#define MD5_DIGEST_LENGTH 16

typedef struct SHA_CTX_
{
} SHA_CTX;

typedef struct SHA256_CTX_
{
} SHA256_CTX;

typedef struct SHA512_CTX_
{
} SHA512_CTX;

typedef struct MD2_CTX_
{
} MD2_CTX;

typedef struct MD4_CTX_
{
} MD4_CTX;

typedef struct MD5_CTX_
{
} MD5_CTX;

typedef struct EVP_CIPHER_
{
} EVP_CIPHER;

typedef struct EVP_CIPHER_CTX_
{
} EVP_CIPHER_CTX;

typedef struct HMAC_CTX_
{
} HMAC_CTX;

typedef struct ENGINE_
{
} ENGINE;

typedef struct EVP_MD_
{
} EVP_MD;

unsigned long strlen(const char *str);

int SHA1_Init(SHA_CTX *c);
int SHA1_Update(SHA_CTX *c, const void *data, unsigned long len);
int SHA1_Final(unsigned char *md, SHA_CTX *c);
unsigned char *SHA1(const unsigned char *d, unsigned long n, unsigned char *md);

int SHA224_Init(SHA256_CTX *c);
int SHA224_Update(SHA256_CTX *c, const void *data, unsigned long len);
int SHA224_Final(unsigned char *md, SHA256_CTX *c);
unsigned char *SHA224(const unsigned char *d, unsigned long n, unsigned char *md);

int SHA256_Init(SHA256_CTX *c);
int SHA256_Update(SHA256_CTX *c, const void *data, unsigned long len);
int SHA256_Final(unsigned char *md, SHA256_CTX *c);
unsigned char *SHA256(const unsigned char *d, unsigned long n, unsigned char *md);

int SHA384_Init(SHA512_CTX *c);
int SHA384_Update(SHA512_CTX *c, const void *data, unsigned long len);
int SHA384_Final(unsigned char *md, SHA512_CTX *c);
unsigned char *SHA384(const unsigned char *d, unsigned long n, unsigned char *md);

int SHA512_Init(SHA512_CTX *c);
int SHA512_Update(SHA512_CTX *c, const void *data, unsigned long len);
int SHA512_Final(unsigned char *md, SHA512_CTX *c);
unsigned char *SHA512(const unsigned char *d, unsigned long n, unsigned char *md);

int MD2_Init(MD2_CTX *c);
int MD2_Update(MD2_CTX *c, const unsigned char *data, unsigned long len);
int MD2_Final(unsigned char *md, MD2_CTX *c);
unsigned char *MD2(const unsigned char *d, unsigned long n, unsigned char *md);

int MD4_Init(MD4_CTX *c);
int MD4_Update(MD4_CTX *c, const void *data, unsigned long len);
int MD4_Final(unsigned char *md, MD4_CTX *c);
unsigned char *MD4(const unsigned char *d, unsigned long n, unsigned char *md);

int MD5_Init(MD5_CTX *c);
int MD5_Update(MD5_CTX *c, const void *data, unsigned long len);
int MD5_Final(unsigned char *md, MD5_CTX *c);
unsigned char *MD5(const unsigned char *d, unsigned long n, unsigned char *md);

EVP_CIPHER_CTX *EVP_CIPHER_CTX_new();
int EVP_CIPHER_CTX_reset(EVP_CIPHER_CTX *ctx);
void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *ctx);

int EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type, ENGINE *impl,
                       unsigned char *key, unsigned char *iv);
int EVP_EncryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl, unsigned char *in,
                      int inl);
int EVP_EncryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl);

int EVP_DecryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type, ENGINE *impl,
                       unsigned char *key, unsigned char *iv);
int EVP_DecryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl, unsigned char *in,
                      int inl);
int EVP_DecryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *outm, int *outl);

int EVP_CipherInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type, ENGINE *impl, unsigned char *key,
                      unsigned char *iv, int enc);
int EVP_CipherUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl, unsigned char *in,
                     int inl);
int EVP_CipherFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *outm, int *outl);

int EVP_EncryptInit(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type, unsigned char *key,
                    unsigned char *iv);
int EVP_EncryptFinal(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl);

int EVP_DecryptInit(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type, unsigned char *key,
                    unsigned char *iv);
int EVP_DecryptFinal(EVP_CIPHER_CTX *ctx, unsigned char *outm, int *outl);

int EVP_CipherInit(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type, unsigned char *key,
                   unsigned char *iv, int enc);
int EVP_CipherFinal(EVP_CIPHER_CTX *ctx, unsigned char *outm, int *outl);

unsigned char *HMAC(const EVP_MD *evp_md, const void *key, int key_len, const unsigned char *d,
                    int n, unsigned char *md, unsigned int *md_len);

void HMAC_CTX_init(HMAC_CTX *ctx);

int HMAC_Init(HMAC_CTX *ctx, const void *key, int key_len, const EVP_MD *md);
int HMAC_Init_ex(HMAC_CTX *ctx, const void *key, int key_len, const EVP_MD *md, ENGINE *impl);
int HMAC_Update(HMAC_CTX *ctx, const unsigned char *data, int len);
int HMAC_Final(HMAC_CTX *ctx, unsigned char *md, unsigned int *len);
void HMAC_CTX_cleanup(HMAC_CTX *ctx);
void HMAC_cleanup(HMAC_CTX *ctx);

const EVP_MD *EVP_md_null();
const EVP_MD *EVP_md2();
const EVP_MD *EVP_md5();
const EVP_MD *EVP_sha1();

const EVP_CIPHER *EVP_aes_128_cbc();
const EVP_CIPHER *EVP_aes_128_ccm();
const EVP_CIPHER *EVP_aes_128_cfb64();
const EVP_CIPHER *EVP_aes_128_ecb();
const EVP_CIPHER *EVP_aes_128_gcm();
const EVP_CIPHER *EVP_aes_128_ocb();
const EVP_CIPHER *EVP_aes_128_ofb();
const EVP_CIPHER *EVP_aes_192_cbc();
const EVP_CIPHER *EVP_aes_192_ccm();
const EVP_CIPHER *EVP_aes_192_cfb64();
const EVP_CIPHER *EVP_aes_192_ecb();
const EVP_CIPHER *EVP_aes_192_gcm();
const EVP_CIPHER *EVP_aes_192_ocb();
const EVP_CIPHER *EVP_aes_192_ofb();
const EVP_CIPHER *EVP_aes_256_cbc();
const EVP_CIPHER *EVP_aes_256_ccm();
const EVP_CIPHER *EVP_aes_256_cfb64();
const EVP_CIPHER *EVP_aes_256_ecb();
const EVP_CIPHER *EVP_aes_256_gcm();
const EVP_CIPHER *EVP_aes_256_ocb();
const EVP_CIPHER *EVP_aes_256_ofb();
const EVP_CIPHER *EVP_bf_cbc();
const EVP_CIPHER *EVP_bf_cfb64();
const EVP_CIPHER *EVP_bf_ecb();
const EVP_CIPHER *EVP_bf_ofb();
const EVP_CIPHER *EVP_cast5_cbc();
const EVP_CIPHER *EVP_cast5_cfb64();
const EVP_CIPHER *EVP_cast5_ecb();
const EVP_CIPHER *EVP_cast5_ofb();
const EVP_CIPHER *EVP_des_cbc();
const EVP_CIPHER *EVP_des_cfb64();
const EVP_CIPHER *EVP_des_ecb();
const EVP_CIPHER *EVP_des_ede();
const EVP_CIPHER *EVP_des_ede3();
const EVP_CIPHER *EVP_des_ede3_cbc();
const EVP_CIPHER *EVP_des_ede3_cfb64();
const EVP_CIPHER *EVP_des_ede3_ofb();
const EVP_CIPHER *EVP_des_ede_cbc();
const EVP_CIPHER *EVP_des_ede_cfb64();
const EVP_CIPHER *EVP_des_ede_ofb();
const EVP_CIPHER *EVP_des_ofb();
const EVP_CIPHER *EVP_desx_cbc();
const EVP_CIPHER *EVP_enc_null();
const EVP_CIPHER *EVP_idea_cbc();
const EVP_CIPHER *EVP_idea_cfb64();
const EVP_CIPHER *EVP_idea_ecb();
const EVP_CIPHER *EVP_idea_ofb();
const EVP_CIPHER *EVP_rc2_40_cbc();
const EVP_CIPHER *EVP_rc2_64_cbc();
const EVP_CIPHER *EVP_rc2_cbc();
const EVP_CIPHER *EVP_rc2_cfb64();
const EVP_CIPHER *EVP_rc2_ecb();
const EVP_CIPHER *EVP_rc2_ofb();
const EVP_CIPHER *EVP_rc4();
const EVP_CIPHER *EVP_rc4_40();
const EVP_CIPHER *EVP_rc5_32_12_16_cbc();
const EVP_CIPHER *EVP_rc5_32_12_16_cfb64();
const EVP_CIPHER *EVP_rc5_32_12_16_ecb();
const EVP_CIPHER *EVP_rc5_32_12_16_ofb();

void
testHash()
{
    char string[] = "openssl";
    unsigned char digest1[SHA_DIGEST_LENGTH];
    unsigned char digest2[MD2_DIGEST_LENGTH];
    unsigned char digest4[MD4_DIGEST_LENGTH];
    unsigned char digest5[MD5_DIGEST_LENGTH];

    SHA1((unsigned char *)&string, strlen(string),
         (unsigned char *)&digest1); // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
                                     // expected-warning@-2{{OBJC_CRYPTO_BAD_HASH}}

    SHA_CTX ctx1;
    SHA1_Init(&ctx1); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    SHA1_Update(&ctx1, (unsigned char *)&string,
                strlen(string)); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    SHA1_Final(digest1, &ctx1);

    MD2((unsigned char *)&string, strlen(string),
        (unsigned char *)&digest2); // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
                                    // expected-warning@-2{{OBJC_CRYPTO_BAD_HASH}}

    MD2_CTX ctx2;
    MD2_Init(&ctx2); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    MD2_Update(&ctx2, (unsigned char *)&string,
               strlen(string)); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    MD2_Final(digest2, &ctx2);

    MD4((unsigned char *)&string, strlen(string),
        (unsigned char *)&digest4); // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
                                    // expected-warning@-2{{OBJC_CRYPTO_BAD_HASH}}

    MD4_CTX ctx4;
    MD4_Init(&ctx4);                           // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    MD4_Update(&ctx4, string, strlen(string)); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    MD4_Final(digest4, &ctx4);

    MD5((unsigned char *)&string, strlen(string),
        (unsigned char *)&digest5); // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
                                    // expected-warning@-2{{OBJC_CRYPTO_BAD_HASH}}

    MD5_CTX ctx5;
    MD5_Init(&ctx5);                           // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    MD5_Update(&ctx5, string, strlen(string)); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    MD5_Final(digest5, &ctx5);
}

void
testEncrypt()
{
    int len, plaintext_len;
    unsigned char *plaintext, *key, *iv, *ciphertext;
    EVP_CIPHER_CTX *ctx;

    if (!(ctx = EVP_CIPHER_CTX_new()))
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_ccm(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_cfb64(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_gcm(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_ocb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_ofb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_cbc(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_ccm(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_cfb64(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_gcm(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_ocb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_ofb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_ccm(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_cfb64(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_ocb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_ofb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_cast5_cbc(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_cast5_cfb64(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_cast5_ofb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_desx_cbc(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_idea_cbc(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_idea_cfb64(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_idea_ofb(), (void *)0, key, iv) != 1)
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_192_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_cast5_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_idea_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_bf_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_bf_cfb64(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_bf_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
           // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_bf_ofb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_cfb64(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
           // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede3(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede3_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede3_cfb64(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede3_ofb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede_cfb64(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ede_ofb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_des_ofb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_enc_null(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc2_40_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc2_64_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc2_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc2_cfb64(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc2_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
           // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc2_ofb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc4(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc4_40(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_cbc(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_cfb64(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_ecb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
           // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
        return;

    if (EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_ofb(), (void *)0, key, iv) !=
        1) // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
        return;

    if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len) != 1)
        return;

    if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1)
        return;

    EVP_CIPHER_CTX_free(ctx);

    EVP_EncryptInit_ex(ctx, EVP_aes_256_ocb(), (void *)0, key,
                       (void *)0); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
    EVP_DecryptInit_ex(ctx, EVP_aes_256_ocb(), (void *)0, key,
                       (void *)0); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
    EVP_CipherInit_ex(ctx, EVP_aes_256_ocb(), (void *)0, key, (void *)0,
                      0); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
    EVP_EncryptInit(ctx, EVP_aes_256_ocb(), key,
                    (void *)0); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
    EVP_DecryptInit(ctx, EVP_aes_256_ocb(), key,
                    (void *)0); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
    EVP_CipherInit(ctx, EVP_aes_256_ocb(), key, (void *)0,
                   0); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
}

void
testHmac()
{
    unsigned char key[1024];
    unsigned char buf[1024];
    unsigned char out[1024];

    HMAC(EVP_sha1(), key, sizeof(key), buf, sizeof(buf), (void *)0,
         (void *)0); // expected-warning@-1{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC(EVP_md_null(), key, sizeof(key), buf, sizeof(buf), (void *)0,
         (void *)0); // expected-warning@-1{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC(EVP_md2(), key, sizeof(key), buf, sizeof(buf), (void *)0,
         (void *)0); // expected-warning@-1{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC(EVP_md5(), key, sizeof(key), buf, sizeof(buf), (void *)0,
         (void *)0); // expected-warning@-1{{OBJC_CRYPTO_BAD_HMAC}}

    unsigned int len = 20;

    HMAC_CTX ctx;
    HMAC_CTX_init(&ctx);
    HMAC_Init(&ctx, key, sizeof(key), EVP_sha1()); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC_Update(&ctx, buf, sizeof(buf));
    HMAC_Final(&ctx, out, &len);
    HMAC_CTX_cleanup(&ctx);

    HMAC_CTX_init(&ctx);
    HMAC_Init(&ctx, key, sizeof(key), EVP_md_null()); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC_Update(&ctx, buf, sizeof(buf));
    HMAC_Final(&ctx, out, &len);
    HMAC_CTX_cleanup(&ctx);

    HMAC_CTX_init(&ctx);
    HMAC_Init(&ctx, key, sizeof(key), EVP_md2()); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC_Update(&ctx, buf, sizeof(buf));
    HMAC_Final(&ctx, out, &len);
    HMAC_CTX_cleanup(&ctx);

    HMAC_CTX_init(&ctx);
    HMAC_Init(&ctx, key, sizeof(key), EVP_md5()); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
    HMAC_Update(&ctx, buf, sizeof(buf));
    HMAC_Final(&ctx, out, &len);
    HMAC_CTX_cleanup(&ctx);
}
