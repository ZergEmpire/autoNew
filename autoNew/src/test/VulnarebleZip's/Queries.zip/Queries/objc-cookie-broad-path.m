// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef signed char BOOL;
typedef struct _NSZone NSZone;

@class NSInvocation, NSMethodSignature, NSCoder, NSString, NSEnumerator;

@protocol NSObject
@end

@protocol NSCopying
- (id)copyWithZone:(NSZone *)zone;
@end

@protocol NSMutableCopying
- (id)mutableCopyWithZone:(NSZone *)zone;
@end

@protocol NSCoding
- (void)encodeWithCoder:(NSCoder *)aCoder;
@end

@protocol NSSecureCoding <NSCoding>
@required
+ (BOOL)supportsSecureCoding;
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

typedef struct
{
} NSFastEnumerationState;

@protocol NSFastEnumeration
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state
                                  objects:(id[])buffer
                                    count:(NSUInteger)len;
@end

@interface NSNumber : NSObject
@end

@interface NSNumber (NSNumberCreation)
- (id)initWithChar:(char)value;
- (id)initWithUnsignedChar:(unsigned char)value;
- (id)initWithShort:(short)value;
- (id)initWithUnsignedShort:(unsigned short)value;
- (id)initWithInt:(int)value;
- (id)initWithUnsignedInt:(unsigned int)value;
- (id)initWithLong:(long)value;
- (id)initWithUnsignedLong:(unsigned long)value;
- (id)initWithLongLong:(long long)value;
- (id)initWithUnsignedLongLong:(unsigned long long)value;
- (id)initWithFloat:(float)value;
- (id)initWithDouble:(double)value;
- (id)initWithBool:(BOOL)value;
- (id)initWithInteger:(NSInteger)value;
- (id)initWithUnsignedInteger:(NSUInteger)value;

+ (NSNumber *)numberWithChar:(char)value;
+ (NSNumber *)numberWithUnsignedChar:(unsigned char)value;
+ (NSNumber *)numberWithShort:(short)value;
+ (NSNumber *)numberWithUnsignedShort:(unsigned short)value;
+ (NSNumber *)numberWithInt:(int)value;
+ (NSNumber *)numberWithUnsignedInt:(unsigned int)value;
+ (NSNumber *)numberWithLong:(long)value;
+ (NSNumber *)numberWithUnsignedLong:(unsigned long)value;
+ (NSNumber *)numberWithLongLong:(long long)value;
+ (NSNumber *)numberWithUnsignedLongLong:(unsigned long long)value;
+ (NSNumber *)numberWithFloat:(float)value;
+ (NSNumber *)numberWithDouble:(double)value;
+ (NSNumber *)numberWithBool:(BOOL)value;
+ (NSNumber *)numberWithInteger:(NSInteger)value;
+ (NSNumber *)numberWithUnsignedInteger:(NSUInteger)value;
@end

@interface NSDictionary : NSObject <NSCopying, NSMutableCopying, NSSecureCoding, NSFastEnumeration>
- (NSUInteger)count;
- (id)objectForKey:(id)aKey;
- (NSEnumerator *)keyEnumerator;
- (id)objectForKeyedSubscript:(id)key;
+ (id)dictionaryWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
- (id)initWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
@end

@interface NSDictionary (NSDictionaryCreation)
+ (id)dictionary;
+ (id)dictionaryWithObject:(id)object forKey:(id)key;
+ (instancetype)dictionaryWithObjects:(const id[])objects
                              forKeys:(const id[])keys
                                count:(NSUInteger)cnt;
@end

@interface NSMutableDictionary : NSDictionary
- (void)removeObjectForKey:(id)aKey;
- (void)setObject:(id)anObject forKey:(id)aKey;
@end

@interface NSMutableDictionary (NSExtendedMutableDictionary)
- (void)addEntriesFromDictionary:(NSDictionary *)otherDictionary;
- (void)removeAllObjects;
- (void)setDictionary:(NSDictionary *)otherDictionary;
- (void)setObject:(id)obj forKeyedSubscript:(id)key;
@end

const NSString *NSHTTPCookieName;
const NSString *NSHTTPCookieValue;
const NSString *NSHTTPCookieOriginURL;
const NSString *NSHTTPCookieVersion;
const NSString *NSHTTPCookieDomain;
const NSString *NSHTTPCookiePath;
const NSString *NSHTTPCookieSecure;
const NSString *NSHTTPCookieExpires;
const NSString *NSHTTPCookieComment;
const NSString *NSHTTPCookieCommentURL;
const NSString *NSHTTPCookieDiscard;
const NSString *NSHTTPCookieMaximumAge;
const NSString *NSHTTPCookiePort;

void
testCookies()
{
    NSDictionary *c_cookies;
    NSMutableDictionary *cookies;

    [cookies setObject:@"/"
                forKey:NSHTTPCookiePath]; // expected-warning@-1{{OBJC_COOKIE_BROAD_PATH}}
                                          // expected-warning@-2{{OBJC_INCORRECT_FUNC_CALL}}
    [cookies setObject:@"/my/site" forKey:NSHTTPCookiePath];
    c_cookies = [[NSDictionary alloc]
        initWithObjectsAndKeys:@"/", NSHTTPCookiePath,
                               (void *)0]; // expected-warning@-2{{OBJC_COOKIE_BROAD_PATH}}
                                           // expected-warning@-3{{C_DEAD_STORE}}
    c_cookies = [[NSDictionary alloc]      // expected-warning{{C_DEAD_STORE}}
        initWithObjectsAndKeys:@"/my/site", NSHTTPCookiePath, (void *)0];
    c_cookies = [NSDictionary
        dictionaryWithObjectsAndKeys:@"/", NSHTTPCookiePath,
                                     (void *)0]; // expected-warning@-2{{OBJC_COOKIE_BROAD_PATH}}
                                                 // expected-warning@-3{{C_DEAD_STORE}}
    c_cookies = [NSDictionary                    // expected-warning{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:@"/my/site", NSHTTPCookiePath, (void *)0];
    c_cookies =
        @{(NSString *)NSHTTPCookiePath : @"/"}; // expected-warning{{OBJC_COOKIE_BROAD_PATH}}
                                                // expected-warning@-2{{C_DEAD_STORE}}
    c_cookies = @{(NSString *)NSHTTPCookiePath : @"/my/site"}; // expected-warning{{C_DEAD_STORE}}
}
