// RUN: iccheck -c %s

struct EVP_CIPHER_CTX
{};

struct EVP_CIPHER
{};

struct ENGINE
{};

const struct EVP_CIPHER *EVP_bf_cbc();
const struct EVP_CIPHER *EVP_bf_cfb();
const struct EVP_CIPHER *EVP_bf_cfb64();
const struct EVP_CIPHER *EVP_bf_ecb();
const struct EVP_CIPHER *EVP_bf_ofb();
const struct EVP_CIPHER *EVP_des_cbc();
const struct EVP_CIPHER *EVP_des_cfb();
const struct EVP_CIPHER *EVP_des_cfb1();
const struct EVP_CIPHER *EVP_des_cfb8();
const struct EVP_CIPHER *EVP_des_cfb64();
const struct EVP_CIPHER *EVP_des_ecb();
const struct EVP_CIPHER *EVP_des_ede();
const struct EVP_CIPHER *EVP_des_ede_cbc();
const struct EVP_CIPHER *EVP_des_ede_cfb();
const struct EVP_CIPHER *EVP_des_ede_cfb64();
const struct EVP_CIPHER *EVP_des_ede_ofb();
const struct EVP_CIPHER *EVP_des_ede3();
const struct EVP_CIPHER *EVP_des_ede3_cbc();
const struct EVP_CIPHER *EVP_des_ede3_cfb();
const struct EVP_CIPHER *EVP_des_ede3_cfb1();
const struct EVP_CIPHER *EVP_des_ede3_cfb8();
const struct EVP_CIPHER *EVP_des_ede3_cfb64();
const struct EVP_CIPHER *EVP_des_ede3_ofb();
const struct EVP_CIPHER *EVP_des_ofb();
const struct EVP_CIPHER *EVP_enc_null();
const struct EVP_CIPHER *EVP_rc2_cbc();
const struct EVP_CIPHER *EVP_rc2_ecb();
const struct EVP_CIPHER *EVP_rc2_ofb();
const struct EVP_CIPHER *EVP_rc2_cfb();
const struct EVP_CIPHER *EVP_rc2_cfb64();
const struct EVP_CIPHER *EVP_rc2_40_cbc();
const struct EVP_CIPHER *EVP_rc2_64_cbc();
const struct EVP_CIPHER *EVP_rc4();
const struct EVP_CIPHER *EVP_rc4_40();
const struct EVP_CIPHER *EVP_rc5_32_12_16_cbc();
const struct EVP_CIPHER *EVP_rc5_32_12_16_ecb();
const struct EVP_CIPHER *EVP_rc5_32_12_16_ofb();
const struct EVP_CIPHER *EVP_rc5_32_12_16_cfb();
const struct EVP_CIPHER *EVP_rc5_32_12_16_cfb64();

int EVP_EncryptInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                       struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_EncryptInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_EncryptInit_ex(ctx, EVP_bf_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
                                     // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_EncryptInit_ex(ctx, EVP_bf_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_bf_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_bf_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_bf_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit_ex(ctx, EVP_des_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_cfb1(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_cfb8(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3_cfb1(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3_cfb8(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ede3_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit_ex(ctx, EVP_enc_null(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit_ex(ctx, EVP_rc2_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_40_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_64_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit_ex(ctx, EVP_rc4(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc4_40(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
}

int EVP_DecryptInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                       struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_DecryptInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_DecryptInit_ex(ctx, EVP_bf_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
                                     // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_DecryptInit_ex(ctx, EVP_bf_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_bf_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_bf_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_bf_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit_ex(ctx, EVP_des_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_cfb1(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_cfb8(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3_cfb1(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3_cfb8(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ede3_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit_ex(ctx, EVP_enc_null(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit_ex(ctx, EVP_rc2_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_40_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_64_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit_ex(ctx, EVP_rc4(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc4_40(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit_ex(ctx, EVP_rc5_32_12_16_cbc(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc5_32_12_16_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc5_32_12_16_ofb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc5_32_12_16_cfb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc5_32_12_16_cfb64(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
}

int EVP_CipherInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                      struct ENGINE *impl, const unsigned char *key, const unsigned char *iv,
                      int enc);

void
test_EVP_CipherInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int enc;
    int result;

    result = EVP_CipherInit_ex(ctx, EVP_bf_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
                                     // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_CipherInit_ex(ctx, EVP_bf_cfb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_bf_cfb64(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_bf_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_bf_ofb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit_ex(ctx, EVP_des_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_cfb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_cfb1(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_cfb8(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_cfb64(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede_cfb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede_cfb64(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede_ofb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3_cfb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3_cfb1(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3_cfb8(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3_cfb64(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ede3_ofb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ofb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit_ex(ctx, EVP_enc_null(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit_ex(ctx, EVP_rc2_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_ofb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_cfb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_cfb64(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_40_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_64_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit_ex(ctx, EVP_rc4(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc4_40(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit_ex(ctx, EVP_rc5_32_12_16_cbc(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc5_32_12_16_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc5_32_12_16_ofb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc5_32_12_16_cfb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc5_32_12_16_cfb64(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
}

int EVP_EncryptInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                    const unsigned char *key, const unsigned char *iv);

void
test_EVP_EncryptInit()
{
    struct EVP_CIPHER_CTX *ctx;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_EncryptInit(ctx, EVP_bf_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_EncryptInit(ctx, EVP_bf_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_bf_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_bf_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_bf_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit(ctx, EVP_des_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_cfb1(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_cfb8(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3_cfb1(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3_cfb8(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ede3_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit(ctx, EVP_enc_null(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit(ctx, EVP_rc2_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_40_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_64_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit(ctx, EVP_rc4(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc4_40(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_EncryptInit(ctx, EVP_rc5_32_12_16_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc5_32_12_16_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc5_32_12_16_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc5_32_12_16_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc5_32_12_16_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
}

int EVP_DecryptInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                    const unsigned char *key, const unsigned char *iv);

void
test_EVP_DecryptInit()
{
    struct EVP_CIPHER_CTX *ctx;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_DecryptInit(ctx, EVP_bf_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_DecryptInit(ctx, EVP_bf_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_bf_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_bf_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_bf_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit(ctx, EVP_des_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_cfb1(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_cfb8(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3_cfb1(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3_cfb8(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ede3_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit(ctx, EVP_enc_null(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit(ctx, EVP_rc2_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_40_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_64_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit(ctx, EVP_rc4(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc4_40(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_DecryptInit(ctx, EVP_rc5_32_12_16_cbc(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc5_32_12_16_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc5_32_12_16_ofb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc5_32_12_16_cfb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc5_32_12_16_cfb64(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
}

int EVP_CipherInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                   const unsigned char *key, const unsigned char *iv, int enc);

void
test_EVP_CipherInit()
{
    struct EVP_CIPHER_CTX *ctx;
    unsigned char *key;
    unsigned char *iv;
    int enc;
    int result;

    result = EVP_CipherInit(ctx, EVP_bf_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_CipherInit(ctx, EVP_bf_cfb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_bf_cfb64(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_bf_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_bf_ofb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit(ctx, EVP_des_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_cfb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_cfb1(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_cfb8(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_cfb64(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede_cfb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede_cfb64(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede_ofb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3_cfb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3_cfb1(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3_cfb8(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3_cfb64(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ede3_ofb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ofb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit(ctx, EVP_enc_null(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit(ctx, EVP_rc2_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_ofb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_cfb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_cfb64(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_40_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_64_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit(ctx, EVP_rc4(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc4_40(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}

    result = EVP_CipherInit(ctx, EVP_rc5_32_12_16_cbc(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc5_32_12_16_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc5_32_12_16_ofb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc5_32_12_16_cfb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc5_32_12_16_cfb64(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
}
