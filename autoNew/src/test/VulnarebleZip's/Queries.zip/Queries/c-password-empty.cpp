// RUN: iccheck++ -c %s

#include "system-header-simulator-cxx.h"

int strcmp(const char *s1, const char *s2);

void
f()
{
    const char *passwords = "";          // expected-warning{{C_PASSWORD_EMPTY}}
    const wchar_t *PASSwordforall = L""; // expected-warning{{C_PASSWORD_EMPTY}}
    char passWORDforall[] = "";          // expected-warning{{C_PASSWORD_EMPTY}}
    const wchar_t Userpassword[] = L"";  // expected-warning{{C_PASSWORD_EMPTY}}
    const char32_t PPassword[] = U"";    // expected-warning{{C_PASSWORD_EMPTY}}
    strcmp(passwords, "");               // expected-warning{{C_PASSWORD_EMPTY}}
    std::string password_;
    password_ == "";                  // expected-warning{{C_PASSWORD_EMPTY}}
    "" == password_;                  // expected-warning{{C_PASSWORD_EMPTY}}
    password_ != "";                  // expected-warning{{C_PASSWORD_EMPTY}}
    "" != password_;                  // expected-warning{{C_PASSWORD_EMPTY}}
    const char32_t *password32 = U""; // expected-warning{{C_PASSWORD_EMPTY}}
}
