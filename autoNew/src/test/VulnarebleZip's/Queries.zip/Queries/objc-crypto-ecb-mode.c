// RUN: iccheck -c %s

struct EVP_CIPHER_CTX
{};

struct EVP_CIPHER
{};

struct ENGINE
{};

const struct EVP_CIPHER *EVP_aes_128_ecb();
const struct EVP_CIPHER *EVP_aes_192_ecb();
const struct EVP_CIPHER *EVP_aes_256_ecb();
const struct EVP_CIPHER *EVP_bf_ecb();
const struct EVP_CIPHER *EVP_cast5_ecb();
const struct EVP_CIPHER *EVP_des_ecb();
const struct EVP_CIPHER *EVP_idea_ecb();
const struct EVP_CIPHER *EVP_rc2_ecb();
const struct EVP_CIPHER *EVP_rc5_32_12_16_ecb();

int EVP_EncryptInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                       struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_EncryptInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_EncryptInit_ex(ctx, EVP_aes_128_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
                                     // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_EncryptInit_ex(ctx, EVP_aes_192_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_aes_256_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_bf_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_cast5_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_des_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_idea_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc2_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit_ex(ctx, EVP_rc5_32_12_16_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
}

int EVP_DecryptInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                       struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_DecryptInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_DecryptInit_ex(ctx, EVP_aes_128_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
                                     // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_DecryptInit_ex(ctx, EVP_aes_192_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_aes_256_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_bf_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_cast5_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_des_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_idea_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc2_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit_ex(ctx, EVP_rc5_32_12_16_ecb(), impl, key,
                                iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
}

int EVP_CipherInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                      struct ENGINE *impl, const unsigned char *key, const unsigned char *iv,
                      int enc);

void
test_EVP_CipherInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int enc;
    int result;

    result = EVP_CipherInit_ex(ctx, EVP_aes_128_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
                                     // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_CipherInit_ex(ctx, EVP_aes_192_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_aes_256_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_bf_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_cast5_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_des_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_idea_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc2_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit_ex(ctx, EVP_rc5_32_12_16_ecb(), impl, key, iv,
                               enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                     // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                     // expected-warning@-3{{C_DEAD_STORE}}
}

int EVP_EncryptInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                    const unsigned char *key, const unsigned char *iv);

void
test_EVP_EncryptInit()
{
    struct EVP_CIPHER_CTX *ctx;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_EncryptInit(ctx, EVP_aes_128_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_EncryptInit(ctx, EVP_aes_192_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_aes_256_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_bf_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_cast5_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_des_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_idea_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc2_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_EncryptInit(ctx, EVP_rc5_32_12_16_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
}

int EVP_DecryptInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                    const unsigned char *key, const unsigned char *iv);

void
test_EVP_DecryptInit()
{
    struct EVP_CIPHER_CTX *ctx;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_DecryptInit(ctx, EVP_aes_128_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_DecryptInit(ctx, EVP_aes_192_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_aes_256_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_bf_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_cast5_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_des_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_idea_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc2_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_DecryptInit(ctx, EVP_rc5_32_12_16_ecb(), key,
                             iv); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
}

int EVP_CipherInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                   const unsigned char *key, const unsigned char *iv, int enc);

void
test_EVP_CipherInit()
{
    struct EVP_CIPHER_CTX *ctx;
    unsigned char *key;
    unsigned char *iv;
    int enc;
    int result;

    result = EVP_CipherInit(ctx, EVP_aes_128_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
                                  // expected-warning@-3{{C_INCORRECT_FUNC_CALL}}
    result = EVP_CipherInit(ctx, EVP_aes_192_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_aes_256_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_bf_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_cast5_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_des_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_idea_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc2_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
    result = EVP_CipherInit(ctx, EVP_rc5_32_12_16_ecb(), key, iv,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                  // expected-warning@-2{{OBJC_CRYPTO_ECB_MODE}}
                                  // expected-warning@-3{{C_DEAD_STORE}}
}
