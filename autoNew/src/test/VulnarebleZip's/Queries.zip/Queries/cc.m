// RUN: iccheck -c %s
// XFAIL: *

#import "system-header-simulator-objc.h"

void
testHash()
{
    unsigned char md[16];
    unsigned char sha[20];
    unsigned char buf[1024];

    CC_SHA1_CTX context1;
    CC_SHA1_Init(&context1);
    CC_SHA1_Update(&context1, buf, sizeof(buf));
    CC_SHA1_Final(sha, &context1);
    CC_SHA1(buf, sizeof(buf), sha);

    CC_MD2_CTX context2;
    CC_MD2_Init(&context2);
    CC_MD2_Update(&context2, buf, sizeof(buf));
    CC_MD2_Final(md, &context2);
    CC_MD2(buf, sizeof(buf), md);

    CC_MD4_CTX context4;
    CC_MD4_Init(&context4);
    CC_MD4_Update(&context4, buf, sizeof(buf));
    CC_MD4_Final(md, &context4);
    CC_MD4(buf, sizeof(buf), md);

    CC_MD5_CTX context5;
    CC_MD5_Init(&context5);
    CC_MD5_Update(&context5, buf, sizeof(buf));
    CC_MD5_Final(md, &context5);
    CC_MD5(buf, sizeof(buf), md);
}

void
testEncrypt()
{
    CCCryptorRef cryptor;

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES, 0,
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES, 0,
                            0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES, 0, 0, 0, 0, 0, 0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES, 0,
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES,
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES, 0, 0, 0, 0, 0,
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2, 0,
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2,
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2, 0, 0, 0, 0, 0,
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4, 0,
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4,
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4, 0, 0, 0, 0, 0,
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128, 0,
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128,
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128, 0, 0, 0, 0, 0,
            0);
}

void
testHmac()
{
    unsigned char key[1024];
    unsigned char buf[1024];
    unsigned char out[1024];

    CCHmac(kCCHmacAlgSHA1, key, sizeof(key), buf, sizeof(buf), out);

    CCHmac(kCCHmacAlgMD5, key, sizeof(key), buf, sizeof(buf), out);

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA1, key, sizeof(key));
    CCHmacUpdate(&context, buf, sizeof(buf));
    CCHmacFinal(&context, out);

    CCHmacInit(&context, kCCHmacAlgMD5, key, sizeof(key));
    CCHmacUpdate(&context, buf, sizeof(buf));
    CCHmacFinal(&context, out);
}

void
testKey()
{
    const char *dataIn = "Data";
    char dataOut[512];
    unsigned int numBytesEncrypted;
    unsigned char out[1024];

    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "hardcoded", 9, (void *)0,
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut), &numBytesEncrypted);
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "", 0, (void *)0, dataIn,
            sizeof(dataIn), dataOut, sizeof(dataOut), &numBytesEncrypted);
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "still_empty", 0, (void *)0,
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut), &numBytesEncrypted);
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, (void *)0, 0, (void *)0, dataIn,
            sizeof(dataIn), dataOut, sizeof(dataOut), &numBytesEncrypted);

    NSString *encryptionKey = @"hardcoded";
    NSString *encryptKey = @"";
    NSString *passPhrase = (void *)0;

    CCHmac(kCCHmacAlgSHA256, "hardcoded", 9, dataOut, sizeof(dataOut), out);
    CCHmac(kCCHmacAlgSHA256, "", 0, dataOut, sizeof(dataOut), out);
    CCHmac(kCCHmacAlgSHA256, "still_empty", 0, dataOut, sizeof(dataOut), out);
    CCHmac(kCCHmacAlgSHA256, (void *)0, 0, dataOut, sizeof(dataOut), out);

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA256, "hardcoded", 3);
    CCHmacInit(&context, kCCHmacAlgSHA256, "", 0);
    CCHmacInit(&context, kCCHmacAlgSHA256, "still_empty", 0);
    CCHmacInit(&context, kCCHmacAlgSHA256, (void *)0, 0);

    if ([encryptionKey isEqualToString:@"hardcoded"]) {
    }
    if ([encryptKey isEqualToString:@""]) {
    }

    NSData *salt = [@"salt" dataUsingEncoding:NSUTF8StringEncoding];
    unsigned int rounds = 2048;
    unsigned int keySize = kCCKeySizeAES128;

    NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
    NSData *keyData = [@"hardcoded" dataUsingEncoding:NSUTF8StringEncoding];
    CCKeyDerivationPBKDF(kCCPBKDF2, keyData.bytes, 0, salt.bytes, salt.length, kCCPRFHmacAlgSHA1,
                         rounds, derivedKey.mutableBytes, derivedKey.length);
    CCKeyDerivationPBKDF(kCCPBKDF2, "", 0, salt.bytes, salt.length, kCCPRFHmacAlgSHA1, rounds,
                         derivedKey.mutableBytes, derivedKey.length);
    CCKeyDerivationPBKDF(kCCPBKDF2, "still_empty", 0, salt.bytes, salt.length, kCCPRFHmacAlgSHA1,
                         rounds, derivedKey.mutableBytes, derivedKey.length);
    CCKeyDerivationPBKDF(kCCPBKDF2, (void *)0, 0, salt.bytes, salt.length, kCCPRFHmacAlgSHA1,
                         rounds, derivedKey.mutableBytes, derivedKey.length);
}

void
testPassword()
{
    NSString *password = @"hardcoded";
    NSString *mypassword = @"";
    NSString *db_password = (void *)0;
}
