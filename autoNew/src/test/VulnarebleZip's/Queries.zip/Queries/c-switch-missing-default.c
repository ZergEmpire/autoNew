// RUN: iccheck -c %s

void
f_without_default()
{
    int x = 5;
    switch (x) { // expected-warning{{C_SWITCH_MISSING_DEFAULT}}
    case 3:
        break;
    }
}

void
f_with_default()
{
    int x = 5;
    switch (x) {
    case 3:
        break;
    default:
        break;
    }
}