typedef struct CC_MD2state_st
{
} CC_MD2_CTX;

typedef struct CC_MD4state_st
{
} CC_MD4_CTX;

typedef struct CC_MD5state_st
{
} CC_MD5_CTX;

typedef struct CC_SHA1state_st
{
} CC_SHA1_CTX;

typedef struct _CCCryptor *CCCryptorRef;

enum
{
    kCCSuccess,
    kCCParamError,
    kCCBufferTooSmall,
    kCCMemoryFailure,
    kCCAlignmentError,
    kCCDecodeError,
    kCCUnimplemented
};
typedef int CCCryptorStatus;

enum
{
    kCCEncrypt,
    kCCDecrypt,
};
typedef unsigned int CCOperation;

enum
{
    kCCAlgorithmAES128,
    kCCAlgorithmDES,
    kCCAlgorithm3DES,
    kCCAlgorithmCAST,
    kCCAlgorithmRC4,
    kCCAlgorithmRC2
};
typedef unsigned int CCAlgorithm;

enum
{
    kCCOptionPKCS7Padding,
    kCCOptionECBMode
};
typedef unsigned int CCOptions;

enum
{
    kCCKeySizeAES128,
    kCCKeySizeAES192,
    kCCKeySizeAES256,
    kCCKeySizeDES,
    kCCKeySize3DES,
    kCCKeySizeMinCAST,
    kCCKeySizeMaxCAST,
    kCCKeySizeMinRC4,
    kCCKeySizeMaxRC4,
    kCCKeySizeMinRC2,
    kCCKeySizeMaxRC2
};

enum
{
    kCCBlockSizeAES128,
    kCCBlockSizeDES,
    kCCBlockSize3DES,
    kCCBlockSizeCAST,
    kCCBlockSizeMaxRC2,
};

enum
{
    kCCContextSizeAES128,
    kCCContextSizeDES,
    kCCContextSize3DES,
    kCCContextSizeCAST,
    kCCContextSizeMaxRC4
};

enum
{
    kCCHmacAlgSHA1,
    kCCHmacAlgMD5,
    kCCHmacAlgSHA256,
    kCCHmacAlgSHA384,
    kCCHmacAlgSHA512,
    kCCHmacAlgSHA224
};
typedef unsigned int CCHmacAlgorithm;

enum
{
    kCCPBKDF2,
};

enum
{
    kCCPRFHmacAlgSHA1,
    kCCPRFHmacAlgSHA224,
    kCCPRFHmacAlgSHA256,
    kCCPRFHmacAlgSHA384,
    kCCPRFHmacAlgSHA512
};

enum
{
    NSUTF8StringEncoding
};

typedef struct
{
} CCHmacContext;

int CC_MD2_Init(CC_MD2_CTX *c);
int CC_MD2_Update(CC_MD2_CTX *c, const void *data, unsigned int len);
int CC_MD2_Final(unsigned char *md, CC_MD2_CTX *c);
unsigned char *CC_MD2(const void *data, unsigned int len, unsigned char *md);
int CC_MD4_Init(CC_MD4_CTX *c);
int CC_MD4_Update(CC_MD4_CTX *c, const void *data, unsigned int len);
int CC_MD4_Final(unsigned char *md, CC_MD4_CTX *c);
unsigned char *CC_MD4(const void *data, unsigned int len, unsigned char *md);
int CC_MD5_Init(CC_MD5_CTX *c);
int CC_MD5_Update(CC_MD5_CTX *c, const void *data, unsigned int len);
int CC_MD5_Final(unsigned char *md, CC_MD5_CTX *c);
unsigned char *CC_MD5(const void *data, unsigned int len, unsigned char *md);
int CC_SHA1_Init(CC_SHA1_CTX *c);
int CC_SHA1_Update(CC_SHA1_CTX *c, const void *data, unsigned int len);
int CC_SHA1_Final(unsigned char *md, CC_SHA1_CTX *c);
unsigned char *CC_SHA1(const void *data, unsigned int len, unsigned char *md);

CCCryptorStatus CCCryptorCreate(CCOperation op, CCAlgorithm alg, CCOptions options, const void *key,
                                unsigned int keyLength, const void *iv, CCCryptorRef *cryptorRef);
CCCryptorStatus CCCryptorCreateFromData(CCOperation op, CCAlgorithm alg, CCOptions options,
                                        const void *key, unsigned int keyLength, const void *iv,
                                        const void *data, unsigned int dataLength,
                                        CCCryptorRef *cryptorRef, unsigned int *dataUsed);
CCCryptorStatus CCCrypt(CCOperation op, CCAlgorithm alg, CCOptions options, const void *key,
                        unsigned int keyLength, const void *iv, const void *dataIn,
                        unsigned int dataInLength, void *dataOut, unsigned int dataOutAvailable,
                        unsigned int *dataOutMoved);

void CCHmacInit(CCHmacContext *ctx, CCHmacAlgorithm algorithm, const void *key,
                unsigned int keyLength);
void CCHmacUpdate(CCHmacContext *ctx, const void *data, unsigned int dataLength);
void CCHmacFinal(CCHmacContext *ctx, void *macOut);
void CCHmac(CCHmacAlgorithm algorithm, const void *key, unsigned int keyLength, const void *data,
            unsigned int dataLength, void *macOut);
