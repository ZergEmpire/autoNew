// RUN: iccheck++ -c %s

void
f()
{
    unsigned char *passwords = nullptr; // expected-warning{{C_PASSWORD_NULL}}
    wchar_t *PASSwordforall = __null;   // expected-warning{{C_PASSWORD_NULL}}
    char *passWORDforall = (char *)0;   // expected-warning{{C_PASSWORD_NULL}}
                                        // expected-warning@-1{{OBJC_PASSWORD_NULL}}
    char *Userpassword = 0;             // expected-warning{{C_PASSWORD_NULL}}
}
