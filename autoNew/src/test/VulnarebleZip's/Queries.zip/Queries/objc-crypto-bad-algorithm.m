// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
testEncrypt()
{
    CCCryptorRef cryptor;

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES,
                            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES, 0, 0, 0, 0, 0,
            0); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}

    CCCryptorCreate(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0,
                            kCCKeySize3DES, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                            // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                            // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0,
                            kCCKeySizeMaxRC2, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                              // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                              // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0,
                            kCCKeySizeMaxRC4, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                              // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                              // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);
}
