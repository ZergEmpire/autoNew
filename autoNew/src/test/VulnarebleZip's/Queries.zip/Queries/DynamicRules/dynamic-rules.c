// RUN: iccheck -c %s

void f(char *a, int b);

void bind() {
    char buf[10];
    f(buf, 1);
    f(buf, 18); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
}
