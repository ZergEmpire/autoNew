// RUN: iccheck -c %s

#include "system-header-simulator-c.h"

int random_func(const char *format, ...);

void
test_to_not_pass()
{
    const char *format;
    char *buffer;
    size_t buf_size;
    printf(format);                     // expected-warning{{C_FORMAT_STRING}}
                                        // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    scanf(format);                      // expected-warning{{C_FORMAT_STRING}}
                                        // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
    sprintf(buffer, format);            // expected-warning{{C_FORMAT_STRING}}
                                        // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
    snprintf(buffer, buf_size, format); // expected-warning{{C_FORMAT_STRING}}
                                        // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
}

void
test_to_pass()
{
    int x;
    char *buffer;
    size_t buf_size;
    printf("format_str");
    scanf("format_str %d", &x);               // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    sprintf(buffer, "format_str");            // expected-warning{{C_INCORRECT_FUNC_CALL}}
                                              // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}
    snprintf(buffer, buf_size, "format_str"); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
}
