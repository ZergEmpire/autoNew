// RUN: iccheck -fblocks -c %s

#define YES __objc_yes
#define NO __objc_no

typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef signed char BOOL;
typedef struct _NSZone NSZone;

@class NSURL, NSDictionary;

@interface UIApplication
@property(nonatomic, readonly) UIApplication *sharedApplication;
- (BOOL)openURL:(NSURL *)url;
- (void)openURL:(NSURL *)url
              options:(NSDictionary *)options
    completionHandler:(void (^)(BOOL success))completion;
@end

void
testOpenUrl()
{
    NSURL *url;
    NSDictionary *options;

    [[UIApplication sharedApplication]
        openURL:url]; // expected-warning@-1{{OBJC_OPENURL}}
                      // expected-warning@-2{{OBJC_INCORRECT_FUNC_CALL}}
    [[UIApplication sharedApplication] openURL:url // expected-warning{{OBJC_OPENURL}}
                                       options:options
                             completionHandler:^(BOOL success){
                             }];
}
