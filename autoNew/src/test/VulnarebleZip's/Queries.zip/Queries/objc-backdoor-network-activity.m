// RUN: iccheck -c %s

@class NSString;

const char *s1 = "https://example.com"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s2 = "use http:// pfx to trigger checker";
const char *s3 = "https://[::1]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s4 =
    "https://[1762:0:0:0:0:B03:1:AF18]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s5 =
    "https://[fe80::219:7eff:fe46:6c42]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s6 =
    "https://[::00:192.168.10.184]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s7 =
    "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s8 = "https://localhost"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

const char *s12 = "ftp://example.com"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s13 = "use ftp:// pfx to trigger checker";
const char *s14 = "ftp://[::1]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s15 =
    "ftp://[1762:0:0:0:0:B03:1:AF18]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s16 =
    "ftp://[fe80::219:7eff:fe46:6c42]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s17 =
    "ftp://[::00:192.168.10.184]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s18 =
    "ftp://[2001:0db8:0000:0000:0000:ff00:0042:8329]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s19 = "ftp://localhost"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

const char *s20 = "ftps://example.com"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s21 = "use ftps:// pfx to trigger checker";
const char *s22 = "ftps://[::1]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s23 =
    "ftps://[1762:0:0:0:0:B03:1:AF18]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s24 =
    "ftps://[fe80::219:7eff:fe46:6c42]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s25 =
    "ftps://[::00:192.168.10.184]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s26 =
    "ftps://[2001:0db8:0000:0000:0000:ff00:0042:8329]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s27 = "ftps://localhost"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

const char *s28 = "ldap://example.com"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s29 = "use ldap:// pfx to trigger checker";
const char *s30 = "ldap://[::1]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s31 =
    "ldap://[1762:0:0:0:0:B03:1:AF18]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s32 =
    "ldap://[fe80::219:7eff:fe46:6c42]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s33 =
    "ldap://[::00:192.168.10.184]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s34 =
    "ldap://[2001:0db8:0000:0000:0000:ff00:0042:8329]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s35 = "ldap://localhost"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

const char *s36 = "telnet://example.com"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s37 = "use telnet:// pfx to trigger checker";
const char *s38 = "telnet://[::1]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s39 =
    "telnet://[1762:0:0:0:0:B03:1:AF18]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s40 =
    "telnet://[fe80::219:7eff:fe46:6c42]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s41 =
    "telnet://[::00:192.168.10.184]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s42 =
    "telnet://[2001:0db8:0000:0000:0000:ff00:0042:8329]"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s43 = "telnet://localhost"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

void foo(const char *s);
void bar(NSString *s);

void
testNetworkBackdoor()
{
    static const char *s9 =
        "https://example.com/suh";            // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    NSString *s10 = @"https://s.example.com"; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    NSString *s11 = @"https://127.0.0.1";     // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

    foo("https://example.org");      // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    bar(@"https://example.org/sub"); // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
}
