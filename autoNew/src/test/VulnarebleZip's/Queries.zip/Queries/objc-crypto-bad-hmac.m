// RUN: iccheck -c %s

#import "system-header-simulator-osx.h"

void
testHmac()
{
    unsigned char key[1024];
    unsigned char buf[1024];
    unsigned char out[1024];

    CCHmac(kCCHmacAlgSHA1, // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
            key, sizeof(key), buf, sizeof(buf), out);

    CCHmac(kCCHmacAlgMD5, // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
            key,          // expected-warning@-1{{OBJC_CRYPTO_KEY_REUSED}}
            sizeof(key), buf, sizeof(buf), out);

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA1, // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
            key,                         // expected-warning@-1{{OBJC_CRYPTO_KEY_REUSED}}
            sizeof(key));
    CCHmacUpdate(&context, buf, sizeof(buf));
    CCHmacFinal(&context, out);

    CCHmacInit(&context, kCCHmacAlgMD5, // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
            key,                        // expected-warning@-1{{OBJC_CRYPTO_KEY_REUSED}}
            sizeof(key));
    CCHmacUpdate(&context, buf, sizeof(buf));
    CCHmacFinal(&context, out);
}
