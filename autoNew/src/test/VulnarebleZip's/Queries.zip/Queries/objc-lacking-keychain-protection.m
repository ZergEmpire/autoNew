// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
test_keychain()
{
    NSString *kSecClassGenericPassword = @"kSec"; // expected-warning{{OBJC_PASSWORD_HARDCODED}}
    NSString *kSecClass = @"kSec";
    NSString *kSecValueData = @"kSec";
    NSString *kSecAttrAccessibleAlways = @"kSec";
    NSString *kSecAttrAccessible = @"kSec";
    NSString *kSecAttrAccessibleAlwaysThisDeviceOnly = @"kSec";
    NSString *kSecAttrAccessibleAfterFirstUnlock = @"kSec";
    NSString *kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly = @"kSec";

    NSMutableDictionary *dict = [NSMutableDictionary dictionary];

    [dict setObject: // expected-warning{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAlways
             forKey:(__bridge id)kSecAttrAccessible];
    [dict setObject: // expected-warning{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAlways
             forKey:(__bridge id)kSecAttrAccessible];
    [dict
        setObject:
            (__bridge id)
                kSecAttrAccessibleAlwaysThisDeviceOnly // expected-warning@-3{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
           forKey:(__bridge id)kSecAttrAccessible];
    [dict
        setObject:
            (__bridge id)
                kSecAttrAccessibleAfterFirstUnlock // expected-warning@-3{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
           forKey:(__bridge id)kSecAttrAccessible];
    [dict
        setObject:
            (__bridge id)
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly // expected-warning@-3{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
           forKey:(__bridge id)kSecAttrAccessible];

    [dict dictionaryWithObjectsAndKeys:
              (__bridge id)
                  kSecAttrAccessible, // expected-warning@-2{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAlways, nil];
    [dict dictionaryWithObjectsAndKeys:
              (__bridge id)
                  kSecAttrAccessible, // expected-warning@-2{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAlways, nil];
    [dict dictionaryWithObjectsAndKeys:
              (__bridge id)
                  kSecAttrAccessible, // expected-warning@-2{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAlwaysThisDeviceOnly, nil];
    [dict dictionaryWithObjectsAndKeys:
              (__bridge id)
                  kSecAttrAccessible, // expected-warning@-2{{OBJC_LACKING_FILE_PROTECTION}}
                                      // expected-warning@-3{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
              (__bridge id)kSecAttrAccessibleAfterFirstUnlock, nil];
    [dict // expected-warning{{OBJC_LACKING_FILE_PROTECTION}}
          // expected-warning@-1{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
        dictionaryWithObjectsAndKeys:(__bridge id)kSecAttrAccessible,
                                     (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
                                     nil];

    [dict // expected-warning{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
        dictionaryWithObject:(__bridge id)kSecAttrAccessibleAlways
                      forKey:(__bridge id)kSecAttrAccessible];
    [dict // expected-warning{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
        dictionaryWithObject:(__bridge id)kSecAttrAccessibleAlways
                      forKey:(__bridge id)kSecAttrAccessible];
    [dict
        dictionaryWithObject:
            (__bridge id)
                kSecAttrAccessibleAlwaysThisDeviceOnly // expected-warning@-3{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
                      forKey:(__bridge id)kSecAttrAccessible];
    [dict
        dictionaryWithObject:
            (__bridge id)
                kSecAttrAccessibleAfterFirstUnlock // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
                                                   // expected-warning@-4{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
                      forKey:(__bridge id)kSecAttrAccessible];
    [dict
        dictionaryWithObject:
            (__bridge id)
                kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly // expected-warning@-3{{OBJC_LACKING_FILE_PROTECTION}}
                                                                 // expected-warning@-4{{OBJC_LACKING_KEYCHAIN_PROTECTION}}
                      forKey:(__bridge id)kSecAttrAccessible];
}
