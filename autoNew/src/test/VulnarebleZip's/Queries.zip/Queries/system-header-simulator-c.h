#define NULL 0

typedef int pid_t;
typedef struct _IO_FILE FILE;
typedef __typeof(sizeof(int)) size_t;
typedef unsigned wchar_t;
typedef int guint32;

int atoi(const char *str);
long atol(const char *str);
char *fgets(char *str, int count, FILE *stream);
FILE *fopen(const char *path, const char *mode);
FILE *popen(const char *command, const char *type);
char *strncpy(char *dest, const char *src, size_t count);
size_t strnlen(const char *str);
int system(const char *command);
int _wsystem(const wchar_t *command);

int spawnl(int mode, char *path, const char *arg0, ...);
int spawnle(int mode, char *file, const char *arg0, ...);
int spawnlp(int mode, char *file, const char *arg0, ...);
int spawnv(int mode, char *path, char *const argv[]);
int spawnvp(int mode, char *file, char *const argv[]);
int spawnlpe(int mode, char *file, const char *arg0, ...);
int spawnvpe(int mode, char *file, char *const arg[], char *const envp[]);
int spawnve(int mode, char *file, char *const arg[], char *const envp[]);
int _wspawnl(int mode, wchar_t *path, const wchar_t *arg0, ...);
int _wspawnle(int mode, wchar_t *file, const wchar_t *arg0, ...);
int _wspawnlp(int mode, wchar_t *file, const wchar_t *arg0, ...);
int _wspawnv(int mode, wchar_t *path, wchar_t *const argv[]);
int _wspawnvp(int mode, wchar_t *file, wchar_t *const argv[]);
int _wspawnlpe(int mode, wchar_t *file, const wchar_t *arg0, ...);
int _wspawnvpe(int mode, wchar_t *file, wchar_t *const arg[], wchar_t *const envp[]);
int _wspawnve(int mode, wchar_t *file, wchar_t *const arg[], wchar_t *const envp[]);

int execl(const char *path, const char *arg0, ...);
int execle(const char *path, const char *arg0, ...);
int execlp(const char *file, const char *arg0, ...);
int execlpe(const char *file, const char *arg0, ...);
int _wexecl(const wchar_t *path, const wchar_t *arg0, ...);
int _wexecle(const wchar_t *path, const wchar_t *arg0, ...);
int _wexeclp(const wchar_t *file, const wchar_t *arg0, ...);
int _wexeclpe(const wchar_t *file, const wchar_t *arg0, ...);

int execv(const char *path, char *const argv[]);
int execve(const char *path, char *const argv[], char *const envp[]);
int execvp(const char *file, char *const argv[]);
int execvpe(const char *file, char *const argv[], char *const envp[]);
int _wexecv(const wchar_t *path, wchar_t *const argv[]);
int _wexecve(const wchar_t *path, wchar_t *const argv[], wchar_t *const envp[]);
int _wexecvp(const wchar_t *file, wchar_t *const argv[]);
int _wexecvpe(const wchar_t *file, wchar_t *const argv[], wchar_t *const envp[]);

int _texecl(const char *path, const char *arg0, ...);
int _texecle(const char *path, const char *arg0, ...);
int _texeclp(const char *file, const char *arg0, ...);
int _texeclpe(const char *file, const char *arg0, ...);

int _texecv(const char *path, char *const argv[]);
int _texecve(const char *path, char *const argv[], char *const envp[]);
int _texecvp(const char *file, char *const argv[]);
int _texecvpe(const char *file, char *const argv[], char *const envp[]);