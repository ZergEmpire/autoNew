// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef signed char BOOL;

struct xmlDoc;
typedef xmlDoc *xmlDocPtr; // expected-error{{must use 'struct' tag to refer to type 'xmlDoc'}}

xmlDocPtr xmlParseMemory(const char *buffer, int size);

@interface NSXMLParser
@property BOOL shouldResolveExternalEntities;
@end

void
testXXE()
{
    NSXMLParser *parser;
    [parser setShouldResolveExternalEntities:YES]; // expected-warning{{OBJC_INJECTION_XXE}}

    const char buffer[10];
    xmlParseMemory(buffer, 10); // expected-warning{{OBJC_INJECTION_XXE}}
}
