// RUN: iccheck -c %s

@class NSString;

const char *s1 = "http://example.com"; // expected-warning{{OBJC_HTTP_USAGE}}
                                       // expected-warning@-1{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
const char *s2 = "use http:// pfx to trigger checker";

void foo(const char *s);
void bar(NSString *s);

void
testUnsafeProtocol()
{
    static const char *s3 =
        "http://example.com/suh";           // expected-warning{{OBJC_HTTP_USAGE}}
                                            // expected-warning@-1{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    NSString *s4 = @"http://s.example.com"; // expected-warning{{OBJC_HTTP_USAGE}}
                                            // expected-warning@-1{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

    foo("http://example.org");      // expected-warning{{OBJC_HTTP_USAGE}}
                                    // expected-warning@-1{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    bar(@"http://example.org/sub"); // expected-warning{{OBJC_HTTP_USAGE}}
                                    // expected-warning@-1{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
}
