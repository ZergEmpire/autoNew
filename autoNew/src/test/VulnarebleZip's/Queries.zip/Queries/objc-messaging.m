// RUN: iccheck -c %s

typedef unsigned long NSUInteger;

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface NSArray : NSObject
@end

@interface NSArray (NSArrayCreation)
+ (instancetype)arrayWithObjects:(const id[])objects count:(NSUInteger)cnt;
@end

@interface MFMessageComposeViewController : NSObject
@property(nonatomic, copy) NSArray *recipients;
@end

void
testMessaging()
{
    MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
    NSArray *recipents = @[ @"12345678", @"72345524" ];
    [picker setRecipients:recipents]; // expected-warning{{OBJC_MESSAGING}}
} // expected-warning{{OBJC_MEMORY_LEAK}}
