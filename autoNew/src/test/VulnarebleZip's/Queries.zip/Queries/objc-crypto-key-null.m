// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
testEncrypt()
{
    CCCryptorRef cryptor;

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES,
                            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmDES, kCCOptionPKCS7Padding, 0, kCCKeySizeDES, 0, 0, 0, 0, 0,
            0); // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}

    CCCryptorCreate(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0,
                            kCCKeySize3DES, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                            // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                            // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithm3DES, kCCOptionPKCS7Padding, 0, kCCKeySize3DES, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0,
                            kCCKeySizeMaxRC2, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                              // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                              // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmRC2, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC2, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4,
                    0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0,
                            kCCKeySizeMaxRC4, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
                                              // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                              // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmRC4, kCCOptionPKCS7Padding, 0, kCCKeySizeMaxRC4, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_BAD_ALGORITHM}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);

    CCCryptorCreate(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128,
                    0, // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                       // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                       // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                    &cryptor);
    CCCryptorCreateFromData(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0,
                            kCCKeySizeAES128, // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
                                              // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
                                              // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
                            0, 0, 0, &cryptor, 0);
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionECBMode, 0, kCCKeySizeAES128, 0, 0, 0, 0,
            0, // expected-warning@-1{{OBJC_CRYPTO_ECB_MODE}}
               // expected-warning@-2{{OBJC_CRYPTO_KEY_NULL}}
               // expected-warning@-3{{OBJC_CRYPTO_NULL_IV}}
            0);
}

void
testKey()
{
    const char *dataIn = "Data";
    char dataOut[512];
    unsigned int numBytesEncrypted;
    unsigned char out[1024];

    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, (void *)0, 0, (void *)0,
            dataIn, // expected-warning@-1{{OBJC_CRYPTO_KEY_NULL}}
                    // expected-warning@-2{{OBJC_CRYPTO_NULL_IV}}
            sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}

    NSString *passPhrase = (void *)0; // expected-warning{{OBJC_CRYPTO_KEY_NULL}}

    CCHmac(kCCHmacAlgSHA256, (void *)0, 0, dataOut, sizeof(dataOut),
           out); // expected-warning@-1{{OBJC_CRYPTO_KEY_NULL}}

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA256, (void *)0,
               0); // expected-warning@-1{{OBJC_CRYPTO_KEY_NULL}}

    NSData *salt = [@"salt" dataUsingEncoding:NSUTF8StringEncoding];
    unsigned int rounds = 2048;
    unsigned int keySize = kCCKeySizeAES128;

    NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
    CCKeyDerivationPBKDF(kCCPBKDF2, (void *)0, 0, salt.bytes, salt.length,
                         kCCPRFHmacAlgSHA1, // expected-warning@-1{{OBJC_CRYPTO_KEY_NULL}}
                         rounds, derivedKey.mutableBytes, derivedKey.length);
}
