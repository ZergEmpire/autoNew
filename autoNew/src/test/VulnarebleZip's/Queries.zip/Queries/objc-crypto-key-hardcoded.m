// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
testKey()
{
    const char *dataIn = "Data";
    char dataOut[512];
    unsigned int numBytesEncrypted;
    unsigned char out[1024];

    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "hardcoded", 9,
            (void *)0, // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}
                       // expected-warning@-2{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "hardcoded", 9,
            (void *)0, // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}
                       // expected-warning@-2{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, "hardcoded", 9,
            (void *)0, // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}
                       // expected-warning@-2{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}

    NSString *encryptionKey = @"hardcoded"; // expected-warning{{OBJC_CRYPTO_KEY_HARDCODED}}

    CCHmac(kCCHmacAlgSHA256, "hardcoded", 9, dataOut, sizeof(dataOut),
           out); // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA256, "hardcoded",
               9); // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}

    if ([encryptionKey
            isEqualToString:@"hardcoded"]) { // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}
    }

    NSData *salt = [@"salt" dataUsingEncoding:NSUTF8StringEncoding];
    unsigned int rounds = 2048;
    unsigned int keySize = kCCKeySizeAES128;

    NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
    NSData *keyData = [@"hardcoded"
        dataUsingEncoding:NSUTF8StringEncoding]; // expected-warning@-1{{C_DEAD_STORE}}
    CCKeyDerivationPBKDF(kCCPBKDF2, "hardcoded", 9, salt.bytes, salt.length,
                         kCCPRFHmacAlgSHA1, // expected-warning@-1{{OBJC_CRYPTO_KEY_HARDCODED}}
                         rounds, derivedKey.mutableBytes, derivedKey.length);
}
