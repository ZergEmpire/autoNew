// RUN: iccheck -c %s

#include "system-header-simulator-osx.h"

struct EVP_MD
{};

const struct EVP_MD *EVP_md_null(void);

void
test_EVP_md_null()
{
    const struct EVP_MD *result = EVP_md_null(); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
                                                 // expected-warning@-1{{C_DEAD_STORE}}
}

const struct EVP_MD *EVP_md2(void);

void
test_EVP_md2()
{
    const struct EVP_MD *result = EVP_md2(); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
                                             // expected-warning@-1{{C_DEAD_STORE}}
}

const struct EVP_MD *EVP_md5(void);

void
test_EVP_md5()
{
    const struct EVP_MD *result = EVP_md5(); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
                                             // expected-warning@-1{{C_DEAD_STORE}}
}

const struct EVP_MD *EVP_sha1(void);

void
test_EVP_sha1()
{
    const struct EVP_MD *result = EVP_sha1(); // expected-warning{{OBJC_CRYPTO_BAD_HMAC}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
}
