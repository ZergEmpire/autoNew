// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

void
testPassword()
{
    NSString *db_password = (void *)0; // expected-warning{{OBJC_PASSWORD_NULL}}
}
