// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef signed char BOOL;
typedef unsigned int NSDataWritingOptions;

@class NSDate, NSDictionary, NSError, NSString;

typedef NSString *NSFileAttributeKey;

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface NSData : NSObject
+ (instancetype)dataWithContentsOfFile:(NSString *)path;
- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)useAuxiliaryFile;
- (BOOL)writeToFile:(NSString *)path
            options:(NSDataWritingOptions)writeOptionsMask
              error:(NSError *_Nullable *)errorPtr;
@end

@interface NSFileManager : NSObject
@property(class, readonly, strong) NSFileManager *defaultManager;
- (BOOL)setAttributes:(NSDictionary *)attributes
         ofItemAtPath:(NSString *)path
                error:(NSError *_Nullable *)error;
- (NSDictionary *)attributesOfItemAtPath:(NSString *)path error:(NSError *_Nullable *)error;
@end

enum
{
    NSDataWritingFileAtomic = 0x00000001
};

void
testTmpDirectories()
{
    NSString *path = @"/privateData.txt";
    NSData *data = [NSData dataWithContentsOfFile:path];
    [data writeToFile:@"foo.png" atomically:YES]; // expected-warning{{OBJC_FILE_SYSTEM_MISUSED}}
                                                  // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}

    NSError *error;
    [data writeToFile:@"foo.png"
              options:NSDataWritingFileAtomic
                error:&error]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
}

void
testFollowSymlinks()
{
    NSString *docsDir;
    NSDictionary *attribs;
    NSError *error;
    [[NSFileManager defaultManager]
        setAttributes:attribs
         ofItemAtPath:docsDir
                error:&error]; // expected-warning@-3{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-4{{OBJC_INCORRECT_FUNC_CALL}}

    NSFileManager *fileManager = [[NSFileManager alloc] init];
    NSString *path = @"~/Library/Safari/History.plist";
    NSDictionary *fileAttributes = [fileManager
        attributesOfItemAtPath:path
                         error:(void *)0]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                                           // expected-warning@-3{{C_DEAD_STORE}}
}
