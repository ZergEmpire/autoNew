// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef signed char BOOL;
typedef NSUInteger NSStringEncoding;

@class NSError;

@interface NSString
- (BOOL)writeToFile:(NSString *)path
         atomically:(BOOL)useAuxiliaryFile
           encoding:(NSStringEncoding)enc
              error:(NSError *_Nullable *)error;
@end

@interface NSURL
+ (instancetype)URLWithString:(NSString *)URLString;
@end

@interface NSFileManager
@property(readonly, strong) NSFileManager *defaultManager;
- (BOOL)fileExistsAtPath:(NSString *)path;
- (BOOL)removeItemAtPath:(NSString *)path error:(NSError *_Nullable *)error;
@end

@interface UIApplication
@property(nonatomic, readonly) UIApplication *sharedApplication;
- (BOOL)canOpenURL:(NSURL *)url;
@end

static NSStringEncoding NSUTF8StringEncoding = 4;

BOOL
testJailbroken()
{
    if ([[NSFileManager defaultManager]
            fileExistsAtPath:@"/Applications/Cydia.app"]) { // expected-warning@-1{{OBJC_JAILBREAK}}
        return YES;
    } else if ([[NSFileManager defaultManager] // expected-warning{{OBJC_JAILBREAK}}
                   fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"]) {
        return YES;
    } else if ([[NSFileManager defaultManager]
                   fileExistsAtPath:@"/bin/bash"]) { // expected-warning@-1{{OBJC_JAILBREAK}}
        return YES;
    } else if ([[NSFileManager defaultManager]
                   fileExistsAtPath:@"/usr/sbin/sshd"]) { // expected-warning@-1{{OBJC_JAILBREAK}}
        return YES;
    } else if ([[NSFileManager defaultManager]
                   fileExistsAtPath:@"/etc/apt"]) { // expected-warning@-1{{OBJC_JAILBREAK}}
        return YES;
    }

    NSError *error;
    NSString *stringToBeWritten = @"This is a test.";
    [stringToBeWritten
        writeToFile:@"/private/jailbreak.txt" // expected-warning@-1{{OBJC_FILE_SYSTEM_MISUSED}}
                                              // expected-warning@-2{{OBJC_JAILBREAK}}
         atomically:YES
           encoding:NSUTF8StringEncoding
              error:&error];
    if (!error) {
        return YES;
    } else {
        [[NSFileManager defaultManager] removeItemAtPath:@"/private/jailbreak.txt" error:(void *)0];
    }

    if ([[UIApplication sharedApplication] // expected-warning{{OBJC_JAILBREAK}}
            canOpenURL:[NSURL URLWithString:@"cydia://package/com.example.package"]]) {
        return YES;
    }

    return NO;
}
