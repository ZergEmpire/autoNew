// RUN: iccheck -c %s

#import "system-header-simulator-osx.h"

void
testHash()
{
    unsigned char md[16];
    unsigned char sha[20];
    unsigned char buf[1024];

    CC_SHA1_CTX context1;
    CC_SHA1_Init(&context1); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    CC_SHA1_Update(&context1, buf, sizeof(buf));
    CC_SHA1_Final(sha, &context1);
    CC_SHA1(buf, sizeof(buf), sha); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}

    CC_MD2_CTX context2;
    CC_MD2_Init(&context2); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    CC_MD2_Update(&context2, buf, sizeof(buf));
    CC_MD2_Final(md, &context2);
    CC_MD2(buf, sizeof(buf), md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}

    CC_MD4_CTX context4;
    CC_MD4_Init(&context4); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    CC_MD4_Update(&context4, buf, sizeof(buf));
    CC_MD4_Final(md, &context4);
    CC_MD4(buf, sizeof(buf), md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}

    CC_MD5_CTX context5;
    CC_MD5_Init(&context5); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
    CC_MD5_Update(&context5, buf, sizeof(buf));
    CC_MD5_Final(md, &context5);
    CC_MD5(buf, sizeof(buf), md); // expected-warning{{OBJC_CRYPTO_BAD_HASH}}
}
