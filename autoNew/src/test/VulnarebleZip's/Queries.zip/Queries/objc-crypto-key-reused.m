// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
testKey()
{
    const char *dataIn = "Data";
    const char *key = "some_key0"; // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    char dataOut[512];
    unsigned int numBytesEncrypted;
    unsigned char out[1024];

    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, key, 9,
            (void *)0, // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted); // expected-warning@-1{{C_SIZEOF_POINTER}}
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, key, // expected-warning{{OBJC_CRYPTO_KEY_REUSED}}
            9, (void *)0,                                               // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted);                                        // expected-warning@-1{{C_SIZEOF_POINTER}}
    CCCrypt(kCCEncrypt, kCCAlgorithmAES128, kCCOptionPKCS7Padding, key, // expected-warning{{OBJC_CRYPTO_KEY_REUSED}}
            9, (void *)0,                                               // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
            dataIn, sizeof(dataIn), dataOut, sizeof(dataOut),
            &numBytesEncrypted);                                        // expected-warning@-1{{C_SIZEOF_POINTER}}

    NSString *encryptionKey = @"hardcoded"; // expected-warning{{OBJC_CRYPTO_KEY_HARDCODED}}

    CCHmac(kCCHmacAlgSHA256, encryptionKey, 9, dataOut, sizeof(dataOut), out);

    CCHmac(kCCHmacAlgSHA256, encryptionKey, // expected-warning{{OBJC_CRYPTO_KEY_REUSED}}
            9, dataOut, sizeof(dataOut), out);

    CCHmacContext context;
    CCHmacInit(&context, kCCHmacAlgSHA256, encryptionKey, // expected-warning{{OBJC_CRYPTO_KEY_REUSED}}
            9);

    NSData *salt = [@"salt" dataUsingEncoding:NSUTF8StringEncoding];
    unsigned int rounds = 2048;
    unsigned int keySize = kCCKeySizeAES128;

    NSMutableData *derivedKey = [NSMutableData dataWithLength:keySize];
    NSData *keyData = [@"hardcoded" dataUsingEncoding:NSUTF8StringEncoding]; // expected-warning{{C_DEAD_STORE}}
    CCKeyDerivationPBKDF(kCCPBKDF2, key, // expected-warning{{OBJC_CRYPTO_KEY_REUSED}}
            9, salt.bytes, salt.length, kCCPRFHmacAlgSHA1, rounds, derivedKey.mutableBytes, derivedKey.length);
}
