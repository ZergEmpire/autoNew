// RUN: iccheck -c %s

@class UITextField;

@interface CacheCredExposed
@property(strong, nonatomic)
    IBOutlet UITextField *textFieldPassword; // expected-warning@-1{{OBJC_KEYBOARD_CACHING}}
@end

@interface
CacheCredExposed ()
@property(strong, nonatomic)
    IBOutlet UITextField *passwordTextField; // expected-warning@-1{{OBJC_KEYBOARD_CACHING}}
@end
