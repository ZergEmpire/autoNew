// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef signed char BOOL;

@class NSString;

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)performSelector:(SEL)aSelector;
- (BOOL)respondsToSelector:(SEL)aSelector;
@end

@interface NSXMLParser : NSObject
- (void)callUnsafeCFuncs;
@end

SEL NSSelectorFromString(NSString *aSelectorName);

void
testReflection()
{
    NSXMLParser *parser;
    [parser performSelector:@selector
            (callUnsafeCFuncs)]; // expected-warning@-1{{OBJC_REFLECTION}}
                                 // expected-warning@-2{{OBJC_INCORRECT_FUNC_CALL}}

    SEL sel = NSSelectorFromString(
        @"someMethodWithAnArg:andAnotherOne:"); // expected-warning@-1{{OBJC_REFLECTION}}
    if ([parser respondsToSelector:sel]) {
    }
}
