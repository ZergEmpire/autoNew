// RUN: iccheck++ -c %s

#include "system-header-simulator-cxx.h"

class T
{};

void func_1(T obj);

void
overflow()
{
    const T const_obj;
    func_1(std::move(const_obj)); // expected-warning{{C_MOVE_FROM_CONST}}

    T obj;
    func_1(std::move(obj)); // ok
}
