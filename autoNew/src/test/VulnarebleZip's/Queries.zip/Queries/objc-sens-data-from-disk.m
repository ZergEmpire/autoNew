// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"

@class NSFileManager, NSData, NSUTF8StringEncoding;

int
main(int argc, const char *argv[])
{
    NSFileManager *filemgr;
    NSData *key;
    NSString *pin = @"1234";
    // expected-warning@-1{{OBJC_SENSITIVE_DATA_HARDCODED}}
    filemgr = [NSFileManager defaultManager];
    key = [filemgr contentsAtPath:@"/tmp/myfile.txt"];
    // expected-warning@-1{{OBJC_STORAGE_SENSITIVE_INFO_ON_DISK}}
    // expected-warning@-2{{C_DEAD_STORE}}
    [pin writeToFile:"Your/Path" atomically:YES encoding:4 error:nil];
    // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}
    // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
    // expected-warning@-3{{OBJC_STORAGE_SENSITIVE_INFO_ON_DISK}}
    key = [pin dataUsingEncoding:4];
    [key writeToFile:"Your/Path" atomically:YES encoding:4 error:nil];
    // expected-warning@-1{{OBJC_STORAGE_SENSITIVE_INFO_ON_DISK}}
    // expected-warning@-2{{OBJC_INTERNAL_STORAGE}}
    // expected-warning@-3{{OBJC_FILE_SYSTEM_MISUSED}}
    return 0;
}
