// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef signed char BOOL;
typedef NSUInteger NSStringEncoding;
typedef int OSStatus;
typedef unsigned int NSDataWritingOptions;

@class NSError, NSString, UIImage;

@interface NSUserDefaults
@property(readonly, strong) NSUserDefaults *standardUserDefaults;
- (void)setObject:(id)value forKey:(NSString *)defaultName;
@end

@interface NSMutableDictionary
- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)useAuxiliaryFile;
@end

@interface NSManagedObjectContext
- (BOOL)save:(NSError *_Nullable *)error;
@end

@interface NSHTTPCookieStorage
@property(readonly, strong) NSHTTPCookieStorage *sharedHTTPCookieStorage;
@end

@interface NSData
- (BOOL)writeToFile:(NSString *)path
            options:(NSDataWritingOptions)writeOptionsMask
              error:(NSError *_Nullable *)errorPtr;
@end

@interface NSURLSession
@property(class, readonly, strong) NSURLSession *sharedSession;
@end

OSStatus SecItemAdd(const NSMutableDictionary *attributes, const void *_Nullable *result);
OSStatus SecItemUpdate(const NSMutableDictionary *query,
                       const NSMutableDictionary *attributesToUpdate);

void UIImageWriteToSavedPhotosAlbum(UIImage *image, id completionTarget, SEL completionSelector,
                                    void *contextInfo);

enum
{
    NSDataWritingFileProtectionNone = 0x10000000,
    NSDataWritingFileProtectionComplete = 0x20000000,
    NSDataWritingFileProtectionCompleteUnlessOpen = 0x30000000,
    NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication = 0x40000000,
    NSDataWritingFileProtectionMask = 0xf0000000
};

void
testInternalStorage()
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:@"DemoKey"
                 forKey:@"DemoValue"]; // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}

    NSMutableDictionary *plist;
    [plist writeToFile:@"plist" atomically:YES]; // expected-warning{{OBJC_FILE_SYSTEM_MISUSED}}
                                                 // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}
                                                 // expected-warning@-2{{OBJC_INCORRECT_FUNC_CALL}}

    NSData *data;
    NSError *error;

    [data writeToFile:@"data"
              options:NSDataWritingFileProtectionNone
                error:&error]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
                               // expected-warning@-4{{OBJC_LACKING_FILE_PROTECTION}}
    [data writeToFile:@"data"
              options:NSDataWritingFileProtectionComplete
                error:&error]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
    [data writeToFile:@"data"
              options:NSDataWritingFileProtectionCompleteUnlessOpen
                error:&error]; // expected-warning@-2{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-3{{OBJC_INTERNAL_STORAGE}}
    [data writeToFile:@"data"  // expected-warning{{OBJC_FILE_SYSTEM_MISUSED}}
                               // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}
              options:NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication
                error:&error];

    SecItemAdd(plist, (void *)0); // expected-warning{{OBJC_INTERNAL_STORAGE}}
    SecItemUpdate(plist, plist);  // expected-warning{{OBJC_INTERNAL_STORAGE}}

    NSManagedObjectContext *managedObjectContext;
    [managedObjectContext save:&error]; // expected-warning{{OBJC_INTERNAL_STORAGE}}

    [NSHTTPCookieStorage sharedHTTPCookieStorage]; // expected-warning{{OBJC_INTERNAL_STORAGE}}

    UIImageWriteToSavedPhotosAlbum((void *)0, (void *)0, (void *)0,
                                   (void *)0); // expected-warning@-1{{OBJC_INTERNAL_STORAGE}}

    NSURLSession *session =
        [NSURLSession sharedSession]; // expected-warning{{OBJC_INTERNAL_STORAGE}}
                                      // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
                                      // expected-warning@-3{{C_DEAD_STORE}}
}
