// RUN: iccheck -target x86_64-apple-darwin10 -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

extern const CFStringRef kCFStreamPropertySSLPeerCertificates;
extern const CFStringRef kCFStreamPropertySSLSettings;
extern const CFStringRef kCFStreamSSLLevel;
extern const CFStringRef kCFStreamSSLAllowsExpiredCertificates;
extern const CFStringRef kCFStreamSSLAllowsExpiredRoots;
extern const CFStringRef kCFStreamSSLAllowsAnyRoot;
extern const CFStringRef kCFStreamSSLValidatesCertificateChain;
extern const CFStringRef kCFStreamSSLPeerName;
extern const CFStringRef kCFStreamSSLCertificates;
extern const CFStringRef kCFStreamSSLIsServer;
extern const CFStringRef kCFStreamPropertySocketSecurityLevel;
extern const CFStringRef kCFStreamSocketSecurityLevelNone;
extern const CFStringRef kCFStreamSocketSecurityLevelSSLv2;
extern const CFStringRef kCFStreamSocketSecurityLevelSSLv3;
extern const CFStringRef kCFStreamSocketSecurityLevelTLSv1;
extern const CFStringRef kCFStreamSocketSecurityLevelNegotiatedSSL;

void
testUnsafeSSL()
{
    NSMutableDictionary *settings;

    [settings
        setObject:@"www.example.com"
           forKey:(NSString *)
                      kCFStreamSSLPeerName]; // expected-warning@-3{{OBJC_INCORRECT_FUNC_CALL}}
    settings[(NSString *)kCFStreamSSLPeerName] = @"www.example.com";
    [settings setObject:[NSNumber numberWithBool:YES]
                 forKey:(NSString *)kCFStreamSSLAllowsExpiredRoots];
    [settings setObject:[NSNumber numberWithBool:NO]
                 forKey:(NSString *)kCFStreamSSLAllowsExpiredRoots];
    settings[(NSString *)kCFStreamSSLAllowsExpiredRoots] = [NSNumber numberWithBool:YES];
    settings[(NSString *)kCFStreamSSLAllowsExpiredRoots] = [NSNumber numberWithBool:NO];
    [settings setObject:[NSNumber numberWithBool:YES]
                 forKey:(NSString *)kCFStreamSSLAllowsExpiredCertificates];
    [settings setObject:[NSNumber numberWithBool:NO]
                 forKey:(NSString *)kCFStreamSSLAllowsExpiredCertificates];
    settings[(NSString *)kCFStreamSSLAllowsExpiredCertificates] = [NSNumber numberWithBool:YES];
    settings[(NSString *)kCFStreamSSLAllowsExpiredCertificates] = [NSNumber numberWithBool:NO];
    [settings setObject:[NSNumber numberWithBool:YES] forKey:(NSString *)kCFStreamSSLAllowsAnyRoot];
    [settings setObject:[NSNumber numberWithBool:NO] forKey:(NSString *)kCFStreamSSLAllowsAnyRoot];
    settings[(NSString *)kCFStreamSSLAllowsAnyRoot] = [NSNumber numberWithBool:YES];
    settings[(NSString *)kCFStreamSSLAllowsAnyRoot] = [NSNumber numberWithBool:NO];
    [settings setObject:[NSNumber numberWithBool:NO]
                 forKey:(NSString *)kCFStreamSSLValidatesCertificateChain];
    [settings setObject:[NSNumber numberWithBool:YES]
                 forKey:(NSString *)kCFStreamSSLValidatesCertificateChain];
    settings[(NSString *)kCFStreamSSLValidatesCertificateChain] = [NSNumber numberWithBool:NO];
    settings[(NSString *)kCFStreamSSLValidatesCertificateChain] = [NSNumber numberWithBool:YES];
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelNone
                 forKey:(NSString *)kCFStreamSSLLevel];
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelSSLv2
                 forKey:(NSString *)kCFStreamSSLLevel];
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelSSLv3
                 forKey:(NSString *)kCFStreamSSLLevel];
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelNone;
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelSSLv2;
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelSSLv3;
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelTLSv1
                 forKey:(NSString *)kCFStreamSSLLevel];
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelNegotiatedSSL
                 forKey:(NSString *)kCFStreamSSLLevel];
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelTLSv1;
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelNegotiatedSSL;

    NSDictionary *f_settings1 = // expected-warning{{C_DEAD_STORE}}
        [[NSDictionary alloc]   // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelNone, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings2 = [[NSDictionary alloc] // expected-warning{{C_DEAD_STORE}}
        initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                               [NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredCertificates,
                               [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                               [NSNumber numberWithBool:YES], kCFStreamSSLValidatesCertificateChain,
                               kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                               @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings3 = // expected-warning{{C_DEAD_STORE}}
        [[NSDictionary alloc]   // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings4 = // expected-warning{{C_DEAD_STORE}}
        [[NSDictionary alloc]   // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings5 = // expected-warning{{C_DEAD_STORE}}
        [[NSDictionary alloc]   // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings6 = // expected-warning{{C_DEAD_STORE}}
        [[NSDictionary alloc]   // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings7 = // expected-warning{{C_DEAD_STORE}}
        [[NSDictionary alloc]   // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelSSLv3, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings1 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelNone, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings2 = [NSDictionary // expected-warning{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings3 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings4 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings5 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings6 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings7 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelSSLv3, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *c_settings1 = @{
        // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
        // expected-warning@-2{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelNone,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings2 = @{
        // expected-warning@-1{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings3 = @{
        // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
        // expected-warning@-2{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings4 = @{
        // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
        // expected-warning@-2{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings5 = @{
        // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
        // expected-warning@-2{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings6 = @{
        // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
        // expected-warning@-2{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings7 = @{
        // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
        // expected-warning@-2{{C_DEAD_STORE}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelSSLv3,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    [NSURLRequest
        setAllowsAnyHTTPSCertificate:YES
                             forHost:
                                 @"https://example.com"]; // expected-warning@-3{{OBJC_SSL_BAD_VERIFICATION}}
                                                          // expected-warning@-1{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    [NSURLRequest
        setAllowsAnyHTTPSCertificate:NO
                             forHost:
                                 @"https://example.com"]; // expected-warning{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}

    NSURLAuthenticationChallenge *challenge;
    NSURLAuthenticationChallengeSender *sender;
    [sender continueWithoutCredentialForAuthenticationChallenge:
                challenge]; // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}

    NSURLSession *session =           // expected-warning{{C_DEAD_STORE}}
        [NSURLSession sharedSession]; // expected-warning{{OBJC_INTERNAL_STORAGE}}
                                      // expected-warning@-1{{OBJC_SSL_BAD_VERIFICATION}}
}
