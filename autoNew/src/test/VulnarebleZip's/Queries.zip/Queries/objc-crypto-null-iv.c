// RUN: iccheck -c %s

struct EVP_CIPHER_CTX
{};

struct EVP_CIPHER
{};

struct ENGINE
{};

int EVP_EncryptInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                       struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_EncryptInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    const struct EVP_CIPHER *type;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_EncryptInit_ex( // expected-warning{{C_DEAD_STORE}}
        ctx, type, impl, key,    // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
        (const unsigned char *)1);

    result = EVP_EncryptInit_ex( // expected-warning{{OBJC_CRYPTO_NULL_IV}}
        ctx, type, impl, key,    // expected-warning@-1{{C_DEAD_STORE}}
        (const unsigned char *)0);
}

int EVP_DecryptInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                       struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_DecryptInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    const struct EVP_CIPHER *type;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_DecryptInit_ex( // expected-warning{{C_DEAD_STORE}}
        ctx, type, impl, key,    // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
        (const unsigned char *)1);

    result = EVP_DecryptInit_ex( // expected-warning{{OBJC_CRYPTO_NULL_IV}}
        ctx, type, impl, key,    // expected-warning@-1{{C_DEAD_STORE}}
        (const unsigned char *)0);
}

int EVP_CipherInit_ex(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                      struct ENGINE *impl, const unsigned char *key, const unsigned char *iv);

void
test_EVP_CipherInit_ex()
{
    struct EVP_CIPHER_CTX *ctx;
    const struct EVP_CIPHER *type;
    struct ENGINE *impl;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_CipherInit_ex( // expected-warning{{C_DEAD_STORE}}
        ctx, type, impl, key,   // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
        (const unsigned char *)1);

    result = EVP_CipherInit_ex( // expected-warning{{OBJC_CRYPTO_NULL_IV}}
        ctx, type, impl, key,   // expected-warning@-1{{C_DEAD_STORE}}
        (const unsigned char *)0);
}

int EVP_EncryptInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                    const unsigned char *key, const unsigned char *iv);

void
test_EVP_EncryptInit()
{
    struct EVP_CIPHER_CTX *ctx;
    const struct EVP_CIPHER *type;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_EncryptInit(                      // expected-warning{{C_DEAD_STORE}}
        ctx, type, key, (const unsigned char *)1); // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}

    result = EVP_EncryptInit( // expected-warning{{OBJC_CRYPTO_NULL_IV}}
        ctx, type, key,       // expected-warning@-1{{C_DEAD_STORE}}
        (const unsigned char *)0);
}

int EVP_DecryptInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                    const unsigned char *key, const unsigned char *iv);

void
test_EVP_DecryptInit()
{
    struct EVP_CIPHER_CTX *ctx;
    const struct EVP_CIPHER *type;
    unsigned char *key;
    unsigned char *iv;
    int result;

    result = EVP_DecryptInit(                      // expected-warning{{C_DEAD_STORE}}
        ctx, type, key, (const unsigned char *)1); // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}

    result = EVP_DecryptInit( // expected-warning{{OBJC_CRYPTO_NULL_IV}}
        ctx, type, key,       // expected-warning@-1{{C_DEAD_STORE}}
        (const unsigned char *)0);
}

int EVP_CipherInit(struct EVP_CIPHER_CTX *ctx, const struct EVP_CIPHER *type,
                   const unsigned char *key, const unsigned char *iv, int enc);

void
test_EVP_CipherInit()
{
    struct EVP_CIPHER_CTX *ctx;
    const struct EVP_CIPHER *type;
    unsigned char *key;
    unsigned char *iv;
    int enc;
    int result;

    result = EVP_CipherInit(ctx, type, key, (const unsigned char *)1,
                            enc); // expected-warning@-1{{C_DEAD_STORE}}
                                  // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = EVP_CipherInit(ctx, type, key, (const unsigned char *)0,
                            enc); // expected-warning@-1{{OBJC_CRYPTO_NULL_IV}}
                                  // expected-warning@-2{{C_DEAD_STORE}}
}
