// RUN: iccheck++ -c %s

#include "system-header-simulator-cxx.h"

int strcmp(const char *s1, const char *s2);

void
key_test()
{
    char *KEY = "str";  // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    KEY == "str";       // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    "str" == KEY;       // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    strcmp(KEY, "str"); // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    strcmp("str", KEY); // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
}

void
encrypt_test()
{
    const wchar_t *_encrypt123 = L"test"; // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    _encrypt123 == L"test";               // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    L"test" == _encrypt123;               // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
}

void
passphrase_test()
{
    const char32_t *_PASSphrase123 = U"test"; // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    _PASSphrase123 == U"test";                // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
    U"test" == _PASSphrase123;                // expected-warning{{C_CRYPTO_KEY_HARDCODED}}
}

void
not_matches()
{
    char *key = "";
    key == "";
    "" == key;
    strcmp(key, "");
    strcmp("", key);
}
