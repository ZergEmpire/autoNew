// RUN: iccheck -c %s

@class WKNavigation;

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface NSString
@end

@interface NSURL
+ (NSURL *)fileURLWithPath:(NSString *)path;
+ (instancetype)URLWithString:(NSString *)URLString relativeToURL:(NSURL *)baseURL;
@end

@interface NSURLRequest : NSObject
+ (instancetype)requestWithURL:(NSURL *)URL;
- (instancetype)initWithURL:(NSURL *)URL;
@end

@interface NSMutableURLRequest : NSURLRequest
@property(copy) NSString *HTTPMethod;
@end

@interface WKWebView : NSObject
- (WKNavigation *)loadRequest:(NSURLRequest *)request;
@end

typedef const struct __CFAllocator *CFAllocatorRef;
typedef const struct __CFHTTPMessage *CFHTTPMessageRef;
typedef const struct __CFString *CFStringRef;
typedef const struct __CFURL *CFURLRef;
typedef const void *CFTypeRef;

void CFRelease(CFTypeRef cf);
CFURLRef CFURLCreateWithString(CFAllocatorRef allocator, CFStringRef URLString, CFURLRef baseURL);
CFHTTPMessageRef CFHTTPMessageCreateRequest(CFAllocatorRef alloc, CFStringRef requestMethod,
                                            CFURLRef url, CFStringRef httpVersion);

extern const CFStringRef kCFHTTPVersion1_1;

#define CFSTR(cStr) ((CFStringRef)cStr)

void
testGetRequest()
{
    NSURL *baseURL = [NSURL fileURLWithPath:@"file:///path/to/user/"];
    NSURL *url = [NSURL URLWithString:@"folder/file.html" relativeToURL:baseURL];
    NSMutableURLRequest *request = [NSMutableURLRequest
        requestWithURL:url];        // expected-warning@-1{{OBJC_GET_REQUEST}}
    [request setHTTPMethod:@"GET"]; // expected-warning{{OBJC_GET_REQUEST}}
    request.HTTPMethod = @"GET";    // expected-warning{{OBJC_GET_REQUEST}}

    CFURLRef myURL = CFURLCreateWithString(
        (void *)0, CFSTR("https://www.apple.com"),
        (void *)0); // expected-warning@-1{{C_TYPE_CAST_ERROR}}
                    // expected-warning@-2{{OBJC_BACKDOOR_NETWORK_ACTIVITY}}
    CFHTTPMessageRef myRequest = CFHTTPMessageCreateRequest(
        (void *)0, CFSTR("GET"), myURL, // expected-warning@-1{{OBJC_GET_REQUEST}}
                                        // expected-warning@-1{{C_TYPE_CAST_ERROR}}
        kCFHTTPVersion1_1);
    CFRelease(myRequest);
    CFRelease(myURL);

    NSURLRequest *req = [[NSURLRequest alloc]
        initWithURL:url]; // expected-warning@-1{{OBJC_GET_REQUEST}}
    WKWebView *webView = [[WKWebView alloc] init];
    [webView loadRequest:req];
} // expected-warning{{OBJC_MEMORY_LEAK}}
  // expected-warning@-1{{OBJC_MEMORY_LEAK}}
