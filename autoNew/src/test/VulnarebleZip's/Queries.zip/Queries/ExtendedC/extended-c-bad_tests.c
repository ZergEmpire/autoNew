// RUN: iccheck -c %s

#define NULL 0

char *get_chars();
int get_int();

void MD2_Init();
void MD2();
void MD4_Init();
void MD4();
void MD5_Init();
void MD5();
void SHA_Init();
void SHA();
void SHA1_Init();
void SHA1();
void RIPEMD160_Init();
void RIPEMD160();

void
c_crypto_bad_hash()
{
    MD2_Init(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    MD2(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    MD4_Init(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    MD4(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    MD5_Init(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    MD5(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    SHA_Init(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    SHA(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    SHA1_Init(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    SHA1(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    RIPEMD160_Init(); // expected-warning{{C_CRYPTO_BAD_HASH}}
    RIPEMD160(); // expected-warning{{C_CRYPTO_BAD_HASH}}
}

void ShellExecuteA();
void ShellExecuteW();
void ShellExecute();
void CreateProcessA();
void CreateProcessW();
void CreateProcess();
void CreateProcessAsUserA();
void CreateProcessAsUserW();
void CreateProcessAsUser();
void CreateProcessWithLogonW();
void CreateProcessWithTokenW();
void WinExec();
void CreateProcessWithLoginW();
void g_spawn_async_with_pipes();
void g_spawn_async();
void g_spawn_sync();
void g_spawn_command_line_async();
void g_spawn_command_line_sync();
void posix_spawn();
void spawnvpe();
void spawnvp();
void spawnve();
void spawnv();
void spawnlpe();
void spawnlp();
void spawnle();
void spawnl();
void spawn();
void _execvpe();
void _execvp();
void _execve();
void _execv();
void _execlpe();
void _execlp();
void _execle();
void _execl();
void _spawnvpe();
void _spawnvp();
void _spawnve();
void _spawnv();
void _spawnlpe();
void _spawnlp();
void _spawnle();
void _spawnl();
void _wexecvpe();
void _wexecvp();
void _wexecve();
void _wexecv();
void _wexeclpe();
void _wexeclp();
void _wexecle();
void _wexecl();
void _wspawnvpe();
void _wspawnvp();
void _wspawnve();
void _wspawnv();
void _wspawnlpe();
void _wspawnlp();
void _wspawnle();
void _wspawnl();
void _texecvpe();
void _texecvp();
void _texecve();
void _texecv();
void _texeclpe();
void _texeclp();
void _texecle();
void _texecl();
void _tspawnvpe();
void _tspawnvp();
void _tspawnve();
void _tspawnv();
void _tspawnlpe();
void _tspawnlp();
void _tspawnle();
void _tspawnl();

void
c_injection_command()
{
    ShellExecuteA(); // expected-warning{{C_INJECTION_COMMAND}}
    ShellExecuteW(); // expected-warning{{C_INJECTION_COMMAND}}
    ShellExecute(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessA(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessW(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcess(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessAsUserA(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessAsUserW(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessAsUser(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessWithLogonW(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessWithTokenW(); // expected-warning{{C_INJECTION_COMMAND}}
    WinExec(); // expected-warning{{C_INJECTION_COMMAND}}
    CreateProcessWithLoginW(); // expected-warning{{C_INJECTION_COMMAND}}
    g_spawn_async_with_pipes(); // expected-warning{{C_INJECTION_COMMAND}}
    g_spawn_async(); // expected-warning{{C_INJECTION_COMMAND}}
    g_spawn_sync(); // expected-warning{{C_INJECTION_COMMAND}}
    g_spawn_command_line_async(); // expected-warning{{C_INJECTION_COMMAND}}
    g_spawn_command_line_sync(); // expected-warning{{C_INJECTION_COMMAND}}
    posix_spawn(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnvp(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnve(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnv(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnlpe(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnlp(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnle(); // expected-warning{{C_INJECTION_COMMAND}}
    spawnl(); // expected-warning{{C_INJECTION_COMMAND}}
    spawn(); // expected-warning{{C_INJECTION_COMMAND}}
    _execvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _execvp(); // expected-warning{{C_INJECTION_COMMAND}}
    _execve(); // expected-warning{{C_INJECTION_COMMAND}}
    _execv(); // expected-warning{{C_INJECTION_COMMAND}}
    _execlpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _execlp(); // expected-warning{{C_INJECTION_COMMAND}}
    _execle(); // expected-warning{{C_INJECTION_COMMAND}}
    _execl(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnvp(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnve(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnv(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnlpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnlp(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnle(); // expected-warning{{C_INJECTION_COMMAND}}
    _spawnl(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexecvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexecvp(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexecve(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexecv(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexeclpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexeclp(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexecle(); // expected-warning{{C_INJECTION_COMMAND}}
    _wexecl(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnvp(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnve(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnv(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnlpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnlp(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnle(); // expected-warning{{C_INJECTION_COMMAND}}
    _wspawnl(); // expected-warning{{C_INJECTION_COMMAND}}
    _texecvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _texecvp(); // expected-warning{{C_INJECTION_COMMAND}}
    _texecve(); // expected-warning{{C_INJECTION_COMMAND}}
    _texecv(); // expected-warning{{C_INJECTION_COMMAND}}
    _texeclpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _texeclp(); // expected-warning{{C_INJECTION_COMMAND}}
    _texecle(); // expected-warning{{C_INJECTION_COMMAND}}
    _texecl(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnvpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnvp(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnve(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnv(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnlpe(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnlp(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnle(); // expected-warning{{C_INJECTION_COMMAND}}
    _tspawnl(); // expected-warning{{C_INJECTION_COMMAND}}
}

void gets();
void _getws();
void _getts();

void
c_insecure_api_gets()
{
    gets(get_chars()); // expected-warning{{C_INSECURE_API_GETS}}
    _getws(); // expected-warning{{C_INSECURE_API_GETS}}
    _getts(); // expected-warning{{C_INSECURE_API_GETS}}
}

void g_list_push_allocator();
void g_list_pop_allocator();
void g_slist_push_allocator();
void g_slist_pop_allocator();
void g_hash_table_freeze();
void g_hash_table_thaw();
void ldap_result2error();
void ldap_abandonA();
void ldap_abandonW();
void ldap_abandon();
void ldap_addA();
void ldap_addW();
void ldap_add();
void ldap_add_sA();
void ldap_add_sW();
void ldap_add_s();
void ldap_modifyA();
void ldap_modifyW();
void ldap_modify();
void ldap_modify_sA();
void ldap_modify_sW();
void ldap_modify_s();
void ldap_deleteA();
void ldap_deleteW();
void ldap_delete();
void ldap_delete_sA();
void ldap_delete_sW();
void ldap_delete_s();
void ldap_modrdn2A();
void ldap_modrdn2W();
void ldap_modrdn2();
void ldap_modrdn2_sA();
void ldap_modrdn2_sW();
void ldap_modrdn2_s();
void ldap_searchA();
void ldap_searchW();
void ldap_search();
void ldap_search_sA();
void ldap_search_sW();
void ldap_search_s();
void ldap_search_stA();
void ldap_search_stW();
void ldap_search_st();
void ldap_compareA();
void ldap_compareW();
void ldap_compare();
void ldap_compare_sA();
void ldap_compare_sW();
void ldap_compare_s();
void ldap_build_filter();
void ldap_modrdn();
void ldap_modrdn_s();
void ldap_setfilteraffixes();
void ldap_version();
void ldap_bindA(int, int, char *);
void ldap_bindW(int, int, char *);
void ldap_bind(int, int, char *);
void ldap_bind_sA(int, int, char *);
void ldap_bind_sW(int, int, char *);
void ldap_bind_s(int, int, char *);
void ldap_cache_flush();
void ldap_openA();
void ldap_openW();
void ldap_open();
void ldap_perror();
void ldap_encode_sort_controlA();
void ldap_encode_sort_controlW();
void ldap_encode_sort_control();
void g_node_push_allocator();
void g_node_pop_allocator();
void g_cache_value_foreach();
void g_allocator_new();
void g_allocater_free();
void g_mem_chunk_print();
void g_mem_chunk_new();
void g_mem_chunk_alloc();
void g_mem_chunk_alloc0();
void g_mem_chunk_free();
void g_mem_chunk_destroy();
void g_mem_chunk_create();
void gsignal();
void ssignal();
void memalign();
void ulimit();
void usleep();
void g_io_channel_close();
void g_io_channel_read();
void g_io_channel_write();
void g_io_channel_seek();
void g_async_queue_ref_unlocked();
void SQLError();
void SQLAllocConnect();
void SQLAllocEnv();
void SQLAllocStmt();
void SQLSetConnectOption();
void SQLSetParam();
void SQLSetStmtOption();
void IsBadHugeWritePtr();
void IsBadHugeReadPtr();
void IsBadWritePtr();
void IsBadReadPtr();
void IsBadCodePtr();
void IsBadStringPtrA();
void IsBadStringPtrW();
void IsBadStringPtr();
void g_chunk_new();
void g_chunk_new0();
void g_chunk_free();
void g_mem_chunk_reset();
void g_mem_chunk_clean();
void g_blow_chunks();
void g_mem_chunk_info();
void cuserid();
void inet_addr();
void __inet_addr();
void bcopy();
void bcmp();
void __bzero();
void bzero();
void strtok();
void WinVerifyTrustEx();
void WinVerifyTrust();
void g_async_queue_unref_and_unlock();
void g_date_set_time();
void g_basename();
void g_dirname();
void SQLColAttributes();
void SQLExtendedFetch();
void SQLParamOptions();
void SQLSetScrollOptions();
void SQLBindParam();
void SQLFreeConnect();
void SQLFreeEnv();
void SQLGetConnectOption();
void SQLGetStmtOption();
void SQLTransact();
void WSACancelBlockingCall();
void WSAIsBlocking();
void WSASetBlockingHook();
void WSAUnhookBlockingHook();
void LoadModule();
void OpenFile();
void SetHandleCount();
void getpw();
void valloc();
void mysql_create_db();
void mysql_drop_db();
void mysql_eof();
void mysql_escape_string();
void keybd_event();
void getpass();
void g_string_sprintf();
void g_string_sprintfa();
void g_string_up();
void g_string_down();
void g_strup();
void g_strdown();
void g_strcasecmp();
void g_strncasecmp();

void
c_obsolete()
{
    g_list_push_allocator(); // expected-warning{{C_OBSOLETE}}
    g_list_pop_allocator(); // expected-warning{{C_OBSOLETE}}
    g_slist_push_allocator(); // expected-warning{{C_OBSOLETE}}
    g_slist_pop_allocator(); // expected-warning{{C_OBSOLETE}}
    g_hash_table_freeze(); // expected-warning{{C_OBSOLETE}}
    g_hash_table_thaw(); // expected-warning{{C_OBSOLETE}}
    ldap_result2error(); // expected-warning{{C_OBSOLETE}}
    ldap_abandonA(); // expected-warning{{C_OBSOLETE}}
    ldap_abandonW(); // expected-warning{{C_OBSOLETE}}
    ldap_abandon(); // expected-warning{{C_OBSOLETE}}
    ldap_addA(); // expected-warning{{C_OBSOLETE}}
    ldap_addW(); // expected-warning{{C_OBSOLETE}}
    ldap_add(); // expected-warning{{C_OBSOLETE}}
    ldap_add_sA(); // expected-warning{{C_OBSOLETE}}
    ldap_add_sW(); // expected-warning{{C_OBSOLETE}}
    ldap_add_s(); // expected-warning{{C_OBSOLETE}}
    ldap_modifyA(); // expected-warning{{C_OBSOLETE}}
    ldap_modifyW(); // expected-warning{{C_OBSOLETE}}
    ldap_modify(); // expected-warning{{C_OBSOLETE}}
    ldap_modify_sA(); // expected-warning{{C_OBSOLETE}}
    ldap_modify_sW(); // expected-warning{{C_OBSOLETE}}
    ldap_modify_s(); // expected-warning{{C_OBSOLETE}}
    ldap_deleteA(); // expected-warning{{C_OBSOLETE}}
    ldap_deleteW(); // expected-warning{{C_OBSOLETE}}
    ldap_delete(); // expected-warning{{C_OBSOLETE}}
    ldap_delete_sA(); // expected-warning{{C_OBSOLETE}}
    ldap_delete_sW(); // expected-warning{{C_OBSOLETE}}
    ldap_delete_s(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn2A(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn2W(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn2(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn2_sA(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn2_sW(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn2_s(); // expected-warning{{C_OBSOLETE}}
    ldap_searchA(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_searchW(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_sA(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_sW(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_s(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_stA(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_stW(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_st(); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_compareA(); // expected-warning{{C_OBSOLETE}}
    ldap_compareW(); // expected-warning{{C_OBSOLETE}}
    ldap_compare(); // expected-warning{{C_OBSOLETE}}
    ldap_compare_sA(); // expected-warning{{C_OBSOLETE}}
    ldap_compare_sW(); // expected-warning{{C_OBSOLETE}}
    ldap_compare_s(); // expected-warning{{C_OBSOLETE}}
    ldap_build_filter(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn(); // expected-warning{{C_OBSOLETE}}
    ldap_modrdn_s(); // expected-warning{{C_OBSOLETE}}
    ldap_setfilteraffixes(); // expected-warning{{C_OBSOLETE}}
    ldap_version(); // expected-warning{{C_OBSOLETE}}
    ldap_bindA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bindW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_s(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_cache_flush(); // expected-warning{{C_OBSOLETE}}
    ldap_openA(); // expected-warning{{C_OBSOLETE}}
    ldap_openW(); // expected-warning{{C_OBSOLETE}}
    ldap_open(); // expected-warning{{C_OBSOLETE}}
    ldap_perror(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_encode_sort_controlA(); // expected-warning{{C_OBSOLETE}}
    ldap_encode_sort_controlW(); // expected-warning{{C_OBSOLETE}}
    ldap_encode_sort_control(); // expected-warning{{C_OBSOLETE}}
    g_node_push_allocator(); // expected-warning{{C_OBSOLETE}}
    g_node_pop_allocator(); // expected-warning{{C_OBSOLETE}}
    g_cache_value_foreach(); // expected-warning{{C_OBSOLETE}}
    g_allocator_new(); // expected-warning{{C_OBSOLETE}}
    g_allocater_free(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_print(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_new(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_alloc(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_alloc0(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_free(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_destroy(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_create(); // expected-warning{{C_OBSOLETE}}
    gsignal(); // expected-warning{{C_OBSOLETE}}
    ssignal(); // expected-warning{{C_OBSOLETE}}
    memalign(); // expected-warning{{C_OBSOLETE}}
    ulimit(); // expected-warning{{C_OBSOLETE}}
    usleep(); // expected-warning{{C_OBSOLETE}}
    g_io_channel_close(); // expected-warning{{C_OBSOLETE}}
    g_io_channel_read(); // expected-warning{{C_OBSOLETE}}
    g_io_channel_write(); // expected-warning{{C_OBSOLETE}}
    g_io_channel_seek(); // expected-warning{{C_OBSOLETE}}
    g_async_queue_ref_unlocked(); // expected-warning{{C_OBSOLETE}}
    SQLError(); // expected-warning{{C_OBSOLETE}}
    SQLAllocConnect(); // expected-warning{{C_OBSOLETE}}
    SQLAllocEnv(); // expected-warning{{C_OBSOLETE}}
    SQLAllocStmt(); // expected-warning{{C_OBSOLETE}}
    SQLSetConnectOption(); // expected-warning{{C_OBSOLETE}}
    SQLSetParam(); // expected-warning{{C_OBSOLETE}}
    SQLSetStmtOption(); // expected-warning{{C_OBSOLETE}}
    IsBadHugeWritePtr(); // expected-warning{{C_OBSOLETE}}
    IsBadHugeReadPtr(); // expected-warning{{C_OBSOLETE}}
    IsBadWritePtr(); // expected-warning{{C_OBSOLETE}}
    IsBadReadPtr(); // expected-warning{{C_OBSOLETE}}
    IsBadCodePtr(); // expected-warning{{C_OBSOLETE}}
    IsBadStringPtrA(); // expected-warning{{C_OBSOLETE}}
    IsBadStringPtrW(); // expected-warning{{C_OBSOLETE}}
    IsBadStringPtr(); // expected-warning{{C_OBSOLETE}}
    g_chunk_new(); // expected-warning{{C_OBSOLETE}}
    g_chunk_new0(); // expected-warning{{C_OBSOLETE}}
    g_chunk_free(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_reset(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_clean(); // expected-warning{{C_OBSOLETE}}
    g_blow_chunks(); // expected-warning{{C_OBSOLETE}}
    g_mem_chunk_info(); // expected-warning{{C_OBSOLETE}}
    cuserid(); // expected-warning{{C_OBSOLETE}}
    inet_addr(); // expected-warning{{C_OBSOLETE}}
    __inet_addr(); // expected-warning{{C_OBSOLETE}}
    bcopy(); // expected-warning{{C_OBSOLETE}}
    bcmp(); // expected-warning{{C_OBSOLETE}}
    __bzero(0, 0); // expected-warning{{C_OBSOLETE}}
    bzero(0, 0); // expected-warning{{C_OBSOLETE}}
    strtok(); // expected-warning{{C_OBSOLETE}}
    WinVerifyTrustEx(); // expected-warning{{C_OBSOLETE}}
    WinVerifyTrust(); // expected-warning{{C_OBSOLETE}}
    g_async_queue_unref_and_unlock(); // expected-warning{{C_OBSOLETE}}
    g_date_set_time(); // expected-warning{{C_OBSOLETE}}
    g_basename(); // expected-warning{{C_OBSOLETE}}
    g_dirname(); // expected-warning{{C_OBSOLETE}}
    SQLColAttributes(); // expected-warning{{C_OBSOLETE}}
    SQLExtendedFetch(); // expected-warning{{C_OBSOLETE}}
    SQLParamOptions(); // expected-warning{{C_OBSOLETE}}
    SQLSetScrollOptions(); // expected-warning{{C_OBSOLETE}}
    SQLBindParam(); // expected-warning{{C_OBSOLETE}}
    SQLFreeConnect(); // expected-warning{{C_OBSOLETE}}
    SQLFreeEnv(); // expected-warning{{C_OBSOLETE}}
    SQLGetConnectOption(); // expected-warning{{C_OBSOLETE}}
    SQLGetStmtOption(); // expected-warning{{C_OBSOLETE}}
    SQLTransact(); // expected-warning{{C_OBSOLETE}}
    WSACancelBlockingCall(); // expected-warning{{C_OBSOLETE}}
    WSAIsBlocking(); // expected-warning{{C_OBSOLETE}}
    WSASetBlockingHook(); // expected-warning{{C_OBSOLETE}}
    WSAUnhookBlockingHook(); // expected-warning{{C_OBSOLETE}}
    LoadModule(); // expected-warning{{C_OBSOLETE}}
    OpenFile(); // expected-warning{{C_OBSOLETE}}
    SetHandleCount(); // expected-warning{{C_OBSOLETE}}
    getpw(); // expected-warning{{C_OBSOLETE}}
    valloc(); // expected-warning{{C_OBSOLETE}}
    mysql_create_db(); // expected-warning{{C_OBSOLETE}}
    mysql_drop_db(); // expected-warning{{C_OBSOLETE}}
    mysql_eof(); // expected-warning{{C_OBSOLETE}}
    mysql_escape_string(); // expected-warning{{C_OBSOLETE}}
    keybd_event(); // expected-warning{{C_OBSOLETE}}
    getpass(); // expected-warning{{C_OBSOLETE}}
    g_string_sprintf(0, "%s"); // expected-warning{{C_OBSOLETE}}
    g_string_sprintfa(); // expected-warning{{C_OBSOLETE}}
    g_string_up(); // expected-warning{{C_OBSOLETE}}
    g_string_down(); // expected-warning{{C_OBSOLETE}}
    g_strup(); // expected-warning{{C_OBSOLETE}}
    g_strdown(); // expected-warning{{C_OBSOLETE}}
    g_strcasecmp(); // expected-warning{{C_OBSOLETE}}
    g_strncasecmp(); // expected-warning{{C_OBSOLETE}}
}

void EVP_enc_null();
void EVP_des_ecb();
void EVP_des_cbc();
void EVP_des_ofb();
void EVP_des_cfb();
void EVP_des_cfb64();
void EVP_des_ede_cbc();
void EVP_des_ede();
void EVP_des_ede_ofb();
void EVP_des_ede_cfb();
void EVP_desx_cbc();
void EVP_rc4();
void EVP_rc4_40();
void RC2_ecb_encrypt();
void RC2_encrypt();
void RC2_decrypt();
void RC2_cbc_encrypt();
void RC2_cfb64_encrypt();
void RC2_ofb64_encrypt();
void crypt();
void crypt_r();
void RC4();
void BF_ecb_encrypt();
void DES_ecb_encrypt();
void DES_ecb2_encrypt();
void DES_ecb3_encrypt();
void EVP_idea_ecb();
void EVP_bf_ecb();
void EVP_cast5_ecb();
void EVP_rc5_32_12_16_ecb();
void EVP_aes_128_ecb();
void EVP_aes_192_ecb();
void EVP_aes_256_ecb();
void DES_crypt();
void DES_fcrypt();
void DES_ecb_encrypt();
void DES_ncbc_encrypt();
void DES_xcbc_encrypt();
void DES_pcbc_encrypt();
void DES_cfb_encrypt();
void DES_cfb64_encrypt();
void DES_ofb_encrypt();
void DES_ofb64_encrypt();
void DES_cbc_cksum();
void DES_quad_cksum();
void DES_enc_write();
void DES_enc_read();
void EVP_rc2_cbc();
void EVP_rc2_ecb();
void EVP_rc2_cfb();
void EVP_rc2_ofb();
void EVP_rc2_40_cbc();
void EVP_rc2_64_cbc();

void
c_crypto_bad_algorithm()
{
    EVP_enc_null(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_cbc(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_ofb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_cfb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_cfb64(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_ede_cbc(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_ede(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_ede_ofb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_des_ede_cfb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_desx_cbc(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc4(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc4_40(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC2_ecb_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC2_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC2_decrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC2_cbc_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC2_cfb64_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC2_ofb64_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    crypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    crypt_r(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    RC4(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BF_ecb_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ecb_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ecb2_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ecb3_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_idea_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_bf_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_cast5_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc5_32_12_16_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_aes_128_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_aes_192_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_aes_256_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_crypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_fcrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ecb_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ncbc_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_xcbc_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_pcbc_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_cfb_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_cfb64_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ofb_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_ofb64_encrypt(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_cbc_cksum(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_quad_cksum(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_enc_write(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_enc_read(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc2_cbc(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc2_ecb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc2_cfb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc2_ofb(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc2_40_cbc(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_rc2_64_cbc(); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void RSA_padding_add_PKCS1_type_1();
void RSA_padding_check_PKCS1_type_1();
void RSA_padding_add_PKCS1_type_2();
void RSA_padding_check_PKCS1_type_2();
void RSA_padding_add_SSLv23();
void RSA_padding_check_SSLv23();
void RSA_padding_add_none();
void RSA_padding_check_none();
void RSA_padding_add_X931();
void RSA_padding_check_X931();

void
c_crypto_bad_padding_1()
{
    RSA_padding_add_PKCS1_type_1(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_check_PKCS1_type_1(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_add_PKCS1_type_2(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_check_PKCS1_type_2(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_add_SSLv23(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_check_SSLv23(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_add_none(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_check_none(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_add_X931(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_padding_check_X931(); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void g_random_double_range();
void g_random_double();
void g_random_int_range();
void g_random_int();
void g_rand_double_range();
void g_rand_double();
void srand();
void rand();
void g_rand_int_range();
void g_rand_int();

void
c_crypto_bad_random()
{
    g_random_double_range(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_random_double(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_random_int_range(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_random_int(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_rand_double_range(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_rand_double(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    srand(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    rand(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_rand_int_range(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
    g_rand_int(); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
}

void ldap_perror();
void mysql_debug();
void mysql_dump_debug_info();
void clnt_pcreateerror();
void clnt_perrno();
void clnt_perror();

void
c_information_leak_internal()
{
    ldap_perror(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
		 // expected-warning@-1{{C_OBSOLETE}}
    mysql_debug(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
    mysql_dump_debug_info(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
    clnt_pcreateerror(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
    clnt_perrno(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
    clnt_perror(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
}

void CoTaskMemRealloc();
void GlobalReAlloc();
void LocalReAlloc();
void HeapReAlloc();
void VirtualLock();
void g_renew();
void g_try_renew();
void g_realloc();
void g_try_realloc();
void _realloc_dbg();
void xrealloc();
void srealloc();
void realloc();

void
c_heap_inspection()
{
    CoTaskMemRealloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    GlobalReAlloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    LocalReAlloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    HeapReAlloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    VirtualLock(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    g_renew(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    g_try_renew(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    g_realloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    g_try_realloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    _realloc_dbg(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    xrealloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    srealloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
    realloc(); // expected-warning{{C_PRIVACY_VIOLATION_HEAP}}
}

void _ttmpnam();
void _tempnam();
void _wtmpnam();
void _ttempnam();
void _wtempnam();
void tempnam();
void tmpnam_r();
int tmpfile();
void mktemp();
void _tmpfile_r();
void tmpfile64();
void mkdtemp();
void tmpnam();

void
c_insecure_temporary_file()
{
    _ttmpnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    _tempnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    _wtmpnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    _ttempnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    _wtempnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    tempnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    tmpnam_r(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    tmpfile(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    mktemp(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    _tmpfile_r(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    tmpfile64(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    mkdtemp(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
    tmpnam(); // expected-warning{{C_INSECURE_TEMPORARY_FILE}}
}

void SSLv3_method();
void SSLv3_server_method();
void SSLv3_client_method();
void SSLv23_method();
void SSLv23_server_method();
void SSLv23_client_method();
void SSLv2_method();
void SSLv2_server_method();
void SSLv2_client_method();

void
c_ssl_bad_config_1()
{
    SSLv3_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv3_server_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv3_client_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv23_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv23_server_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv23_client_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv2_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv2_server_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
    SSLv2_client_method(); // expected-warning{{C_SSL_BAD_CONFIG}}
}

void clearenv();

void
c_setting_manipulation()
{
    clearenv(); // expected-warning{{C_SETTING_MANIPULATION}}
}

void strcpy();
void wcscpy();
void lstrcpy();

void
c_insecure_api_str()
{
    strcpy(); // expected-warning{{C_INSECURE_API_STR}}
    wcscpy(); // expected-warning{{C_INSECURE_API_STR}}
    lstrcpy(); // expected-warning{{C_INSECURE_API_STR}}
}

void xmlParseMemory();

void
c_injection_xxe()
{
    xmlParseMemory(); // expected-warning{{C_INJECTION_XXE}}
}

void setresuid();
void setregid();
void setegid();
void setrsuid();
void seteuid();
void setuid();
void setresgid();
void setreuid();
void setgid();

void
c_insecure_api_setuid()
{
    setresuid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setregid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setegid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setrsuid(); // expected-warning{{C_INSECURE_API_SETUID}}
    seteuid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setuid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setresgid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setreuid(); // expected-warning{{C_INSECURE_API_SETUID}}
    setgid(); // expected-warning{{C_INSECURE_API_SETUID}}
}

void srand48();
void erand48();
void drand48();
void mrand48();
void nrand48();
void lrand48();
void jrand48();
void srandom();
void random();
void random_r();
void initstate();
void lcong48();
void seed48();
void setstate();
void strfry();
void memfrob();

void
c_insecure_api_rand()
{
    srand48(); // expected-warning{{C_INSECURE_API_RAND}}
    erand48(); // expected-warning{{C_INSECURE_API_RAND}}
    drand48(); // expected-warning{{C_INSECURE_API_RAND}}
    mrand48(); // expected-warning{{C_INSECURE_API_RAND}}
    nrand48(); // expected-warning{{C_INSECURE_API_RAND}}
    lrand48(); // expected-warning{{C_INSECURE_API_RAND}}
    jrand48(); // expected-warning{{C_INSECURE_API_RAND}}
    srandom(); // expected-warning{{C_INSECURE_API_RAND}}
    random(); // expected-warning{{C_INSECURE_API_RAND}}
    random_r(); // expected-warning{{C_INSECURE_API_RAND}}
    initstate(); // expected-warning{{C_INSECURE_API_RAND}}
    lcong48(); // expected-warning{{C_INSECURE_API_RAND}}
    seed48(); // expected-warning{{C_INSECURE_API_RAND}}
    setstate(); // expected-warning{{C_INSECURE_API_RAND}}
    strfry(); // expected-warning{{C_INSECURE_API_RAND}}
    memfrob(); // expected-warning{{C_INSECURE_API_RAND}}
}

void strcmpi();
void PathAppend();
void memmem();
void getwd();
void PathCombineA();
void PathCombineW();
void PathCombine();
void WSAAsyncGetHostByAddr();
void WSAAsyncGetHostByName();
void PathAddExtensionA();
void PathAddExtensionW();
void PathAddExtension();
void getlogin();
void PathCanonicalizeA();
void PathCanonicalizeW();
void PathCanonicalize();
void vfork();
void gethostbyname();
void gethostbyaddr();
void LoadModule();
void strdupa();
void strndupa();
void alloca();
void* _alloca(unsigned long long size);
void PathAddBackslashA();
void PathAddBackslashW();
void PathAddBackslash();

void
id_not_found()
{
    strcmpi(); // expected-warning{{C_PORTABILITY_FLAW}}
    PathAppend(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    memmem(); // expected-warning{{C_PORTABILITY_FLAW}}
    getwd(); // expected-warning{{C_OBSOLETE}}
    PathCombineA(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathCombineW(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathCombine(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    WSAAsyncGetHostByAddr(); // expected-warning{{C_INSECURE_API_GETHOST}}
    WSAAsyncGetHostByName(); // expected-warning{{C_INSECURE_API_GETHOST}}
    PathAddExtensionA(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathAddExtensionW(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathAddExtension(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    getlogin(); // expected-warning{{C_INSECURE_API_GETLOGIN}}
    PathCanonicalizeA(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathCanonicalizeW(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathCanonicalize(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    vfork(); // expected-warning{{C_INSECURE_API_VFORK}}
    gethostbyname(); // expected-warning{{C_INSECURE_API_GETHOST}}
    gethostbyaddr(); // expected-warning{{C_INSECURE_API_GETHOST}}
    LoadModule(); // expected-warning{{C_OBSOLETE}}
    strdupa(); // expected-warning{{C_INSECURE_API_ALLOCA}}
    strndupa(); // expected-warning{{C_INSECURE_API_ALLOCA}}
    alloca(); // expected-warning{{C_INSECURE_API_ALLOCA}}
    _alloca(10U); // expected-warning{{C_INSECURE_API_ALLOCA}}
    PathAddBackslashA(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathAddBackslashW(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    PathAddBackslash(); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
}

void
c_crypto_bad_random_2()
{
    srand48(0); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    erand48(12345); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    nrand48(4567); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    jrand48(34534534); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    srandom(3453); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    initstate(5353); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    lcong48(5353); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    seed48(353); // expected-warning{{C_CRYPTO_BAD_SEED}}
		 // expected-warning@-1{{C_INSECURE_API_RAND}}
    srand(345345); // expected-warning{{C_CRYPTO_BAD_RANDOM}}
		 // expected-warning@-1{{C_CRYPTO_BAD_SEED}}
    rand_r(53453); // expected-warning{{C_CRYPTO_BAD_SEED}}
}

char *get_chars();

void printw();
void scanw();
void warn();
void warnx();
void vwarn();
void vwarnx();
void setproctitle();

void
c_format_string_1()
{
    printw(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    scanw(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    warn(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    warnx(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vwarn(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vwarnx(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    setproctitle(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    printw("%s");
    scanw("%s");
    warn("%s");
    warnx("%s");
    vwarn("%s");
    vwarnx("%s");
    setproctitle("%s");
}

void BCryptOpenAlgorithmProvider();
void NCryptIsAlgSupported();

void
c_crypto_bad_algorithm_2()
{
    BCryptOpenAlgorithmProvider(0, "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptOpenAlgorithmProvider(0, "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptOpenAlgorithmProvider(0, "skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptOpenAlgorithmProvider(0, "desede");
    BCryptOpenAlgorithmProvider(0, "3des");
    BCryptOpenAlgorithmProvider(0, "tripledes");
    NCryptIsAlgSupported(0, "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptIsAlgSupported(0, "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptIsAlgSupported(0, "skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptIsAlgSupported(0, "desede");
    NCryptIsAlgSupported(0, "3des");
    NCryptIsAlgSupported(0, "tripledes");
}

void CryptCreateHash();
void CryptHashCertificate();
void CryptHashPublicKeyInfo();
void CPCreateHash();

void
c_crypto_bad_hash_2()
{
    CryptCreateHash(0, 0);
    CryptCreateHash(0, 32769); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptCreateHash(0, 32770); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptCreateHash(0, 32771); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptCreateHash(0, 32772); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate(0, 0);
    CryptHashCertificate(0, 32769); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate(0, 32770); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate(0, 32771); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate(0, 32772); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashPublicKeyInfo(0, 0);
    CryptHashPublicKeyInfo(0, 32769); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashPublicKeyInfo(0, 32770); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashPublicKeyInfo(0, 32771); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashPublicKeyInfo(0, 32772); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CPCreateHash(0, 0);
    CPCreateHash(0, 32769); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CPCreateHash(0, 32770); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CPCreateHash(0, 32771); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CPCreateHash(0, 32772); // expected-warning{{C_CRYPTO_BAD_HASH}}
}

void fwprintf();
void vfwprintf();
void vfprintf();
void vsprintf();
void fprintf();
void sprintf();
void fscanf();
void sscanf();
void fwscanf();
void swscanf();
void vsyslog();
void syslog();

void
c_format_string_2()
{
    fwprintf(0, "%s");
    vfwprintf(0, "%s");
    vfprintf(0, "%s");
    vsprintf(0, "%s");
    fprintf(0, "%s");
    sprintf(0, "%s");
    fscanf(0, "%s");
    sscanf(0, "%s");
    fwscanf(0, "%s");
    swscanf(0, "%s");
    vsyslog(0, "%s");
    syslog(0, "%s");

    fwprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vfwprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vfprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    fprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    sprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    fscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    sscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    fwscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    swscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsyslog(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    syslog(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void RSA_generate_key();

void
c_crypto_key_size()
{
    RSA_generate_key(2048);
    RSA_generate_key(2047); // expected-warning{{C_CRYPTO_KEY_SIZE}}
}

void AES_set_encrypt_key();
void AES_set_decrypt_key();

void
c_crypto_key_size_2()
{
    AES_set_encrypt_key(0, 128);
    AES_set_decrypt_key(0, 128);
    AES_set_encrypt_key(0, 127); // expected-warning{{C_CRYPTO_KEY_SIZE}}
    AES_set_decrypt_key(0, 127); // expected-warning{{C_CRYPTO_KEY_SIZE}}
}

void RSA_generate_key_ex();

void
c_crypto_key_size_3()
{
    RSA_generate_key_ex(1, 2047); // expected-warning{{C_CRYPTO_KEY_SIZE}}
    RSA_generate_key_ex(1, 2048);
}

void BCryptOpenAlgorithmProvider();
void NCryptIsAlgSupported();

void
c_crypto_bad_algorithm_3()
{
    BCryptOpenAlgorithmProvider(0, "smt");
    BCryptOpenAlgorithmProvider(0, "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptIsAlgSupported(0, "smt");
    NCryptIsAlgSupported(0, "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void SSL_CTX_set_verify();
void SSL_set_verify();

void
c_ssl_bad_verification_1()
{
    SSL_CTX_set_verify('A', 1);
    SSL_set_verify('A', 1);
    SSL_CTX_set_verify('A', 0); // expected-warning{{C_SSL_BAD_VERIFICATION}}
    SSL_set_verify('A', 0); // expected-warning{{C_SSL_BAD_VERIFICATION}}
}

void BCryptGenerateSymmetricKey();

void
c_crypto_key_size_4()
{
    BCryptGenerateSymmetricKey(0, 1, 2, 3, 4, 16);
    BCryptGenerateSymmetricKey(0, 1, 2, 3, 4, 15); // expected-warning{{C_CRYPTO_KEY_SIZE}}
}

void PKCS5_PBKDF2_HMAC();
void PKCS5_PBKDF2_HMAC_SHA1();

void
c_crypto_bad_iteration_count_1()
{
    PKCS5_PBKDF2_HMAC(0, 1, 2, 3, 999); // expected-warning{{C_CRYPTO_BAD_ITERATION_COUNT}}
    PKCS5_PBKDF2_HMAC_SHA1(0, 1, 2, 3, 999); // expected-warning{{C_CRYPTO_BAD_HASH}}
		 // expected-warning@-1{{C_CRYPTO_BAD_ITERATION_COUNT}}
    PKCS5_PBKDF2_HMAC(0, 1, 2, 3, 100000);
    PKCS5_PBKDF2_HMAC_SHA1(0, 1, 2, 3, 100000); // expected-warning{{C_CRYPTO_BAD_HASH}}
    PKCS5_PBKDF2_HMAC(0, 1, 2, 3, 1000); // expected-warning{{C_CRYPTO_BAD_ITERATION_COUNT}}
    PKCS5_PBKDF2_HMAC_SHA1(0, 1, 2, 3, 1000); // expected-warning{{C_CRYPTO_BAD_HASH}}
		 // expected-warning@-1{{C_CRYPTO_BAD_ITERATION_COUNT}}
}

void DSA_generate_parameters_ex();
void EVP_PKEY_CTX_set_dsa_paramgen_bits();

void
c_crypto_key_size_5()
{
    DSA_generate_parameters_ex(0, 2048);
    EVP_PKEY_CTX_set_dsa_paramgen_bits(0, 2048);
    DSA_generate_parameters_ex(1, 2047); // expected-warning{{C_CRYPTO_KEY_SIZE}}
    EVP_PKEY_CTX_set_dsa_paramgen_bits(1, 2047); // expected-warning{{C_CRYPTO_KEY_SIZE}}
}

void SQLDriverConnect();

void
c_password_hardcoded()
{
    SQLDriverConnect(0, 1, "something");
    SQLDriverConnect(0, 1, "password"); // expected-warning{{C_PASSWORD_HARDCODED}}
    SQLDriverConnect(0, 1, "pwd"); // expected-warning{{C_PASSWORD_HARDCODED}}
    SQLDriverConnect(0, 1, "pwrd"); // expected-warning{{C_PASSWORD_HARDCODED}}
}

void mysql_change_user(int, int, char *);

void
c_password_hardcoded_2()
{
    mysql_change_user(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    mysql_change_user(0, 1, 0); // expected-warning{{C_PASSWORD_NULL}}
    mysql_change_user(0, 1, "pwd"); // expected-warning{{C_PASSWORD_HARDCODED}}
}

void BCryptEncrypt();
void BCryptDecrypt();

void
c_crypto_iv_hardcoded_1()
{
    BCryptEncrypt(0, 1, 2, 3, 4, 5, 6, 7, 8, 4);
    BCryptDecrypt(0, 1, 2, 3, 4, 5, 6, 7, 8, 4);
    BCryptEncrypt(0, 1, 2, 3, "IV", 5, 6, 7, 8, 4); // expected-warning{{C_CRYPTO_IV_HARDCODED}}
    BCryptDecrypt(0, 1, 2, 3, "IV", 5, 6, 7, 8, 4); // expected-warning{{C_CRYPTO_IV_HARDCODED}}
}

void CryptDecrypt();
void CryptEncrypt();

void
c_crypto_bad_padding_2()
{
    CryptDecrypt(0, 1, 2, 64);
    CryptEncrypt(0, 1, 2, 64);
    CryptDecrypt(0, 1, 2, 65); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    CryptEncrypt(0, 1, 2, 65); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void
c_crypto_bad_padding_3()
{
    BCryptEncrypt(0, 1, 2, 3, 4, 5, 6, 7, 8, 4);
    BCryptDecrypt(0, 1, 2, 3, 4, 5, 6, 7, 8, 4);
    BCryptEncrypt(0, 1, 2, 3, 4, 5, 6, 7, 8, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    BCryptDecrypt(0, 1, 2, 3, 4, 5, 6, 7, 8, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void _snwscanf_l();
void _snwscanf();
void _snscanf_l();
void _snscanf();
void _vstscanf_l();
void _vstscanf();
void wvnsprintf();
void vsnprintf();
void _vsnwprintf_l();
void _vsnwprintf();
void _vsntprintf_l();
void _vsntprintf();
void _vsnprintf_l();
void _vsnprintf();
void _snwprintf_l();
void _snwprintf();
void _sntprintf_l();
void _sntprintf();
void _snprintf_l();
void _snprintf();
void wnsprintfA();
void wnsprintfW();
void wnsprintf();
void vsnwprintfA();
void vsnwprintfW();
void vsnwprintf();
void StringCchVPrintfExA();
void StringCchVPrintfExW();
void StringCchVPrintfEx();
void StringCchVPrintfA();
void StringCchVPrintfW();
void StringCchVPrintf();
void StringCchPrintfExA();
void StringCchPrintfExW();
void StringCchPrintfEx();
void StringCchPrintfA();
void StringCchPrintfW();
void StringCchPrintf();
void StringCbVPrintfExA();
void StringCbVPrintfExW();
void StringCbVPrintfEx();
void StringCbVPrintfA();
void StringCbVPrintfW();
void StringCbVPrintf();
void StringCbPrintfExA();
void StringCbPrintfExW();
void StringCbPrintfEx();
void StringCbPrintfA();
void StringCbPrintfW();
void StringCbPrintf();

void
c_format_string_3()
{
    _snwscanf_l(0, 1, "string");
    _snwscanf(0, 1, "string");
    _snscanf_l(0, 1, "string");
    _snscanf(0, 1, "string");
    _vstscanf_l(0, 1, "string");
    _vstscanf(0, 1, "string");
    wvnsprintf(0, 1, "string");
    vsnprintf(0, 1, "string");
    _vsnwprintf_l(0, 1, "string");
    _vsnwprintf(0, 1, "string");
    _vsntprintf_l(0, 1, "string");
    _vsntprintf(0, 1, "string");
    _vsnprintf_l(0, 1, "string");
    _vsnprintf(0, 1, "string");
    _snwprintf_l(0, 1, "string");
    _snwprintf(0, 1, "string");
    _sntprintf_l(0, 1, "string");
    _sntprintf(0, 1, "string");
    _snprintf_l(0, 1, "string");
    _snprintf(0, 1, "string");
    wnsprintfA(0, 1, "string");
    wnsprintfW(0, 1, "string");
    wnsprintf(0, 1, "string");
    vsnwprintfA(0, 1, "string");
    vsnwprintfW(0, 1, "string");
    vsnwprintf(0, 1, "string");
    StringCchVPrintfExA(0, 1, "string");
    StringCchVPrintfExW(0, 1, "string");
    StringCchVPrintfEx(0, 1, "string");
    StringCchVPrintfA(0, 1, "string");
    StringCchVPrintfW(0, 1, "string");
    StringCchVPrintf(0, 1, "string");
    StringCchPrintfExA(0, 1, "string");
    StringCchPrintfExW(0, 1, "string");
    StringCchPrintfEx(0, 1, "string");
    StringCchPrintfA(0, 1, "string");
    StringCchPrintfW(0, 1, "string");
    StringCchPrintf(0, 1, "string");
    StringCbVPrintfExA(0, 1, "string");
    StringCbVPrintfExW(0, 1, "string");
    StringCbVPrintfEx(0, 1, "string");
    StringCbVPrintfA(0, 1, "string");
    StringCbVPrintfW(0, 1, "string");
    StringCbVPrintf(0, 1, "string");
    StringCbPrintfExA(0, 1, "string");
    StringCbPrintfExW(0, 1, "string");
    StringCbPrintfEx(0, 1, "string");
    StringCbPrintfA(0, 1, "string");
    StringCbPrintfW(0, 1, "string");
    StringCbPrintf(0, 1, "string");

    _snwscanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snscanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vstscanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vstscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wvnsprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsnprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnwprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnwprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsntprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsntprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _sntprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _sntprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wnsprintfA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wnsprintfW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wnsprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsnwprintfA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsnwprintfW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsnwprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchVPrintfExA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchVPrintfExW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchVPrintfEx(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchVPrintfA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchVPrintfW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchVPrintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchPrintfExA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchPrintfExW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchPrintfEx(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchPrintfA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchPrintfW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCchPrintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbVPrintfExA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbVPrintfExW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbVPrintfEx(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbVPrintfA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbVPrintfW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbVPrintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbPrintfExA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbPrintfExW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbPrintfEx(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbPrintfA(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbPrintfW(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    StringCbPrintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void
c_crypto_bad_algorithm_4()
{
    SslComputeClientAuthHash(0, 1, 2, "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    SslComputeClientAuthHash(0, 1, 2, "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    SslComputeClientAuthHash(0, 1, 2, "skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    SslComputeClientAuthHash(0, 1, 2, "desede");
    SslComputeClientAuthHash(0, 1, 2, "3des");
    SslComputeClientAuthHash(0, 1, 2, "tripledes");
}

void
c_crypto_bad_hash_3()
{
    BCryptOpenAlgorithmProvider(0, "somethingelse");
    BCryptOpenAlgorithmProvider(0, "md2"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    BCryptOpenAlgorithmProvider(0, "md4"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    BCryptOpenAlgorithmProvider(0, "md5"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    BCryptOpenAlgorithmProvider(0, "sha"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    BCryptOpenAlgorithmProvider(0, "sha1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    BCryptOpenAlgorithmProvider(0, "sha-1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
}

void mysql_connect(int, int, int, char *);
void mysql_real_connect(int, int, int, char *);

void
c_password_hardcoded_3()
{
    mysql_connect(0, 1, 2, get_chars());
    mysql_real_connect(0, 1, 2, get_chars());
    mysql_connect(0, 1, 2, "123"); // expected-warning{{C_PASSWORD_HARDCODED}}
    mysql_real_connect(0, 1, 2, "456"); // expected-warning{{C_PASSWORD_HARDCODED}}
}

void SQLConnect(int, int, int, int, int, char *);

void
c_password_hardcoded_4()
{
    SQLConnect(0, 1, 2, 3, 4, get_chars());
    SQLConnect(0, 1, 2, 3, 4, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
}

void mvwprintw();
void mvwscanw();

void
c_format_string_4()
{
    mvwprintw(0, 1, 2, "");
    mvwscanw(0, 1, 2, "");
    mvwprintw(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    mvwscanw(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void
c_password_null_1()
{
    SQLConnect(0, 1, 2, 3, 4, get_chars());
    SQLConnect(0, 1, 2, 3, 4, NULL); // expected-warning{{C_PASSWORD_NULL}}
}

void SslCreateClientAuthHash();

void
c_crypto_bad_algorithm_5()
{
    SslCreateClientAuthHash(0, 1, 13, 3, "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    SslCreateClientAuthHash(0, 1, 13, 3, "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    SslCreateClientAuthHash(0, 1, 13, 3, "skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    SslCreateClientAuthHash(0, 1, 13, 3, "desede");
    SslCreateClientAuthHash(0, 1, 13, 3, "3des");
    SslCreateClientAuthHash(0, 1, 13, 3, "tripledes");
}

void umask();

void
id_not_found_1()
{
    umask(022);
    umask(700); // expected-warning{{C_INVALID_UMASK}}
    umask(0700); // expected-warning{{C_INVALID_UMASK}}
    umask(644); // expected-warning{{C_INVALID_UMASK}}
    umask(0644); // expected-warning{{C_INVALID_UMASK}}
    umask(655); // expected-warning{{C_INVALID_UMASK}}
    umask(0655); // expected-warning{{C_INVALID_UMASK}}
}

void error();
void __error();

void
c_format_string_5()
{
    error(0, 1, "str");
    __error(0, 1, "str");
    error(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    __error(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void sprintf_s();
void swprintf_s();
void stprintf_s();
void vsprintf_s();
void vswprintf_s();
void _sprintf_s_l();
void _swprintf_s_l();
void _stprintf_s_l();
void _vsprintf_s_l();
void _vswprintf_s_l();
void _snwscanf_s_l();
void _snwscanf_s();
void _snscanf_s_l();
void _snscanf_s();

void
c_format_string_6()
{
    sprintf_s(0, 1, "str");
    swprintf_s(0, 1, "str");
    stprintf_s(0, 1, "str");
    vsprintf_s(0, 1, "str");
    vswprintf_s(0, 1, "str");
    _sprintf_s_l(0, 1, "str");
    _swprintf_s_l(0, 1, "str");
    _stprintf_s_l(0, 1, "str");
    _vsprintf_s_l(0, 1, "str");
    _vswprintf_s_l(0, 1, "str");
    _snwscanf_s_l(0, 1, "str");
    _snwscanf_s(0, 1, "str");
    _snscanf_s_l(0, 1, "str");
    _snscanf_s(0, 1, "str");

    sprintf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    swprintf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    stprintf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsprintf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vswprintf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _sprintf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _swprintf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _stprintf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsprintf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vswprintf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwscanf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwscanf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snscanf_s_l(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snscanf_s(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void g_fprintf();
void g_sprintf();
void g_vsprintf();
void g_vasprintf();
void g_scanner_warn();
void g_scanner_error();
void g_string_sprintf();
void g_string_snprintf();
void g_string_append_vprintf();
void g_string_append_printf();
void g_string_printf();
void g_prefix_error();

void
c_format_string_7()
{
    g_fprintf(0, "str");
    g_sprintf(0, "str");
    g_vsprintf(0, "str");
    g_vasprintf(0, "str");
    g_scanner_warn(0, "str");
    g_scanner_error(0, "str");
    g_string_sprintf(0, "str"); // expected-warning{{C_OBSOLETE}}
    g_string_snprintf(0, "str");
    g_string_append_vprintf(0, "str");
    g_string_append_printf(0, "str");
    g_string_printf(0, "str");
    g_prefix_error(0, "str");

    g_fprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_sprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_vsprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_vasprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_scanner_warn(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_scanner_error(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_string_sprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
		 // expected-warning@-1{{C_OBSOLETE}}
    g_string_snprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_string_append_vprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_string_append_printf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_string_printf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_prefix_error(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void wprintw();
void wscanw();
void vwprintw();
void vwscanw();
void vw_printw();
void vw_scanw();
void verrx();
void verr();
void errx();
void err();

void
c_format_string_8()
{
    wprintw(0, "str");
    wscanw(0, "str");
    vwprintw(0, "str");
    vwscanw(0, "str");
    vw_printw(0, "str");
    vw_scanw(0, "str");
    verrx(0, "str");
    verr(0, "str");
    errx(0, "str");
    err(0, "str");

    wprintw(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wscanw(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vwprintw(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vwscanw(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vw_printw(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vw_scanw(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    verrx(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    verr(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    errx(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    err(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void BCryptDeriveKeyPBKDF2();

void
c_crypto_bad_iteration_count_2()
{
    BCryptDeriveKeyPBKDF2(0, 1, 2, 3, 4, 100000);
    BCryptDeriveKeyPBKDF2(0, 1, 2, 3, 4, 1000); // expected-warning{{C_CRYPTO_BAD_ITERATION_COUNT}}
    BCryptDeriveKeyPBKDF2(0, 1, 2, 3, 4, 999); // expected-warning{{C_CRYPTO_BAD_ITERATION_COUNT}}
}

void EVP_get_digestbyname();

void
c_crypto_bad_hash_4()
{
    EVP_get_digestbyname("somethingelse");
    EVP_get_digestbyname("md2"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_get_digestbyname("md4"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_get_digestbyname("md5"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_get_digestbyname("ripemd160"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_get_digestbyname("sha"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_get_digestbyname("sha1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_get_digestbyname("sha-1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
}

void CryptDeriveKey();
void CryptGenKey();
void CPDeriveKey();
void CPGenKey();
void BCryptDeriveKeyCapi();

void
c_crypto_bad_algorithm_6()
{
    CryptDeriveKey(0, 0);
    CryptDeriveKey(0, 26113); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CryptDeriveKey(0, 26625); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CryptDeriveKey(0, 26122); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CryptGenKey(0, 0);
    CryptGenKey(0, 26113); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CryptGenKey(0, 26625); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CryptGenKey(0, 26122); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPDeriveKey(0, 0);
    CPDeriveKey(0, 26113); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPDeriveKey(0, 26625); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPDeriveKey(0, 26122); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPGenKey(0, 0);
    CPGenKey(0, 26113); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPGenKey(0, 26625); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPGenKey(0, 26122); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptDeriveKeyCapi(0, 0);
    BCryptDeriveKeyCapi(0, 26113); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptDeriveKeyCapi(0, 26625); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptDeriveKeyCapi(0, 26122); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void swprintf();
void vswprintf();

void
c_format_string_9()
{
    swprintf(0, 1, "str");
    vswprintf(0, 1, "str");

    swprintf(0, get_int(), "str"); // expected-warning{{C_BUFFER_OVERFLOW}}
    vswprintf(0, get_int(), "str"); // expected-warning{{C_BUFFER_OVERFLOW}}
}

void fprintf_s();
void fwprintf_s();
void vfprintf_s();
void vfwprintf_s();
void _fprintf_s_l();
void _fwprintf_s_l();
void _vfprintf_s_l();
void _vfwprintf_s_l();
void fscanf_s();
void fwscanf_s();
void sscanf_s();
void swscanf_s();
void _fscanf_s_l();
void _fwscanf_s_l();
void _sscanf_s_l();
void _swscanf_s_l();

void
c_format_string_10()
{
    fprintf_s(0, "str");
    fwprintf_s(0, "str");
    vfprintf_s(0, "str");
    vfwprintf_s(0, "str");
    _fprintf_s_l(0, "str");
    _fwprintf_s_l(0, "str");
    _vfprintf_s_l(0, "str");
    _vfwprintf_s_l(0, "str");
    fscanf_s(0, "str");
    fwscanf_s(0, "str");
    sscanf_s(0, "str");
    swscanf_s(0, "str");
    _fscanf_s_l(0, "str");
    _fwscanf_s_l(0, "str");
    _sscanf_s_l(0, "str");
    _swscanf_s_l(0, "str");

    fprintf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    fwprintf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vfprintf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vfwprintf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _fprintf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _fwprintf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfprintf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfwprintf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    fscanf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    fwscanf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    sscanf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    swscanf_s(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _fscanf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _fwscanf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _sscanf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _swscanf_s_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void
c_password_empty_2()
{
    mysql_change_user(0, 1, get_chars());
    mysql_change_user(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
}

void NCryptCreatePersistedKey();

void
c_crypto_bad_algorithm_7()
{
    NCryptCreatePersistedKey(0, 1, "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void
c_password_empty_3()
{
    mysql_connect(0, 1, 2, get_chars());
    mysql_real_connect(0, 1, 2, get_chars());

    mysql_connect(0, 1, 2, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    mysql_real_connect(0, 1, 2, ""); // expected-warning{{C_PASSWORD_EMPTY}}
}

void SslLookupCipherSuiteInfo();
void SslGetCipherSuitePRFHashAlgorithm();
void SslLookupCipherLengths();

void
c_ssl_bad_config_2()
{
    SslLookupCipherSuiteInfo(0, 1);
    SslGetCipherSuitePRFHashAlgorithm(0, 1);
    SslLookupCipherLengths(0, 1);

    SslLookupCipherSuiteInfo(0, 2); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslGetCipherSuitePRFHashAlgorithm(0, 2); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslLookupCipherLengths(0, 2); // expected-warning{{C_SSL_BAD_CONFIG}}

    SslLookupCipherSuiteInfo(0, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslGetCipherSuitePRFHashAlgorithm(0, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslLookupCipherLengths(0, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
}

void *get_pointer();

void ldap_sasl_bindA(int, int, int, void *);
void ldap_sasl_bindW(int, int, int, void *);
void ldap_sasl_bind(int, int, int, void *);
void ldap_sasl_bind_sA(int, int, int, void *);
void ldap_sasl_bind_sW(int, int, int, void *);
void ldap_sasl_bind_s(int, int, int, void *);

void
c_access_control_ldap_bind_1()
{
    ldap_sasl_bindA(0, 1, 2, get_pointer());
    ldap_sasl_bindW(0, 1, 2, get_pointer());
    ldap_sasl_bind(0, 1, 2, get_pointer());
    ldap_sasl_bind_sA(0, 1, 2, get_pointer());
    ldap_sasl_bind_sW(0, 1, 2, get_pointer());
    ldap_sasl_bind_s(0, 1, 2, get_pointer());

    ldap_sasl_bindA(0, 1, 2, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_sasl_bindW(0, 1, 2, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_sasl_bind(0, 1, 2, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_sasl_bind_sA(0, 1, 2, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_sasl_bind_sW(0, 1, 2, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_sasl_bind_s(0, 1, 2, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
}

void FormatMessageA();
void FormatMessageW();
void FormatMessage();

void
c_format_string_11()
{
    FormatMessageA(1, "str");
    FormatMessageW(1, "str");
    FormatMessage(1, "str");

    FormatMessageA(1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    FormatMessageW(1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    FormatMessage(1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void RSA_public_encrypt();
void RSA_private_encrypt();
void RSA_public_decrypt();
void RSA_private_decrypt();

void
c_crypto_bad_padding_4()
{
    RSA_public_encrypt(0, 1, 2, 3, 4);
    RSA_private_encrypt(0, 1, 2, 3, 4);
    RSA_public_decrypt(0, 1, 2, 3, 4);
    RSA_private_decrypt(0, 1, 2, 3, 4);

    RSA_public_encrypt(0, 1, 2, 3, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_private_encrypt(0, 1, 2, 3, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_public_decrypt(0, 1, 2, 3, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    RSA_private_decrypt(0, 1, 2, 3, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void g_rand_new_with_seed();
void g_rand_new_with_seed_array();
void g_random_set_seed();

void
c_crypto_bad_seed_1()
{
    g_rand_new_with_seed(get_int());
    g_rand_new_with_seed_array(get_int());
    g_random_set_seed(get_int());

    g_rand_new_with_seed(1); // expected-warning{{C_CRYPTO_BAD_SEED}}
    g_rand_new_with_seed_array((int[]){1, 2, 3}); // expected-warning{{C_CRYPTO_BAD_SEED}}
    g_random_set_seed(1); // expected-warning{{C_CRYPTO_BAD_SEED}}
}

void
c_crypto_bad_hash_5()
{
    NCryptCreatePersistedKey(0, 1, "somethingelse");
    NCryptCreatePersistedKey(0, 1, "md2"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    NCryptCreatePersistedKey(0, 1, "md4"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    NCryptCreatePersistedKey(0, 1, "md5"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    NCryptCreatePersistedKey(0, 1, "sha"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    NCryptCreatePersistedKey(0, 1, "sha1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    NCryptCreatePersistedKey(0, 1, "sha-1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
}

void g_set_error();

void
c_format_string_12()
{
    g_set_error(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_set_error(0, 1, 2, "string");
}

void
c_crypto_bad_algorithm_8()
{
    SslComputeClientAuthHash(0, 1, 3, "smt_else");
    SslComputeClientAuthHash(0, 1, 3, "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void DSA_generate_parameters();

void
c_crypto_key_size_6()
{
    DSA_generate_parameters(2048);
    DSA_generate_parameters(2047); // expected-warning{{C_CRYPTO_KEY_SIZE}}
}

void _cprintf_l();
void _cprintf();
void _cwprintf_l();
void _cwprintf();
void _tcprintf_l();
void _tcprintf();
void _tprintf_l();
void _tprintf();
void _vtprintf_l();
void _vtprintf();
void _printf_l();
void _printf();
void _wtscanf_l();
void _wtscanf();
void _cscanf_l();
void _cscanf();
void _cwscanf_l();
void _cwscanf();
void _scanf_l();
void _scanf();

void
c_format_string_13()
{
    _cprintf_l("format");
    _cprintf("format");
    _cwprintf_l("format");
    _cwprintf("format");
    _tcprintf_l("format");
    _tcprintf("format");
    _tprintf_l("format");
    _tprintf("format");
    _vtprintf_l("format");
    _vtprintf("format");
    _printf_l("format");
    _printf("format");
    _wtscanf_l("format");
    _wtscanf("format");
    _cscanf_l("format");
    _cscanf("format");
    _cwscanf_l("format");
    _cwscanf("format");
    _scanf_l("format");
    _scanf("format");

    _cprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cwprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cwprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _tcprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _tcprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _tprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _tprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vtprintf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vtprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _printf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _printf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _wtscanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _wtscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cscanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cwscanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _cwscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _scanf_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _scanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void mvprintw();
void mvscanw();

void
c_format_string_14()
{
    mvprintw(0, 1, "fmt");
    mvscanw(0, 1, "fmt");

    mvprintw(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    mvscanw(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void BCryptSetProperty();

void
c_crypto_bad_padding_5()
{
    BCryptSetProperty(0, "otherProperty", 2);
    BCryptSetProperty(0, "PaddingSchemes", 8);
    BCryptSetProperty(0, "PaDdiNGscheMes", 2014); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void
c_crypto_salt_hardcoded_1()
{
    crypt(0, get_chars()); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    crypt_r(0, get_chars()); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}

    crypt(0, "salt"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
		 // expected-warning@-1{{C_CRYPTO_SALT_HARDCODED}}
    crypt_r(0, "hardcoded"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
		 // expected-warning@-1{{C_CRYPTO_SALT_HARDCODED}}
}

void _snprintf_s();
void _snwprintf_s();
void vsnprintf_s();
void _vsnprintf_s();
void _vsnwprintf_s();
void _snprintf_s_l();
void _snwprintf_s_l();
void _vsnprintf_s_l();
void _vsnwprintf_s_l();

void
c_format_string_15()
{
    _snprintf_s(0, 1, 2, "fmt");
    _snwprintf_s(0, 1, 2, "fmt");
    vsnprintf_s(0, 1, 2, "fmt");
    _vsnprintf_s(0, 1, 2, "fmt");
    _vsnwprintf_s(0, 1, 2, "fmt");
    _snprintf_s_l(0, 1, 2, "fmt");
    _snwprintf_s_l(0, 1, 2, "fmt");
    _vsnprintf_s_l(0, 1, 2, "fmt");
    _vsnwprintf_s_l(0, 1, 2, "fmt");

    _snprintf_s(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwprintf_s(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsnprintf_s(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnprintf_s(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnwprintf_s(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snprintf_s_l(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _snwprintf_s_l(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnprintf_s_l(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vsnwprintf_s_l(0, 1, 2, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void snprintf();

void
c_format_string_16()
{
    snprintf(0, 1, "fmt");
    snprintf(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void BCryptVerifySignature();
void NCryptVerifySignature();

void
c_crypto_bad_padding_6()
{
    BCryptVerifySignature(0, 1, 2, 3, 4, 5, 0);
    NCryptVerifySignature(0, 1, 2, 3, 4, 5, 0);

    BCryptVerifySignature(0, 1, 2, 3, 4, 5, 1); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    NCryptVerifySignature(0, 1, 2, 3, 4, 5, 1); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void
c_password_null_2()
{
    mysql_change_user(0, 1, NULL); // expected-warning{{C_PASSWORD_NULL}}
    mysql_change_user(0, 1, get_chars());
}

void SslGenerateMasterKey();

void
ssl_bad_config_2()
{
    SslGenerateMasterKey(0, 1, 2, 3, 800);
    SslGenerateMasterKey(0, 1, 2, 3, 2); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslGenerateMasterKey(0, 1, 2, 3, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
}

void NCryptSetProperty();

void
c_crypto_bad_algorithm_9()
{
    BCryptSetProperty(0, "algorithmname", "somename");
    NCryptSetProperty(0, "algorithmname", "somename");

    BCryptSetProperty(0, "some property", "rc2");
    NCryptSetProperty(0, "some property", "rc2");

    BCryptSetProperty(0, "algorithmname", "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptSetProperty(0, "algorithmname", "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}

    BCryptSetProperty(0, "algorithm name", "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptSetProperty(0, "algorithm name", "rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void g_strdup_printf();
void g_vprintf();
void g_strdup_vprintf();
void g_printf();
void printf_string_upper_bound();
void g_printerr();
void g_print();
void markup_vprintf_escape();
void markup_printf_escape();
void g_debug();
void g_error();
void g_critical();
void g_message();
void g_warning();

void
c_format_string_17()
{
    g_strdup_printf("format");
    g_vprintf("format");
    g_strdup_vprintf("format");
    g_printf("format");
    printf_string_upper_bound("format");
    g_printerr("format");
    g_print("format");
    markup_vprintf_escape("format");
    markup_printf_escape("format");
    g_debug("format");
    g_error("format");
    g_critical("format");
    g_message("format");
    g_warning("format");

    g_strdup_printf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_vprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_strdup_vprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_printf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    printf_string_upper_bound(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_printerr(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_print(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    markup_vprintf_escape(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    markup_printf_escape(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_debug(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_error(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_critical(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_message(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_warning(get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void
c_crypto_iv_hardcoded_2()
{
    BCryptSetProperty(0, "prop", "123");
    BCryptSetProperty(0, "iv", get_chars());
    BCryptSetProperty(0, "iv", "123"); // expected-warning{{C_CRYPTO_IV_HARDCODED}}
    BCryptSetProperty(0, "IV", "123"); // expected-warning{{C_CRYPTO_IV_HARDCODED}}
}

void wprintf_s();
void _vcprintf_s();
void _vcwprintf_s();
void vprintf_s();
void vwprintf_s();
void printf_s();
void _wprintf_s_l();
void _vcprintf_s_l();
void _vcwprintf_s_l();
void _vprintf_s_l();
void _vwprintf_s_l();
void _printf_s_l();
void wscanf_s();
void scanf_s();
void _wscanf_s_l();
void _scanf_s_l();

void
c_format_string_18()
{
    wprintf_s("format");
    _vcprintf_s("format");
    _vcwprintf_s("format");
    vprintf_s("format");
    vwprintf_s("format");
    printf_s("format");
    _wprintf_s_l("format");
    _vcprintf_s_l("format");
    _vcwprintf_s_l("format");
    _vprintf_s_l("format");
    _vwprintf_s_l("format");
    _printf_s_l("format");
    wscanf_s("format");
    scanf_s("format");
    _wscanf_s_l("format");
    _scanf_s_l("format");

    wprintf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vcprintf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vcwprintf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vprintf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vwprintf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    printf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _wprintf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vcprintf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vcwprintf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vprintf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vwprintf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _printf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wscanf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    scanf_s(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _wscanf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _scanf_s_l(get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void EVP_get_cipherbyname();

void
c_crypto_bad_algorithm_10()
{
    EVP_get_cipherbyname("desede");
    EVP_get_cipherbyname("3des");
    EVP_get_cipherbyname("tripledes");

    EVP_get_cipherbyname("des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_get_cipherbyname("arcfour"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_get_cipherbyname("rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    EVP_get_cipherbyname("skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void ldap_simple_bindA(int, char *, char *);
void ldap_simple_bindW(int, char *, char *);
void ldap_simple_bind(int, char *, char *);
void ldap_simple_bind_sA(int, char *, char *);
void ldap_simple_bind_sW(int, char *, char *);
void ldap_simple_bind_s(int, char *, char *);

void
c_access_control_ldap_bind_2()
{
    ldap_simple_bindA(0, get_chars(), get_chars());
    ldap_simple_bindW(0, get_chars(), get_chars());
    ldap_simple_bind(0, get_chars(), get_chars());
    ldap_simple_bind_sA(0, get_chars(), get_chars());
    ldap_simple_bind_sW(0, get_chars(), get_chars());
    ldap_simple_bind_s(0, get_chars(), get_chars());

    ldap_simple_bindA(0, 0, get_chars()); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_simple_bindW(0, 0, get_chars()); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_simple_bind(0, 0, get_chars()); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_simple_bind_sA(0, 0, get_chars()); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_simple_bind_sW(0, 0, get_chars()); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
    ldap_simple_bind_s(0, 0, get_chars()); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}

    ldap_simple_bindA(0, get_chars(), 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bindW(0, get_chars(), 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind(0, get_chars(), 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_sA(0, get_chars(), 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_sW(0, get_chars(), 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_s(0, get_chars(), 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}

    ldap_simple_bindA(0, 0, 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bindW(0, 0, 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind(0, 0, 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_sA(0, 0, 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_sW(0, 0, 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_s(0, 0, 0); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
}

void ldap_search_extA();
void ldap_search_extW();
void ldap_search_ext();
void ldap_search_ext_sA();
void ldap_search_ext_sW();
void ldap_search_ext_s();
void ldap_searchA();
void ldap_searchW();
void ldap_search();
void ldap_search_sA();
void ldap_search_sW();
void ldap_search_s();
void ldap_search_stA();
void ldap_search_stW();
void ldap_search_st();
void ldap_search_init_pageA();
void ldap_search_init_pageW();
void ldap_search_init_page();

void
c_ldap_injection()
{
    ldap_search_extA(0, 1, 2, "literal");
    ldap_search_extW(0, 1, 2, "literal");
    ldap_search_ext(0, 1, 2, "literal");
    ldap_search_ext_sA(0, 1, 2, "literal");
    ldap_search_ext_sW(0, 1, 2, "literal");
    ldap_search_ext_s(0, 1, 2, "literal");
    ldap_searchA(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_searchW(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_sA(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_sW(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_s(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_stA(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_stW(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_st(0, 1, 2, "literal"); // expected-warning{{C_OBSOLETE}}
    ldap_search_init_pageA(0, 1, 2, "literal");
    ldap_search_init_pageW(0, 1, 2, "literal");
    ldap_search_init_page(0, 1, 2, "literal");

    ldap_search_extA(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_extW(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_ext(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_ext_sA(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_ext_sW(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_ext_s(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_searchA(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_searchW(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_sA(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_sW(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_s(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_stA(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_stW(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_st(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
		 // expected-warning@-1{{C_OBSOLETE}}
    ldap_search_init_pageA(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_init_pageW(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
    ldap_search_init_page(0, 1, 2, get_chars()); // expected-warning{{C_INJECTION_LDAP}}
}

void
c_crypto_salt_hardcoded_2()
{
    DES_crypt(0, get_chars()); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    DES_fcrypt(0, get_chars()); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}

    DES_crypt(0, "hardcoded"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
		 // expected-warning@-1{{C_CRYPTO_SALT_HARDCODED}}
    DES_fcrypt(0, "salt"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
		 // expected-warning@-1{{C_CRYPTO_SALT_HARDCODED}}
}

void
c_crypto_salt_hardcoded_3()
{
    PKCS5_PBKDF2_HMAC(0, 1, get_chars());
    PKCS5_PBKDF2_HMAC_SHA1(0, 1, get_chars()); // expected-warning{{C_CRYPTO_BAD_HASH}}

    PKCS5_PBKDF2_HMAC(0, 1, "salt"); // expected-warning{{C_CRYPTO_SALT_HARDCODED}}
    PKCS5_PBKDF2_HMAC_SHA1(0, 1, "hardcoded"); // expected-warning{{C_CRYPTO_BAD_HASH}}
		 // expected-warning@-1{{C_CRYPTO_SALT_HARDCODED}}
}

void
c_crypto_bad_algorithm_11()
{
    BCryptSetProperty(0, "algorithmname", "desede");
    BCryptSetProperty(0, "algorithmname", "3des");
    BCryptSetProperty(0, "algorithmname", "tripledes");
    NCryptSetProperty(0, "algorithmname", "desede");
    NCryptSetProperty(0, "algorithmname", "3des");
    NCryptSetProperty(0, "algorithmname", "tripledes");

    BCryptSetProperty(0, "some property", "des");
    BCryptSetProperty(0, "some property", "rc4");
    BCryptSetProperty(0, "some property", "skipjack");
    NCryptSetProperty(0, "some property", "des");
    NCryptSetProperty(0, "some property", "rc4");
    NCryptSetProperty(0, "some property", "skipjack");

    BCryptSetProperty(0, "algorithmname", "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptSetProperty(0, "algorithmname", "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptSetProperty(0, "algorithmname", "skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptSetProperty(0, "algorithmname", "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptSetProperty(0, "algorithmname", "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptSetProperty(0, "algorithmname", "skipjack"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void sqlite3_prepare();
void sqlite3_prepare_v2();
void sqlite3_prepare_v3();
void sqlite3_prepare16();
void sqlite3_prepare16_v2();
void sqlite3_prepare16_v3();

void
c_injection_sql_3()
{
    sqlite3_prepare(0, "select * from table");
    sqlite3_prepare_v2(0, "select * from table");
    sqlite3_prepare_v3(0, "select * from table");
    sqlite3_prepare16(0, "select * from table");
    sqlite3_prepare16_v2(0, "select * from table");
    sqlite3_prepare16_v3(0, "select * from table");

    sqlite3_prepare(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    sqlite3_prepare_v2(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    sqlite3_prepare_v3(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    sqlite3_prepare16(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    sqlite3_prepare16_v2(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    sqlite3_prepare16_v3(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
}

void ldapssl_enable_clientauth(int, int, char *);

void
c_password_hardcoded_5()
{
    ldap_simple_bindA(0, 1, get_chars());
    ldap_simple_bindW(0, 1, get_chars());
    ldap_simple_bind(0, 1, get_chars());
    ldap_simple_bind_sA(0, 1, get_chars());
    ldap_simple_bind_sW(0, 1, get_chars());
    ldap_simple_bind_s(0, 1, get_chars());
    ldapssl_enable_clientauth(0, 1, get_chars());
    ldap_bindA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bindW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_s(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}

    ldap_simple_bindA(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldap_simple_bindW(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldap_simple_bind(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldap_simple_bind_sA(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldap_simple_bind_sW(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldap_simple_bind_s(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldapssl_enable_clientauth(0, 1, "hardcoded"); // expected-warning{{C_PASSWORD_HARDCODED}}
    ldap_bindA(0, 1, "hardcoded"); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_HARDCODED}}
    ldap_bindW(0, 1, "hardcoded"); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_HARDCODED}}
    ldap_bind(0, 1, "hardcoded"); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_HARDCODED}}
    ldap_bind_sA(0, 1, "hardcoded"); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_HARDCODED}}
    ldap_bind_sW(0, 1, "hardcoded"); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_HARDCODED}}
    ldap_bind_s(0, 1, "hardcoded"); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_HARDCODED}}
}

void NCryptDecrypt();
void NCryptEncrypt();

void
c_crypto_bad_padding_7()
{
    NCryptDecrypt(0, 1, 2, 3, 4, 5, 6, 4);
    NCryptEncrypt(0, 1, 2, 3, 4, 5, 6, 4);

    NCryptDecrypt(0, 1, 2, 3, 4, 5, 6, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
    NCryptEncrypt(0, 1, 2, 3, 4, 5, 6, 5); // expected-warning{{C_CRYPTO_BAD_PADDING}}
}

void SslImportMasterKey();

void
c_ssl_bad_config_3()
{
    SslImportMasterKey(0, 1, 2, 3);
    SslImportMasterKey(0, 1, 2, 2); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslImportMasterKey(0, 1, 2, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
}

void g_vsnprintf();
void g_snprintf();
void g_ascii_formatd();
void g_error_new();
void g_propagate_prefixed_error();
void g_logv();
void g_log();

void
c_format_string_19()
{
    g_vsnprintf(0, 1, "format");
    g_snprintf(0, 1, "format");
    g_ascii_formatd(0, 1, "format");
    g_error_new(0, 1, "format");
    g_propagate_prefixed_error(0, 1, "format");
    g_logv(0, 1, "format");
    g_log(0, 1, "format");

    g_vsnprintf(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_snprintf(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_ascii_formatd(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_error_new(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_propagate_prefixed_error(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_logv(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    g_log(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void BCryptSignHash();
void NCryptSignHash();

void
c_ssl_bad_config_4()
{
    BCryptSignHash(0, 1, 2, 3, 4, 5, 6, 0);
    NCryptSignHash(0, 1, 2, 3, 4, 5, 6, 0);

    BCryptSignHash(0, 1, 2, 3, 4, 5, 6, 1); // expected-warning{{C_SSL_BAD_CONFIG}}
    NCryptSignHash(0, 1, 2, 3, 4, 5, 6, 1); // expected-warning{{C_SSL_BAD_CONFIG}}
}

void g_rand_set_seed();
void g_rand_set_seed_array();

void
c_crypto_bad_seed_2()
{
    g_rand_set_seed(0, get_int());
    g_rand_set_seed_array(0, get_int());

    g_rand_set_seed(0, 1); // expected-warning{{C_CRYPTO_BAD_SEED}}
    g_rand_set_seed_array(0, (int[]){1}); // expected-warning{{C_CRYPTO_BAD_SEED}}
}

void
c_crypto_bad_algorithm_12()
{
    SslCreateClientAuthHash(0, 1, 13, 3, "alg");
    SslCreateClientAuthHash(0, 1, 13, 3, "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void
c_crypto_bad_algorithm_13()
{
    BCryptSetProperty(0, "someprop");
    BCryptSetProperty(0, "EffectiveKeyLength"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void
c_crypto_bad_algorithm_14()
{
    EVP_get_cipherbyname("some_alg");
    EVP_get_cipherbyname("rc2"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void SslCreateClientAuthHash();
void SslCreateEphemeralKey();
void SslCreateHandshakeHash();

void
c_crypto_bad_config()
{
    SslCreateClientAuthHash(0, 1, 3);
    SslCreateEphemeralKey(0, 1, 3);
    SslCreateHandshakeHash(0, 1, 3);

    SslCreateClientAuthHash(0, 1, 2); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslCreateEphemeralKey(0, 1, 2); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslCreateHandshakeHash(0, 1, 2); // expected-warning{{C_SSL_BAD_CONFIG}}

    SslCreateClientAuthHash(0, 1, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslCreateEphemeralKey(0, 1, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
    SslCreateHandshakeHash(0, 1, 768); // expected-warning{{C_SSL_BAD_CONFIG}}
}

void wprintf();
void vwprintf();
void vprintf();
void printf();
void wscanf();
void vscanf();
void scanf();

void
c_format_string_20()
{
    wprintf("format");
    vwprintf("format");
    vprintf("format");
    printf("format");
    wscanf("format");
    vscanf("format");
    scanf("format");

    wprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vwprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vprintf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    printf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vscanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    scanf(get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void SQLExecDirectW();
void SQLExecDirect();
void SQLPrepareW();

void
c_injection_sql_1()
{
    SQLExecDirectW(0, "select * from ");
    SQLExecDirect(0, "select * from ");
    SQLPrepareW(0, "select * from ");

    SQLExecDirectW(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    SQLExecDirect(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    SQLPrepareW(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
}

void
c_password_null_3()
{
    mysql_connect(0, 1, 2, get_chars());
    mysql_real_connect(0, 1, 2, get_chars());

    mysql_connect(0, 1, 2, NULL); // expected-warning{{C_PASSWORD_NULL}}
    mysql_real_connect(0, 1, 2, NULL); // expected-warning{{C_PASSWORD_NULL}}
}

void
c_crypto_bad_algorithm_15()
{
    BCryptSetProperty(0, "ChainingMode", "Chaining");
    BCryptSetProperty(0, "Mode", "ChainingModeECB");
    BCryptSetProperty(0, "ChainingMode", "ChainingModeECB"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void mysql_query();
void mysql_real_query();
void mysql_stmt_prepare();

void
c_injection_sql_2()
{
    mysql_query(0, "query");
    mysql_real_query(0, "query");
    mysql_stmt_prepare(0, "query");

    mysql_query(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    mysql_real_query(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
    mysql_stmt_prepare(0, get_chars()); // expected-warning{{C_INJECTION_SQL}}
}

void vfscanf();
void vsscanf();
void _ftscanf();
void _stscanf();
void _vftprintf();
void _ftprintf();
void _vfwprintf_p_l();
void _vfwprintf_p();
void _vfprintf_p_l();
void _vfprintf_p();
void _vfwprintf_l();
void _vfprintf_l();
void wvsprintf();
void wsprintf();

void
c_format_string_21()
{
    vfscanf(0, "format");
    vsscanf(0, "format");
    _ftscanf(0, "format");
    _stscanf(0, "format");
    _vftprintf(0, "format");
    _ftprintf(0, "format");
    _vfwprintf_p_l(0, "format");
    _vfwprintf_p(0, "format");
    _vfprintf_p_l(0, "format");
    _vfprintf_p(0, "format");
    _vfwprintf_l(0, "format");
    _vfprintf_l(0, "format");
    wvsprintf(0, "format");
    wsprintf(0, "format");

    vfscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vsscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _ftscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _stscanf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vftprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _ftprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfwprintf_p_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfwprintf_p(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfprintf_p_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfprintf_p(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfwprintf_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    _vfprintf_l(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wvsprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    wsprintf(0, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void
c_crypto_key_size_7()
{
    BCryptSetProperty(0, "KeyLength", 128);
    BCryptSetProperty(0, "Length", 127);
    BCryptSetProperty(0, "KeyLength", 127); // expected-warning{{C_CRYPTO_KEY_SIZE}}
}

void
c_crypto_bad_algorithm_16()
{
    CryptDeriveKey(0, 1);
    CryptGenKey(0, 1);
    CPDeriveKey(0, 1);
    CPGenKey(0, 1);
    BCryptDeriveKeyCapi(0, 1);

    CryptDeriveKey(0, 26114); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CryptGenKey(0, 26114); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPDeriveKey(0, 26114); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    CPGenKey(0, 26114); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    BCryptDeriveKeyCapi(0, 26114); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void
c_password_null_4()
{
    ldap_simple_bindA(0, 1, get_chars());
    ldap_simple_bindW(0, 1, get_chars());
    ldap_simple_bind(0, 1, get_chars());
    ldap_simple_bind_sA(0, 1, get_chars());
    ldap_simple_bind_sW(0, 1, get_chars());
    ldap_simple_bind_s(0, 1, get_chars());
    ldapssl_enable_clientauth(0, 1, get_chars());
    ldap_bindA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bindW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_s(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}

    ldap_simple_bindA(0, 1, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bindW(0, 1, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind(0, 1, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_sA(0, 1, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_sW(0, 1, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_simple_bind_s(0, 1, NULL); // expected-warning{{C_ACCESS_CONTROL_LDAP_BIND}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldapssl_enable_clientauth(0, 1, NULL); // expected-warning{{C_PASSWORD_NULL}}
    ldap_bindA(0, 1, NULL); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_bindW(0, 1, NULL); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_bind(0, 1, NULL); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_bind_sA(0, 1, NULL); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_bind_sW(0, 1, NULL); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
    ldap_bind_s(0, 1, NULL); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_NULL}}
}

void
c_crypto_salt_hardcoded_4()
{
    BCryptDeriveKeyPBKDF2(0, 1, 2, get_chars());
    BCryptDeriveKeyPBKDF2(0, 1, 2, "salt"); // expected-warning{{C_CRYPTO_SALT_HARDCODED}}
}

void
c_crypto_bad_hash_6()
{
    CryptHashCertificate2("somethingelse");
    CryptHashCertificate2("md2"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate2("md4"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate2("md5"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate2("sha"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate2("sha1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
    CryptHashCertificate2("sha-1"); // expected-warning{{C_CRYPTO_BAD_HASH}}
}

void
c_crypto_bad_algorithm_17()
{
    NCryptCreatePersistedKey(0, 1, "desede");
    NCryptCreatePersistedKey(0, 1, "3des");
    NCryptCreatePersistedKey(0, 1, "tripledes");

    NCryptCreatePersistedKey(0, 1, "des"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
    NCryptCreatePersistedKey(0, 1, "rc4"); // expected-warning{{C_CRYPTO_BAD_ALGORITHM}}
}

void
c_format_string_22()
{
    swprintf(0, 1, "str");
    vswprintf(0, 1, "str");

    swprintf(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
    vswprintf(0, 1, get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

void
c_password_empty_4()
{
    SQLConnect(0, 1, 2, 3, 4, get_chars());
    SQLConnect(0, 1, 2, 3, 4, ""); // expected-warning{{C_PASSWORD_EMPTY}}
}

void
c_password_empty_5()
{
    ldap_simple_bindA(0, 1, get_chars());
    ldap_simple_bindW(0, 1, get_chars());
    ldap_simple_bind(0, 1, get_chars());
    ldap_simple_bind_sA(0, 1, get_chars());
    ldap_simple_bind_sW(0, 1, get_chars());
    ldap_simple_bind_s(0, 1, get_chars());
    ldapssl_enable_clientauth(0, 1, get_chars());
    ldap_bindA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bindW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sA(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_sW(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}
    ldap_bind_s(0, 1, get_chars()); // expected-warning{{C_OBSOLETE}}

    ldap_simple_bindA(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldap_simple_bindW(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldap_simple_bind(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldap_simple_bind_sA(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldap_simple_bind_sW(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldap_simple_bind_s(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldapssl_enable_clientauth(0, 1, ""); // expected-warning{{C_PASSWORD_EMPTY}}
    ldap_bindA(0, 1, ""); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_EMPTY}}
    ldap_bindW(0, 1, ""); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_EMPTY}}
    ldap_bind(0, 1, ""); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_EMPTY}}
    ldap_bind_sA(0, 1, ""); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_EMPTY}}
    ldap_bind_sW(0, 1, ""); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_EMPTY}}
    ldap_bind_s(0, 1, ""); // expected-warning{{C_OBSOLETE}}
		 // expected-warning@-1{{C_PASSWORD_EMPTY}}
}
