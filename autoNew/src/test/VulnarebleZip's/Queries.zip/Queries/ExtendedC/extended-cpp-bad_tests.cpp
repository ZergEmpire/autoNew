// RUN: iccheck++ -c %s

char *get_chars();
int get_int();

class CDaoQueryDef
{
public:
    void Create(char *str, char *str2);
    void SetSQL(char *str);
};

class CDaoDatabase
{
public:
    void Execute(char *str);
};

class CDatabase
{
public:
    void ExecuteSQL(char *str);
};
void
c_injection_sql()
{
    CDaoQueryDef query;
    query.Create("str", "str");
    query.Create("str", get_chars()); // expected-warning{{C_INJECTION_SQL}}
    query.SetSQL("str");
    query.SetSQL(get_chars()); // expected-warning{{C_INJECTION_SQL}}

    CDaoDatabase db;
    db.Execute("str");
    db.Execute(get_chars()); // expected-warning{{C_INJECTION_SQL}}

    CDatabase database;
    database.ExecuteSQL("sql");
    database.ExecuteSQL(get_chars()); // expected-warning{{C_INJECTION_SQL}}
}

class CHString
{
public:
    void FormatMessageW(unsigned int id);
    void FormatV(char *string);
};

class CString
{
public:
    void FormatMessage(unsigned int id);
    void FormatV(char *string);
    void FormatMessageV(char *string);
    void Format(char *string);
};

void
c_format_string()
{
    CHString string;
    string.FormatMessageW(0);
    string.FormatV("string");
    string.FormatMessageW(get_int()); // expected-warning{{C_FORMAT_STRING}}
    string.FormatV(get_chars()); // expected-warning{{C_FORMAT_STRING}}

    CString str;
    str.FormatMessage(0);
    str.FormatV("str");
    str.FormatMessageV("str");
    str.Format("str");
    str.FormatMessage(get_int()); // expected-warning{{C_FORMAT_STRING}}
    str.FormatV(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    str.FormatMessageV(get_chars()); // expected-warning{{C_FORMAT_STRING}}
    str.Format(get_chars()); // expected-warning{{C_FORMAT_STRING}}
}

class CException
{
public:
    void ReportError();
};

void
c_information_leak_internal()
{
    CException exception;
    exception.ReportError(); // expected-warning{{C_INFORMATION_LEAK_INTERNAL}}
}
