// RUN: iccheck -c %s

typedef int wchar_t;
char *gets(char *buffer);
char *_getts(char *buffer);
wchar_t *_getws(wchar_t *buffer);

void
call_gets()
{
    char *buf;
    wchar_t *wbuf;
    gets(buf);    // expected-warning{{C_INSECURE_API_GETS}}
    _getws(wbuf); // expected-warning{{C_INSECURE_API_GETS}}
    _getts(buf);  // expected-warning{{C_INSECURE_API_GETS}}
}

typedef struct EVP_MD_
{
} EVP_MD;
const EVP_MD *EVP_md2();
const EVP_MD *EVP_md4();
const EVP_MD *EVP_md5();
const EVP_MD *EVP_sha();
const EVP_MD *EVP_sha1();
const EVP_MD *EVP_ripemd160();
const EVP_MD *EVP_md_null();
int PKCS5_PBKDF2_HMAC(const char *pass, int passlen, const unsigned char *salt, int saltlen,
                      int iter, const EVP_MD *digest, int keylen, unsigned char *out);

void
openssl_weak_hash()
{
    EVP_md2();                                            // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_md4();                                            // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_md5();                                            // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_sha();                                            // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_sha1();                                           // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_ripemd160();                                      // expected-warning{{C_CRYPTO_BAD_HASH}}
    EVP_md_null();                                        // expected-warning{{C_CRYPTO_BAD_HASH}}
    PKCS5_PBKDF2_HMAC_SHA1(0, 0, 0, 0, 1000000, 0, 0, 0); // expected-warning{{C_CRYPTO_BAD_HASH}}
}
