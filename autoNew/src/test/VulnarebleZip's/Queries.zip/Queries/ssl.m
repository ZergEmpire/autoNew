// RUN: iccheck -target x86_64-apple-darwin -c %s
// XFAIL: *

#define YES __objc_yes
#define NO __objc_no

typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef signed char BOOL;
typedef struct _NSZone NSZone;

@class NSInvocation, NSMethodSignature, NSCoder, NSString, NSEnumerator,
    NSURLAuthenticationChallenge;

@protocol NSObject
@end

@protocol NSCopying
- (id)copyWithZone:(NSZone *)zone;
@end

@protocol NSMutableCopying
- (id)mutableCopyWithZone:(NSZone *)zone;
@end

@protocol NSCoding
- (void)encodeWithCoder:(NSCoder *)aCoder;
@end

@protocol NSSecureCoding <NSCoding>
@required
+ (BOOL)supportsSecureCoding;
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

typedef struct
{
    unsigned long state;
    id *itemsPtr;
    unsigned long *mutationsPtr;
    unsigned long extra[5];
} NSFastEnumerationState;

@protocol NSFastEnumeration
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state
                                  objects:(id[])buffer
                                    count:(NSUInteger)len;
@end

@interface NSNumber : NSObject
@end

@interface NSNumber (NSNumberCreation)
- (id)initWithChar:(char)value;
- (id)initWithUnsignedChar:(unsigned char)value;
- (id)initWithShort:(short)value;
- (id)initWithUnsignedShort:(unsigned short)value;
- (id)initWithInt:(int)value;
- (id)initWithUnsignedInt:(unsigned int)value;
- (id)initWithLong:(long)value;
- (id)initWithUnsignedLong:(unsigned long)value;
- (id)initWithLongLong:(long long)value;
- (id)initWithUnsignedLongLong:(unsigned long long)value;
- (id)initWithFloat:(float)value;
- (id)initWithDouble:(double)value;
- (id)initWithBool:(BOOL)value;
- (id)initWithInteger:(NSInteger)value;
- (id)initWithUnsignedInteger:(NSUInteger)value;

+ (NSNumber *)numberWithChar:(char)value;
+ (NSNumber *)numberWithUnsignedChar:(unsigned char)value;
+ (NSNumber *)numberWithShort:(short)value;
+ (NSNumber *)numberWithUnsignedShort:(unsigned short)value;
+ (NSNumber *)numberWithInt:(int)value;
+ (NSNumber *)numberWithUnsignedInt:(unsigned int)value;
+ (NSNumber *)numberWithLong:(long)value;
+ (NSNumber *)numberWithUnsignedLong:(unsigned long)value;
+ (NSNumber *)numberWithLongLong:(long long)value;
+ (NSNumber *)numberWithUnsignedLongLong:(unsigned long long)value;
+ (NSNumber *)numberWithFloat:(float)value;
+ (NSNumber *)numberWithDouble:(double)value;
+ (NSNumber *)numberWithBool:(BOOL)value;
+ (NSNumber *)numberWithInteger:(NSInteger)value;
+ (NSNumber *)numberWithUnsignedInteger:(NSUInteger)value;
@end

@interface NSDictionary : NSObject <NSCopying, NSMutableCopying, NSSecureCoding, NSFastEnumeration>
- (NSUInteger)count;
- (id)objectForKey:(id)aKey;
- (NSEnumerator *)keyEnumerator;
- (id)objectForKeyedSubscript:(id)key;
+ (id)dictionaryWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
- (id)initWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
@end

@interface NSDictionary (NSDictionaryCreation)
+ (id)dictionary;
+ (id)dictionaryWithObject:(id)object forKey:(id)key;
+ (instancetype)dictionaryWithObjects:(const id[])objects
                              forKeys:(const id[])keys
                                count:(NSUInteger)cnt;
@end

@interface NSMutableDictionary : NSDictionary
- (void)removeObjectForKey:(id)aKey;
- (void)setObject:(id)anObject forKey:(id)aKey;
@end

@interface NSMutableDictionary (NSExtendedMutableDictionary)
- (void)addEntriesFromDictionary:(NSDictionary *)otherDictionary;
- (void)removeAllObjects;
- (void)setDictionary:(NSDictionary *)otherDictionary;
- (void)setObject:(id)obj forKeyedSubscript:(id)key;
@end

@interface NSURLRequest
+ (void)setAllowsAnyHTTPSCertificate:(BOOL)allow forHost:(NSString *)host;
@end

@interface NSURLAuthenticationChallengeSender
- (void)continueWithoutCredentialForAuthenticationChallenge:
    (NSURLAuthenticationChallenge *)challenge;
@end

@interface NSURLSession
@property(class, readonly, strong) NSURLSession *sharedSession;
@end

@interface AFSecurityPolicy
@property(nonatomic, assign) BOOL allowInvalidCertificates;
@end

typedef const struct __CFString *CFStringRef;

extern const CFStringRef kCFStreamPropertySSLPeerCertificates;
extern const CFStringRef kCFStreamPropertySSLSettings;
extern const CFStringRef kCFStreamSSLLevel;
extern const CFStringRef kCFStreamSSLAllowsExpiredCertificates;
extern const CFStringRef kCFStreamSSLAllowsExpiredRoots;
extern const CFStringRef kCFStreamSSLAllowsAnyRoot;
extern const CFStringRef kCFStreamSSLValidatesCertificateChain;
extern const CFStringRef kCFStreamSSLPeerName;
extern const CFStringRef kCFStreamSSLCertificates;
extern const CFStringRef kCFStreamSSLIsServer;
extern const CFStringRef kCFStreamPropertySocketSecurityLevel;
extern const CFStringRef kCFStreamSocketSecurityLevelNone;
extern const CFStringRef kCFStreamSocketSecurityLevelSSLv2;
extern const CFStringRef kCFStreamSocketSecurityLevelSSLv3;
extern const CFStringRef kCFStreamSocketSecurityLevelTLSv1;
extern const CFStringRef kCFStreamSocketSecurityLevelNegotiatedSSL;

void
testUnsafeSSL()
{
    NSMutableDictionary *settings;

    [settings setObject:@"www.example.com" forKey:(NSString *)kCFStreamSSLPeerName];
    settings[(NSString *)kCFStreamSSLPeerName] = @"www.example.com";
    [settings
        setObject:[NSNumber numberWithBool:YES] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
           forKey:(NSString *)kCFStreamSSLAllowsExpiredRoots];
    [settings setObject:[NSNumber numberWithBool:NO]
                 forKey:(NSString *)kCFStreamSSLAllowsExpiredRoots];
    settings[(NSString *)kCFStreamSSLAllowsExpiredRoots] = [NSNumber
        numberWithBool:YES]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    settings[(NSString *)kCFStreamSSLAllowsExpiredRoots] = [NSNumber numberWithBool:NO];
    [settings
        setObject:[NSNumber numberWithBool:YES] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
           forKey:(NSString *)kCFStreamSSLAllowsExpiredCertificates];
    [settings setObject:[NSNumber numberWithBool:NO]
                 forKey:(NSString *)kCFStreamSSLAllowsExpiredCertificates];
    settings[(NSString *)kCFStreamSSLAllowsExpiredCertificates] = [NSNumber
        numberWithBool:YES]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    settings[(NSString *)kCFStreamSSLAllowsExpiredCertificates] = [NSNumber numberWithBool:NO];
    [settings
        setObject:[NSNumber numberWithBool:YES]
           forKey:(NSString *)
                      kCFStreamSSLAllowsAnyRoot]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    [settings setObject:[NSNumber numberWithBool:NO] forKey:(NSString *)kCFStreamSSLAllowsAnyRoot];
    settings[(NSString *)kCFStreamSSLAllowsAnyRoot] = [NSNumber
        numberWithBool:YES]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    settings[(NSString *)kCFStreamSSLAllowsAnyRoot] = [NSNumber numberWithBool:NO];
    [settings
        setObject:[NSNumber numberWithBool:NO] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
           forKey:(NSString *)kCFStreamSSLValidatesCertificateChain];
    [settings setObject:[NSNumber numberWithBool:YES]
                 forKey:(NSString *)kCFStreamSSLValidatesCertificateChain];
    settings[(NSString *)kCFStreamSSLValidatesCertificateChain] = [NSNumber
        numberWithBool:NO]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    settings[(NSString *)kCFStreamSSLValidatesCertificateChain] = [NSNumber numberWithBool:YES];
    [settings
        setObject:
            (NSString *)
                kCFStreamSocketSecurityLevelNone // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
           forKey:(NSString *)kCFStreamSSLLevel];
    [settings
        setObject:
            (NSString *)
                kCFStreamSocketSecurityLevelSSLv2 // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
           forKey:(NSString *)kCFStreamSSLLevel];
    [settings
        setObject:
            (NSString *)
                kCFStreamSocketSecurityLevelSSLv3 // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
           forKey:(NSString *)kCFStreamSSLLevel];
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)
        kCFStreamSocketSecurityLevelNone; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)
        kCFStreamSocketSecurityLevelSSLv2; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)
        kCFStreamSocketSecurityLevelSSLv3; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelTLSv1
                 forKey:(NSString *)kCFStreamSSLLevel];
    [settings setObject:(NSString *)kCFStreamSocketSecurityLevelNegotiatedSSL
                 forKey:(NSString *)kCFStreamSSLLevel];
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelTLSv1;
    settings[(NSString *)kCFStreamSSLLevel] = (NSString *)kCFStreamSocketSecurityLevelNegotiatedSSL;

    NSDictionary *f_settings1 =
        [[NSDictionary alloc] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelNone, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings2 = [[NSDictionary alloc]
        initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                               [NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredCertificates,
                               [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                               [NSNumber numberWithBool:YES], kCFStreamSSLValidatesCertificateChain,
                               kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                               @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings3 =
        [[NSDictionary alloc] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings4 =
        [[NSDictionary alloc] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings5 =
        [[NSDictionary alloc] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings6 =
        [[NSDictionary alloc] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *f_settings7 =
        [[NSDictionary alloc] // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
            initWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                   [NSNumber numberWithBool:NO],
                                   kCFStreamSSLAllowsExpiredCertificates,
                                   [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                   [NSNumber numberWithBool:YES],
                                   kCFStreamSSLValidatesCertificateChain,
                                   kCFStreamSocketSecurityLevelSSLv3, kCFStreamSSLLevel,
                                   @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings1 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelNone, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings2 = [NSDictionary
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings3 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings4 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings5 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:YES], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings6 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelTLSv1, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *d_settings7 = [NSDictionary // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kCFStreamSSLAllowsExpiredRoots,
                                     [NSNumber numberWithBool:NO],
                                     kCFStreamSSLAllowsExpiredCertificates,
                                     [NSNumber numberWithBool:NO], kCFStreamSSLAllowsAnyRoot,
                                     [NSNumber numberWithBool:YES],
                                     kCFStreamSSLValidatesCertificateChain,
                                     kCFStreamSocketSecurityLevelSSLv3, kCFStreamSSLLevel,
                                     @"www.example.com", kCFStreamSSLPeerName, (void *)0];

    NSDictionary *c_settings1 = @{
        // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelNone,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings2 = @{
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings3 = @{
        // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings4 = @{
        // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings5 = @{
        // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings6 = @{
        // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelTLSv1,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    NSDictionary *c_settings7 = @{
        // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
        (NSString *)kCFStreamSSLAllowsExpiredRoots : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsExpiredCertificates : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLAllowsAnyRoot : [NSNumber numberWithBool:NO],
        (NSString *)kCFStreamSSLValidatesCertificateChain : [NSNumber numberWithBool:YES],
        (NSString *)kCFStreamSSLLevel : (NSString *)kCFStreamSocketSecurityLevelSSLv3,
        (NSString *)kCFStreamSSLPeerName : @"www.example.com"
    };

    [NSURLRequest
        setAllowsAnyHTTPSCertificate:YES
                             forHost:
                                 @"https://example.com"]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}
    [NSURLRequest setAllowsAnyHTTPSCertificate:NO forHost:@"https://example.com"];

    NSURLAuthenticationChallenge *challenge;
    NSURLAuthenticationChallengeSender *sender;
    [sender continueWithoutCredentialForAuthenticationChallenge:
                challenge]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}

    NSURLSession *session =
        [NSURLSession sharedSession]; // expected-warning{{OBJC_SSL_BAD_VERIFICATION}}

    AFSecurityPolicy *sp;
    [sp setAllowInvalidCertificates:
            YES]; // expected-warning{{OBJC_AFNETWORKING_SSL_BAD_VERIFICATION}}
}
