// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
test_format()
{
    NSString *format = @"format";

    [NSString stringWithFormat:@"match"];
    [NSString stringWithFormat:format]; // expected-warning{{OBJC_FORMAT_STRING}}

    NSString *baseString = @"str";
    [baseString stringByAppendingFormat:@"not_match"];
    [baseString stringByAppendingFormat:format]; // expected-warning{{OBJC_FORMAT_STRING}}

    NSMutableString *myString = @"str";
    [myString appendFormat:@"not_match"];
    [myString appendFormat:format]; // expected-warning{{OBJC_FORMAT_STRING}}

    CFStringRef format2 = @"format";

    NSLog(@"not_match"); // expected-warning{{OBJC_NSLOG}}
    NSLog(format2);      // expected-warning{{OBJC_FORMAT_STRING}}
                         // expected-warning@-1{{OBJC_NSLOG}}

    [NSException raise:@"exception" format:@"not_match"];
    [NSException raise:@"exception" format:format]; // expected-warning{{OBJC_FORMAT_STRING}}

    AEDesc *dst;
    AEBuildError *error;
    AEBuildDesc(dst, error, "not_match");
    AEBuildDesc(dst, error, @"match"); // expected-warning{{OBJC_FORMAT_STRING}}
    AEBuildDesc(dst, error, format);   // expected-warning{{OBJC_FORMAT_STRING}}

    CFAllocatorRef alloc;
    CFStringCreateWithFormat(alloc, NULL, "not_match"); // expected-warning{{C_TYPE_CAST_ERROR}}
    CFStringCreateWithFormat(alloc, NULL, @"match");    // expected-warning{{OBJC_FORMAT_STRING}}
    CFStringCreateWithFormat(alloc, NULL, format2);     // expected-warning{{OBJC_FORMAT_STRING}}

    CFMutableStringRef str;
    CFDictionaryRef dict;
    CFStringAppendFormat(str, dict, "not_match"); // expected-warning{{C_TYPE_CAST_ERROR}}
    CFStringAppendFormat(str, dict, @"match");    // expected-warning{{OBJC_FORMAT_STRING}}
    CFStringAppendFormat(str, dict, format2);     // expected-warning{{OBJC_FORMAT_STRING}}
}
