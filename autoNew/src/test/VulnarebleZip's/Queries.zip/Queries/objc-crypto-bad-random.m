// RUN: iccheck -c %s

#include "system-header-simulator-objc.h"

void
test_arc4random()
{
    int a = arc4random(); // expected-warning{{OBJC_CRYPTO_BAD_RANDOM}}
                          // expected-warning@-1{{C_DEAD_STORE}}
    unsigned char b[3] = {0, 0, 0};
    arc4random_buf(b, 3); // expected-warning{{OBJC_CRYPTO_BAD_RANDOM}}
}
