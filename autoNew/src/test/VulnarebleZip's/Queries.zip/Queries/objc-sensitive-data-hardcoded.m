// RUN: iccheck -c %s

#import "system-header-simulator-objc.h"
#import "system-header-simulator-osx.h"

void
testSensitiveDataHardcoded()
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    // expected-warning@+2{{OBJC_INTERNAL_STORAGE}}
    // expected-warning@+1{{OBJC_SENSITIVE_DATA_HARDCODED}}
    [defaults setObject:@"53cr3tP" forKey: @"PIN"];

    // expected-warning@+1{{OBJC_SENSITIVE_DATA_HARDCODED}}
    [[NSUserDefaults standardUserDefaults] setInteger:123 forKey: @"cvv"];

    // expected-warning@+1{{C_SENSITIVE_DATA_HARDCODED}}
    const char *pin = "123";
    // expected-warning@+1{{OBJC_SENSITIVE_DATA_HARDCODED}}
    NSString *secretKey = @"123";
}
