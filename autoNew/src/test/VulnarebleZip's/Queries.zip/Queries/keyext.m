// RUN: iccheck -c %s
// XFAIL: *

#define YES __objc_yes
#define NO __objc_no

typedef signed char BOOL;

@class NSString;
@class UIApplication;

typedef NSString *UIApplicationExtensionPointIdentifier;

void other_cfun();

@protocol UIApplicationDelegate
- (BOOL)application:(UIApplication *)application
    shouldAllowExtensionPointIdentifier:
        (UIApplicationExtensionPointIdentifier)extensionPointIdentifier;
@end

@interface UIResponder
@end

@interface AppDelegate1 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate2 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate3 : UIResponder <UIApplicationDelegate>
- (void)otherFun;
@end

@interface AppDelegate4 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate5 : UIResponder <UIApplicationDelegate>
@end

@implementation AppDelegate1 // expected-warning{{OBJC_KEYBOARD_EXTENSIONS}}
@end

@implementation AppDelegate2 // expected-warning{{OBJC_KEYBOARD_EXTENSIONS}}

- (BOOL)application:(UIApplication *)application
    shouldAllowExtensionPointIdentifier:
        (UIApplicationExtensionPointIdentifier)extensionPointIdentifier
{
    return YES;
}

@end

@implementation AppDelegate3

- (void)otherFun
{}

- (BOOL)application:(UIApplication *)application
    shouldAllowExtensionPointIdentifier:
        (UIApplicationExtensionPointIdentifier)extensionPointIdentifier
{
    [self otherFun];
    return NO;
}

@end

@implementation AppDelegate4

- (BOOL)application:(UIApplication *)application
    shouldAllowExtensionPointIdentifier:
        (UIApplicationExtensionPointIdentifier)extensionPointIdentifier
{
    other_cfun();
    return YES;
}
// expected-warning{{OBJC_KEYBOARD_EXTENSIONS}}
@end

@implementation AppDelegate5

- (BOOL)application:(UIApplication *)application
    shouldAllowExtensionPointIdentifier:
        (UIApplicationExtensionPointIdentifier)extensionPointIdentifier
{
    int useless = 0, y = 3;
    useless += 3 - y;
    return NO;
}

@end
