// RUN: iccheck -c %s
// XFAIL: *

@class UIApplication;

void other_cfun();

@protocol UIApplicationDelegate
- (void)applicationDidEnterBackground:(UIApplication *)application;
@end

@interface UIResponder
@end

@interface AppDelegate1 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate2 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate3 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate4 : UIResponder <UIApplicationDelegate>
- (void)otherFun;
@end

@interface AppDelegate5 : UIResponder <UIApplicationDelegate>
@end

@interface AppDelegate6 : UIResponder <UIApplicationDelegate>
@end

@implementation AppDelegate1 // expected-warning{{OBJC_BACKGROUND_SCREENSHOT}}
@end

@implementation AppDelegate2 // expected-warning{{OBJC_BACKGROUND_SCREENSHOT}}

- (void)applicationDidEnterBackground:(UIApplication *)application
{}

@end

@implementation AppDelegate3 // expected-warning{{OBJC_BACKGROUND_SCREENSHOT}}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Just a comment.
}

@end

@implementation AppDelegate4

- (void)otherFun
{}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [self otherFun];
}

@end

@implementation AppDelegate5

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    other_cfun();
}
// expected-warning{{OBJC_BACKGROUND_SCREENSHOT}}
@end

@implementation AppDelegate6

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    int useless = 0, y = 3;
    useless += 3 - y;
}

@end
