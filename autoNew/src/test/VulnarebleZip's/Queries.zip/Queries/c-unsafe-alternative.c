// RUN: iccheck -c %s

#include "system-header-simulator-c.h"

size_t
unsafe_strlen(char *buf)
{
    return strlen(buf); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
}

void
unsafe_strncpy(char *source)
{
    char buf[10];
    strncpy(buf, source, 10); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
}

long
unsafe_atoi(char *buf)
{
    int i = atoi(buf);  // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    long l = atol(buf); // expected-warning{{C_UNSAFE_ALTERNATIVE}}
    return l + i;
}
