#define YES __objc_yes
#define NO __objc_no
#define NULL (void *)0
#define nil NULL

typedef signed char BOOL;
typedef int SInt32;
typedef unsigned long NSUInteger;
typedef NSUInteger NSStringEncoding;
typedef unsigned long CCPBKDFAlgorithm;
typedef unsigned long CCPseudoRandomAlgorithm;
typedef struct _NSZone NSZone;
typedef const struct __CFString *CFStringRef;
typedef unsigned int NSDataWritingOptions;
typedef struct __CFAllocator *CFAllocatorRef;
typedef struct __CFDictionary *CFDictionaryRef;
typedef struct __CFString *CFMutableStringRef;
typedef SInt32 OSStatus;
typedef struct AEDesc AEDesc;
typedef struct AEBuildError AEBuildError;
typedef long NSInteger;
typedef __UINT32_TYPE__ uint32_t;
typedef __SIZE_TYPE__ size_t;

@class NSDate, NSDictionary, NSError, NSString, NSUserDefaults, CGRect, NSSize;

typedef NSString *NSExceptionName;

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface CGRect
@property(nonatomic, assign) NSSize *size;
@end

@interface UITextView
@property(nonatomic, copy) NSString *text;
@end

@interface NSException : NSObject
+ (void)raise:(NSExceptionName)name format:(NSString *)format, ...;
@end

@interface NSData : NSObject
+ (instancetype)dataWithContentsOfFile:(NSString *)path;
- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)useAuxiliaryFile;
- (BOOL)writeToFile:(NSString *)path
            options:(NSDataWritingOptions)writeOptionsMask
              error:(NSError *_Nullable *)errorPtr;
- (NSDate *)compare:(NSDate *)date;
@property(readonly) const void *bytes;
@property(readonly) NSUInteger length;
@end

@interface NSMutableData : NSData
+ (instancetype)dataWithLength:(NSUInteger)length;
@property(readonly) void *mutableBytes;
@end

@interface NSString : NSObject
- (BOOL)isEqualToString:(NSString *)aString;
- (NSData *)dataUsingEncoding:(NSStringEncoding)encoding;
- (NSString *)stringByAppendingFormat:(NSString *)format, ...;
+ (instancetype)stringWithFormat:(NSString *)format, ...;
@end

@interface NSMutableString : NSString
- (void)appendFormat:(NSString *)format, ...;
@end

typedef struct
{
    unsigned long state;
    id *itemsPtr;
    unsigned long *mutationsPtr;
    unsigned long extra[5];
} NSFastEnumerationState;

@protocol NSFastEnumeration
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state
                                  objects:(id[])buffer
                                    count:(NSUInteger)len;
@end

@protocol NSCopying
- (id)copyWithZone:(NSZone *)zone;
@end

@protocol NSMutableCopying
- (id)mutableCopyWithZone:(NSZone *)zone;
@end

@class NSInvocation, NSMethodSignature, NSCoder, NSEnumerator, NSURLAuthenticationChallenge;

@protocol NSCoding
- (void)encodeWithCoder:(NSCoder *)aCoder;
@end

@protocol NSSecureCoding <NSCoding>
@required
+ (BOOL)supportsSecureCoding;
@end

@interface NSDictionary : NSObject <NSCopying, NSMutableCopying, NSSecureCoding, NSFastEnumeration>
- (NSUInteger)count;
- (id)objectForKey:(id)aKey;
- (NSEnumerator *)keyEnumerator;
- (id)objectForKeyedSubscript:(id)key;
+ (id)dictionaryWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
- (id)initWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
@end

@interface NSDictionary (NSDictionaryCreation)
+ (id)dictionary;
+ (id)dictionaryWithObject:(id)object forKey:(id)key;
+ (instancetype)dictionaryWithObjects:(const id[])objects
                              forKeys:(const id[])keys
                                count:(NSUInteger)cnt;
@end

@interface NSMutableDictionary : NSDictionary
- (void)removeObjectForKey:(id)aKey;
- (void)setObject:(id)anObject forKey:(id)aKey;
- (void)dictionaryWithObjectsAndKeys:(id)firstObject, ... __attribute__((sentinel(0, 1)));
- (void)dictionaryWithObject:(id)anObject forKey:(id)aKey;
@end

@interface NSMutableDictionary (NSExtendedMutableDictionary)
- (void)addEntriesFromDictionary:(NSDictionary *)otherDictionary;
- (void)removeAllObjects;
- (void)setDictionary:(NSDictionary *)otherDictionary;
- (void)setObject:(id)obj forKeyedSubscript:(id)key;
@end

@interface NSFileManager : NSObject
@property(class, readonly, strong) NSFileManager *defaultManager;
- (BOOL)setAttributes:(NSDictionary *)attributes
         ofItemAtPath:(NSString *)path
                error:(NSError *_Nullable *)error;
- (NSDictionary *)attributesOfItemAtPath:(NSString *)path error:(NSError *_Nullable *)error;
@end

@interface NSNumber : NSObject
@end

@interface NSNumber (NSNumberCreation)
- (id)initWithChar:(char)value;
- (id)initWithUnsignedChar:(unsigned char)value;
- (id)initWithShort:(short)value;
- (id)initWithUnsignedShort:(unsigned short)value;
- (id)initWithInt:(int)value;
- (id)initWithUnsignedInt:(unsigned int)value;
- (id)initWithLong:(long)value;
- (id)initWithUnsignedLong:(unsigned long)value;
- (id)initWithLongLong:(long long)value;
- (id)initWithUnsignedLongLong:(unsigned long long)value;
- (id)initWithFloat:(float)value;
- (id)initWithDouble:(double)value;
- (id)initWithBool:(BOOL)value;
- (id)initWithInteger:(NSInteger)value;
- (id)initWithUnsignedInteger:(NSUInteger)value;

+ (NSNumber *)numberWithChar:(char)value;
+ (NSNumber *)numberWithUnsignedChar:(unsigned char)value;
+ (NSNumber *)numberWithShort:(short)value;
+ (NSNumber *)numberWithUnsignedShort:(unsigned short)value;
+ (NSNumber *)numberWithInt:(int)value;
+ (NSNumber *)numberWithUnsignedInt:(unsigned int)value;
+ (NSNumber *)numberWithLong:(long)value;
+ (NSNumber *)numberWithUnsignedLong:(unsigned long)value;
+ (NSNumber *)numberWithLongLong:(long long)value;
+ (NSNumber *)numberWithUnsignedLongLong:(unsigned long long)value;
+ (NSNumber *)numberWithFloat:(float)value;
+ (NSNumber *)numberWithDouble:(double)value;
+ (NSNumber *)numberWithBool:(BOOL)value;
+ (NSNumber *)numberWithInteger:(NSInteger)value;
+ (NSNumber *)numberWithUnsignedInteger:(NSUInteger)value;
@end

@interface NSURLRequest
+ (void)setAllowsAnyHTTPSCertificate:(BOOL)allow forHost:(NSString *)host;
@end

@interface NSURLAuthenticationChallengeSender
- (void)continueWithoutCredentialForAuthenticationChallenge:
    (NSURLAuthenticationChallenge *)challenge;
@end
@interface NSURLSession
@property(class, readonly, strong) NSURLSession *sharedSession;
@end

@interface AFSecurityPolicy
@property(nonatomic, assign) BOOL allowInvalidCertificates;
@end

int CCKeyDerivationPBKDF(CCPBKDFAlgorithm algorithm, const char *password, unsigned int passwordLen,
                         const unsigned char *salt, unsigned int saltLen,
                         CCPseudoRandomAlgorithm prf, unsigned int rounds,
                         unsigned char *derivedKey, unsigned int derivedKeyLen);

CFStringRef CFStringCreateWithFormat(CFAllocatorRef alloc, CFDictionaryRef formatOptions,
                                     CFStringRef format, ...);
void CFStringAppendFormat(CFMutableStringRef theString, CFDictionaryRef formatOptions,
                          CFStringRef format, ...);
OSStatus AEBuildDesc(AEDesc *dst, AEBuildError *error, const char *src, ...);
void NSLog(NSString *format, ...);

uint32_t arc4random(void);
void arc4random_buf(void *buf, size_t nbytes);
CGRect * CGRectMake(int a, int b, int c, int d);
