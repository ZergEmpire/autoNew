// RUN: iccheck -c %s

#include "system-header-simulator-c.h"

typedef struct mbstate_t mbstate_t;
void consume(char *buf);
size_t mbsnrtowcs(wchar_t *dest, const char **src, size_t nms, size_t len, mbstate_t *ps);

void
mbstowcs_bad()
{
    char *mbstr[5], src[5];
    wchar_t wstr[5];
    mbstate_t *ps;
    mbstowcs(wstr, src, 10);            // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
                                        // expected-warning@-1{{C_DEPRECATED}}
    mbsnrtowcs(wstr, mbstr, 10, 5, ps); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
                                        // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    mbsnrtowcs(wstr, mbstr, 5, 10, ps); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}

    size_t *pReturnValue, sizeInWords;
    mbstowcs_s(pReturnValue, wstr, sizeInWords, src,
               6); // expected-warning@-1{{C_ARRAY_OUT_OF_BOUNDS}}
}

void
mbstowcs_good()
{
    char *mbstr[5], src[5];
    wchar_t wstr[5];
    mbstate_t *ps;
    mbstowcs(wstr, src, 5);             // expected-warning{{C_DEPRECATED}}
    mbsnrtowcs(wstr, &mbstr, 5, 5, ps); // expected-warning{{C_INCORRECT_FUNC_CALL}}

    size_t *pReturnValue, sizeInWords;
    mbstowcs_s(pReturnValue, wstr, sizeInWords, src, 5);
}

void
memcpy_bad()
{
    wchar_t source1[8], dest1[4];
    wchar_t source2[4], dest2[8];
    mempcpy(dest1, source1, 6); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
    mempcpy(dest2, source2, 6); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
}

void
memcpy_good()
{
    wchar_t source1[8], dest1[4];
    wchar_t source2[4], dest2[8];
    mempcpy(dest1, source1, 4);
    mempcpy(dest2, source2, 4);
}

void
fgets_bad()
{
    FILE *f = fopen("file_name", "r");
    char buf[10];
    fgets(buf, 18, f); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
    fclose(f);
    consume(buf);
}

void
fgets_good()
{
    FILE *f = fopen("file_name", "r");
    char buf[10];
    fgets(buf, 10, f);
    fclose(f);
    consume(buf);
}
