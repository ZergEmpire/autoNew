// RUN: iccheck -target x86_64-unknown-linux -c %s

#include "system-header-simulator-c.h"

struct stat
{};

int __xstat(int ver, const char *path, struct stat *stat_buf);

void
test___xstat()
{
    const char *path;
    struct stat *stat_buf;

    int result = __xstat(3, path, stat_buf); // expected-warning{{C_DEAD_STORE}}
                                             // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    result = __xstat(2, path, stat_buf);     // expected-warning{{C_UNDEFINED_RESULT}}
                                             // expected-warning@-1{{C_DEAD_STORE}}
}

struct stat64
{};

int __xstat64(int ver, const char *path, struct stat64 *stat_buf);

void
test___xstat64()
{
    const char *path;
    struct stat64 *stat_buf;

    int result = __xstat64(3, path, stat_buf); // expected-warning{{C_DEAD_STORE}}
                                               // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    result = __xstat64(2, path, stat_buf);     // expected-warning{{C_UNDEFINED_RESULT}}
                                               // expected-warning@-1{{C_DEAD_STORE}}
}

int __lxstat(int ver, const char *path, struct stat *stat_buf);

void
test___lxstat()
{
    const char *path;
    struct stat *stat_buf;

    int result = __lxstat(3, path, stat_buf); // expected-warning{{C_DEAD_STORE}}
                                              // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    result = __lxstat(2, path, stat_buf);     // expected-warning{{C_UNDEFINED_RESULT}}
                                              // expected-warning@-1{{C_DEAD_STORE}}
}

int __lxstat64(int ver, const char *path, struct stat64 *stat_buf);

void
test___lxstat64()
{
    const char *path;
    struct stat64 *stat_buf;

    int result = __lxstat64(3, path, stat_buf); // expected-warning{{C_DEAD_STORE}}
                                                // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    result = __lxstat64(2, path, stat_buf);     // expected-warning{{C_UNDEFINED_RESULT}}
                                                // expected-warning@-1{{C_DEAD_STORE}}
}

int __fxstat(int ver, int fildes, struct stat *stat_buf);

void
test___fxstat()
{
    int fildes;
    struct stat *stat_buf;

    int result = __fxstat(3, fildes, stat_buf); // expected-warning{{C_DEAD_STORE}}
                                                // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    result = __fxstat(2, fildes, stat_buf);     // expected-warning{{C_UNDEFINED_RESULT}}
                                                // expected-warning@-1{{C_DEAD_STORE}}
}

int __fxstat64(int ver, int fildes, struct stat64 *stat_buf);

void
test___fxstat64()
{
    int fildes;
    struct stat64 *stat_buf;

    int result = __fxstat64(3, fildes, stat_buf); // expected-warning{{C_DEAD_STORE}}
                                                  // expected-warning@-1{{C_INCORRECT_FUNC_CALL}}
    result = __fxstat64(2, fildes, stat_buf);     // expected-warning{{C_UNDEFINED_RESULT}}
                                                  // expected-warning@-1{{C_DEAD_STORE}}
}

double __wcstod_internal(const wchar_t *nptr, wchar_t **endptr, int group);

void
test___wcstod_internal()
{
    const wchar_t *nptr;
    wchar_t **endptr;

    double result = __wcstod_internal(nptr, endptr,
                                      0);        // expected-warning@-1{{C_DEAD_STORE}}
                                                 // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = __wcstod_internal(nptr, endptr, 1); // expected-warning{{C_UNDEFINED_RESULT}}
                                                 // expected-warning@-1{{C_DEAD_STORE}}
}

float __wcstof_internal(const wchar_t *nptr, wchar_t **endptr, int group);

void
test___wcstof_internal()
{
    const wchar_t *nptr;
    wchar_t **endptr;

    float result = __wcstof_internal(nptr, endptr,
                                     0);         // expected-warning@-1{{C_DEAD_STORE}}
                                                 // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = __wcstof_internal(nptr, endptr, 1); // expected-warning{{C_UNDEFINED_RESULT}}
                                                 // expected-warning@-1{{C_DEAD_STORE}}
}

long double __wcstold_internal(const wchar_t *nptr, wchar_t **endptr, int group);

void
test___wcstold_internal()
{
    const wchar_t *nptr;
    wchar_t **endptr;

    long double result = __wcstold_internal(nptr, endptr,
                                            0);   // expected-warning@-1{{C_DEAD_STORE}}
                                                  // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = __wcstold_internal(nptr, endptr, 1); // expected-warning{{C_UNDEFINED_RESULT}}
                                                  // expected-warning@-1{{C_DEAD_STORE}}
}

long __wcstol_internal(const wchar_t *nptr, wchar_t **endptr, int base, int group);

void
test___wcstol_internal()
{
    const wchar_t *nptr;
    wchar_t **endptr;
    int base;

    long result = __wcstol_internal(nptr, endptr, base,
                                    0); // expected-warning@-1{{C_DEAD_STORE}}
                                        // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = __wcstol_internal(nptr, endptr, base, 1); // expected-warning{{C_UNDEFINED_RESULT}}
                                                       // expected-warning@-1{{C_DEAD_STORE}}
}

unsigned long __wcstoul_internal(const wchar_t *nptr, wchar_t **endptr, int base, int group);

void
test___wcstoul_internal()
{
    const wchar_t *nptr;
    wchar_t **endptr;
    int base;

    unsigned long result = __wcstoul_internal(nptr, endptr, base,
                                              0); // expected-warning@-1{{C_DEAD_STORE}}
                                                  // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = __wcstoul_internal(nptr, endptr, base, 1); // expected-warning{{C_UNDEFINED_RESULT}}
                                                        // expected-warning@-1{{C_DEAD_STORE}}
}

struct mode_t
{};

struct dev_t
{};

int __xmknod(int ver, const char *path, struct mode_t mode, struct dev_t *dev);

void
test___xmknod()
{
    const char *path;
    struct mode_t mode;
    struct dev_t *dev;

    int result = __xmknod(1, path, mode, dev); // expected-warning{{C_ARRAY_OUT_OF_BOUNDS}}
                                               // expected-warning@-1{{C_DEAD_STORE}}
                                               // expected-warning@-2{{C_INCORRECT_FUNC_CALL}}
    result = __xmknod(0, path, mode, dev);     // expected-warning{{C_UNDEFINED_RESULT}}
                                               // expected-warning@-1{{C_DEAD_STORE}}
}
