// RUN: iccheck++ -c %s

#include "system-header-simulator-cxx.h"

void
func1()
{
    char *password = "str"; // expected-warning{{C_PASSWORD_HARDCODED}}
}

void
func2()
{
    char password[] = "pass"; // expected-warning{{C_PASSWORD_HARDCODED}}
}

int strcmp(const char *s1, const char *s2);

int
main()
{
    {
        char *password = "test"; // expected-warning{{C_PASSWORD_HARDCODED}}
        password == "test";      // expected-warning{{C_PASSWORD_HARDCODED}}
        password != "test";      // expected-warning{{C_PASSWORD_HARDCODED}}
        password == "";
        strcmp(password, "test"); // expected-warning{{C_PASSWORD_HARDCODED}}
        strcmp("test", password); // expected-warning{{C_PASSWORD_HARDCODED}}
        strcmp(password, "test"); // expected-warning{{C_PASSWORD_HARDCODED}}
    }
    {
        std::string password("test");
        password == "test"; // expected-warning{{C_PASSWORD_HARDCODED}}
        password != "test"; // expected-warning{{C_PASSWORD_HARDCODED}}
        "test" == password; // expected-warning{{C_PASSWORD_HARDCODED}}
        "test" == password; // expected-warning{{C_PASSWORD_HARDCODED}}
    }
    {
        const char32_t *PASSword32 = U"test"; // expected-warning{{C_PASSWORD_HARDCODED}}
        const wchar_t *password = L"test";    // expected-warning{{C_PASSWORD_HARDCODED}}
    }
    return 0;
}
