// RUN: iccheck -c %s

#define YES __objc_yes
#define NO __objc_no

typedef int OSStatus;
typedef long NSInteger;
typedef signed char BOOL;
typedef unsigned int SecPadding;
typedef unsigned long NSUInteger;

@class NSString;

@protocol NSObject
@end

@interface NSObject <NSObject> {
}
- (id)init;
+ (id)alloc;
- (id)mutableCopy;
@end

@interface NSMutableDictionary : NSObject
- (void)setObject:(id)anObject forKey:(id)aKey;
@end

@interface NSData : NSObject
+ (instancetype)dataWithBytes:(const void *)bytes length:(NSUInteger)length;
@end

@interface NSNumber : NSObject
@end

@interface NSNumber (NSNumberCreation)
- (id)initWithChar:(char)value;
- (id)initWithUnsignedChar:(unsigned char)value;
- (id)initWithShort:(short)value;
- (id)initWithUnsignedShort:(unsigned short)value;
- (id)initWithInt:(int)value;
- (id)initWithUnsignedInt:(unsigned int)value;
- (id)initWithLong:(long)value;
- (id)initWithUnsignedLong:(unsigned long)value;
- (id)initWithLongLong:(long long)value;
- (id)initWithUnsignedLongLong:(unsigned long long)value;
- (id)initWithFloat:(float)value;
- (id)initWithDouble:(double)value;
- (id)initWithBool:(BOOL)value;
- (id)initWithInteger:(NSInteger)value;
- (id)initWithUnsignedInteger:(NSUInteger)value;

+ (NSNumber *)numberWithChar:(char)value;
+ (NSNumber *)numberWithUnsignedChar:(unsigned char)value;
+ (NSNumber *)numberWithShort:(short)value;
+ (NSNumber *)numberWithUnsignedShort:(unsigned short)value;
+ (NSNumber *)numberWithInt:(int)value;
+ (NSNumber *)numberWithUnsignedInt:(unsigned int)value;
+ (NSNumber *)numberWithLong:(long)value;
+ (NSNumber *)numberWithUnsignedLong:(unsigned long)value;
+ (NSNumber *)numberWithLongLong:(long long)value;
+ (NSNumber *)numberWithUnsignedLongLong:(unsigned long long)value;
+ (NSNumber *)numberWithFloat:(float)value;
+ (NSNumber *)numberWithDouble:(double)value;
+ (NSNumber *)numberWithBool:(BOOL)value;
+ (NSNumber *)numberWithInteger:(NSInteger)value;
+ (NSNumber *)numberWithUnsignedInteger:(NSUInteger)value;
@end

typedef const struct __CFString *CFStringRef;

extern const CFStringRef kSecAttrApplicationTag;
extern const CFStringRef kSecAttrKeyType;
extern const CFStringRef kSecAttrKeyTypeRSA;
extern const CFStringRef kSecClass;
extern const CFStringRef kSecClassKey;
extern const CFStringRef kSecReturnRef;

enum
{
    kSecPaddingNone = 0,
    kSecPaddingPKCS1 = 1,
    kSecPaddingPKCS1MD2 = 0x8000,
    kSecPaddingPKCS1MD5 = 0x8001,
    kSecPaddingPKCS1SHA1 = 0x8002
};

int printf(const char *format, ...);
unsigned long strlen(const char *str);
void *malloc(unsigned long size);
OSStatus SecItemCopyMatching(const NSMutableDictionary *query, const void *_Nullable *result);
OSStatus SecKeyEncrypt(const void *key, SecPadding padding, const unsigned char *plainText,
                       unsigned long plainTextLen, unsigned char *cipherText,
                       unsigned long *cipherTextLen);
unsigned long SecKeyGetBlockSize(const void *key);

void
testPadding()
{
    static const unsigned char publicKeyIdentifier[] =
        "com.apple.sample.publickey\0"; // expected-warning@-1{{C_CRYPTO_KEY_HARDCODED}}
    static const unsigned char privateKeyIdentifier[] =
        "com.apple.sample.privatekey\0"; // expected-warning@-1{{C_CRYPTO_KEY_HARDCODED}}
    OSStatus status = 0;

    unsigned long cipherBufferSize;
    unsigned char *cipherBuffer;

    const unsigned char dataToEncrypt[] =
        "the quick brown fox jumps " // expected-warning@-1{{C_CRYPTO_KEY_HARDCODED}}
        "over the lazy dog\0";
    unsigned long dataLength = sizeof(dataToEncrypt) / sizeof(dataToEncrypt[0]);

    const void *publicKey = (void *)0;

    NSData *publicTag = [NSData dataWithBytes:publicKeyIdentifier
                                       length:strlen((const char *)publicKeyIdentifier)];
    // expected-warning@-1{{C_UNSAFE_ALTERNATIVE}}

    NSMutableDictionary *queryPublicKey = [[NSMutableDictionary alloc] init];

    [queryPublicKey setObject:(__bridge id)kSecClassKey forKey:(__bridge id)kSecClass];
    [queryPublicKey setObject:publicTag forKey:(__bridge id)kSecAttrApplicationTag];
    [queryPublicKey setObject:(__bridge id)kSecAttrKeyTypeRSA forKey:(__bridge id)kSecAttrKeyType];
    [queryPublicKey setObject:[NSNumber numberWithBool:YES] forKey:(__bridge id)kSecReturnRef];

    status = SecItemCopyMatching((__bridge const NSMutableDictionary *)
                                     queryPublicKey, // expected-warning@-1{{C_DEAD_STORE}}
                                                     // expected-warning@-2{{OBJC_MEMORY_LEAK}}
                                 (const void **)&publicKey);

    cipherBufferSize = SecKeyGetBlockSize(publicKey);
    cipherBuffer = malloc(cipherBufferSize);

    if (cipherBufferSize < sizeof(dataToEncrypt)) {
        printf("Could not decrypt. Packet too large.\n"); // expected-warning{{C_MEMORY_LEAK}}
        return;
    }

    status = SecKeyEncrypt(
        publicKey, kSecPaddingNone, dataToEncrypt,
        (unsigned long)dataLength, // expected-warning@-2{{OBJC_CRYPTO_BAD_PADDING}}
                                   // expected-warning@-3{{C_DEAD_STORE}}
        cipherBuffer, &cipherBufferSize);
    status = SecKeyEncrypt(publicKey, kSecPaddingPKCS1, dataToEncrypt,
                           (unsigned long)dataLength, // expected-warning@-1{{C_DEAD_STORE}}
                           cipherBuffer, &cipherBufferSize);
    status = SecKeyEncrypt(
        publicKey, kSecPaddingPKCS1MD2, dataToEncrypt,
        (unsigned long)dataLength, // expected-warning@-2{{OBJC_CRYPTO_BAD_PADDING}}
                                   // expected-warning@-3{{C_DEAD_STORE}}
        cipherBuffer, &cipherBufferSize);
    status = SecKeyEncrypt(
        publicKey, kSecPaddingPKCS1MD5, dataToEncrypt,
        (unsigned long)dataLength, // expected-warning@-2{{OBJC_CRYPTO_BAD_PADDING}}
                                   // expected-warning@-3{{C_DEAD_STORE}}
        cipherBuffer, &cipherBufferSize);
    status = SecKeyEncrypt(publicKey, kSecPaddingPKCS1SHA1,
                           dataToEncrypt, // expected-warning@-1{{OBJC_CRYPTO_BAD_PADDING}}
                                          // expected-warning@-2{{C_DEAD_STORE}}
                           (unsigned long)dataLength, cipherBuffer, &cipherBufferSize);
}
