// <yes> <report> JS_CRYPTO_KEY_SIZE 9214f2
crmfObject = crypto.generateCRMFRequest(
                "CN=" + name.value,
                password.value,
                authenticator,
        	keyTransportCert,
                "setCRMFRequest();",
                512, null, "rsa-dual-use");
// <yes> <report> JS_CRYPTO_KEY_SIZE 8b588d
crmfObject = crypto.generateCRMFRequest(
                "CN=" + name.value,
                password.value,
                authenticator,
        	keyTransportCert,
                "setCRMFRequest();",
                1666, null, "rsa-dual-use");
// <yes> <report> JS_CRYPTO_KEY_SIZE 8b138d
var MattsRSAkey = cryptico.generateRSAKey(PassPhrase, 1024);

var NodeRSA = require('node-rsa');
// <yes> <report> JS_CRYPTO_KEY_SIZE mferkj
var key = new NodeRSA({b: 512});