// <yes> <report> JS_PASSWORD_HARDCODED 8a083f
password > 'literal';
// <yes> <report> JS_PASSWORD_HARDCODED 8a083t
password > 'lit eral';
// <yes> <report> JS_PASSWORD_HARDCODED 8a083f
password != 'literal';
// <yes> <report> JS_PASSWORD_HARDCODED 8a083t
password != 'lit eral';
// <yes> <report> JS_PASSWORD_HARDCODED f05946
var password_ = '123';
// <yes> <report> JS_PASSWORD_HARDCODED f0594t
var password_ = '12 3';
// <yes> <report> JS_HIJACKING_AJAX e21f94 <yes> <report> JS_CSRF ed0544 <yes> <report> JS_PASSWORD_HARDCODED d16b5e
obj = new XMLHttpRequest(); obj.open('GET','/fetchusers.jsp?id='+form.id.value,'true','scott','tiger');
// <yes> <report> JS_PASSWORD_HARDCODED b78df4
var password = 'hardcode';
// <yes> <report> JS_PASSWORD_HARDCODED b78dft
var password = 'hard code';
// <yes> <report> JS_PASSWORD_HARDCODED 33f2f0
p.password_ = 'abc';
// <yes> <report> JS_PASSWORD_HARDCODED 33f2ft
p.password_ = 'a bc';
// <yes> <report> JS_PASSWORD_HARDCODED 4f9fb3
p.password = 'abc';
// <yes> <report> JS_PASSWORD_HARDCODED 4f9fbt
p.password = 'ab c';
// <yes> <report> JS_PASSWORD_HARDCODED 0ee5a6
password_ <= 'q';
// <yes> <report> JS_PASSWORD_HARDCODED 0ee5at
password_ <= 'q sd';
var params = { 
	statics : {
			requestId : 0
		},
	config : {
			username : "admin",
			// <yes> <report> JS_PASSWORD_HARDCODED 7cba87
			password : "hardcodedPassword1",
			// <yes> <report> JS_PASSWORD_HARDCODED 7cba8t
            password : "hardcoded Password1",
			// <yes> <report> JS_PASSWORD_HARDCODED ab76ca
			secondPassword : "hardcodedPassword2",
			// <yes> <report> JS_PASSWORD_HARDCODED ab76ct
            secondPassword : "hardcoded Password2",
			// <no> <report>
			mypassword : true
		}
	};
var azure = require('azure-storage');
// <yes> <report> JS_PASSWORD_HARDCODED sfkwss
var tableSvc = azure.createTableService(accountname, "password");

// <yes> <report> JS_PASSWORD_HARDCODED wmix29
xhttp.send(JSON.stringify({ 'email': 'testing@test.com', 'password': 'pwned', 'isAdmin': true }));
// <yes> <report> JS_PASSWORD_HARDCODED wmix2t
xhttp.send(JSON.stringify({ 'email': 'testing@test.com', 'password': 'pw ned', 'isAdmin': true }));

var data = {
    username: `${nf.config['@nf/npm-web'].npm_config.npm_login}`,
    // <no> <report>
    password: `${nf.config['@nf/npm-web'].npm_config.npm_password}`
}

var client = new Client({
    // <yes> <report> JS_PASSWORD_HARDCODED gr1002
    connectionString: 'postgresql://admin:aX6kVd0W6z@18.43.65.72:3211/'
});
// <yes> <report> JS_PASSWORD_HARDCODED gr1003
var data = {connection: 'postgres://username:password@host:381/database/'}
// <no> <report>
var str  = typeof pass == 'undefined' ? user : [user, pass].join(':');
// <no> <report>
if (typeof password === 'string') password = Buffer.from(password)

// <yes> <report> JS_PASSWORD_HARDCODED tsph03
v['password_'] = 'ASD';
// <yes> <report> JS_PASSWORD_HARDCODED tsp03t
v['password_'] = 'A SD';
// <yes> <report> JS_PASSWORD_HARDCODED tsph02
v['password'] = 'ASD';
// <yes> <report> JS_PASSWORD_HARDCODED tsp02t
v['password'] = 'AS D';
