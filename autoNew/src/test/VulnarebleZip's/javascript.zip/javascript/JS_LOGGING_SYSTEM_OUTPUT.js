// <yes> <report> JS_LOGGING_SYSTEM_OUTPUT 211fe0
process.stdout.write(s);
// <yes> <report> JS_LOGGING_SYSTEM_OUTPUT 211fe0
process.stderr.write(err);