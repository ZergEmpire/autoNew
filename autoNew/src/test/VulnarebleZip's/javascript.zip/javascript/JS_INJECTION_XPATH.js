const express = require('express');
const xpath = require('xpath');
const app = express();

app.get('/some/route', function(req, res) {
    let userName = req.param("userName");
    // <yes> <report> JS_INJECTION_XPATH xpath0
    let badXPathExpr = xpath.parse("//users/user[login/text()='" + userName + "']/home_dir/text()");
});