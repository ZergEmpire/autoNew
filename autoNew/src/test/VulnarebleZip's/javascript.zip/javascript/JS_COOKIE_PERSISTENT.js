// <yes> <report> JS_COOKIE_PERSISTENT 40a015 <yes> <report> JS_COOKIE_BROAD_PATH 107085 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('rememberme', '1', { maxAge: 900001, secure: true });
// <yes> <report> JS_COOKIE_PERSISTENT 40b015 <yes> <report> JS_COOKIE_BROAD_PATH 107085 <yes> <report> JS_COOKIE_NOT_HTTPONLY 407015
res.cookie('rememberme', '1', { expires: new Date(Date.now() + 900001), secure: true });

import Cookies = require("js-cookie");

// <no> <report>
Cookies.set('name', 'value', { expires: 7 });
// <yes> <report> JS_COOKIE_PERSISTENT tcp000
Cookies.set('name', 'value', { expires: 9999999 });