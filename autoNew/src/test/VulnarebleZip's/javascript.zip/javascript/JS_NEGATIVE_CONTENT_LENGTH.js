// <yes> <report> JS_NEGATIVE_CONTENT_LENGTH 284fe0
xhr.setRequestHeader("Content-Length", "-1000");