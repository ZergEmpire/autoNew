var https = require('https'),
    url = require('url');

var server = https.createServer(function(){});

server.on('request', function(req, res) {
    let origin = url.parse(req.url, true).query.origin;
    // <yes> <report> JS_HTML5_CORS cors00
    res.setHeader("Access-Control-Allow-Origin", origin);
    // <yes> <report> JS_HTML5_CORS cors01
    res.setHeader("Access-Control-Allow-Origin", '*');

});

const mainWindow = new BrowserWindow({
    webPreferences: {
        // <yes> <report> JS_HTML5_CORS cors02
        webSecurity: false,
        // <no> <report>
        webSecurity: true
    }
});