const options = {
  method: 'POST',
  headers: { 'content-type': 'application/x-www-form-urlencoded' },
  // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY react14
  url: 'https://www.example.com',
  // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY reactl4
  url: "https://localhost",
};
