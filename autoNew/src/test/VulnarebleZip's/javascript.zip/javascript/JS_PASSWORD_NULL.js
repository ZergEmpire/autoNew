// <yes> <report> JS_PASSWORD_NULL 198065
var password_ = null;
// <yes> <report> JS_PASSWORD_NULL 4f230a
v.password_ = null;
// <yes> <report> JS_PASSWORD_NULL 4f230a
v['password_'] = null;

// <yes> <report> JS_PASSWORD_NULL 6c48f3
var password = null;
// <yes> <report> JS_PASSWORD_NULL 133577
v.password = null;
// <yes> <report> JS_PASSWORD_NULL 133577
v['password'] = null;

// <yes> <report> JS_PASSWORD_NULL fa7614 <yes> <report> JS_HIJACKING_AJAX e21f94 <yes> <report> JS_CSRF ed0544
obj = new XMLHttpRequest(); obj.open('GET','/fetchusers.jsp?id='+form.id.value,'true','scott',null);
var params = { 
	statics : {
			requestId : 0
		},
	config : {
			username : "admin",
			// <yes> <report> JS_PASSWORD_NULL 38cbfd
			password : null,
			// <yes> <report> JS_PASSWORD_NULL 7a8cbd
			secondPassword : null
		}
	};
var azure = require('azure-storage');
// <yes> <report> JS_PASSWORD_NULL frwnfk
var tableSvc = azure.createTableService(accountname, null);

// <yes> <report> JS_PASSWORD_NULL tspn09
if (password == null){
    doSomethingBad();
}
// <yes> <report> JS_PASSWORD_NULL tspn10
if (password_new != null){
    doSomethingBad();
}