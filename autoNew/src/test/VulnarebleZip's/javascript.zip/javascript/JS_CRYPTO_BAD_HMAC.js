//CryptoJS library
// <yes> <report> JS_CRYPTO_BAD_HMAC lksj6e
var hash = CryptoJS.HmacMD5("Message", key);
// <yes> <report> JS_CRYPTO_BAD_HMAC ldkru4
var hmac = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA1, key);
// <yes> <report> JS_CRYPTO_BAD_HMAC vtjeke
const hash = crypto.createHmac('sha1', secret)
                   .update('I love cupcakes')
                   .digest('hex');
// <yes> <report> JS_CRYPTO_BAD_HMAC cb7b6f
function hex_hmac_md5(key, data) { return binl2hex(core_hmac_md5(key, data)); }