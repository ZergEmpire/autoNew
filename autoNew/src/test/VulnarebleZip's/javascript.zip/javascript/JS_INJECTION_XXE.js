const libxml = require('libxmljs');
// <yes> <report> JS_INJECTION_XXE xxe000
var doc = libxml.parseXml(document.body.outerHTML, { noent: true });