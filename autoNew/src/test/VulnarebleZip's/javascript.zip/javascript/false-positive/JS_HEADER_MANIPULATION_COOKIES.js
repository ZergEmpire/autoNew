// <yes> <report> JS_COOKIE_NOT_OVER_SSL 405015
document.cookie = 'smth';

