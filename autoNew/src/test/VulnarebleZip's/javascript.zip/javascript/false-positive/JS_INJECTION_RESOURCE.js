URL.createObjectURL('smth');
document.loadBindingDocument('smth');
user_input = 'hello';
document.addBinding(user_input, 'smth');
smth.resolveLocalFileSystemSyncURI('smth');
