eval('smth');
window.setInterval('smth');