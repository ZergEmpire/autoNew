const pwd = smth.getPassword();
// <yes> <report> JS_PRIVACY_VIOLATION jgkelf
console.log(pwd);
// <yes> <report> JS_PRIVACY_VIOLATION fjfkdu
fs.write(path, pwd);
// <yes> <report> JS_PRIVACY_VIOLATION fjdlen
fs.writeFile(path, pwd);
// <yes> <report> JS_PRIVACY_VIOLATION fjfkdu
fs.writeSync(path, pwd);
// <yes> <report> JS_PRIVACY_VIOLATION fjdlen
fs.writeFileSync(path, pwd);
