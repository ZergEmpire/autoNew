// <yes> <report> JS_CRYPTO_IV_HARDCODED bedked
var iv = "hardcoded_iv";
// <yes> <report> JS_CRYPTO_IV_HARDCODED thjkee
crypto.createCipheriv("aes192", key, "");
// <yes> <report> JS_CRYPTO_IV_HARDCODED b44k33
var decrypted = CryptoJS.AES.decrypt(encrypted, key, { iv: "hardcoded_iv" });
// <yes> <report> JS_CRYPTO_IV_HARDCODED wwwke5
var r = Crypto.encrypts(message,key,"hardcoded_iv");
// <yes> <report> JS_CRYPTO_IV_HARDCODED b44k33
const alg = { name: 'AES-GCM', iv: "iv" };
// <yes> <report> JS_CRYPTO_IV_HARDCODED b44k33
const key = await crypto.subtle.importKey('raw', pwHash, { name: 'AES-GCM', iv: "iv" }, false, ['encrypt']);

// <yes> <report> JS_CRYPTO_IV_HARDCODED tscih2
var ivMomo = 'IV';
// <yes> <report> JS_CRYPTO_IV_HARDCODED tscih2
var momoIv = 'IV';
// <no> <report>
var olive = 'IV';
// <yes> <report> JS_CRYPTO_IV_HARDCODED bedked
var Iv = 'ds';