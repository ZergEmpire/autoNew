const UserText1 = req.params;
// <yes> <report> JS_XSS_REFLECTED react02
var Hello = <div dangerouslySetInnerHTML={{ __html: UserText1}}></div>;

class AboutUserComponent extends React.Component {
    render() {
        const UserText2 = req.params;
        return (
            // <yes> <report> JS_XSS_REFLECTED react02
            <div dangerouslySetInnerHTML={{"__html": UserText2}} />
        );
    }
}

const state = req.params;
const inlineScript = `
    <script>
        <!-- // <yes> <report> JS_XSS_REFLECTED react05 -->
        window.__INITIAL_DATA__ = ${JSON.stringify(state)};
    </script>
    `

function renderFullPage(html, preloadedState) {
    return `
        <!doctype html>
        <html>
            <head>
                <title>Redux Universal Example</title>
            </head>
            <body>
                <script>
                    <!-- // <yes> <report> JS_XSS_REFLECTED react05 -->
                    window.__PRELOADED_STATE__ = ${JSON.stringify(req.params)}
                </script>
                <script src="/static/bundle.js"></script>
            </body>
        </html>
        `
}

class UserProfilePage extends React.Component {
    render() {
        const userWebsite = req.params;
        // <yes> <report> JS_XSS_REFLECTED react07
        return (<a href={userWebsite}>My Website</a>)
    }
}
const input = req.params;
// <yes> <report> JS_XSS_REFLECTED react07
let zzz = <Foo className={"foobar"} href={input} />;
// <yes> <report> JS_XSS_REFLECTED react07
const e = await render(<form action={input}>p0wned</form>, 1);

function style1() {
    const input = req.params;
    return (
            <!-- // <yes> <report> JS_XSS_REFLECTED react09 -->
            <div style={input}>
                Hello world
            </div>
    );
}

function  style2() {
    const input = req.params;
    return (
            <!-- // <no> <report> -->
            <div style={{color: input}}>
                Hello world
            </div>
    );
}

let userPreferences = req.params;
// <yes> <report> JS_XSS_REFLECTED react13
React.createElement('span', userPreferences);

class HtmlComponent extends React.Component {
    render() {
        // <yes> <report> JS_XSS_REFLECTED react17
        var dev = ReactHtmlParser(req.params);
        const html = req.params;
        return (
            <div>
                <!-- // <yes> <report> JS_XSS_REFLECTED react17 -->
                { ReactHtmlParser(html) }
            </div>
        );
  }
}