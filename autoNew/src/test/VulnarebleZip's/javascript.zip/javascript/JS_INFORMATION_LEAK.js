angular.module('myApp', [])
.factory('SessionService', function($q, $http) {
  var service = {
    user_id: null,
    getCurrentUser: function() {
// <yes> <report> JS_INFORMATION_LEAK ldfsje
      debugger; 
      return service.user_id;
    }
  }
  return service;
});

io  = require('socket.io').listen(app);
// <yes> <report> JS_INFORMATION_LEAK ldlk3e
io.set('log level',3);
// <yes> <report> JS_INFORMATION_LEAK djrne2
var debug = require('debug')