const os = require('os');

// <yes> <report> JS_INFORMATION_LEAK_EXTERNAL lldjfn
console.log(os.freemem());
// <no> <report>
console.log("error");
// <no> <report>
console.log();
// <yes> <report> JS_INFORMATION_LEAK_EXTERNAL gjfkep
console.log(`            user: ${os.freemem()} (${user.percentOutput})`)
// <yes> <report> JS_INFORMATION_LEAK_EXTERNAL gjfkep
console.log(`            real: ${hr.baseOutput} (${os.networkInterfaces()})`)

// <yes> <report> JS_INFORMATION_LEAK_EXTERNAL lldjfn
console.log(','+JSON.stringify(os.freemem()));
// <no> <report>
console.log(']' + 'smth');
try {
    throw new Error('Whoops!');
} catch (e) {
// <yes> <report> JS_INFORMATION_LEAK_EXTERNAL fhfjdl
    console.log(e.name + ': ' + e.message);
}
