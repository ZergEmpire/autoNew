// <yes> <report> JS_CRYPTO_BAD_ALGORITHM 407085
ARCFOUR();
TripleDES();
// <yes> <report> JS_CRYPTO_BAD_ALGORITHM 407085
RC2();
//CryptoJS library
// <yes> <report> JS_CRYPTO_BAD_ALGORITHM lks085
var encrypted = CryptoJS.DES.encrypt("Message", key); //DES, TripleDES, RC4
// <yes> <report> JS_CRYPTO_BAD_ALGORITHM lks085
var desEncryptor = CryptoJS.algo.DES.createEncryptor(key, { iv: iv });

const crypto = require('crypto');
// <yes> <report> JS_CRYPTO_BAD_ALGORITHM rejeks
const cipher = crypto.createCipher('des', passPhrase);
// <yes> <report> JS_CRYPTO_BAD_ALGORITHM lks085
var encrypted = C.DES.encrypt(
    C.enc.Utf8.parse(source),
    C.enc.Hex.parse(key),
    { mode: C.mode.ECB, padding: C.pad.NoPadding }
).ciphertext.toString();

// <yes> <report> JS_CRYPTO_BAD_ALGORITHM lks085
Crypto.DES("Message");
// <yes> <report> JS_CRYPTO_BAD_ALGORITHM lks085
CryptoTS.RC4("Message");
// <no> <report>
Crypto.AES("Message");