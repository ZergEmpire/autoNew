// <yes> <report> JS_HIJACKING_AJAX a0c37e
MochiKit.Async.doSimpleXMLHttpRequest();
// <yes> <report> JS_CSRF ed0544 <yes> <report> JS_HIJACKING_AJAX e21f94
open('get');
// <yes> <report> JS_HIJACKING_AJAX f6d315
v.type = 'get';
YAHOO.util.Connect.asyncRequest('GET');
// <yes> <report> JS_HIJACKING_AJAX 7e2aa1
set_httpVerb('GET');
// <yes> <report> JS_HIJACKING_AJAX dca283 <yes> <report> JS_CSRF ff778b
v.method = 'get';
// <yes> <report> JS_CSRF 7fc074 <yes> <report> JS_HIJACKING_AJAX 3ff6ff
jQuery.get();
// <yes> <report> JS_HIJACKING_AJAX 0d4ef4
DWREngine.setVerb('GET');
// <yes> <report> JS_HIJACKING_AJAX cd5eb5
DWREngine = dwr.not_engine;
var user_input = 'hello';
// <yes> <report> JS_HIJACKING_AJAX 5f6adb
Json.evaluate(user_input);
// <yes> <report> JS_HIJACKING_AJAX 5f6bdb
jQuery.ajax ({
	url : "",
	type : "GET"
});
// <yes> <report> JS_HIJACKING_AJAX ee6b55
jQuery.ajax ({
	url : ""
	// type : "GET" - by default
});
// <yes> <report> JS_HIJACKING_AJAX 5f6bdb
ajaxsettings({
	url : "",
	type : "GET"
});