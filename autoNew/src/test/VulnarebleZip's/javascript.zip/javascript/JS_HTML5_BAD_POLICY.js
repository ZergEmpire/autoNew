// <yes> <report> JS_HTML5_BAD_POLICY 1a73ef
o.contentWindow.postMessage(message, '*');