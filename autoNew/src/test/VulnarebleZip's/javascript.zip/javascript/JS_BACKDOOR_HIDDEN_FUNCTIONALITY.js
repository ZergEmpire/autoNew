import {Base64} from 'js-base64' ;
import {atob} from 'Window Or Worker Global Scope' ;

// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
eval(atob('4pyTIMOgIGxhIG1vZGU='));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
importScripts(atob('4pyTIMOgIGxhIG1vZGU='));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
eval(Base64.decode(encodedString));

// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
eval(Base64.decode('saaxsdcwdw='));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
eval(window_scsope.atob('saaxsdcwdw='));
// <no><report>
eval(window_scsope.atdob('saaxsdcwdw='));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
var a = eval(Base64.decode('saaxsdcwdw='));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
var b = eval(Base64.decode(string_));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
var c = eval(atob('4pyTIMOgIGxhIG1vZGU='));
// <yes> <report> JS_BACKDOOR_HIDDEN_FUNCTIONALITY 407x15
var d = importScripts(atob('4pyTIMOgIGxhIG1vZGU='));