var user_input = localStorage.getItem("1");
// <yes> <report> JS_XSS_PERSISTENT ngh5w6
document.writeln(user_input);
// <yes> <report> JS_XSS_PERSISTENT 09ghtj
style.background = user_input;
// <yes> <report> JS_XSS_PERSISTENT 96jhuy
jQuery.after(user_input);
// <yes> <report> JS_XSS_PERSISTENT 96jhuy
$.append(user_input);
// <yes> <report> JS_XSS_PERSISTENT 17th4e
smth.document.writeln(user_input);
// <yes> <report> JS_XSS_PERSISTENT cngh57
smth.style.background = user_input;
// <yes> <report> JS_XSS_PERSISTENT 48fhtj
smth.jQuery.after(user_input);
// <yes> <report> JS_XSS_PERSISTENT 48fhtj
smth.$.append(user_input);
// <yes> <report> JS_XSS_PERSISTENT 96jhuy
$(".container").append(user_input);
$(document.createElement('div'))
          .addClass('dropdown-backdrop')
          // <no> <report> JS_XSS_PERSISTENT 96jhuy
          .insertAfter($(this))
          .on('click', clearMenus)
//<yes> <report> JS_XSS_PERSISTENT fm677a
user_input.insertAfter($(this))

var url = localStorage.getItem("2").el;

if (a == 2) {
    // <yes> <report> JS_XSS_PERSISTENT 4j6g64
    smth.innerHTML = url;
    // <yes> <report> JS_XSS_PERSISTENT 4j6g64
    smth.insertAdjacentHTML = url;
}

// <yes> <report> JS_XSS_PERSISTENT cmgu85
document.getElementById('eRunningFrame').src = url;
// <no> <report>
document.getElementById('eRunningFrame');
// <no> <report>
document.getElementById('eRunningFrame').src = 'src';
// <yes> <report> JS_XSS_PERSISTENT cmgu85
document.getElementById('eRunningFrame').innerHTML = url;
// <yes> <report> JS_XSS_PERSISTENT cmgu85
document.getElementById('eRunningFrame').insertAdjacentHTML = url;
// <yes> <report> JS_XSS_PERSISTENT 4j6g64
smth.innerHTML = url;

const data = localStorage.getItem("1");
// <yes> <report> JS_XSS_PERSISTENT 4j6g64
el.innerHTML = data;
const data2 = window.localStorage.getItem("1");
// <yes> <report> JS_XSS_PERSISTENT 4j6g64
el.innerHTML = data2;

var app7 = new Vue({
    el: '#app-7',
    data: {
        groceryList: [
            // <yes> <report> JS_XSS_PERSISTENT jfkdwk
            { id: 0, text: user_input },
            { id: 1, text: 'Cheese' },
        ]
    }
})

new Vue({
    el: '#app',
    data: {
        // <yes> <report> JS_XSS_PERSISTENT jfkdwk
        message: user_input
    }
})

new Vue({
    el: '#app',
    // <yes> <report> JS_XSS_PERSISTENT jmcd53
    data: user_input
})

// <yes> <report> JS_XSS_PERSISTENT mvkdwk
createElement('span', user_input)

// below tests for the framework Bootstrap
$('#example-tooltip').tooltip({
    // <yes> <report> JS_XSS_PERSISTENT btstr2
    title: user_input,
    // <yes> <report> JS_XSS_PERSISTENT btstr2
    template: user_input,
    trigger: 'hover',
    placement: 'bottom'
})

$(function () {
  $('.example-popover').popover({
    container: 'body',
    // <yes> <report> JS_XSS_PERSISTENT btstr2
    content: user_input,
    // <yes> <report> JS_XSS_PERSISTENT btstr2
    title: user_input,
    // <yes> <report> JS_XSS_PERSISTENT btstr2
    template: user_input
  })
})