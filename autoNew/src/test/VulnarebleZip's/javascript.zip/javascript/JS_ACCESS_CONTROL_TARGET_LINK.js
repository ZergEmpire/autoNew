// <yes> <report> JS_ACCESS_CONTROL_TARGET_LINK actl00 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
window.open("https://attacker-site.example.com/useful-page.html", "_blank");

// <yes> <report> JS_ACCESS_CONTROL_TARGET_LINK actl00 <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY bne002
var goodWindow = window.open("https://attacker-site.example.com/useful-page.html", "_blank");  // It's FP
goodWindow.opener = null;