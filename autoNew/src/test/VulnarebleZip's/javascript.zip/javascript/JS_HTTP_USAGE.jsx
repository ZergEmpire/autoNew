const options = {
  method: 'POST',
  headers: { 'content-type': 'application/x-www-form-urlencoded' },
  // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY react14 <yes> <report> JS_HTTP_USAGE react15
  url: 'http://www.example.com',
  // <yes> <report> JS_BACKDOOR_NETWORK_ACTIVITY reactl4 <yes> <report> JS_HTTP_USAGE reactl5
  url: "http://localhost",
};