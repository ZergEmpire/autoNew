DECLARE @Time1 DATETIME
SELECT @Time1 = getdate()
WAITFOR DELAY '00:00:01'
-- <yes> <report> TSQL_DOS 07362a 
WAITFOR TIME @Time1 --WILL HANG FOREVER

DECLARE @Delay3 DATETIME 
-- <yes> <report> TSQL_IMPLICIT_CONVERSION a6340z
SELECT @Delay3 = dateadd(SECOND, -1, convert(DATETIME, 0))
-- <yes> <report> TSQL_DOS 07362a
WAITFOR DELAY @Delay3 --WILL HANG FOREVER

-- <no> <report>
WAITFOR DELAY '00:00:02' --Two seconds

-- http://stackoverflow.com/a/31058908/5752262