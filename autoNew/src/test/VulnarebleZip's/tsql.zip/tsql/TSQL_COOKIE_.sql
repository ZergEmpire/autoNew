CREATE PROCEDURE ChilkatCookieSample
AS
BEGIN
    DECLARE @hr int
    DECLARE @sTmp0 nvarchar(4000)
    DECLARE @http int
    EXEC @hr = sp_OACreate 'Chilkat_9_5_0.Http', @http OUT
    IF @hr <> 0
    BEGIN
        PRINT 'Failed to create ActiveX component'
        RETURN
    END

    DECLARE @success int

    --  Any string unlocks the component for the 1st 30-days.
    EXEC sp_OAMethod @http, 'UnlockComponent', @success OUT, 'Anything for 30-day trial'
    IF STR(@success) <> 1
      BEGIN
        EXEC sp_OAGetProperty @http, 'LastErrorText', @sTmp0 OUT
        PRINT @sTmp0
        EXEC @hr = sp_OADestroy @http
        RETURN
      END
    -- <yes> <report> TSQL_COOKIE_BROAD_PATH 8463bb
    EXEC sp_OASetProperty @http, 'CookieDir', '/'
    -- <no> <report>
    EXEC sp_OASetProperty @http, 'CookieDir', '/dir'
    EXEC sp_OASetProperty @http, 'SaveCookies', 1

    --  To cause cached cookies to be sent with
    --  subsequent HTTP requests, set the SendCookies
    -- property = 1.
    EXEC sp_OASetProperty @http, 'SendCookies', 1

    --  Any methods that do a GET, POST, etc. will save
    --  cookies to the CookieDir 
    DECLARE @html nvarchar(4000)

    EXEC sp_OAMethod @http, 'QuickGetStr', @html OUT, 'https://www.paypal.com/'

    --  To fetch the XML cookie(s) for a domain, call GetCookieXml:
    DECLARE @xmlStr nvarchar(4000)
    -- <yes> <report> TSQL_COOKIE_BROAD_DOMAIN 31ff09
    EXEC sp_OAMethod @http, 'GetCookieXml', @xmlStr OUT, '.paypal.com'

    EXEC @hr = sp_OADestroy @http
END
GO