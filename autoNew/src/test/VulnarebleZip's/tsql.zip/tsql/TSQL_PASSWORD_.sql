DECLARE @@MyPswd1 nvarchar(30), @MyPswd2 nvarchar(30), @MyPswd3 nvarchar(30); 
-- <yes> <report> TSQL_PASSWORD_EMPTY 07390z
SET @@MyPswd1 = '';
-- <yes> <report> TSQL_PASSWORD_NULL b6390z
SET @MyPswd2 = NULL;
-- <yes> <report> TSQL_PASSWORD_HARDCODED a6390z
SET @MyPswd3 = 'qwerty';
-- <yes> <report> TSQL_PASSWORD_HARDCODED a6390t
SET @MyPswd3 = 'qwe rty';
GO 
UPDATE Sales.CreditCard
-- <yes> <report> TSQL_PASSWORD_HARDCODED rtu3fj 
SET CardNumber_EncryptedbyPassphrase = EncryptByPassPhrase('passphrase'  
    , CardNumber, 1, CONVERT( varbinary, CreditCardID))  
WHERE CreditCardID = '3681';  
GO  
UPDATE Sales.CreditCard
-- <yes> <report> TSQL_PASSWORD_NULL hhuddv 
SET CardNumber_EncryptedbyPassphrase = EncryptByPassPhrase(NULL 
    , CardNumber, 1, CONVERT( varbinary, CreditCardID))  
WHERE CreditCardID = '3681';  
GO  