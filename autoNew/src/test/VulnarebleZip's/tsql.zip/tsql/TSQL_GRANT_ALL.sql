USE MyDataBase;
-- <yes> <report> TSQL_GRANT_ALL 07379c
GRANT ALL TO some_user;
GO
-- <no> <report> 
GRANT execute ON MyDataBase TO some_user WITH GRANT OPTION;
GO