USE CreditCards;  
GO  

-- <yes> <report> TSQL_BACKDOOR_SPECIAL_ACCOUNT c1kdh2 
IF @hash = '8743b52063cd84097a65d1633f5c74f5' PRINT msg_str;
-- <yes> <report> TSQL_BACKDOOR_SPECIAL_ACCOUNT cas3h2
IF @password = 'qwerty' PRINT msg_str;
-- <no> <report>
IF @password = '' PRINT msg_str;
