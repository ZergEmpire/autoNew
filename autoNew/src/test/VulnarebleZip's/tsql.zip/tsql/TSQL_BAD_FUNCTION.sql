-- <yes> <report> TSQL_BAD_FUNCTION 991fcc
EXEC xp_cmdshell 'dir *.exe';  
GO 
