SELECT   
    c.session_id, c.net_transport, c.encrypt_option /*,   
    c.auth_scheme, s.host_name, s.program_name,   
    s.client_interface_name, s.login_name, s.nt_domain,   
    s.nt_user_name, s.original_login_name, c.connect_time,   
    s.login_time*/   
FROM sys.dm_exec_connections
-- <yes> <report> TSQL_BACKDOOR_NETWORK_ACTIVITY c1kd09
WHERE c.local_net_address = '192.168.1.188' and c.local_tcp_port = 'port';

-- <yes> <report> TSQL_BACKDOOR_NETWORK_ACTIVITY cdx3h2
IF @url = 'http://www.example.com/wpstyle/?p=364' PRINT msg_str;

SELECT
    c.session_id, c.net_transport, c.encrypt_option
FROM sys.dm_exec_connections
-- <yes> <report> TSQL_BACKDOOR_NETWORK_ACTIVITY c1kd09
WHERE c.local_net_address = '192.168.1.188' and c.client_tcp_port = 'port';

-- <yes> <report> TSQL_BACKDOOR_NETWORK_ACTIVITY c1kd09
IF c.client_net_address = '192.168.1.188' PRINT msg_str;