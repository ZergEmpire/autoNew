USE SomeDataBase;
-- <yes> <report> TSQL_BACKDOOR_HIDDEN_FUNCTIONALITY csdd09
EXEC DecryptByPassphrase @PassphraseEnteredByUser, 'SGVsbG8=';
-- <yes> <report> TSQL_BACKDOOR_HIDDEN_FUNCTIONALITY c1fd09
EXECUTE DecryptByKey 'key';
