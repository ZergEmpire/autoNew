DECLARE @sys_usr char(30);  
  -- <yes> <report> TSQL_DEFAULT_CREDENTIALS 07379a
SET @sys_usr = SYSTEM_USER;  
SELECT 'The current system user is: '+ @sys_usr;  
GO  