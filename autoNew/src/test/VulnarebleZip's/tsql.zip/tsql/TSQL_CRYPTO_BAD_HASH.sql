-- http://stackoverflow.com/questions/173329/how-to-decrypt-a-password-from-sql-server
-- <yes> <report> TSQL_CRYPTO_BAD_HASH 8aaca2
select pwdencrypt('AAAA')

DECLARE @HashThis nvarchar(4000);  
SET @HashThis = CONVERT(nvarchar(4000),'dslfdkjLK85kldhnv$n000#knf');  
-- <yes> <report> TSQL_CRYPTO_BAD_HASH e983fd
SELECT HASHBYTES('SHA1', @HashThis);
-- MD2 | MD4 | MD5 | SHA | SHA1 | SHA2_256 | SHA2_512