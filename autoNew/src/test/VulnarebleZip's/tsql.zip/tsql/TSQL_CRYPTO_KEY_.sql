DECLARE @@MyKey1 nvarchar(30), @MyKey2 nvarchar(30), @MyKey nvarchar(30), @EncryptionKey3 nvarchar(30);
-- <yes> <report> TSQL_CRYPTO_KEY_EMPTY 07310z
SET @@MyKey1 = '';
-- <yes> <report> TSQL_CRYPTO_KEY_NULL a6310z
SET @MyKey2 = NULL;
-- <yes> <report> TSQL_CRYPTO_KEY_HARDCODED v6310z
SET @MyKey = 'qwerty';
-- <yes> <report> TSQL_CRYPTO_KEY_HARDCODED jkw39w
SET @EncryptionKey3 = 'qwerty';
GO 

-- https://docs.microsoft.com/ru-ru/sql/t-sql/statements/create-symmetric-key-transact-sql
CREATE SYMMETRIC KEY JanainaKey09
-- No report
WITH ALGORITHM = AES_256  
ENCRYPTION BY CERTIFICATE Shipping04;  
GO  

 USE [tempdb];

 DROP SYMMETRIC KEY [test_key];
 CREATE SYMMETRIC KEY key_name
 -- <yes> <report> TSQL_CRYPTO_BAD_ALGORITHM crypt0balg02
 WITH ALGORITHM = DES,
      KEY_SOURCE = '{your "key"}'
 ENCRYPTION BY PASSWORD = 'weak';
 USE AdventureWorks2012;
 OPEN SYMMETRIC KEY key_name
    DECRYPTION BY PASSWORD = 'weak';
 GO
 DECLARE @Encrypted VARBINARY(8000);
 SET @Encrypted = ENCRYPTBYKEY(KEY_GUID(N'key_name'), 'test me!');

 SELECT @Encrypted AS EncryptedValue,
        DECRYPTBYKEY(@Encrypted) DecryptedBytes,
        CONVERT(VARCHAR(500), DECRYPTBYKEY(@Encrypted)) AS DecryptedText;

 CLOSE SYMMETRIC KEY test_key;