SET @x = 1
-- <yes> <report> TSQL_CORRECTNESS_EQUALS_NULL ed2589
IF @x != NULL PRINT 'x != NULL'

-- <yes> <report> TSQL_CORRECTNESS_EQUALS_NULL ed2589 
IF NULL = @x PRINT 'x = NULL'

IF @x is null PRINT 'Here is a proper comparison'

