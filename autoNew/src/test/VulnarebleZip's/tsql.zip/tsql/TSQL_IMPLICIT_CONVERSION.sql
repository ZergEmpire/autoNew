DECLARE @expression AS varchar(10);
SET @expression = '23.09.2016';
-- <yes> <report> TSQL_IMPLICIT_CONVERSION i6340z
SELECT CAST ( @expression AS date);  
-- <yes> <report> TSQL_IMPLICIT_CONVERSION a6340z
SELECT CONVERT (datetimeoffset, @expression); 
GO
-- <yes> <report> TSQL_IMPLICIT_CONVERSION b6340z
SELECT CONVERT (varchar(20), SYSDATETIME()); 
GO