-- <yes> <report> TSQL_INFORMATION_LEAK_INTERNAL 07379z  
RAISERROR (N'This is message %s %d.', -- Message text.
           10, -- Severity,
           1, -- State,
           N'number', -- First argument.
           5); -- Second argument.
-- The message text returned is: This is message number 5.
GO

BEGIN TRY  
    -- Generate a divide-by-zero error.  
    SELECT 1/0;  
END TRY  
BEGIN CATCH  
-- <yes> <report> TSQL_INFORMATION_LEAK_INTERNAL 07379y 
    SELECT ERROR_MESSAGE() AS ErrorMessage;  
END CATCH;  
GO  