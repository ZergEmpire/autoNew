-- <yes> <report> TSQL_CRYPTO_BAD_RANDOM c1ff09
SELECT RAND() Random_Number
-- If your T-SQL application needs to use a cryptographically secure PRNG (CSPRNG), an alternative is to use CRYPT_GEN_RANDOM