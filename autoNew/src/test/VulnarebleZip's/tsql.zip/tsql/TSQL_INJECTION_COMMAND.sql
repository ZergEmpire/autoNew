USE msdb ;
GO
EXEC dbo.sp_add_job
    @job_name = N'Weekly Sales Data Backup' ;
GO
SET @command = N'ALTER DATABASE SALES SET READ_ONLY';
-- <yes> <report> TSQL_INJECTION_COMMAND 9u3fch
EXEC sp_add_jobstep
    @job_name = N'Weekly Sales Data Backup',
    @step_name = N'Set database to read only',
    @subsystem = N'TSQL',
    @command = @danger_command, 
    @retry_attempts = 5,
    @retry_interval = 5 ;
GO
-- <no> <report>
EXEC sp_add_jobstep
    @job_name = N'Weekly Sales Data Backup',
    @step_name = N'Set database to read only',
    @subsystem = N'TSQL',
    @command = N'ALTER DATABASE SALES SET READ_ONLY', 
    @retry_attempts = 5,
    @retry_interval = 5 ;
GO

-- <yes> <report> TSQL_INJECTION_COMMAND 2u3mcd
EXEC msdb.dbo.sp_add_jobschedule 
        @job_name = N'Weekly Sales Data Backup', -- Job name
        @name = N'Weekly_Sat_2AM',  -- Schedule name
        @freq_type = 8, -- Weekly
        @freq_interval = 64, -- Saturday
        @freq_recurrence_factor = 1, -- every week
        @active_start_time = @stime -- 2:00 AM
GO        

-- <yes> <report> TSQL_INJECTION_COMMAND 2u3mcd
EXEC dbo.sp_add_schedule
    @schedule_name = N'RunOnce',
    @freq_type = 1,
    @active_start_date = @sdate,
    @active_start_time = @stime ;
USE msdb ;
GO
EXEC sp_attach_schedule
   @job_name = N'Weekly Sales Data Backup',
   @schedule_name = N'RunOnce';
GO
EXEC dbo.sp_add_jobserver
    @job_name = N'Weekly Sales Data Backup';
GO

