DECLARE @TableName  nvarchar(20) = 'Students',
        @SqlText    nvarchar(200),
        @Tainted    nvarchar(100) = 'Robert''); DROP TABLE students;--';
SET @SqlText = 'INSERT INTO ' + @TableName + ' (FirstName) VALUES (' + @Tainted + ')';
-- <yes> <report> TSQL_INJECTION_SQL 8463aa
EXEC(@SqlText);
GO
-- <yes> <report> TSQL_INJECTION_SQL 8463aa
EXEC('INSERT INTO ' + @TableName + ' (FirstName) VALUES (' + @Tainted + ')');
GO
-- <no> <report>
EXEC('SELECT * from Students;');
GO


-- sp_executesql - need taint
DECLARE @IntVariable int;  
DECLARE @SQLString nvarchar(500);  
DECLARE @ParmDefinition nvarchar(500);  
DECLARE @max_title varchar(30);  
  
SET @IntVariable = 197;  
SET @SQLString = N'SELECT @max_titleOUT = max(JobTitle)   
   FROM AdventureWorks2012.HumanResources.Employee  
   WHERE BusinessEntityID = @level';  
SET @ParmDefinition = N'@level tinyint, @max_titleOUT varchar(30) OUTPUT';  
  
-- <yes> <report> TSQL_INJECTION_SQL b4w3a3
EXECUTE sp_executesql @TainedSQLString, @ParmDefinition, @level = @IntVariable, @max_titleOUT=@max_title OUTPUT;  
SELECT @max_title;
-- <yes> <report> TSQL_INJECTION_SQL tt6yya
SELECT PARSE(@SQLString) AS e;
GO