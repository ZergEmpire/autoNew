void main() {
  // <yes> <report> DART_COOKIE_NOT_HTTPONLY 7cnl8s
  var cookie = new Cookie.fromSetCookieValue("name=val; domain=example.com; path=/admin; Secure; expires=Sat, 08 Sep 2018 16:54:31 GMT");
  // <yes> <report> DART_COOKIE_NOT_HTTPONLY 3vmkba
  final Cookie cookie = Cookie.fromSetCookieValue("name=val; domain=example.com; path=/admin; Secure");

  var cookie_1 = new Cookie("name", "value");
  // <yes> <report> DART_COOKIE_NOT_HTTPONLY 7svtn6
  cookie_1.httpOnly = false;

  // <no> <report>
  var cookie_2 = new Cookie("name", "value");
  cookie_2.httpOnly = true;
}