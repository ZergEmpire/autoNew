void main() {
  // <yes> <report> DART_PASSWORD_EMPTY 0aj4lv
  String _password_smth = "";
  // <yes> <report> DART_PASSWORD_EMPTY ne6vka
  var password = "";
}