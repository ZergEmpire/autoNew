void main() {
  // <yes> <report> DART_COOKIE_BROAD_DOMAIN landjy
  var cookie = new Cookie.fromSetCookieValue("name=val; domain=.example.com; path=/admin; HttpOnly; Secure; expires=Sat, 08 Sep 2018 16:54:31 GMT");
  // <yes> <report> DART_COOKIE_BROAD_DOMAIN nau8dn
  final Cookie cookie = Cookie.fromSetCookieValue("name=val; domain=.example.com; path=/admin; HttpOnly; Secure");

  // <yes> <report> DART_COOKIE_BROAD_DOMAIN p2ir8d
  var cookie_1 = new Cookie("name", "value");
  cookie_1.domain = ".domain.com";

  // <no> <report>
  var cookie = new Cookie.fromSetCookieValue("name=val; domain=example.com; path=/admin; HttpOnly; Secure");
}