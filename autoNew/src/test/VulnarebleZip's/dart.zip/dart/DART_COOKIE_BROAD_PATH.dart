void main() {
  // <yes> <report> DART_COOKIE_BROAD_PATH n2icld
  var cookie = new Cookie.fromSetCookieValue("name=val; domain=secure.example.com; path=/; HttpOnly; Secure; expires=Sat, 08 Sep 2018 16:54:31 GMT");
  // <yes> <report> DART_COOKIE_BROAD_PATH tt7mi7
  final Cookie cookie = Cookie.fromSetCookieValue("name=val; domain=secure.example.com; path=/; HttpOnly; Secure");

  // <yes> <report> DART_COOKIE_BROAD_PATH 6cndfk
  var cookie_1 = new Cookie("name", "value");
  cookie_1.path = "/";

  // <no> <report>
  final Cookie cookie = Cookie.fromSetCookieValue("name=val; domain=secure.example.com; path=/admin; HttpOnly; Secure");

}