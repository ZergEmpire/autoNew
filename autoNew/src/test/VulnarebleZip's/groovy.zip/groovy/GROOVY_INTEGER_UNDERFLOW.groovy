class GROOVY_INTEGER_UNDERFLOW{
    public static void main(String[] args) {
        int a = -5;
        a = 5;
        //<yes><report> GROOVY_INTEGER_UNDERFLOW asfgr8
        a = a + Integer.MIN_VALUE;
        //<no><report>
        a = 5 + Integer.MIN_VALUE;
        //<yes><report> GROOVY_INTEGER_UNDERFLOW asfgr7
        a = -5 + Integer.MIN_VALUE;
        //<no><report> FN
        a = -(-(-5)) + Integer.MIN_VALUE;
        return;
    }
}