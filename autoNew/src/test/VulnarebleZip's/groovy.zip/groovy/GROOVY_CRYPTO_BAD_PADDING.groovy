import javax.crypto.Cipher

class GROOVY_CRYPTO_BAD_PADDING{
    static public void main(String[] args){
        //<yes><report> GROOVY_CRYPTO_BAD_PADDING asfgr3
        Cipher.getInstance("RSA", "NoPadding");
        //<yes><report> GROOVY_CRYPTO_BAD_PADDING asfgr3
        Cipher.getInstance("sasaRSAsadfq", "qefcsNoPaddingasfe");
        //<no><report>
        Cipher.getInstance("sasaAsadfq", "qefcsNoPaddingasfe");
        //<no><report>
        Cipher.getInstance("sasaRSAsadfq", "qefcPaddingasfe");
        //<no><report>
        Cipher.getInstance("sasAsadfq", "qefcsNddingasfe");
        //<yes><report> GROOVY_CRYPTO_BAD_PADDING asfgr3
        Cipher.getInstance("sasarsasadfq", "qefcsnopaddingngasfe");
    }
}