class GROOVY_CRYPTO_BAD_HMAC {
    def hmac()
    {
        // <yes> <report> GROOVY_CRYPTO_BAD_HMAC nn2777
        Mac mac = Mac.getInstance("HmacSHA1");
    }
}