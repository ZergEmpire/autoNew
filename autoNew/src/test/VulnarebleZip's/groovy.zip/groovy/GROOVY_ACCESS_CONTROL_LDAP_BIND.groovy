class GROOVY_ACCESS_CONTROL_LDAP_BIND {
    // <yes> <report> GROOVY_ACCESS_CONTROL_LDAP_BIND gkre43
    LDAP ldap = LDAP.newInstance("ldap://ldap.mycompany.com:389/dc=mycompany,dc=com")
    // <yes> <report> GROOVY_ACCESS_CONTROL_LDAP_BIND gkre43
    LDAP ldap2 = LDAP.newInstance()
    // <no> <report>
    LDAP connection = LDAP.newInstance('ldap://MY_SERVER:389','cn=MY_ACCOUNT, ou=MY_OU, dc=MY_DC', password)
}
