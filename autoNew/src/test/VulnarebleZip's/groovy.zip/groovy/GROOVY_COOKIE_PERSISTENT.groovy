import javax.servlet.http.Cookie

class GROOVY_COOKIE_PERSISTENT {
    def setCookieValue(name, value) {
        def cookie = new Cookie(name, value)
        // <yes> <report> GROOVY_COOKIE_PERSISTENT mdd366
        grails.plugins.cookie.cookieage.default = 1000
        // <yes> <report> GROOVY_COOKIE_PERSISTENT mhm322
        grails.plugins.cookie.cookieage.default = 600000
    }
}
