class GROOVY_BACKDOOR_NETWORK_ACTIVITY
{
    int port;
    public static void Main()
    {
        Socket sock = new Socket("localhost", 4444);
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna001
        Socket a = new Socket("123.230.000.255", remotePort, localAddr, localPort);
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna001
        sock = new DatagramSocket(data, data.length, "192.100.200.400", port);
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna001 <yes> <report> GROOVY_HTTP_USAGE g11hu1
        sock = new DatagramSocket(data, data.length, "http://www.example.com/wpstyle/?p=364", port);
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna002
        sock.listen("192.168.000.000");
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna002
        sock.bind("192.168.000.100");
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna002
        sock.connect("000.000.000.000");
        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY bna002 <yes> <report> GROOVY_HTTP_USAGE g11hu1
        sock.connect("http://-.2.com");

        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY g11sa2
        if (hash == "8743b52063cd84097a65d1633f5c74f5") {
            println "backdoor"
        }

        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY g11sa3
        if (ip == "127.0.0.1") {
            println "backdoor"
        }

        //<yes> <report> GROOVY_BACKDOOR_NETWORK_ACTIVITY g11sa4 <yes> <report> GROOVY_HTTP_USAGE g11hu1
        if (url == "http://www.backdoor.net") {
            println 'backdoor'
        }
    }
}