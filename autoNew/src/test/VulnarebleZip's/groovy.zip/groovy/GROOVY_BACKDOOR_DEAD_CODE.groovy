class GROOVY_BACKDOOR_DEAD_CODE{
    public static void main(String[] args) {
        //<yes><report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (false) {
            println "deadcode";
        } else {
            pass;
        }//<yes><report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (true) {
            pass;
        } else {
            println "deadcode"
        }//<yes><report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (53 > 90) {
            println "deadcode"
        } else {
            pass;
        }//<yes><report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (53.3 > 90.3) {
            println "deadcode"
        } else {
            pass;
        }//<no><report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if (a == (53.3 > 90.3)) {
            println "deadcode"
        } else {
            pass;
        }//<yes><report> GROOVY_BACKDOOR_DEAD_CODE gbd001
        if ('b' > 'a') {
            pass;
        } else {
            println "deadcode"
        }
    }
}
