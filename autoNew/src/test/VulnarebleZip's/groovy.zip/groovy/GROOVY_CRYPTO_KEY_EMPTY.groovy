class GROOVY_CRYPTO_KEY_EMPTY {
    def key() {
    	// <yes> <report> GROOVY_CRYPTO_KEY_EMPTY pjd444
        SecretKeySpec signingKey = new SecretKeySpec("", 
                                                    "HmacSHA256");
        // <yes> <report> GROOVY_CRYPTO_KEY_EMPTY rrhgsw
        ciphertext = "someplaintext".bytes.encrypt("".toKey())
    }
}