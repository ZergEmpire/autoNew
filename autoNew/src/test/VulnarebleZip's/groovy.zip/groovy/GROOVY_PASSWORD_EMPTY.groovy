class GROOVY_PASSWORD_EMPTY {
	def passwordEmpty() {
		// <yes> <report> GROOVY_PASSWORD_EMPTY jfekgs
		def pwd = ""
		// <yes> <report> GROOVY_PASSWORD_EMPTY ddd235
		def myPwd = ''
		// <yes> <report> GROOVY_PASSWORD_EMPTY dshawq
	    KeySpec spec = new PBEKeySpec("", salt, 20000, 128)
	    // <yes> <report> GROOVY_PASSWORD_EMPTY dqb576
	    decrypted = Blowfish.decryptBase64(encrypted, "", false)
	    // <yes> <report> GROOVY_PASSWORD_EMPTY dqb576
	    byte[] encrypted = Blowfish.encrypt(message.getBytes(), "")
	    // <yes> <report> GROOVY_PASSWORD_EMPTY dqb576
	    String encrypted = Blowfish.encryptBase64(message, "")
	assert encrypted
		// <yes> <report> GROOVY_PASSWORD_EMPTY dqb576
		String decrypted = Blowfish.decryptBase64(encrypted, "")
	assert decrypted
		// <yes> <report> GROOVY_PASSWORD_EMPTY snm5as
		def sql = Sql.newInstance(url, "user", "", driver)
		// <yes> <report> GROOVY_PASSWORD_EMPTY fejrks
		def dataSource = new JDBCDataSource(database: 'jdbc:hsqldb:mem:yourDB', user: 'sa', password: "")
		// <yes> <report> GROOVY_PASSWORD_EMPTY snm5as
	    Sql.withInstance(url, user, "", driver) { sql ->
	  // use 'sql' instance ...
	  	// <yes> <report> GROOVY_PASSWORD_EMPTY nxc453
	  	def dataSource = new JDBCDataSource('jdbc:hsqldb:mem:yourDB', 'sa', "")
		}
		// <yes> <report> GROOVY_PASSWORD_EMPTY vmd79t
		def ds = new BasicDataSource("org.hsqldb.jdbcDriver", 'jdbc:hsqldb:mem:yourDB', 'sa', "")
		// <yes> <report> GROOVY_PASSWORD_EMPTY 4tk3ls
		ds.password = ''
		// <yes> <report> GROOVY_PASSWORD_EMPTY fjfger
		LDAP connection = LDAP.newInstance('ldap://MY_SERVER:389','cn=MY_ACCOUNT, ou=MY_OU, dc=MY_DC', '')
	}
}