class GROOVY_BACKDOOR_SECURITY_PARAMS {
  def testSecurityParams() {
    String authorized
    String login

    //<yes> <report> GROOVY_BACKDOOR_SECURITY_PARAMS g11sp1
    while (login = "user 1") {
      println "backdoor"
    }

    //<yes> <report> GROOVY_BACKDOOR_SECURITY_PARAMS g11sp1
    if (login = "user 1") {
      println "backdoor"
    } else {
      println "ok"
    }

    if (test = "no") {
      println "no report"
    }
  }
}