class GROOVY_CRYPTO_KEY_HARDCODED {
    def key() {
    	// <yes> <report> GROOVY_CRYPTO_KEY_HARDCODED njdsn3
        SecretKeySpec signingKey = new SecretKeySpec("key", 
                                                    "HmacSHA256");
        // <yes> <report> GROOVY_CRYPTO_KEY_HARDCODED wqhgvb
        ciphertext = "someplaintext".bytes.encrypt("key".toKey())
    }
}