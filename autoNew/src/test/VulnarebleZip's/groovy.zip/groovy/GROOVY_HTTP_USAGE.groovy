@Grab(group='org.codehaus.gpars', module='gpars', version='0.12')
import static groovyx.gpars.GParsExecutorsPool.withPool

Thread.start {
  println Thread.currentThread().getId()
}

//<yes> <report> GROOVY_HTTP_USAGE g11hu1
def http = "http://test.com"
//<yes> <report> GROOVY_HTTP_USAGE g11hu2
def http2 = "http://127.0.70.1"
//<no> <report>
def http1 = "ht://no.report"
//<yes> <report> GROOVY_HTTP_USAGE g11hu1
javaHttpString = "http://yandex.com"
groovyHttpString = "${javaHttpString}"
int count = 50
withPool(count) {
	count.times {
		//<yes> <report> GROOVY_HTTP_USAGE g11hu1
		Closure callUrl = {"http://google.com".toURL().withReader {
			reader -> println reader.readLines()
			}}
	t	callUrl.callAsync();
		
	}
}