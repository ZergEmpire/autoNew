class GROOVY_USE_OF_SYSTEM_EXIT {

    static public void ex() {
        String a = "asdaf";
        String b = "dsnfeoi";
        a = a + b;
        //<yes> <report> GROOVY_USE_OF_SYSTEM_EXIT asfgre
        System.exit(0);
    }
    public static void main(String[] args) {
        GROOVY_USE_OF_SYSTEM_EXIT.ex();
        System.exit(0);
    }
}