import org.eclipse.jgit.util.SystemReader
class GROOVY_USE_GETENV{

    public static void main(String[] args) {
        String a = "sdffsd";
        // <yes> <report> GROOVY_USE_GETENV asfgr2
        System.getenv(a);
        // <yes> <report> GROOVY_USE_GETENV asf214
        SystemReader.instance.getenv('выаыва');
        // <yes> <report> GROOVY_USE_GETENV asf214
        SystemReader.instance.getenv(a);
    }
}