class GROOVY_CRYPTO_BAD_ALGORITHM {
    def cryptoBadAlg() {
    	// <yes> <report> GROOVY_CRYPTO_BAD_ALGORITHM mmss55
        def cipher = Cipher.getInstance('DES')
        // <yes> <report> GROOVY_CRYPTO_BAD_ALGORITHM mggaa1 
        key = "password".toKey(algorithm: 'DES', length: 8)
        // <yes> <report> GROOVY_CRYPTO_BAD_ALGORITHM wwhgk9
		ciphertext = "some plaintext".bytes.encrypt(key: key, algorithm: 'DES')
    }    
}
