class GROOVY_PROCESS_CONTROL{
    static public void main(String[] args){
        //<yes><report> GROOVY_PROCESS_CONTROL asfgr1
        System.loadLibrary("feoigbwdkcp");
        System.load("snncxlrlsls");
        return;
    }
}