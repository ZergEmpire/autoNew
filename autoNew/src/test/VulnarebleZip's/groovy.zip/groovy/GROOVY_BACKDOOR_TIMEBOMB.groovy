import java.text.SimpleDateFormat
class GROOVY_BACKDOOR_TIMEBOMB{

        public static void Main()
        {
            String date_0 = "2011-10-12";
            String date_1 = "2011/10/12";
            String date_2 = "12:10:12";
            String date_3 = "2018_09_12";
            Date now = new Date();
            Date now_1 = new Date(15,5,12);
            String a = now.format("yyyy-dd-MM")
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt001
            if(now.format("yyyy-dd-MM")>="2012-23-12"){
                println now.format("yyyy-MM-dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt002
            if(now.format("hh:mm:ss")<="23:22:21"){
                println now.format("yyyy-MM-dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt001
            if(now.format("yyyy-MM-dd")=="23-12-2018"){
                println now.format("yyyy-MM-dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt003
            if(now.format("yyyy-dd-MM")>"2023/21/12"){
                println now.format("yyyy-MM-dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt003
            if(now.format("dd-yyyy-MM")>"21/2023/12"){
                println now.format("yyyy-MM-dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy-MM-dd")<date_0){
                println now.format("yyyy-MM-dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy/MM/dd")<=date_1){
                println now.format("yyyy/MM/dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy/MM/dd")>=date_1){
                println now.format("yyyy/MM/dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy/MM/dd")==date_1){
                println now.format("yyyy/MM/dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy/MM/dd")>date_1){
                println now.format("yyyy/MM/dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy/MM/dd")<date_1){
                println now.format("yyyy/MM/dd")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("HH:mm:ss")<=date_2){
                println now.format("HH:mm:ss")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("HH:mm:ss")>=date_2){
                println now.format("HH:mm:ss")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("HH:mm:ss")==date_2){
                println now.format("HH:mm:ss")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("HH:mm:ss")>date_2){
                println now.format("HH:mm:ss")
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy_dd_MM")<date_2){
                println now.format("yyyy_dd_MM");
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy_dd_MM")<=date_3){
                println now.format("yyyy_dd_MM");
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy_dd_MM")>=date_3){
                println now.format("yyyy_dd_MM");
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy_dd_MM")==date_3){
                println now.format("yyyy_dd_MM");
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy_dd_MM")>date_3){
                println now.format("yyyy_dd_MM");
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt004
            if(now.format("yyyy_dd_MM")<date_3){
                println now.format("yyyy_dd_MM");
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt005
             if (now.before(now_1)){
                println "timebomb";
             }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt005
            if (now.after(now_1)){
                println "timebomb";
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt006
            if (now.equals("2018_09_13")){
                println "doTimebomb";
            }
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getTime() == 123124141){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getSecond() == 123.2){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getDate() > 15){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getDate() < 15){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getDate() >= 15){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getDate() <= 15){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getDate() == 15){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getYear() < 2018){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getYear() > 2018){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getYear() <= 2018){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getYear() >= 2018){
                println "doTimebomb";
            };
            //<yes> <report> GROOVY_BACKDOOR_TIMEBOMB gbt007
            if (now.getYear() == 2018){
                println "doTimebomb";
            };
        }
    }