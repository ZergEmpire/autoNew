class GROOVY_PASSWORD_HARDCODED {
	def passwordsHardcoded(){
		// <yes> <report> GROOVY_PASSWORD_HARDCODED gjeo5k
		def pwd = "hardcoded"
		// <yes> <report> GROOVY_PASSWORD_HARDCODED gjeo5t
		def pwd = "hard coded"
		// <yes> <report> GROOVY_PASSWORD_HARDCODED tdds33
		def myPwd = 'hardcoded'
		// <yes> <report> GROOVY_PASSWORD_HARDCODED tdds3t
		def myPwd = 'hard coded'
		// <no> <report> GROOVY_PASSWORD_HARDCODED tdds33
		def pwd = not_hardcoded
		// <yes> <report> GROOVY_PASSWORD_HARDCODED ddh4qq
	    KeySpec spec = new PBEKeySpec("password".toCharArray(), salt, 20000, 128)
		// <yes> <report> GROOVY_PASSWORD_HARDCODED ddh4qt
		KeySpec spec = new PBEKeySpec("pass word".toCharArray(), salt, 20000, 128)
	    // <yes> <report> GROOVY_PASSWORD_HARDCODED drd55q
	    decrypted = Blowfish.decryptBase64(encrypted, "password", false)
	    // <yes> <report> GROOVY_PASSWORD_HARDCODED drd55q
	    byte[] encrypted = Blowfish.encrypt(message.getBytes(), "password")
	    // <yes> <report> GROOVY_PASSWORD_HARDCODED drd55q
	    String encrypted = Blowfish.encryptBase64(message, "password")
	assert encrypted
		// <yes> <report> GROOVY_PASSWORD_HARDCODED drd55q
		String decrypted = Blowfish.decryptBase64(encrypted, "password")
	assert decrypted
		// <yes> <report> GROOVY_PASSWORD_HARDCODED ssd5vv
		def sql = Sql.newInstance(url, "user", "password", driver)
		// <yes> <report> GROOVY_PASSWORD_HARDCODED ssd5vv
		Sql.withInstance("jdbc:postgresql://127.0.0.1/postgres", "user",
		"password","org.postgresql.Driver") { 
		    
		    instance -> instance.execute("SELECT 1") 
		    
			}
		// <yes> <report> GROOVY_PASSWORD_HARDCODED fwjelf <yes> <report> GROOVY_PASSWORD_HARDCODED gwqw2r
	  	def dataSource = new JDBCDataSource( database: 'jdbc:hsqldb:mem:yourDB', user: 'sa', password: 'password')
		// <yes> <report> GROOVY_PASSWORD_HARDCODED fkgwls <yes> <report> GROOVY_PASSWORD_HARDCODED gwqw2r
		def dataSource = new JDBCDataSource( database: 'jdbc:hsqldb:mem:yourDB', user: 'sa', password_field: 'password')
		// <yes> <report> GROOVY_PASSWORD_HARDCODED fkgwlt <yes> <report> GROOVY_PASSWORD_HARDCODED gwffbr
		def dataSource = new JDBCDataSource( database: 'jdbc:hsqldb:mem:yourDB', user: 'sa', password_field_name: 'pass word')
	    // <yes> <report> GROOVY_PASSWORD_HARDCODED nnd345
	    def dataSource2 = new JDBCDataSource('jdbc:hsqldb:mem:yourDB', user, "password")
		// <yes> <report> GROOVY_PASSWORD_HARDCODED snd749
		def ds = new BasicDataSource("org.hsqldb.jdbcDriver", 'jdbc:hsqldb:mem:yourDB', 'sa', "password")
		// <yes> <report> GROOVY_PASSWORD_HARDCODED gejksf
		dataSource.password = 'sesame'
		// <yes> <report> GROOVY_PASSWORD_HARDCODED gejkst
		dataSource.password = 'se same'
		// <yes> <report> GROOVY_PASSWORD_HARDCODED gekdsf
		dataSource.password_some = 'sesame'
		// <yes> <report> GROOVY_PASSWORD_HARDCODED gekdst
		dataSource.password_some = 'se same'
		// <yes> <report> GROOVY_PASSWORD_HARDCODED fjskr4
		LDAP connection = LDAP.newInstance('ldap://MY_SERVER:389','cn=MY_ACCOUNT, ou=MY_OU, dc=MY_DC', 'MY_PASSWORD')
	    
	}
}
