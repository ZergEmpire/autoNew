import javax.servlet.http.Cookie

class GROOVY_COOKIE_NOT_HTTPONLY {
    def setCookieValue(name, value) {
        // <yes> <report> GROOVY_COOKIE_NOT_HTTPONLY rvc333
        grails.plugins.cookie.httpOnly.default = false
    }
}
