class GROOVY_PASSWORD_NULL {
	def passwordNull() {
		// <yes> <report> GROOVY_PASSWORD_NULL vfjkre
		def pwd = null
		// <yes> <report> GROOVY_PASSWORD_NULL vld244
		def myPwd = null
		// <yes> <report> GROOVY_PASSWORD_NULL wshasb
	    KeySpec spec = new PBEKeySpec(null, salt, 20000, 128)
	    // <yes> <report> GROOVY_PASSWORD_NULL dww555
	    decrypted = Blowfish.decryptBase64(encrypted, null, false)
	    // <yes> <report> GROOVY_PASSWORD_NULL dww555
	    byte[] encrypted = Blowfish.encrypt(message.getBytes(), null)
	    // <yes> <report> GROOVY_PASSWORD_NULL dww555
	    String encrypted = Blowfish.encryptBase64(message, null)
	assert encrypted
		// <yes> <report> GROOVY_PASSWORD_NULL dww555
		String decrypted = Blowfish.decryptBase64(encrypted, null)
	assert decrypted
		// <yes> <report> GROOVY_PASSWORD_NULL saq5aj
		def sql = Sql.newInstance(url, "user", null, driver)
		// <yes> <report> GROOVY_PASSWORD_NULL nv4w93
		def dataSource = new JDBCDataSource('jdbc:hsqldb:mem:yourDB', 'sa', null)
		// <yes> <report> GROOVY_PASSWORD_NULL saq5aj
	    Sql.withInstance(url, user, null, driver) { sql ->
	  	// use 'sql' instance ...
		// <yes> <report> GROOVY_PASSWORD_NULL jfkd58
	  	def dataSource = new JDBCDataSource(database: 'jdbc:hsqldb:mem:yourDB', user: 'sa', password: null)
		}
		// <yes> <report> GROOVY_PASSWORD_NULL rmd722
		def ds = new BasicDataSource("org.hsqldb.jdbcDriver", 'jdbc:hsqldb:mem:yourDB', 'sa', null)
		// <yes> <report> GROOVY_PASSWORD_NULL gejlfn
		ds.password = null
		// <yes> <report> GROOVY_PASSWORD_NULL gj56ks
		LDAP connection = LDAP.newInstance('ldap://MY_SERVER:389','cn=MY_ACCOUNT, ou=MY_OU, dc=MY_DC', null)
	}
}