import javax.servlet.http.Cookie

class GROOVY_COOKIE_BROAD_PATH {
    def setCookieValue(name, value) {
        def cookie = new Cookie(name, value)
        // TODO class porpogation needed
        cookie.path = '/'
        // TODO class porpogation needed
        cookie.setPath = '/'
        // <yes> <report> GROOVY_COOKIE_BROAD_PATH zzc006
        grails.plugins.cookie.path.defaultStrategy = '/'
    }
}
