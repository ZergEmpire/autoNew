class GROOVY_CRYPTO_IV_HARDCODED {
    def cryptoIVHardcoded() {
    	// <yes> <report> GROOVY_CRYPTO_IV_HARDCODED ddhgbb
        ciphertext = "some plaintext".bytes.encrypt(key: key, initializationVector: [0] * 16, 
                                        prependIvToCipherText: true)
    }
}