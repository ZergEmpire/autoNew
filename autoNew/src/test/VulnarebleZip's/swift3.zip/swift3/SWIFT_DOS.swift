// <yes> <report> SWIFT_GET_REQUEST gr0054
let urlRequest = URLRequest(url: URL(string: "example.com")!)
let dos = parseJson(urlRequest.httpBody).getValue("value")

// <yes> <report> SWIFT_DOS dos0000
Thread.sleep(forTimeInterval: dos)
// <yes> <report> SWIFT_DOS dos0000
Thread.sleep(until: Date() + dos)

let fileHandle = try! FileHandle(forReadingFrom: URL(fileURLWithPath: someGoodFile))
// <yes> <report> SWIFT_DOS dos0001
try! fileHandle.read(upToCount: dos)
// <yes> <report> SWIFT_DOS dos0001
try! FileHandle(forReadingFrom: URL(fileURLWithPath: someGoodFile)).read(upToCount: dos)
// <yes> <report> SWIFT_DOS dos0002
let result = try! fileHandle.readToEnd()

let fileHandleBad = try! FileHandle(forReadingFrom: URL(fileURLWithPath: dos))
// <yes> <report> SWIFT_DOS dos0002
let resultBad = try! fileHandleBad.readToEnd()

