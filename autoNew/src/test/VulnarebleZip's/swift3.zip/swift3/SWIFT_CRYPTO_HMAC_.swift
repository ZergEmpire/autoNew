// <yes> <report> SWIFT_CRYPTO_HMAC_KEY_EMPTY crypt0ehmac01
CCHmac(UInt32(kCCHmacAlgSHA256), "", 0, plaintext, plaintextLen, &output)

// <yes> <report> SWIFT_CRYPTO_HMAC_KEY_HARDCODED crypt0keyhard01
CCHmac(UInt32(kCCHmacAlgSHA256), "secret", 6, plaintext, plaintextLen, &output)

// <no> <report>
CCHmac(UInt32(kCCHmacAlgSHA256), seretKeyBytes, 6, plaintext, plaintextLen, &output)