import NetworkExtension
import TunnelKit

var sessionBuilder = OpenVPN.ConfigurationBuilder()
// <yes> <report> SWIFT_DNS_UNENCRYPTED dnscleartext
sessionBuilder.dnsProtocol = .cleartext

var networkSettings = ExampleNetworkSettings()
// <yes> <report> SWIFT_DNS_UNENCRYPTED dnscleartext
networkSettings.dnsProtocol = .cleartext

// <no> <report>
networkSettings.dnsProtocol = .tls
// <no> <report>
networkSettings.dnsProtocol = .https

var dnsProtocol: NEDNSProtocol?
// <yes> <report> SWIFT_DNS_UNENCRYPTED dnscleartext
dnsProtocol = .cleartext
var dnsProtocolversion: NEDNSProtocol?
// <no> <report>
dnsProtocolversion = .https

// <yes> <report> SWIFT_DNS_UNENCRYPTED dnscleartext2
var dnsProtocol1 = NEDNSProtocol.cleartext
var dnsProtocol2: NEDNSProtocol?
// <yes> <report> SWIFT_DNS_UNENCRYPTED dnscleartext
dnsProtocol2 = NEDNSProtocol.cleartext