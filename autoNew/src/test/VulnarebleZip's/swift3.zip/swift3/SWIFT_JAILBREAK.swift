// <yes> <report> SWIFT_JAILBREAK gr0057
let exists1 = FileManager.default.fileExists(atPath: "/Applications/Cydia.app")
// <yes> <report> SWIFT_JAILBREAK gr0057
let exists2 = FileManager.default.fileExists(atPath: "/usr/sbin/sshd")
// <yes> <report> SWIFT_JAILBREAK gr0057
let exists3 = FileManager.default.fileExists(atPath: "/etc/apt")
// <yes> <report> SWIFT_JAILBREAK gr0058
let wr = data.write(toFile: "/private/jailbreak.txt", atomically: true)
// <yes> <report> SWIFT_JAILBREAK gr0059
let openURL = UIApplication.sharedApplication().canOpenURL(URL(string: "cydia://package/com.example.package"))