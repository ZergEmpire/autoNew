import Foundation
import SwiftUI
import UIKit
//DEALING WITH ENVIRONMENT VARIABLES
let word = ProcessInfo.processInfo.environment["API_key"]
let testClass: ProcessInfo
let myFrame = CGRect(x: 0, y: 0, width: 320, height: 35)
let view = UIView(frame: myFrame)
let label = UILabel(frame: frame)
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI envrmntvar
label.text = word

let testClass: ProcessInfo
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI envrmntvar
label.text = testClass.processInfo.environment["apikey"]
view.addSubview(label)

@IBOutlet weak var sensitive: UITextField!
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI envrmntvar
sensitive.text = word
@IBOutlet  weak var sensitiveLong: UITextView!
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI envrmntvar
sensitiveLong.text = word

//Alerting on sensitive variable names

@IBOutlet weak var sensitive1: UITextField!
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI pswrdvar
sensitive1.text = UserPassword
@IBOutlet weak var sensitive2: UITextView!
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI pswrdvar
sensitive2.text = secretName
@IBOutlet weak var sensitive3: UILabel!
// <yes> <report>  SWIFT_SENSITIVE_DATA_EXPOSURE_TO_UI pswrdvar
sensitive3.text = secretPin
