let system_info = ProcessInfo.processInfo

let url = URL(string: "https://example.com")!
// <yes> <report> SWIFT_GET_REQUEST gr0054
var request: URLRequest = URLRequest(url: url)
// <yes> <report> SWIFT_INFORMATION_LEAK_EXTERNAL inf0leake00
request.httpBody = system_info.data(using: .utf8)

let dir = FileManager.`default`.currentDirectoryPath
// <yes> <report> SWIFT_GET_REQUEST gr0054
var request: NSURLRequest = NSURLRequest(url: url)
// <yes> <report> SWIFT_INFORMATION_LEAK_EXTERNAL inf0leake00
request.httpBody = dir.data(using: .utf8)

var systemVersion = UIDevice.current.systemVersion
// <yes> <report> SWIFT_GET_REQUEST gr0054
var request: NSMutableURLRequest = NSMutableURLRequest(url: url)
// <yes> <report> SWIFT_INFORMATION_LEAK_EXTERNAL inf0leake00
request.httpBody = systemVersion.data(using: .utf8)