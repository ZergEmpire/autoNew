let logger: Logger = Logger(label: "some logger")
let system_info = ProcessInfo.processInfo

// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki00
print(system_info)

// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki01
logger.info(system_info)
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki01
logger.notices(system_info)
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki01
logger.warning(system_info)
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki01
logger.error(system_info)
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki01
logger.critical(system_info)

// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki02 <yes> <report> SWIFT_CLIPBOARD gr0040
UIPasteboard.general.string = system_info
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki03 <yes> <report> SWIFT_CLIPBOARD gr0040
NSPasteboard.general.setString(system_info, forType: .string)
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki03 <yes> <report> SWIFT_CLIPBOARD gr0040
NSPasteboard.general.setData(system_info, forType: .string)

let env = ProcessInfo.processInfo.environment

let str = env["something"]
// <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki04
str.write(toFile: "some file")
for cs in Thread.callStackSymbols {
    // <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki04
    cs.write(to: url)
}
guard let data = str.data(using: .utf8) else {
    print("Unable to convert string to data")
    return
}
do {
    // <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki04
    try data.write(toFile: some_file)
    // <yes> <report> SWIFT_INFORMATION_LEAK_INTERNAL inf0leaki04
    try data.write(to: url)
}
