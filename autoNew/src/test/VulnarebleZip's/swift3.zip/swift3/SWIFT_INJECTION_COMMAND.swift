import Foundation

let tainted = parseJson(urlRequest.httpBody).getValue("value")

let url = URL(fileURLWithPath:"/bin/ls")
do {
// <yes> <report> SWIFT_INJECTION_COMMAND comm0inj00
   try Process.run(url, arguments: [tainted]) { (process) in
      print("\ndidFinish: \(!process.isRunning)")
   }
} catch {
    print("error")
}

// <yes> <report> SWIFT_INJECTION_COMMAND comm0inj00
try Process.run(url, arguments: tainted)  // case where its already array

let process = Process()
process.executableURL = URL(fileURLWithPath:"/bin/ls")
// <yes> <report> SWIFT_INJECTION_COMMAND comm0inj01
process.arguments = [tainted]
process.terminationHandler = { (process) in
   print("\ndidFinish: \(!process.isRunning)")
}
try process.run()

@discardableResult
func shell(_ args: String...) -> Int32 {
    let task = Process()
    task.launchPath = "/usr/bin/env"
    task.arguments = args
    task.launch()
    task.waitUntilExit()
    return task.terminationStatus
}

// <no> <report>
shell("ls", "-l")
// <yes> <report> SWIFT_INJECTION_COMMAND comm0inj02
shell("ls", tainted)