import Foundation
import FoundationNetworking

// <yes> <report> SWIFT_COOKIE_NOT_OVER_SSL cookie0ssl000
let properties1 = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/tmp",
    HTTPCookiePropertyKey.name: "some_name1",
    HTTPCookiePropertyKey.value: "some_value1"
]

// <no> <report>
let properties2 = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/tmp",
    HTTPCookiePropertyKey.name: "some_name2",
    HTTPCookiePropertyKey.value: "some_value2",
    HTTPCookiePropertyKey.secure: "TRUE"
]

// <yes> <report> SWIFT_COOKIE_NOT_OVER_SSL cookie0ssl000
let properties3 : [HTTPCookiePropertyKey : Any] = [
    .domain: "www.test.com",
    .path: "/tmp",
    .name: "some_name3",
    .value: "some_value3"
]

// <no> <report>
let cookie1 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path1",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE"
])

// <yes> <report> SWIFT_COOKIE_NOT_OVER_SSL cookie0ssl000 <yes> <report> SWIFT_COOKIE_NOT_OVER_SSL cookie0ssl001
let cookie2 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path2",
    .name: "some_name2",
    HTTPCookiePropertyKey.value: "some_value2"
])

// <yes> <report> SWIFT_COOKIE_NOT_OVER_SSL cookie0ssl001
let cookie3 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path3",
    .name: "some_name3",
    .value: "some_value3",
])!

// <no> <report>
let cookie4 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path4",
    .name: "some_name4",
    .value: "some_value4",
    HTTPCookiePropertyKey.secure: "TRUE"
])