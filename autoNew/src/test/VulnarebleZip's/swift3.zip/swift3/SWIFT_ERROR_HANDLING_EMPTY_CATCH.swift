let a = 10

// <yes> <report> SWIFT_ERROR_HANDLING_EMPTY_CATCH empty0catch01
do {
 try a()
} catch {
 // Nothing
}

do {
 try a()
 // <no> <report>
} catch {
 print(a)
}