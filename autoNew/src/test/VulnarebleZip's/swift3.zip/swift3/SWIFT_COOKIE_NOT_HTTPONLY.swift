import Foundation
import FoundationNetworking

extension HTTPCookiePropertyKey {
    static let anyhttpOnlyName = HTTPCookiePropertyKey("HttpOnly")
}

let properties1 : [HTTPCookiePropertyKey : Any] = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/some_path1",
    HTTPCookiePropertyKey.name: "some_name1",
    HTTPCookiePropertyKey.value: "some_value1",
    HTTPCookiePropertyKey.secure: "TRUE",
    // <no> <report>
    HTTPCookiePropertyKey.anyhttpOnlyName: true
]

let properties2 : [HTTPCookiePropertyKey : Any] = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/some_path2",
    HTTPCookiePropertyKey.name: "some_name2",
    HTTPCookiePropertyKey.value: "some_value2",
    HTTPCookiePropertyKey.secure: "TRUE",
    // <yes> <report> SWIFT_COOKIE_NOT_HTTPONLY cookie0http000
    HTTPCookiePropertyKey.anyhttpOnlyName: false,
    // <yes> <report> SWIFT_COOKIE_NOT_HTTPONLY cookie0http000
    .anyhttpOnlyName: false
]

let cookie1 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path1",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE",
    .version: 1,
    // <no> <report>
    .anyhttpOnlyName: true
])!

let cookie2 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path2",
    .name: "some_name2",
    .value: "some_value2",
    .secure: "TRUE",
    .version: 1,
    // <yes> <report> SWIFT_COOKIE_NOT_HTTPONLY cookie0http000
    HTTPCookiePropertyKey.anyhttpOnlyName: false
])!

let cookie3 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path3",
    .name: "some_name3",
    .value: "some_value3",
    .secure: "TRUE",
    .version: 1,
    // <yes> <report> SWIFT_COOKIE_NOT_HTTPONLY cookie0http001
    .anyhttpOnlyName: false
])!
