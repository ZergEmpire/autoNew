import Foundation
import FoundationNetworking

let properties1 = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/some_path",
    HTTPCookiePropertyKey.name: "some_name1",
    HTTPCookiePropertyKey.value: "some_value1",
    HTTPCookiePropertyKey.secure: "TRUE",
    // <yes> <report> SWIFT_COOKIE_PERSISTENT cookie0pers000
    HTTPCookiePropertyKey.expires: Date() + 10000,
    HTTPCookiePropertyKey.version: "0"
]

let properties2 = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/some_path",
    HTTPCookiePropertyKey.name: "some_name2",
    HTTPCookiePropertyKey.value: "some_value2",
    HTTPCookiePropertyKey.secure: "TRUE",
    // <no> <report>
    HTTPCookiePropertyKey.expires: Date() + 600,
    HTTPCookiePropertyKey.version: "0"
]

let properties3 : [HTTPCookiePropertyKey : Any] = [
    .domain: "www.test.com",
    .path: "/some_path",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE",
    // <yes> <report> SWIFT_COOKIE_PERSISTENT cookie0pers002
    .maximumAge: "-1",
    .version: "1"
]

let cookie1 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path1",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE",
    // <no> <report>
    .maximumAge: "600",
    .version: "1"
])

let cookie2 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path",
    .name: "some_name2",
    .value: "some_value2",
    .secure: "TRUE",
    // <yes> <report> SWIFT_COOKIE_PERSISTENT cookie0pers000
    HTTPCookiePropertyKey.expires: Date() + 10000,
    .version: "0"
])

let cookie3 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path",
    .name: "some_name3",
    .value: "some_value3",
    .secure: "TRUE",
    // <yes> <report> SWIFT_COOKIE_PERSISTENT cookie0pers003
    .maximumAge: "10000",
    .version: "1"
])

let cookie4 = HTTPCookie(properties: [
    .domain: "www.test.com",
    .path: "/some_path",
    .name: "some_name4",
    .value: "some_value4",
    .secure: "TRUE",
    // <yes> <report> SWIFT_COOKIE_PERSISTENT cookie0pers001
    .expires: Date() + 10000,
    .version: "0"
])