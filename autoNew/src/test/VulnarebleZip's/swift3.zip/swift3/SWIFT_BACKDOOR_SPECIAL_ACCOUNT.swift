// <yes> <report> SWIFT_BACKDOOR_SPECIAL_ACCOUNT b11sa1
if (password == "qwerty") {
}
// <yes> <report> SWIFT_BACKDOOR_SPECIAL_ACCOUNT b11sa2
if (hash == "8743b52063cd84097a65d1633f5c74f5") {
}
// <no> <report>
if (password == "") {}
