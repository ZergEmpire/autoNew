// <yes> <report> SWIFT_CRYPTO_BAD_HMAC crypt0bhmac01
let algorithm = CCHmacAlgorithm(kCCHmacAlgSHA1)

// <yes> <report> SWIFT_CRYPTO_BAD_HMAC crypt0bhmac01
CCHmac(CCHmacAlgorithm(kCCHmacAlgMD5), hmacKey, hmacKey.count, hmacData, hmacData, &hmac)

// <yes> <report> SWIFT_CRYPTO_BAD_HMAC crypt0bhmac01
CCHmac(kCCHmacAlgMD5, hmacKey, hmacKey.count, hmacData, hmacData, &hmac)

// <no> <report>
CCHmac(kCCHmacAlgSHA256, hmacKey, hmacKey.count, hmacData, hmacData, &hmac)