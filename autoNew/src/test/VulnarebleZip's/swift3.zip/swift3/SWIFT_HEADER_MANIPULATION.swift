let attack = parseJson(urlRequest.httpBody).getValue("value")

var some_headers : [String: Any?] = [:]
some_headers["name"] = attack

// <yes> <report> SWIFT_HEADER_MANIPULATION head0man0
URLSessionConfiguration.`default`.httpAdditionalHeaders = some_headers

// <yes> <report> SWIFT_GET_REQUEST gr0054
var urlRequest = URLRequest(url: URL(string: "example.com")!)
// <yes> <report> SWIFT_HEADER_MANIPULATION head0man1
urlRequest.allHTTPHeaderFields["name"] = attack
// swift parsing incorrect
urlRequest.allHTTPHeaderFields?["name"] = attack
urlRequest.allHTTPHeaderFields!["name"] = attack
// <yes> <report> SWIFT_HEADER_MANIPULATION head0man2
urlRequest.addValue(attack, forHTTPHeaderField: "name")
// <yes> <report> SWIFT_HEADER_MANIPULATION head0man2
urlRequest.setValue(attack, forHTTPHeaderField: "name")
