// <yes> <report> SWIFT_GET_REQUEST gr0052
let CFRequest = CFHTTPMessageCreateRequest(kCFAllocatorDefault, "GET", myURL, kCFHTTPVersion1_1).takeRetainedValue()
// <yes> <report> SWIFT_GET_REQUEST gr0054
let request =  NSMutableURLRequest(url: NSURL(string: accessTokenEndPoint)! as URL)
// <yes> <report> SWIFT_GET_REQUEST gr0053
request.httpMethod = "GET"
// <yes> <report> SWIFT_GET_REQUEST gr0054
let urlRequest = URLRequest(url: URL(string: "example.com")!)
// <yes> <report> SWIFT_GET_REQUEST gr0054
var NSURL: NSURLRequest = NSURLRequest(URL: url)
// <no> <report>
let request1 = URLRequest(url: URL(string: "example.com")!)
request1.httpMethod = "POST"