// <yes> <report> SWIFT_KEYBOARD_CACHING kbd0cach01
@IBOutlet weak var ssnField: UITextField!

// <yes> <report> SWIFT_KEYBOARD_CACHING kbd0cach01
@IBOutlet weak var ccNoTextField: UITextField!

// <yes> <report> SWIFT_KEYBOARD_CACHING kbd0cach01
@IBOutlet weak var cvvTextField: UITextField!

// <yes> <report> SWIFT_KEYBOARD_CACHING kbd0cach01
@IBOutlet weak var pinTextField: UITextField!

// <no> <report>
@IBOutlet weak var passwordField: UITextField!
passwordField.secureTextEntry = true // it is validation

// <yes> <report> SWIFT_KEYBOARD_CACHING atryhh
let passField1: UITextField = UITextField(frame: CGRect(x: 0, y: 0, width: 300.00, height: 30.00));

// <no> <report> SWIFT_KEYBOARD_CACHING
let passField2: UITextField = UITextField(frame: CGRect(x: 0, y: 0, width: 300.00, height: 30.00));
passField2.autocorrectionType = .no

// <yes> <report> SWIFT_KEYBOARD_CACHING atryhh
let secretKey: UITextField = UITextField(frame: CGRect(x: 0, y: 0, width: 300.00, height: 30.00));

// <yes> <report> SWIFT_KEYBOARD_CACHING atryhh
let loginField: UITextField = UITextField(frame: CGRect(x: 0, y: 0, width: 300.00, height: 30.00));
