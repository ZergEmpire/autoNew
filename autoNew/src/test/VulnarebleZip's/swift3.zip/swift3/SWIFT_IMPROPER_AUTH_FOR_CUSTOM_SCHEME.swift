class A{
    let url = URL(string: "https://bartjacobs:mypassword@myapi.com?token=12345&query=swift%20ios#five")!
    let components = URLComponents(url: url, resolvingAgainstBaseURL: false)


    func writeToFile(file: String, text: String) -> Void {
        //do something
    }

    func parse(query: String) -> NSDictionary {
        //do something
    }

    func main() {
        let componentsDict = parse(components.query)
        // <yes> <report> SWIFT_IMPROPER_AUTH_FOR_CUSTOM_SCHEME abcdef
        writeToFile(file: componentsDict["file"], text: componentsDict["text"])
    }
}

