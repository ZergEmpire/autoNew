let usr_pass = getPassword(usr: "admin")
check(usr_pass)

let url = URL(string: "https://example.com")!
// <yes> <report> SWIFT_GET_REQUEST gr0054
var request = URLRequest(url: url)
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol0
request.httpBody = usr_pass.data(using: .utf8)

// <yes> <report> SWIFT_GET_REQUEST gr0054
var request: NSURLRequest = NSURLRequest(url: url)
// <yes> <report> SWIFT_CLIPBOARD gr0040
let clipboard = NSPasteboard.general.data(smh: smh)
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol0
request.httpBody = clipboard.data(using: .utf8)

// <yes> <report> SWIFT_GET_REQUEST gr0054
var request: NSMutableURLRequest = NSMutableURLRequest(url: url)
// <yes> <report> SWIFT_CLIPBOARD gr0040
let clipboard2 = UIPasteboard.general.string
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol0
request.httpBody = clipboard2.data(using: .utf8)
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol1
usr_pass.write(toFile: "some file")
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol2
print(usr_pass)
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol3
logger.info(usr_pass)
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol4 <yes> <report> SWIFT_CLIPBOARD gr0040
UIPasteboard.general.string = usr_pass
// <yes> <report> SWIFT_PRIVACY_VIOLATION priv0viol5 <yes> <report> SWIFT_CLIPBOARD gr0040
NSPasteboard.general.setString(usr_pass, forType: .string)