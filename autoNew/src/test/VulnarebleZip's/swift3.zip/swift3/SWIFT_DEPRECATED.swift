// <yes> <report> SWIFT_DEPRECATED gr0051
let webview = UIWebView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))