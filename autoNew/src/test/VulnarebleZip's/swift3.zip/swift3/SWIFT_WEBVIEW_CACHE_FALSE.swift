import UIKit
import WebKit
var wkWebview = WKWebView()
var webView: WKWebView!
// <no> <report>
webView?.removeFromSuperview()
// <no> <report>
wkWebview.removeFromSuperview()

var a = NSURLCache()
a.sharedURLCache.removeAllCachedResponses()
NSURLCache.sharedURLCache().removeAllCachedResponses()

URLCache.shared.removeAllCachedResponses()

HTTPCookieStorage.shared.removeCookies(since: Date.distantPast)
WKWebsiteDataStore.default().removeData(ofTypes: record.dataTypes, for: [record], completionHandler: {})
