// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
var url: String = "https://ya.ru"
// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna001
var url: String = "https://localhost"
// <no> <report>
var xsd: String = "http://asd.lkj"

class Superclass {
    // <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
    private var xValue = "https://ya.ru"
}

// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
var url: String = "https://[::1]"
// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
var url: String = "https://[1762:0:0:0:0:B03:1:AF18]"
// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
var url: String = "https://[fe80::219:7eff:fe46:6c42]"
// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
var url: String = "https://[::00:192.168.10.184]"
// <yes> <report> SWIFT_BACKDOOR_NETWORK_ACTIVITY bna000
var url: String = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]"
