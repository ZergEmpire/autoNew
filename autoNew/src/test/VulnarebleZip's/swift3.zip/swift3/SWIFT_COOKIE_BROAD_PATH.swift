import Foundation
import FoundationNetworking

let properties1 = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    // <yes> <report> SWIFT_COOKIE_BROAD_PATH cookie0bp000
    HTTPCookiePropertyKey.path: "/",
    HTTPCookiePropertyKey.name: "some_name1",
    HTTPCookiePropertyKey.value: "some_value1",
    HTTPCookiePropertyKey.secure: "TRUE"
]

let properties2 = [
    HTTPCookiePropertyKey.domain: "www.test.com",
    // <no> <report>
    HTTPCookiePropertyKey.path: "/some_path",
    HTTPCookiePropertyKey.name: "some_name2",
    HTTPCookiePropertyKey.value: "some_value2",
    HTTPCookiePropertyKey.secure: "TRUE"
]

let properties3 : [HTTPCookiePropertyKey : Any] = [
    .domain: "www.test.com",
    // <yes> <report> SWIFT_COOKIE_BROAD_PATH cookie0bp000
    .path: "/",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE"
]

let cookie1 = HTTPCookie(properties: [
    .domain: "www.test.com",
    // <no> <report>
    .path: "/some_path1",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE"
])

let cookie2 = HTTPCookie(properties: [
    .domain: "www.test.com",
    // <yes> <report> SWIFT_COOKIE_BROAD_PATH cookie0bp000
    HTTPCookiePropertyKey.path: "/",
    .name: "some_name2",
    .value: "some_value2",
    .secure: "TRUE"
])

let cookie3 = HTTPCookie(properties: [
    .domain: "www.test.com",
    // <yes> <report> SWIFT_COOKIE_BROAD_PATH cookie0bp001
    .path: "/",
    .name: "some_name3",
    .value: "some_value3",
    .secure: "TRUE"
])