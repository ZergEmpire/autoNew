import Foundation

let tainted = parseJson(urlRequest.httpBody).getValue("value")

// <yes> <report> SWIFT_INJECTION_JSON json0inj00
let encoder = try JSONEncoder().encode(tainted)
// <yes> <report> SWIFT_EXTERNAL_STORAGE fjkdsl
try encoder.write(to: URL(fileURLWithPath: "some_path"))