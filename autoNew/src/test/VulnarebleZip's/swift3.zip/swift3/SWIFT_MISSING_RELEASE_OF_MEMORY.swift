// <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
let globalIntPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
func f() -> Int {
    // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
    let intPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
    for i in 0..<4 {
        (intPointer + i).initialize(to: i)
    }
    print(intPointer.pointee)
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    if rand() % 2 != 0 {
        intPointer.deallocate()
        // <no> <report>
        return 42
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    } else if rand() % 2 != 0 {
        // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
        return 13
    }
    globalIntPointer.deallocate()
    // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector_info
    exit(0)
}

func released_before_exit() {
    let intPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    if rand() % 2 != 0 {
        intPointer.deallocate()
        do {
            stuff()
            globalIntPointer.deallocate()
            // <no> <report>
            exit(0)
        }
    }
    intPointer.deallocate()
}

func void_func() {
    // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
    var intPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
}

func only_in_some_cases() {
    // <no> <report>
    let intPointer = UnsafeMutableRawPointer.allocate(byteCount: 4, alignment: 4)
    for i in 0..<4 {
        (intPointer + i).initialize(to: i)
    }
    print(intPointer.pointee)
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    if rand() % 2 != 0 {
        // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
        return 42
    }
    intPointer.deallocate()
}

func with_defer() {
    // <no> <report>
    let intPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
    for i in 0..<4 {
        (intPointer + i).initialize(to: i)
    }
    print((intPointer + 2).pointee)
    defer {  // should come before potential exit point to be executed
        intPointer.deallocate()
    }
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    if rand() % 2 != 0 {
        // <no> <report>
        return
    }
}

func with_defer2() {
    // <no> report>
    let intPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
    for i in 0..<4 {
        (intPointer + i).initialize(to: i)
    }
    print((intPointer + 2).pointee)
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    if rand() % 2 != 0 {
        // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
        return
    }
    defer {
        intPointer.deallocate()
        print("deallocation")
    }
}

do {
    // <yes> <report> SWIFT_MISSING_RELEASE_OF_MEMORY missing_release_of_memory_detector
    let some_var = 3
    let localIntPointer = UnsafeMutablePointer<Int>.allocate(capacity: 4)
}

//mb add exception handling, continue and break cases