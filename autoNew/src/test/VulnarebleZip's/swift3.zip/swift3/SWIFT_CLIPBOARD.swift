// <yes> <report> SWIFT_CLIPBOARD gr0040
let pb1 = UIPasteboard.general
// <yes> <report> SWIFT_CLIPBOARD gr0041
let pb2 = UIPasteboard.init(name: "pasteboard_name", create: true)
// <yes> <report> SWIFT_CLIPBOARD gr0040
let pb3 = NSPasteboard.withUniqueName()