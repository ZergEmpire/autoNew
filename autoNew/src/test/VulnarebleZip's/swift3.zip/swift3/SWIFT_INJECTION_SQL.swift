import FMDB
import RealmSwift

// <yes> <report> SWIFT_GET_REQUEST gr0054
let urlRequest = URLRequest(url: URL(string: "example.com")!)
let input = parseJson(urlRequest.httpBody).getValue("value")

let db = FMDatabase(path: databasePath as String)
let querySQL = "SELECT name FROM CONTACTS WHERE gender = " + input

// <no> <report>
let results:FMResultSet? = db.executeQuery(querySQL, withArgumentsInArray: nil)

// <yes> <report> SWIFT_INJECTION_SQL sql0inj01
let results:FMResultSet? = db.executeQuery(querySQL, withArgumentsInArray: input)

let realm = try! Realm()

let name = parseJson(urlRequest.httpBody).getValue("name")
// <yes> <report> SWIFT_INJECTION_SQL sql0inj02
let res = realm.objects(User.self).filter("name = '" + name + "'")