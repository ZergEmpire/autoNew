// <yes> <report> SWIFT_CRYPTO_ECB_MODE gr0062
let cryptStatus = CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES128), CCOptions(kCCOptionECBMode),
                          keyData.bytes, keyLength, ivBuffer, data.bytes, data.length, cryptData.mutableBytes, cryptData.length, &numBytesEncrypted)
// <yes> <report> SWIFT_CRYPTO_ECB_MODE gr0062
let rawStatus = CCCryptorCreate(operation.nativeValue(), CCAlgorithm(kCCAlgorithmAES128), CCOptions(kCCOptionECBMode),
                                keyBytes, chosenCipherBlockSize, ivBuffer, cryptorRefPointer)