import Foundation
import Security

let token = "secret"
var query = [String : AnyObject]()
query[kSecClass as String] = kSecClassGenericPassword
query[kSecValueData as String] = token as AnyObject?

// <yes> <report> SWIFT_UNSAFE_KEYCHAIN_USAGE uns0keychain01
query[kSecAttrAccessible as String] = kSecAttrAccessibleAlwaysThisDeviceOnly

// <yes> <report> SWIFT_UNSAFE_KEYCHAIN_USAGE uns0keychain01
query[kSecAttrAccessible as String] = kSecAttrAccessibleAlways

// <no> <report>
query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly