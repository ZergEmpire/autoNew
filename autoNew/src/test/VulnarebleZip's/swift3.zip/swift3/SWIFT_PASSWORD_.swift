// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd01
let Password : String = "hardcoded_password"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hr01t
let Password : String = "hardcoded password"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd03
let Smth_passwd : String = "hardcoded_password"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hr03t
let Smth_passwd : String = "hardcoded password"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd01
let Password : Int = 14

// <yes> <report> SWIFT_PASSWORD_EMPTY pswrd0empt01
let pwd : String = ""

// <yes> <report> SWIFT_PASSWORD_EMPTY pswrd0empt03
let smth_pwd : String = ""

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd01
var Password = "password"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd02
password = "password"
// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd02
password = 14

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hr02t
password = "pass word"

// <no> <report>
password == "pass word"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd04
password_smth = "password"

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd04
password_smth = 14

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hr04t
password_smth = "pass word"

// <yes> <report> SWIFT_PASSWORD_EMPTY pswrd0empt02
password = ""

// <yes> <report> SWIFT_PASSWORD_EMPTY pswrd0empt04
password_smth = ""

// <no> <report>
UIAlertController.showAlertWith(title: "iGoat", message:
            (user?.email == email && user?.password == password) ? "Success" : "Failed")

// <no> <report>
let passwordItem = KeychainPasswordItem(service: "SaveUser",
                                                    account: userName,
                                                    accessGroup: nil)

// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd03
let validPassword = credentialsInfo["Password"] as? String

// <yes> <report> SWIFT_COOKIE_NOT_OVER_SSL cookie0ssl000
let passwordProperties: [HTTPCookiePropertyKey: Any] = [.domain: siteUrl.host ?? "",
                                                                .path: siteUrl.path,
                                                                // <no> <report>
                                                                .name: "password",
                                                                .value: CookiePassword,
                                                                .expires: expireInterval!]
// <yes> <report> SWIFT_PASSWORD_NULL gr0055
let pass: Int? = nil
// <yes> <report> SWIFT_PASSWORD_NULL gr0060
let myPass1: Int? = nil
// <yes> <report> SWIFT_PASSWORD_NULL gr0056
var password: String?