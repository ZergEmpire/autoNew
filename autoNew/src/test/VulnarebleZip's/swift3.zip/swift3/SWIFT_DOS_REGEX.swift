import Foundation

let login = URL(string: "example.com/users?q=bob&sort=name")!.query!
let password = parseJson(urlRequest.httpBody).getPassword()
// <yes> <report> SWIFT_DOS_REGEX dos0regex0
let regex = try! NSRegularExpression(pattern: login)
if regex.firstMatch(in: password, options: [], range: NSMakeRange(0, password.utf16.count)) != nil {
    print("Bad password")
} else {
    print("Accepted!")
}

let buf = NSRegularExpression.escapedPattern(for: login)
// <no> <report>
let regex1 = try! NSRegularExpression(pattern: buf)
// <no> <report>
let regex2 = try! NSRegularExpression(pattern: NSRegularExpression.escapedTemplate(for: login))

