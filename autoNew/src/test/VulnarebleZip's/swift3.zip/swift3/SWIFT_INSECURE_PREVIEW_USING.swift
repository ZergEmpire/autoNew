let webUrl : NSURL = NSURL(string: "https://some.site.com/")!
// <yes> <report> SWIFT_GET_REQUEST gr0054
let webRequest : NSURLRequest = NSURLRequest(URL: webUrl)
// <yes> <report> SWIFT_INSECURE_PREVIEW_USING uns0prewvus01
webView.loadRequest(webRequest)