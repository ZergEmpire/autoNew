import UIKit
import WebKit

var webView: WKWebView!
let urlLink = URL(fileURLWithPath: "somepath")
// <yes> <report> SWIFT_GET_REQUEST gr0054
let request = URLRequest(URL: urlLink)
//<yes> <report> SWIFT_WEBVIEW_MISCONFIG mstg66
webView.load(request)
// <yes> <report>  SWIFT_GET_REQUEST gr0054
let urlRequest = URLRequest(url: URL(string: "https://example.com/")!)
// <no> <report>
webView.load(urlRequest)