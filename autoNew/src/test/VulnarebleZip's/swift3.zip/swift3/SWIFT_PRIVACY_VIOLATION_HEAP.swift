// <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0031
let a1 = password as? String
// <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0032
let a2 = password123 as String?
// <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0036
let a3 = password as! String
// <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0037
let a4 = password123 as! String
// <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0033
let a5 = String(pass)
// <yes> <report> SWIFT_PASSWORD_HARDCODED pswrd0hrd01
let password = "123"
// <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0038
let a6: String = password