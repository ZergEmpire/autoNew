func test1(_ application: UIApplication, continue userActivity: NSUserActivity,
                 restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
    // <no> <report>
    if userActivity.activityType == NSUserActivityTypeBrowsingWeb, let url = check(userActivity.webpageURL) {
        application.open(url, options: [:], completionHandler: nil)
    }

    return true;
}

let url = URL(string: "https://example.com/exampleaction?param1=1&param2=2");
var new_url: URL = validate(url);

func test2(_ application: UIApplication, continue userActivity: NSUserActivity,
            restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {

    url2 = userActivity.webpageURL;
    // <yes> <report> SWIFT_SENSITIVE_DATA_EXPOSURE_IPC unvalidatedurls
    application.open(url2, options: [:], completionHandler: nil)

    // <yes> <report> SWIFT_SENSITIVE_DATA_EXPOSURE_IPC unvalidatedurls
    application.open(url, options: [:], completionHandler: nil)
    // <no> <report>
    application.open(new_url, options: [:], completionHandler: nil)
    return true;
}
