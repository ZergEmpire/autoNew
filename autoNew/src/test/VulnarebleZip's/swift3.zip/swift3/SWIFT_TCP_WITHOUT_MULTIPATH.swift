// <yes> <report> SWIFT_TCP_WITHOUT_MULTIPATH varmulpathtypenone
var multipathServiceType:  URLSessionConfiguration.MultipathServiceType = .none

let configuration: URLSessionConfiguration = URLSessionConfiguration.default
// <yes> <report> SWIFT_TCP_WITHOUT_MULTIPATH mulpathtypenone
configuration.multipathServiceType = .none

var type2: URLSessionConfiguration.MultipathServiceType?
// <yes> <report> SWIFT_TCP_WITHOUT_MULTIPATH mulpathnoneend
type2 = MultipathServiceType.none

var type3: URLSessionConfiguration.MultipathServiceType?
// <yes> <report> SWIFT_TCP_WITHOUT_MULTIPATH mulpathtypenone
type3 = .none

