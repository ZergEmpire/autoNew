extension String {
    func cc_sha1() -> String {
        let data = Data(self.utf8)
        var digest = [UInt8](repeating: 0, count: Int(CC_SHA1_DIGEST_LENGTH))
        data.withUnsafeBytes {

        // <yes> <report> SWIFT_CRYPTO_BAD_HASH crypt0bh01
            _ = CC_SHA1($0.baseAddress, CC_LONG(data.count), &digest)
        }

        data.withUnsafeBytes {
        // <yes> <report> SWIFT_CRYPTO_BAD_HASH crypt0bh01
            _ = CC_MD2($0.baseAddress, CC_LONG(data.count), &digest)
        }

        data.withUnsafeBytes {
        // <yes> <report> SWIFT_CRYPTO_BAD_HASH crypt0bh01
            _ = CC_MD5($0.baseAddress, CC_LONG(data.count), &digest)
        }
    }
}