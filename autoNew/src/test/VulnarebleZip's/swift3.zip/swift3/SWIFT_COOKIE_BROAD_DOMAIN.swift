import Foundation
import FoundationNetworking

let properties1 = [
    // <yes> <report> SWIFT_COOKIE_BROAD_DOMAIN cookie0bd000
    HTTPCookiePropertyKey.domain: ".test.com",
    HTTPCookiePropertyKey.path: "/some_path",
    HTTPCookiePropertyKey.name: "some_name1",
    HTTPCookiePropertyKey.value: "some_value1",
    HTTPCookiePropertyKey.secure: "TRUE"
]

let properties2 = [
    // <no> <report>
    HTTPCookiePropertyKey.domain: "www.test.com",
    HTTPCookiePropertyKey.path: "/some_path",
    HTTPCookiePropertyKey.name: "some_name2",
    HTTPCookiePropertyKey.value: "some_value2",
    HTTPCookiePropertyKey.secure: "TRUE"
]

let properties3 : [HTTPCookiePropertyKey : Any] = [
    // <yes> <report> SWIFT_COOKIE_BROAD_DOMAIN cookie0bd000
    .domain: ".test.com",
    .path: "/some_path",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE"
]

let cookie1 = HTTPCookie(properties: [
    // <no> <report>
    .domain: "www.test.com",
    .path: "/some_path1",
    .name: "some_name1",
    .value: "some_value1",
    .secure: "TRUE"
])

let cookie2 = HTTPCookie(properties: [
    // <yes> <report> SWIFT_COOKIE_BROAD_DOMAIN cookie0bd000
    HTTPCookiePropertyKey.domain: ".test.com",
    .path: "/some_path",
    .name: "some_name2",
    .value: "some_value2",
    .secure: "TRUE"
])

let cookie3 = HTTPCookie(properties: [
    // <yes> <report> SWIFT_COOKIE_BROAD_DOMAIN cookie0bd001
    .domain: ".test.com",
    .path: "/some_path",
    .name: "some_name3",
    .value: "some_value3",
    .secure: "TRUE"
])