
let driveURL = FileManager.default.url(forUbiquityContainerIdentifier: nil)?.appendingPathComponent("Documents").appendingPathComponent("file.txt")

guard let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
let fileURL = directory.appendingPathComponent(file)
// <yes> <report> SWIFT_EXTERNAL_STORAGE fjkdsl
text.write(to: fileURL, atomically: false, encoding: .utf8)
// <yes> <report> SWIFT_EXTERNAL_STORAGE jfrdqk
let getText = try String(contentsOf: fileURL, encoding: .utf8)
