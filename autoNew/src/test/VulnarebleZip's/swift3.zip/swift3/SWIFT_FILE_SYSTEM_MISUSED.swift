guard let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
let fileURL = directory.appendingPathComponent(file)
// <yes> <report> SWIFT_FILE_SYSTEM_MISUSED gr0063 <yes> <report> SWIFT_EXTERNAL_STORAGE fjkdsl
text.write(to: fileURL, atomically: true, encoding: .utf8)

do {
    // <yes> <report> SWIFT_FILE_SYSTEM_MISUSED gr0064
    let attr : NSDictionary? = try NSFileManager.defaultManager().attributesOfItemAtPath(filePath)
} catch {
    print("Error: \(error)")
}

do {
   // <yes> <report> SWIFT_FILE_SYSTEM_MISUSED gr0065
   try FileManager.default.setAttributes(attributes, ofItemAtPath: myPath)
   }
   catch
   {
        print(error)
   }
