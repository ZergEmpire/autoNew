//<yes> <report> SWIFT_HTTP_USAGE http0usage01 <yes> <report> SWIFT_GET_REQUEST gr0054
var request = URLRequest(url: URL(string:"http://example.com/")!)

//<yes> <report> SWIFT_HTTP_USAGE http0usage01
let url = URL(string: "http://www.stackoverflow.com")!

//<yes> <report> SWIFT_HTTP_USAGE http0usagel1
let url = URL(string: "http://localhost")!

// <no> <report>
let url = URL(string: "https://www.good.io")