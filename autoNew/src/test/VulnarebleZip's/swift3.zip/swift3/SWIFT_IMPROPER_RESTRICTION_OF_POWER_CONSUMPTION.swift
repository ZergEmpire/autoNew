//Camera and Audio Sessions

// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION camicr
let session1 = AVCaptureSession()
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION camicr1
var recordingSession: AVAudioSession!
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION camicr
let audioSession = AVAudioSession.sharedInstance()
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION camicr1
var session: AVCaptureSession?
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION camicr
session?.addInput()


//Working with brightness
var c:UIScreen
let b=UIScreen()
func testBrightness(){
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION brtnss1
b.main.brightness = 1
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION brtnss1
c.main.brightness = 1
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION brtnss1
UIScreen.main.brightness = 0.1
}
//Dealing with location

var d:CLLocationManager = CLLocationManager()
self.locationManager.delegate = self

if #available (iOS 8.0,*) {
    // <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION stlctn1h
    d.locationManager.requestAlwaysAuthorization()
}

if #available (iOS 9.0,*) {
    // <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION stlctn1h
    d.locationManager.allowsBackgroundLocationUpdates = true
}
// <yes> <report> SWIFT_IMPROPER_RESTRICTION_OF_POWER_CONSUMPTION stlctn1h
d.locationManager.startUpdatingLocation()