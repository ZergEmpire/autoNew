import UIKit
import WebKit
var wkWebview = WKWebView()
var webView: WKWebView!

// <yes> <report> SWIFT_WEBVIEW_CACHE mstg610
webView?.removeFromSuperview()
// <yes> <report> SWIFT_WEBVIEW_CACHE mstg610
wkWebview.removeFromSuperview()

