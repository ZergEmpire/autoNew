
import UIKit

class NSUserDefaultsStorageExerciseVC: UIViewController {
    
    func storeInDefaults() {
    // <yes> <report> SWIFT_SENSITIVE_DATA_HARDCODED sensd0hrd02
        UserDefaults.standard.set("53cr3tP", forKey: "PIN")
    }
    
    func storeInDefaults() {
    // <yes> <report> SWIFT_SENSITIVE_DATA_HARDCODED sensd0hrd02
        UserDefaults.standard.set(123, forKey: "cvv")
    }
    
    // <yes> <report> SWIFT_SENSITIVE_DATA_HARDCODED sensd0hrd01
    let secretKey = "123"

    // <no> <report>
    let secret = ClientRegistrationInfoSectionController(
        validator: nil,
        model: createClientFormModel(forSection: .registrationInfo))
    // <no> <report>
    private var buttonViewIntersection = false {
        willSet {
            if !shouldCheckBottomIntersection { return }
            if buttonViewIntersection == newValue { return }
            buttonsBlurView.isHidder = newValue ? false : true
        }
    }
    // <no> <report>
    static let sectionTitleFontSize: CGFloat = 13
    // <no> <report>
    let secret = nil
}
