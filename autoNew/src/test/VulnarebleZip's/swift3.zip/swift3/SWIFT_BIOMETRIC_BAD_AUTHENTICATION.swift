import LocalAuthentication
let context:LAContext = LAContext();
var error:NSError?
let reason : String = "Use Touch ID sensor for authenticate"

// <yes> <report> SWIFT_BIOMETRIC_BAD_AUTHENTICATION biom0badaut01
if (context.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error: &error)) {
    context.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason, reply: { (success, error) -> Void in
        if (success) {
            // OK
        } else {
            // Wrong
        }
    })
}

// <yes> <report> SWIFT_BIOMETRIC_BAD_AUTHENTICATION biom0badaut02
let flags = SecAccessControlCreateWithFlags(kCFAllocatorDefault,
                                            kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
                                            .touchIDAny,
                                            nil)

func accessControl(with protection: CFString = kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
    // <yes> <report> SWIFT_BIOMETRIC_BAD_AUTHENTICATION biom0badaut03
                    flags: SecAccessControlCreateFlags = [.biometryAny, .privateKeyUsage]) -> SecAccessControl?{
    
    var accessControlError: Unmanaged<CFError>?
    
    let accessControl = SecAccessControlCreateWithFlags(kCFAllocatorDefault, protection, flags, &accessControlError)
    
    return accessControl!
}