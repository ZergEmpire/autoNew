// <yes> <report> SWIFT_CRYPTO_BAD_ITERATION_COUNT gr0034
let derivedKey = pbkdf2(hash:CCPBKDFAlgorithm(kCCPRFHmacAlgSHA512), password:password, salt:salt, keyByteCount:keyByteCount, rounds:1200)
// <yes> <report> SWIFT_CRYPTO_BAD_ITERATION_COUNT gr0035
let derivedKey = pbkdf2SHA1(password:password, salt:salt, keyByteCount:keyByteCount, rounds:40000)
// <no> <report>
let derivedKey = pbkdf2SHA256(password:password, salt:salt, keyByteCount:keyByteCount, rounds:150000)
