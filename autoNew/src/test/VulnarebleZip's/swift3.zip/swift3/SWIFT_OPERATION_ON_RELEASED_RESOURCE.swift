func double_dealloc() {
    let ptr = UnsafeMutablePointer<Int>.allocate(capacity: 10)
    ptr.deallocate()
    // <yes> <report> SWIFT_USE_AFTER_RELEASE double_dealloc_detector
    ptr.deallocate()
}

func double_dealloc_in_smaller_scope() {
    let ptr = UnsafeMutablePointer<Int>.allocate(capacity: 10)
    ptr.deallocate()
    do {
        // <yes> <report> SWIFT_USE_AFTER_RELEASE double_dealloc_detector
        ptr.deallocate()
    }
}

func operation_on_deallocated() {
    let ptr = UnsafeMutablePointer<Int>.allocate(capacity: 10)
    ptr.deallocate()
    // <yes> <report> SWIFT_USE_AFTER_RELEASE after_release_usage_detector
    do_stuff(ptr)
    do {
        // <yes> <report> SWIFT_USE_AFTER_RELEASE after_release_usage_detector
        do_another_stuff(ptr)
    }
    // <yes> <report> SWIFT_USE_AFTER_RELEASE after_release_usage_detector
    instance.call(ptr)
}