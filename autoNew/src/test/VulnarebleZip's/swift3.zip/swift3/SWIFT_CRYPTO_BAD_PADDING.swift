// <yes> <report> SWIFT_CRYPTO_BAD_PADDING gr0039
let status_n = SecKeyEncrypt(publicKey, none, dataToEncrypt, dataLength, cipherBuffer, &cipherBufferSize)
//<no><report>
let status_1 = SecKeyEncrypt(publicKey, SecPadding.PKCS1, dataToEncrypt, dataLength,cipherBuffer, &cipherBufferSize)
// <yes> <report> SWIFT_CRYPTO_BAD_PADDING gr0050
let status_12 = SecKeyEncrypt(publicKey, SecPadding.PKCS1MD2, dataToEncrypt, dataLength, cipherBuffer, &cipherBufferSize)
// <yes> <report> SWIFT_CRYPTO_BAD_PADDING gr0050
let status_15 = SecKeyEncrypt(publicKey, SecPadding.PKCS1MD5, dataToEncrypt, dataLength, cipherBuffer, &cipherBufferSize)
// <yes> <report> SWIFT_CRYPTO_BAD_PADDING gr0050
let status_11 = SecKeyEncrypt(publicKey, PKCS1SHA1, dataToEncrypt, dataLength, cipherBuffer, &cipherBufferSize)
