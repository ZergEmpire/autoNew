import Foundation

class Rand {

    var last: Int

    func seed(st: Int) {
        self.last = st;
    }

    func random() -> Int {
        self.last = (123*last+192) % 256;
        return self.last;
    }

}
func swift_crypto_bad_random1() {
    // <no> <report>
    var lcg: Rand = Rand()
    lcg.seed(3)

    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    var b_rnd_1 = rand()
    // <yes> <report> SWIFT_CRYPTO_BAD_RANDOM crypt0badrand0
    var b_rnd_2 = random()
    // <no> <report>
    var my_rnd_1: Int = lcg.random()
    // <no> <report>
    var b_rnd : Bool = Bool.random()
    // <no> <report>
    var my_rnd_1: Int = lcg.random()
    // <no> <report>
    var arc_rnd : Int = arc4random()
    // <no> <report>
    var rand: Int = 10;
}
