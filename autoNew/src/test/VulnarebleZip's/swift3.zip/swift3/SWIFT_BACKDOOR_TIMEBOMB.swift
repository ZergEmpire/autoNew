let now:Date = Date()
let soon:Date = Date().addingTimeInterval(5000)

// <yes> <report> SWIFT_BACKDOOR_TIMEBOMB bjfk94
if (now == soon) {
    dosmth()
}
// <no> <report>
now == soon
// <yes> <report> SWIFT_BACKDOOR_TIMEBOMB gjdkel
while (now == soon) { true }
// <yes> <report> SWIFT_BACKDOOR_TIMEBOMB dkflej
repeat { true } while now == soon;
