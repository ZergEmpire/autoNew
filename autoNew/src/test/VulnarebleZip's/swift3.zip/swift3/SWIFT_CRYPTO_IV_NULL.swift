// <yes> <report> SWIFT_CRYPTO_IV_NULL crypt0ivnull01
var cryptStatus = CCCrypt(operation,
                         algorithm,
                         options,
                         keyPointer,
                         keyLength,
                         nil,
                         dataPointer,
                         dataLength,
                         cryptBufferPointer,
                         cryptBufferSize,
                         numBytesEncrypted)