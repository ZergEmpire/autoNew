let tainted = parseJson(urlRequest.httpBody).getValue("value")
// <yes> <report> SWIFT_INJECTION_CODE n1y5ck
webView.evaluateJavaScript(tainted, completionHandler: nil)