// <yes> <report> SWIFT_READ_SENSITIVE_DATA_FROM_DISK fjdeqk
let password = try String(contentsOf: fileURL, encoding: .utf8)
// <yes> <report> SWIFT_READ_SENSITIVE_DATA_FROM_DISK fjdeqk
let passwd = try String(contentsOfFile: filepath)
// <yes> <report> SWIFT_READ_SENSITIVE_DATA_FROM_DISK fkseqf
let cryptoKey = try String(contentsOfFile: filepath)
// <yes> <report> SWIFT_READ_SENSITIVE_DATA_FROM_DISK fjmv53
let secretKey = try String(contentsOfFile: filepath)
// <no> <report>
let a = try String(contentsOf: fileURL, encoding: .utf8)
// <no> <report>
let b = try String(contentsOfFile: filepath)


func SecItemCopyMatching(
    _ query: CFDictionary,
    _ result: UnsafeMutablePointer<CFTypeRef?>?
) -> OSStatus

static func readPassword(service: String, account: String) throws -> Data {
    // <yes> <report> SWIFT_PRIVACY_VIOLATION_HEAP gr0038
    let query: [String: AnyObject] = [
        kSecAttrService as String: service as AnyObject,
        kSecAttrAccount as String: account as AnyObject,
        kSecClass as String: kSecClassGenericPassword,
        kSecMatchLimit as String: kSecMatchLimitOne,
        kSecReturnData as String: kCFBooleanTrue
    ]
    var itemCopy: AnyObject?
    let status = SecItemCopyMatching(
        query as CFDictionary,
        &itemCopy
    )
    // <no> <report> for keystore
    guard let password = itemCopy as? Data else {
        throw KeychainError.invalidItemFormat
    }
    return password
}