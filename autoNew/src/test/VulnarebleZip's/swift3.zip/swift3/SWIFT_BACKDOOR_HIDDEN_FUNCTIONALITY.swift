let base64Encoded = "YW55IGNhcm5hbCBwbGVhc3VyZS4="

let decodedData = Data(base64Encoded: base64Encoded)!
let decodedString = String(data: decodedData, encoding: .utf8)!

let process = Process()
//<yes> <report> SWIFT_BACKDOOR_HIDDEN_FUNCTIONALITY bs64proc
process.launchPath = decodedString
process.arguments = arguments
let outputPipe = Pipe()
process.standardOutput = outputPipe
process.launch()

//<yes> <report> SWIFT_BACKDOOR_HIDDEN_FUNCTIONALITY bs64proc
process.arguments = decodedData

func shell(command: String) -> Int32 {
    let task = NSTask()
    task.launchPath = "/usr/bin/env"
    //<yes> <report> SWIFT_BACKDOOR_HIDDEN_FUNCTIONALITY bs64proc
    task.arguments = [decodedData, command]
    task.launch()
    task.waitUntilExit()
    return task.terminationStatus
}
