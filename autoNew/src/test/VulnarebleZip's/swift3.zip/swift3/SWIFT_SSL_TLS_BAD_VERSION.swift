let socket = WebSocket(request: request)
// <yes> <report> SWIFT_SSL_TLS_BAD_VERSION ssln0nversion
socket.socketSecurityLevel = StreamSocketSecurityLevel.none

// <yes> <report> SWIFT_SSL_TLS_BAD_VERSION ssl0ldversion
socket.socketSecurityLevel = StreamSocketSecurityLevel.ssLv2
let session = URLSession(configuration: .default)
// <yes> <report> SWIFT_SSL_TLS_BAD_VERSION tls0ldversion
session.configuration.tlsMinimumSupportedProtocol = SSLProtocol.tlsProtocol1

// <yes> <report> SWIFT_SSL_TLS_BAD_VERSION tls0ldversion
let minVersion = SSLProtocol.tlsProtocol1
// <yes> <report> SWIFT_SSL_TLS_BAD_VERSION tls0ldversion
let minVersion = SSLProtocol.tlsProtocol11
// <yes> <report> SWIFT_SSL_TLS_BAD_VERSION tls0ldversion
let status = SSLSetProtocolVersionMin(ctx, SSLProtocol.tlsProtocol1)
// <no> <report>
let minVersion = SSLProtocol.tlsProtocol12
let status = SSLSetProtocolVersionMin(ctx, minVersion)