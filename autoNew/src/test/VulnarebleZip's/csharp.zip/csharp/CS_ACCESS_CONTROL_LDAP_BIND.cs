using System.Data.Common;
using System.Data;

namespace Tests
{
    class CS_ACCESS_CONTROL_LDAP_BIND
    {
        static void Main()
        {
            // <yes> <report> CS_PASSWORD_HARDCODED b61d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string pswd = "pswd";
            // <yes> <report> CS_ACCESS_CONTROL_LDAP_BIND a678ca
            DirectoryEntry de = new DirectoryEntry("","",pswd,AuthenticationTypes.Anonymous);
            // <yes> <report> CS_ACCESS_CONTROL_LDAP_BIND 76afc7
            de.AuthenticationType = Anonymous;
            // <yes> <report> CS_ACCESS_CONTROL_LDAP_BIND 75afc7 <yes> <report> CS_PASSWORD_NULL 97acf0
            de.Password = null;
            // <yes> <report> CS_ACCESS_CONTROL_LDAP_BIND agf8ca <yes> <report> CS_PASSWORD_NULL b73fd7
            DirectoryEntry de = new DirectoryEntry("","",null);

        }
    }
}