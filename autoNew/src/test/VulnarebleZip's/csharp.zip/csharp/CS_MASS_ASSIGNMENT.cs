namespace Tests
{
    public class CS_MASS_ASSIGNMENT : Controller
    {
        static void Main()
        {
            Entity myEntity = new Entity();
            // <yes> <report> CS_MASS_ASSIGNMENT 10add7
            TryUpdateModel<myEntity>(myEntity);
        }
    }
}