using System;

namespace Tests
{
    class CsDebugCode
    {
        // <yes> <report> CS_DEBUG_CODE 6623f4
        static void Main(string[] args) 
        {
            // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.WriteLine("Hello, world!");
        }
    }
}