namespace Tests
{
    class BACKDOOR_SPECIAL_ACCOUNT
    {
        // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
        string password;
        bool exitpassword;
        string hash;
        string url;
        string ip;
        string user;
        static void Main()
        {
            // <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b11sa1
            if (password == "qwerty")
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b12sa1 <yes> <report> CS_PASSWORD_HARDCODED d66d5b
            if (password.Equals("qwerty"))
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            if (exitpassword == true)
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b11sa2
            if (hash == "8743b52063cd84097a65d1633f5c74f5")
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_SPECIAL_ACCOUNT b12sa2
            if (hash.Equals("8743b52063cd84097a65d1633f5c74f5"))
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <no> <report>
            if (password == "") {}
            // <yes> <report> CS_PASSWORD_EMPTY d76d5b
            if (password.Equals("")) {}
        }
    }
}