namespace Tests
{
    class CS_LDAP_MANIPULATION
    {
        static void Main()
        {
            // +WEB to return
            string MyCookie = Application.GetCookie(remoteUri);
            // <yes> <report> CS_LDAP_MANIPULATION 3244bc
            DirectorySearcher ds3 = new DirectorySearcher("str", MyCookie);
            // <yes> <report> CS_LDAP_MANIPULATION 1244bc
            DirectoryEntry de = new DirectoryEntry(MyCookie);
            DirectoryEntry de2 = new DirectoryEntry();
            // <yes> <report> CS_LDAP_MANIPULATION ldl8ac
            DirectorySearcher ds2 = new DirectorySearcher(de2,"some_string", MyCookie);
            DirectoryEntries myEntries = de.Children;
            // <yes> <report> CS_LDAP_MANIPULATION kdfn32
            myEntries.Add(MyCookie, myDE.SchemaClassName);


            DirectorySearcher search = new DirectorySearcher();
            // +LDAP to return
            SearchResult res = search.FindOne();
            // LDAP from this to return
            DirectoryEntry myDirectoryEntry = res.GetDirectoryEntry();
            // <yes> <report> CS_LDAP_MANIPULATION 342fds <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9475
            bool exist = DirectoryEntry.Exists(MyCookie);
            // <yes> <report> CS_LDAP_MANIPULATION 341fds
            de.MoveTo(myDirectoryEntry);
            TextBox textBox1 = new TextBox();
            // +WEB to return
            string path = textBox1.GetLineText(5);
            // <yes> <report> CS_LDAP_MANIPULATION lenns3
            de.Path = path;
            DirectoryEntry de3 = new DirectoryEntry();
            // <yes> <report> CS_LDAP_MANIPULATION ld4fds
            DirectoryEntry de2 = myDirectoryEntry.CopyTo(de3, MyCookie);
            // <yes> <report> CS_LDAP_MANIPULATION senns3
            ds3.SearchRoot = path;
            DirectoryServicesPermissionAccess access = new DirectoryServicesPermissionAccess();
            // <yes> <report> CS_LDAP_MANIPULATION 2234bc
            DirectoryServicesPermissionEntry dspe = new DirectoryServicesPermissionEntry(access, path);
            DirectoryServicesPermissionAttribute attribute = new DirectoryServicesPermissionAttribute();
            // <yes> <report> CS_LDAP_MANIPULATION lenns3
            attribute.Path = path;


        }
    }
}