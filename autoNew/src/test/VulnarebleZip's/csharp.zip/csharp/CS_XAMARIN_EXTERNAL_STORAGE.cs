namespace Tests
{
    class CS_XAMARIN_EXTERNAL_STORAGE
    {
        static void Main()
        {
             // <yes> <report> CS_XAMARIN_EXTERNAL_STORAGE caes00
             GetExternalFilesDir(Environment.DirectoryPictures);
             // <yes> <report> CS_XAMARIN_EXTERNAL_STORAGE caes00
             GetExternalFilesDirs(Environment.DirectoryPictures);
             // <yes> <report> CS_XAMARIN_EXTERNAL_STORAGE caes00
             GetExternalMediaDirs();
             // <yes> <report> CS_XAMARIN_EXTERNAL_STORAGE caes00
             GetExternalCacheDirs();
             // <yes> <report> CS_XAMARIN_EXTERNAL_STORAGE caes01
             this.GetExternalFilesDir(Environment.DirectoryPictures);
             // <yes> <report> CS_XAMARIN_EXTERNAL_STORAGE caes00
             base.GetExternalFilesDirs(Environment.DirectoryPictures);

        }
    }
}