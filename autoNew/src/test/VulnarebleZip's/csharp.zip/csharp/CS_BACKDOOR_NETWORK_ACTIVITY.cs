namespace Tests
{
    class CS_BACKDOOR_NETWORK_ACTIVITY
    {
        // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY bl1sa7
        private const string localHost = "https://localhost/";
        // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY bl1sa8
        private string localHost = "https://localhost/";
        // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa8
        private string localHost = "https://example.com/";

        int port;
        static void Main()
        {
            Socket s = new Socket();
            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11na1 
            s.Connect("127.0.0.1", port);
            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11na1 
            s.Listen("127.0.0.1");
            // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11na2
            s.Connect("http://www.example.com/wpstyle/?p=364", port);

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b12sa4 <yes> <report> CS_HTTP_USAGE gre3jk
            if (url.Equals("http://www.example.com/wpstyle/?p=364"))
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa4 <yes> <report> CS_HTTP_USAGE gre3jk
            if (url == "http://www.example.com/wpstyle/?p=364")
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url = "1.1.1.1";
            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url1 = "https://www.example.com/wpstyle";
            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url2 = "https://1.1.1.1";
            // <no> <report>
            string url3 = "http://www.w3.org/";


            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa3
            if (url == "127.0.0.1")
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b12sa3
            if (url.Equals("127.0.0.1"))
            {
                //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
                Console.WriteLine("hola!");
            }

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url2 = "https://1.1.1.1/123";

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url2 = "https://[::1]";

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url2 = "https://[1762:0:0:0:0:B03:1:AF18]";

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url2 = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]";

            // <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            string url2 = "https://[fe80::219:7eff:fe46:6c42]";
        }
    }
}