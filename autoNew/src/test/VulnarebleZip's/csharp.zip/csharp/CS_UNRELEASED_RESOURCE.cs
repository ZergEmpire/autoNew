namespace Tests
{
    class CS_UNRELEASED_RESOURCE
    {
        static void Main()
        {
            System.IO.Stream stream = (currentContext.Request.Files[0].InputStream);
            // <yes> <report> CS_UNRELEASED_RESOURCE poi876
            Bitmap map = new Bitmap(stream);
            // <no> <report>
            using (Bitmap map2 = new Bitmap(str))
            {

            }

            try 
            {
                System.IO.Stream responseStream = (currentContext.Request.Files[0].InputStream);
                // <no> <report>
                Bitmap map3 = new Bitmap(responseStream);
            }
            finally {
                  if (map3 != null) {
                map3.Dispose();
            }

        }
    }
}