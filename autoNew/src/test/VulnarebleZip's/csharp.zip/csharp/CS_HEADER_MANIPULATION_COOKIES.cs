using System.Web.Configuration;

namespace Tests
{
    class CS_HEADER_MANIPULATION_COOKIES
    {
        static void Main()
        {
            WebClient client = new WebClient ();
            string remoteUri = Console.ReadLine();
            byte[] data = client.DownloadData(remoteUri);
            var resp = new HttpResponseMessage();
            var cookie = new CookieHeaderValue("session-id", "12345"); 
            cookie.Expires = DateTimeOffset.Now.AddDays(1); 
            cookie.Domain = Request.RequestUri.Host; 
            cookie.Path = data;  
            WebClient client = new WebClient ();
            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 1e1b40 
            response.Headers.AddCookies(new CookieHeaderValue[] { cookie });

            HttpCookieCollection MyCookieCollection = new HttpCookieCollection();
            string MyCookie = Application.GetCookie(remoteUri);
            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 231b40
            MyCookieCollection.Add(MyCookie);
            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 2t1b40
            MyCookieCollection.Item = MyCookie;

            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 10yb29 <yes> <report> CS_COOKIE_NOT_HTTPONLY ht4pdk
            HttpCookie cookie = new HttpCookie(MyCookie);

            TextBox textBox1 = new TextBox();
            string domain = textBox1.GetLineText(5);
            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 321b40
            cookie.Domain = domain;
            
            Uri uri = new Uri(domain);
            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 222b29
            Application.SetCookie(uri, simpleCookie);
            // <yes> <report> CS_COOKIE_NOT_HTTPONLY ht4pdk
            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encrypted_ticket);
            // <yes> <report> CS_HEADER_MANIPULATION_COOKIES 321b40
            cookie.Expires = domain.Expires;

        }
    }
}