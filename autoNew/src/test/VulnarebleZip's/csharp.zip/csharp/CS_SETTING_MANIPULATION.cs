namespace Tests
{
    class CS_SETTING_MANIPULATION
    {
        static void Main()
        {
            ResultTable table = new ResultTable();
            var name = table.GetString(5);
            // <yes> <report> CS_SETTING_MANIPULATION 115b29
            ObjectContext context = new ObjectContext(name);

            SqlConnection connection = new SqlConnection(connectionString);
            SqlTransaction transaction;
            // <yes> <report> CS_SETTING_MANIPULATION a0pd15
            transaction = connection.BeginTransaction(IsolationLevel.ReadCommitted, name);    

            var address = "https://address";    
            WebClient client = new WebClient ();
            string reply = client.DownloadString(address);
            // <yes> <report> CS_SETTING_MANIPULATION q0pd15
            transaction = connection.BeginTransaction(reply);
            // <yes> <report> CS_SETTING_MANIPULATION 105b29
            DirectoryServicesPermissionEntry entry = new DirectoryServicesPermissionEntry(reply, "/");

            var number = table.GetValue(1);
            Stream str = new Stream();
            // <yes> <report> CS_SETTING_MANIPULATION q01015
            str.SetLength(number);
            // <yes> <report> CS_SETTING_MANIPULATION ldj415
            str.Capacity = number;

            string n = @"C:\test\newdir";
            DateTime dtime1 = new DateTime(number, 1, 3);
            // <yes> <report> CS_SETTING_MANIPULATION pore15
            Directory.SetAccessControl(n, dtime1);

            AppDomain currentDomain = AppDomain.CurrentDomain;
            // <yes> <report> CS_SETTING_MANIPULATION 121015
            currentDomain.SetData(name, "Example value");

            // <yes> <report> CS_SETTING_MANIPULATION p12e15
            Console.SetError(reply);

            RegistryProxy proxy = new RegistryProxy();
            // <yes> <report> CS_SETTING_MANIPULATION p21015
            proxy.SetValue("key", name, "Example value");

            RowUpdatedEventArgs arg = new RowUpdatedEventArgs(dataRow, command, statementType, tableMapping);
            // <yes> <report> CS_SETTING_MANIPULATION 3tyb40
            arg.Status = reply;

            String myADSPath = "LDAP://onecity/CN=Users,DC=onecity,DC=corp,DC=fabrikam,DC=com";
            DirectoryEntry myDirectoryEntry = new DirectoryEntry(myADSPath);
            string userName = client.DownloadString(name);
            // <yes> <report> CS_SETTING_MANIPULATION w21w15
            myDirectoryEntry.Username = userName;

            // <yes> <report> CS_SETTING_MANIPULATION ldtt15
            Environment.CurrentDirectory = reply;
            // <yes> <report> CS_SETTING_MANIPULATION iwjrwm
            int rowsAffected = SqlHelper.ExecuteNonQuery(name, CommandType.Text, query, parameters.ToArray());
            // <yes> <report> CS_SETTING_MANIPULATION 564nj4
            Interaction.DeleteSetting(name);
        }
    }
}