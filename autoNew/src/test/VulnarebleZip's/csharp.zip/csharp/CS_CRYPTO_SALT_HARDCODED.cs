namespace Tests
{
    class CS_CRYPTO_SALT_HARDCODED
    {
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_SALT_HARDCODED gtkj54
            Rfc2898DeriveBytes rdb = new Rfc2898DeriveBytes(password, "salt", 1000000);
            // <yes> <report> CS_CRYPTO_SALT_HARDCODED f3hjws
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, "salt", "sha256", 100000);
        }
    }
}