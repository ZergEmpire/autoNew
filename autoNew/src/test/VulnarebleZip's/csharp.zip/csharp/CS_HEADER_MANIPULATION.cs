using System.Web.Configuration;

namespace Tests
{
    class CsHeaderManipulation
    {
        static void Main()
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration("/app");
            HttpRuntimeSection hrs = (HttpRuntimeSection) config.GetSection("system.web/httpRuntime");
            // <yes> <report> CS_HEADER_MANIPULATION e2913e
            hrs.EnableHeaderChecking = false;
            boolean notFalse = true;
            // <no> <report>
            hrs.EnableHeaderChecking = notFalse;
            Application app = new Application();
            string tainted = app.GetCookie();
            SPSite sps = new SPSite();
            // <yes> <report> CS_HEADER_MANIPULATION 2e5b40
            sps.OpenWeb(tainted);

            WebHeaderCollection myWebHeaderCollection = myHttpWebResponse.Headers;
            // <yes> <report> CS_HEADER_MANIPULATION 12913e
            myWebHeaderCollection.AllKeys = tainted;
            // <yes> <report> CS_HEADER_MANIPULATION 123mde
            myWebHeaderCollection.Set("Cache-Control", tainted);
            // <yes> <report> CS_HTTP_USAGE gre3jk <yes> <report> CS_BACKDOOR_NETWORK_ACTIVITY b11sa5
            WebRequest myWebRequest = WebRequest.Create("http://www.contoso.com");
            // <yes> <report> CS_HEADER_MANIPULATION uir13e
            myWebRequest.Headers = tainted;
            HttpResponseWrapper response = new HttpResponseWrapper(resp);
            // <yes> <report> CS_HEADER_MANIPULATION le3mde
            response.AddHeader(tainted, "value");
            // <yes> <report> CS_HEADER_MANIPULATION orpw4e
            Response.AppendHeader("CustomAspNetHeader", tainted);
            // <yes> <report> CS_HEADER_MANIPULATION 0495jd
            HttpStatusCodeResult res = new HttpStatusCodeResult(statusCode, tainted);
            // <yes> <report> CS_HEADER_MANIPULATION 04krtj
            HttpNotFoundResult nfr = new HttpNotFoundResult(tainted);
            // <yes> <report> CS_HEADER_MANIPULATION 0kf5jd
            FilePathResult pathResult = new FilePathResult("name", tainted);
            // <yes> <report> CS_HEADER_MANIPULATION kkr13e
            pathResult.FileDownloadName = tainted;
            ContentResult content = new ContentResult();
            // <yes> <report> CS_HEADER_MANIPULATION ktheb5
            content.ContentType = tainted;
            // <yes> <report> CS_HEADER_MANIPULATION orpw4e
            Response.Cache.AppendCacheExtension(tainted);
            SimpleWorkerRequest simpleRequest = new SimpleWorkerRequest();
            // <yes> <report> CS_HEADER_MANIPULATION 12vfy5
            simpleRequest.SendKnownResponseHeader(index, tainted);
            // <yes> <report> CS_HEADER_MANIPULATION ltmq3e
            Response.ContentType = tainted;
            // +WEB
            Guid webId = new Guid(HttpUtility.UrlDecode(Request.QueryString["Web"]));
            Guid listId = new Guid(HttpUtility.UrlDecode(Request.QueryString["List"]));
            // <yes> <report> CS_HEADER_MANIPULATION fgej3b
            survey = SPContext.Current.Site.OpenWeb(webId).Lists[listId];
            // <yes> <report> CS_HEADER_MANIPULATION 0495jg
            var contentDisposition = new ContentDispositionHeaderValue(Request.QueryString["Web"]);

            NameValueCollection newHeader = new NameValueCollection();
            newHeader.Add("newHeader", Request.QueryString["Header"]);
            // <yes> <report> CS_HEADER_MANIPULATION head01
            Response.Headers.Add(newHeader);
            // <yes> <report> CS_HEADER_MANIPULATION head01
            Response.Cookies.Add(newHeader);
        }

    }
}