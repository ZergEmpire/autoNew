namespace Tests
{
    class CS_UNCHECKED_RETURN_VALUE
    {
        static void Main()
        {
            string filename = @"C:\Example\existingfile.txt";
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9474
            Interaction.Shell();
            TextReader reader = File.OpenText(filename);
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9473
            reader.ReadBlock(a);

            Stream stream = File.Open(filename);
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9473
            stream.Read(b);

            BinaryReader breader = new BinaryReader(File.Open(fileName, FileMode.Open));
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9473
            breader.Read(c);
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9475
            d = DirectoryEntry.UsePropertyCache;
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9475
            DirectoryEntry.Exists();
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9476
            e = DirectorySearcher.CacheResults;
            DirectorySearcher search = new DirectorySearcher(searchRoot);
            // <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9477
            e = search.CacheResults;
        }
        private static byte[] StreamReadSafe(Stream streamResponse)
        {
            byte[] content;
            var buffer = new byte[1024];
            using (var ms = new MemoryStream())
            {
                int read;
                // <yes> <report> CS_DOS jtk53n
                while ((read = streamResponse.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                content = ms.ToArray();
            }
            return content;
        }
    }
}