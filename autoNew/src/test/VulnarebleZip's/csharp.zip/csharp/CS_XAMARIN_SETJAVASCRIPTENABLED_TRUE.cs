namespace Tests
{
    class CS_XAMARIN_SETJAVASCRIPTENABLED_TRUE
    {
        static void Main()
        {
             WebView myWebView = FindViewById<WebView>(Resource.Id.LoginText);
             // <yes> <report> CS_XAMARIN_SETJAVASCRIPTENABLED_TRUE cxsjst
             myWebView.Settings.JavaScriptEnabled = true;
             WebView myWebView = FindViewById<WebView>(Resource.Id.LoginText);
             var JavaScriptEnabled = true;
             _javascriptEnabled = JavaScriptEnabled; // Somewhere here should be reported also. Please, do it if you catch how it works

        }
    }
}