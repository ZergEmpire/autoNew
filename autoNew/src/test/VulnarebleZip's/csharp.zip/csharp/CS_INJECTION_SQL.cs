using Microsoft.ApplicationBlocks.Data;

namespace Tests
{
    class CS_SQL_INJECTION
    {
        private readonly string _connectionString;
        // <yes> <report> CS_DEBUG_CODE 6623f4     
        static void Main(string[] args)
        {
            string a = Request.QueryString["a"];
            string some_string = Request.QueryString["some_string"];
            SqlHelperParameterCache shpc = new SqlHelperParameterCache();
            // <yes> <report> CS_INJECTION_SQL cb6691
            shpc.CacheParameterSet('a', a);
            Database d = new Database();
            // <yes> <report> CS_INJECTION_SQL 2e1b2a 
            d.GetSqlStringCommand(a);
            /* Это неправильная конструкция - интерфейс задается по другому, 
            когда будем уметь отлавливать supers надо вернуться к этим паттернам
            IMultiQuery imq = new IMultiQuery();
            <yes> <report> CS_INJECTION_SQL 6406ef <yes> <report> CS_INJECTION_SQL 2e1b2b
            imq.Add(func());
            ISession i = new ISession();
            <yes> <report> CS_INJECTION_SQL eef009 <yes> <report> CS_INJECTION_SQL 2e1b2e
            i.CreateFilter(1, func(1));
            */
            SqlClientSqlCommandSet scscs;
            // <yes> <report> CS_INJECTION_SQL 2e1b2f <yes> <report> CS_INJECTION_SQL 307198
            scscs.Append(a);
            SqlString ss = new SqlString();
            // <yes> <report> CS_INJECTION_SQL cb3003
            ss.Replace("q", a);
            QueryCommand qc = new QueryCommand();
            // <yes> <report> CS_INJECTION_SQL d247b2
            qc.CommandSql = f;
            DataContext dc = new DataContext();
            // <yes> <report> CS_INJECTION_SQL a6cb76
            dc.ExecuteQuery();
            System.String some_string = "hello";
            // <yes> <report> CS_INJECTION_SQL a68b67
            DbDataAdapter dda1 = new DbDataAdapter(some_string, "wildcard");
            /* Это неправильная конструкция - интерфейс задается по другому, 
            когда будем уместь отлавливать supers надо вернуться к этим паттернам
             <yes> <report> CS_INJECTION_SQL 09acbf
            IDbCommand idc1 = new IDbCommand(some_string);
             <yes> <report> CS_INJECTION_SQL 09acbf
            IDbCommand idc3 = new IDbCommand(some_string,"hello","hello");
             <yes> <report> CS_INJECTION_SQL 7634ba
            idc1.CommandText = some_string;
            */
            SqlDataSource source = new SqlDataSource();
            // <yes> <report> CS_INJECTION_SQL bc189c
            source.SelectCommand = some_string;
            source.SelectCommand = 2;
            System.Data.CommandType cmt = new System.Data.CommandType();
            // <yes> <report> CS_INJECTION_SQL 2e1b27
            SqlHelper.FillDataset(some_string, cmt, a, 0);
            System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
            // <yes> <report> CS_INJECTION_SQL 2e1b27
            SqlHelper.FillDataset(sc, cmt, a, 0);
            Database db = new Database();
            // <yes> <report> CS_INJECTION_SQL 2e1b28
            db.LoadDataSet(a, some_string);
            System.Data.Common.DbTransaction dt = new System.Data.Common.DbTransaction();
            // <yes> <report> CS_INJECTION_SQL 2e1b29
            db.LoadDataSet(a, cmt, some_string);
            // <yes> <report> CS_INJECTION_SQL 2e1b2a 
            db.GetSqlStringCommand(a);
            /*
            Это неправильная конструкция - интерфейс задается по другому, 
            когда будем уметь отлавливать supers надо вернуться к этим паттернам
            IMultiQuery imq = new IMultiQuery();
             <yes> <report> CS_INJECTION_SQL 6406ef <yes> <report> CS_INJECTION_SQL 2e1b2b
            imq.AddNamedQuery(some_string);
             <yes> <report> CS_INJECTION_SQL 2e1b2c
            IQuery iq = new IQuery(some_string);
            ISession session = new ISession();
             <yes> <report> CS_INJECTION_SQL 2e1b2d
            session.CreateQuery(some_string);
             <yes> <report> CS_INJECTION_SQL eef009 <yes> <report> CS_INJECTION_SQL 2e1b2e
            session.CreateFilter(0, some_string);
            */
            SqlClientSqlCommandSet scscs = new SqlClientSqlCommandSet();
            // <yes> <report> CS_INJECTION_SQL 2e1b2f <yes> <report> CS_INJECTION_SQL 307198
            scscs.Append(a);
            // <yes> <report> CS_INJECTION_SQL 2e3b30
            SqlString ss = new SqlString(a);
            // <yes> <report> CS_INJECTION_SQL 2e1b31
            ss.Append(a);
            // <yes> <report> CS_INJECTION_SQL cb3003
            ss.Replace(0, a);
            SqlStringBuilder ssb = new SqlStringBuilder();
            // <yes> <report> CS_INJECTION_SQL 2e1b33
            ssb.Add(a);
            // <yes> <report> CS_INJECTION_SQL 2e1b34
            ssb.Insert(0,a);
            QueryCommand qc = new QueryCommand();
            // <yes> <report> CS_INJECTION_SQL d247b2
            qc.CommandSql = a;
            // <yes> <report> CS_INJECTION_SQL 2e1b36
            qc.QueryCommand(a);
            // <yes> <report> CS_INJECTION_SQL 2e1b37
            Query.ParseAndRunSqlCommand(a);
            InlineQuery iq = new InlineQuery();
            // <yes> <report> CS_INJECTION_SQL 8a64ef
            iq.ExecuteAggregate(a);
            // <yes> <report> CS_INJECTION_SQL 231e46 
            HqlBasedQuery abq = new HqlBasedQuery(a);
            ActiveRecordBase arb = new ActiveRecordBase();
            Type t = new Type();
            // <yes> <report> CS_INJECTION_SQL 2e1b3a
            arb.Exists(t, a);
            Recordset rs = new Recordset();
            // <yes> <report> CS_INJECTION_SQL bd4c70
            rs.Open(a);
            
            //sink rules

            string tainted = "tainted";
            ObjectContext context = new ObjectContext("name=AdventureWorksEntities");
            //создается сет, содержащий метаданные о конкретной сущности
            var query = context.CreateObjectSet<Person>();

            DbSet ds = new DbSet();
            // <yes> <report> CS_INJECTION_SQL 2e5b32
            ds.SqlQuery(query);
            IPAddress ip = new IPAddress();
            n = ip.Parse(tainted);
            ObjectContext oc = new ObjectContext();
            // <yes> <report> CS_INJECTION_SQL 2e5b33
            oc.CreateQuery(query);
            // <no> <report>
            oc.CreateQuery(n);
            // <yes> <report> CS_INJECTION_SQL 2e5b34
            oc.ExecuteStoreCommand(query);
            // <yes> <report> CS_INJECTION_SQL 2e5b35
            oc.ExecuteStoreQuery(query);
            // <yes> <report> CS_INJECTION_SQL 2e5b36
            ObjectQuery oc1 = new ObjectQuery(query);
            taint = oc1.Execute();
            
            ObjectQuery<Product> productQuery2 = new ObjectQuery<Product>(query, context);
            // <yes> <report> CS_INJECTION_SQL 2e5b38
            ObjectQuery<Product> productQuery3 = productQuery2.Except(productQuery2);
            // <yes> <report> CS_INJECTION_SQL 2e5b37
            ObjectQuery<DbDataRecord> productQuery = productQuery2.GroupBy(query,some_string);

            DataSet ds = SqlHelper.ExecuteDataset(connection,CommandType.StoredProcedure,"SELECT_DATA"); 

            Query q = Challenge.CreateQuery();
            q.ExecuteJoinedDataSet();
            q.ExecuteReader();
            SimpleQuery<Post> q = new SimpleQuery<Post>(@" from Post p where p.Blog.Author = ?", author);;
            var ie = q.InternalExecute(session);
            // <no> <report>
            SqlCommand scom = new SqlCommand(ie);

            XQueryEvaluator evaluator = executable.Load();
            var smth = evaluator.Evaluate();
            // +ARGS to return
            SqlDataAdapter adapter1 = new SqlDataAdapter(args[1], connectionstring);
            // <yes> <report> CS_INJECTION_SQL 42n34w
            adapter1.Fill(ds, "Contents");
            // <yes> <report> CS_INJECTION_SQL 2e1b27
            SqlHelper.FillDataset(some_string, cmt, ie, 0);
            System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
            // <yes> <report> CS_INJECTION_SQL 2e1b27
            SqlHelper.FillDataset(sc, cmt, ie, 0);

            string sql = "select * from Comments where productCode" + a;
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                MySqlDataAdapter da = new MySqlDataAdapter(sql, connection);
                da.SelectCommand.Parameters.AddWithValue("@productCode", productCode);
                DataSet ds = new DataSet();
                // <yes> <report> CS_INJECTION_SQL mysqla
                da.Fill(ds);
            }
            using (SqliteConnection connection = new SqliteConnection(_connectionString))
            {
                connection.Open();
                SqliteDataAdapter da = new SqliteDataAdapter(sql, connection);
                DataSet ds = new DataSet();
                // <yes> <report> CS_INJECTION_SQL monoa1
                da.Fill(ds);

            }

            SqlCommand cmd = new SqlCommand(a);
            // <yes> <report> CS_INJECTION_SQL 2e5439
            SqlDataReader rdr = cmd.ExecuteReader();
        }
    }

    public class HomeController : Controller {
            public void SaveAccount(string username, string email){
                // <yes> <report> CS_PASSWORD_HARDCODED 59382k
                SqlConnection cnn = new SqlConnection("Server=;Database=fake;User Id=fake;Password=fake@123;Encrypt=yes");
                cnn.Open();
                string query = "INSERT INTO NhanTin(UserName,Email) values ('"+ username + "','"+email+"')";
                SqlCommand sqlcom = new SqlCommand(query, cnn);
                try {
                    // <yes> <report> CS_INJECTION_SQL 2e5439 <yes> <report> CS_CSRF sdfteq
                    sqlcom.ExecuteNonQuery();
                // <yes> <report> CS_ERROR_HANDLING_EMPTY_CATCH 63438e
                } catch (SqlException ex) {
                }
            }

              public string GetCustomerEmail(string customerNumber, HttpRequest Request)
                    {
                            using (MySqlConnection connection = new MySqlConnection(_connectionString))
                            {
                                string sql = "select email from CustomerLogin where customerNumber = " + customerNumber;
                                MySqlCommand command = new MySqlCommand(sql, connection);
                                // <yes> <report> CS_INJECTION_SQL 2e5439
                                output = command.ExecuteScalar().ToString();
                            }

                          string input = Request.QueryString["user"];
                          MySqlCommand cmd = new MySqlCommand(sql, connection);
                          cmd.CommandText = "DELETE FROM " + USERS_IN_ROLES_TB_NAME + " WHERE UserId = $UserId";
                          cmd.Parameters.Clear ();
                          cmd.Parameters.AddWithValue ("$UserId", input);
                          cmd.ExecuteNonQuery ();
                        }
                    }
        }
}