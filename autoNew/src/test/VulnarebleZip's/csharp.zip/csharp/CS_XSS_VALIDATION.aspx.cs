using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using OWASP.WebGoat.NET.App_Code.DB;
using OWASP.WebGoat.NET.App_Code;

namespace OWASP.WebGoat.NET
{
    public partial class ReflectedXSS : System.Web.UI.Page
    {

        void LoadCity (String city)
        {
            // +WEB to return
            string tainted = Request.RawUrl;
            // +POOR_VALIDATION to return
            string encoded_string = AntiXssEncoder.HtmlEncode(tainted, true);
            // <yes> <report> CS_XSS_VALIDATION xssv00
            lblOutput.Text = "Here are the details for our " + encoded_string + " Office";
        }
    }
}