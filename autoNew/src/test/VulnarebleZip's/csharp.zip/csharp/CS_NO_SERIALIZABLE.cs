namespace Tests
{
    // <no> <report>
    [Serializable]
    public class SERIALIZABLE : ISerializable
    {
        static void Main()
        {
            // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.WriteLine("Hello World!");
        }
    }
    // <yes> <report> CS_NO_SERIALIZABLE 90add7
    public class CS_NO_SERIALIZABLE : ISerializable
    {
        static void Main()
        {
            // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.WriteLine("Hello World!");
        }
    }
}