namespace Tests
{
    class CS_CRYPTO_BAD_ALGORITHM
    {
        static void Main()
        {
             RijndaelManaged rijndaelManaged = new RijndaelManaged();
             rijndaelManaged.KeySize = 256;
             rijndaelManaged.BlockSize = 256;
             // <yes> <report> CS_CRYPTO_ALGORITHM_BAD_MODE ccabm0
             rijndaelManaged.Mode = CipherMode.ECB;
             // <yes> <report> CS_CRYPTO_ALGORITHM_BAD_MODE ccabm1
             rijndaelManaged.Mode = System.Security.Cryptography.CipherMode.ECB;
             return rijndaelManaged.CreateEncryptor();
        }
    }
}