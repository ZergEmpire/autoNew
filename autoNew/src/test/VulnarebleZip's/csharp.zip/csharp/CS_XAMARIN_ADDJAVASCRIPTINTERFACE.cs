namespace Tests
{
    class CS_XAMARIN_ADDJAVASCRIPTINTERFACE
    {
        static void Main()
        {
             WebView myWebView = FindViewById<WebView>(Resource.Id.LoginText);
             // <yes> <report> CS_XAMARIN_ADDJAVASCRIPTINTERFACE cxajs0
             myWebView.AddJavascriptInterface(this, "Example");

        }
    }
}