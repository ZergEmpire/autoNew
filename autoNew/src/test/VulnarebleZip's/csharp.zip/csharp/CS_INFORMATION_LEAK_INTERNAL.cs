using System.Web.UI;

namespace Tests
{
    class CS_INFORMATION_LEAK_INTERNAL
    {
        static void Main()
        {
            Page p = new Page();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL bf6f3d
            p.TraceEnabled = true;
            Exception e = new Exception();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL lde2k4
            Clipboard.SetDataObject(e.ToString());

            TextBox textBox1 = new TextBox();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL dler43
            textBox1.AppendText(e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL thek44
            Logger.SetContextItem(e.ToString(), myComponent.SessionId);
            LogWriter writer = new LogWriter();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL ijte4k
            writer.Write(e.ToString());
            Logger logger = LogManager.GetCurrentClassLogger();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL 546thi
            logger.Trace(e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL 654ked
            Files.CreateToFile(path, e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL kmty44
            Interaction.InputBox(e.ToString(), a, b, 4, 5);
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL tym453 <yes> <report> CS_UNCHECKED_RETURN_VALUE dd9474
            var p = Interaction.MsgBox(e.ToString());
            ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL infle0
            log.Info(e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL infle1
            log.WarnFormat(format, e.ToString());
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL 12e2k4 <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.Write(e.ToString());
            string es = e.ToString();
            EventLog myLog = new EventLog();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL kfhr43
            myLog.WriteEntry(es);

            Guid g = Guid.NewGuid();
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL ijte4k
            writer.Write(g);
            // <yes> <report> CS_INFORMATION_LEAK_INTERNAL ijte4k
            writer.Write(Guid.NewGuid());

            try {
            } catch (Exception ex){
                // <yes> <report> CS_INFORMATION_LEAK_INTERNAL infle3
                log.Error("Error with custom customer login", ex);
            }
        }
    }
}