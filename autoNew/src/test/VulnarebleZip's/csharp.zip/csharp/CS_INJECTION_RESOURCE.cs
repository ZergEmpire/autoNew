using System;
using System.Data.Common;
using System.IO;
using System.Net.Sockets;
using System.Net;

namespace Tests
{
    class CsInjectionResource
    {
        static void Main()
        {
            // <no> <report>
            DbDataAdapter oldAdapter = new DbDataAdapter();
            // <yes> <report> CS_INJECTION_RESOURCE 64965d
            DbDataAdapter adapter = new DbDataAdapter(oldAdapter); //InArguments 1 ??

            UnmanagedMemoryStream readStream = new UnmanagedMemoryStream(memBytePtr, message.Length, message.Length, FileAccess.Read);
            readStream.Read(outMessage, 0, message.Length);
            
            String taintedString = "qwerty";
            // <yes> <report> CS_INJECTION_RESOURCE c91ae1
            TextReader reader = new TextReader(outMessage);
            // <no> <report>
            TextWriter writer = File.CreateText("newfile.txt");
            
            FileInfo fileInfo = new FileInfo();
            // <yes> <report> CS_INJECTION_RESOURCE e3997f
            fileInfo.Open(outMessage);
            
            DirectoryInfo directoryInfo = new DirectoryInfo();
            // <yes> <report> CS_INJECTION_RESOURCE 513a6c
            directoryInfo.CreateText(outMessage);
            
            // <yes> <report> CS_INJECTION_RESOURCE c91ah1
            Socket tempSocket = new Socket(ipe.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            
            // <yes> <report> CS_INJECTION_RESOURCE 71e541
            WebRequest request = WebRequest.Create(outMessage);
            
            // System.Web.Mail.SmtpMail.Send() : Recommended alternative: System.Net.Mail
            // <yes> <report> CS_INJECTION_RESOURCE 3f9634
            SmtpMail.Send(outMessage);

            // <yes> <report> CS_INJECTION_RESOURCE 7f9634
            Activator activator = Activator.CreateInstance("taintedString", outMessage);

            Exception e = new Exception();
            
            // <yes> <report> CS_INJECTION_RESOURCE 22gl15
            e.HelpLink = outMessage;

            Chart chart = new Chart();
            // <yes> <report> CS_INJECTION_RESOURCE 43gl15
            chart.BackImage = outMessage;

            // <yes> <report> CS_INJECTION_RESOURCE c92ae1 <yes> <report> CS_PATH_MANIPULATION ab5b24
            TextReader read = File.OpenText(e);
            // <yes> <report> CS_INJECTION_RESOURCE erf321
            FlatFileTraceListenerData data = new FlatFileTraceListenerData(outMessage);
            // <yes> <report> CS_INJECTION_RESOURCE rwe322
            data.FileName = outMessage;
            // <yes> <report> CS_INJECTION_RESOURCE erfn33
            ActiveRecordStarter.CreateSchema(outMessage);

            Application app = new Application();
            string tainted = app.GetCookie();
            CloudBlobClient client = CloudStorageAccount.Parse(config).CreateCloudBlobClient();
            // <yes> <report> CS_INJECTION_RESOURCE ab5b02
            mediaContainer = client.GetContainerReference(tainted);

            Encoding rEncoding = Encoding.GetEncoding(tainted);
            // <no> <report>
            using (var sr = new StreamReader(rEncoding)) {

            }
            // <yes> <report> CS_INJECTION_RESOURCE csir00
            Assembly.Load(outMessage.GetBuffer());
        }
    }
}