using System.Security.Cryptography;

namespace Tests
{
    class CS_WEAK_ENCRYPTION_INADEQUATE_RSA_PADDING
    {
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_BAD_PADDING b9f8eb
            RSAPKCS1KeyExchangeFormatter var1 = new RSAPKCS1KeyExchangeFormatter();
            RSACryptoServiceProvider var2 = new RSACryptoServiceProvider();
            byte[] b;
            // <yes> <report> CS_CRYPTO_BAD_PADDING cbd5ec
            var2.Encrypt(b, false);
            RSACryptoServiceProvider r1 = new RSACryptoServiceProvider(2048);
            // <yes> <report> CS_CRYPTO_BAD_PADDING cbd5ec
            r1.Decrypt("smth",false);
            // <yes> <report> CS_CRYPTO_BAD_PADDING cbd5ec
            r1.Encrypt("smth",0);
            r1.Encrypt("smth",true);
            // <yes> <report> CS_CRYPTO_BAD_PADDING b9f8eb
            RSAPKCS1KeyExchangeDeformatter r2 = new RSAPKCS1KeyExchangeDeformatter();

        }
    }
}