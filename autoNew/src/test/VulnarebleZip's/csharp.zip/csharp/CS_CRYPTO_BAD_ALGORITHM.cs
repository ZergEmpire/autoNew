namespace Tests
{
    class CS_CRYPTO_BAD_ALGORITHM
    {
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_BAD_ALGORITHM f8bd5a
            DES d = new DES();
            // <yes> <report> CS_CRYPTO_BAD_ALGORITHM ab72dc
            DES.Create();
            // <yes> <report> CS_CRYPTO_BAD_ALGORITHM f8bd5a
            RC2 r = new RC2();
            // <yes> <report> CS_CRYPTO_BAD_ALGORITHM ab72dc
            RC2.Create();
            SymmetricAlgorithm sa = new SymmetricAlgorithm();
            // <yes> <report> CS_CRYPTO_BAD_ALGORITHM 1272dc
            SymmetricAlgorithm.Create("DES");
            // <yes> <report> CS_CRYPTO_BAD_ALGORITHM a8bd5a
            CngAlgorithm ca = new CngAlgorithm("RC4");
        }
    }
}