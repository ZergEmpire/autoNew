using System;

namespace Tests
{
    class CsCorrectnessGc
    {
        static void Main()
        {
            // <yes> <report> CS_CORRECTNESS_GC 215968
            GC.Collect();
        }
    }
}