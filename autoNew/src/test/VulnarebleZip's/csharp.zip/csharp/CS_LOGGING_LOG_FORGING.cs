namespace Tests
{
    class CS_LOGGING_LOG_FORGING
    {
        static void Main()
        {
            ResultTable table = new ResultTable(); 
            string p = table.GetString(10);
            // <yes> <report> CS_LOGGING_LOG_FORGING pdad17
            EventLog.WriteEntry("MySource", p);
            // <yes> <report> CS_LOGGING_LOG_FORGING pdad44
            Response.AppendToLog(p);
            Log myLog = new Log();
            // <yes> <report> CS_LOGGING_LOG_FORGING 245b3c
            myLog.WriteEntry(p);
            // <yes> <report> CS_LOGGING_LOG_FORGING lkad17
            log.Info("Failed to parse val= " + p);
            // <yes> <report> CS_LOGGING_LOG_FORGING tekwks
            Logger.SetContextItem(p, myComponent.SessionId);
            LogWriter writer = new LogWriter();
            // <yes> <report> CS_LOGGING_LOG_FORGING y4mle2
            writer.Write(p);
            Logger logger = LogManager.GetCurrentClassLogger();
            // <yes> <report> CS_LOGGING_LOG_FORGING ektelw
            logger.Trace(p);
            // <yes> <report> CS_LOGGING_LOG_FORGING tyeh53
            Utility.WriteTrace(p);

            ILogger logger;
            String username = ctx.Request.QueryString["username"];
            // <yes> <report> CS_LOGGING_LOG_FORGING ektelw
            logger.Warn(username + " log in requested.");
        }
    }
}