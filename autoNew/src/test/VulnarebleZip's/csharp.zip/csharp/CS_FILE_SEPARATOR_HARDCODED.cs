namespace Tests
{
    class CS_FILE_SEPARATOR_HARDCODED
    {
        static void Main()
        {
            // <yes> <report> CS_FILE_SEPARATOR_HARDCODED lirenk
            DirectoryInfo di = Directory.CreateDirectory(path1 + "\\" + path2);
        }
    }
}