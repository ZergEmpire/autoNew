using System.Text.RegularExpressions;

namespace Tests
{
    class CS_CORRECTNESS_ARRAY_TOSTRING
    {
        static void Main()
        {
            ArrayList myAL = new ArrayList();
            // <yes> <report> CS_CORRECTNESS_ARRAY_TOSTRING 215967 <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.WriteLine(myAL.ToString());

            BitArray myBA = new BitArray( 5 );
            // <yes> <report> CS_CORRECTNESS_ARRAY_TOSTRING 215967 <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.WriteLine(myBA.ToString());
        }
    }
}