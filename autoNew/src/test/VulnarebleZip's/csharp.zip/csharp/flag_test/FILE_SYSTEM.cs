namespace Tests
{
    class FILE_SYSTEM
    {
        static void Main()
        {
            UnmanagedMemoryStream readStream = new UnmanagedMemoryStream(memBytePtr, message.Length, message.Length, FileAccess.Read);
            StringDictionary dict = new StringDictionary();
            // +FILE_SYSTEM to arg = 0
            readStream.Read(dict, 0, message.Length);
            // +FILE_SYSTEM from this to return (passthrough)
            var collection = dict.Keys;
            // +FILE_SYSTEM from arg0 to return (passthrough)
            DictionaryEntry de = new DictionaryEntry(collection, values);
            // +FILE_SYSTEM from this to return (passthrough)
            var tainted = de.Value;
        }
    }
}