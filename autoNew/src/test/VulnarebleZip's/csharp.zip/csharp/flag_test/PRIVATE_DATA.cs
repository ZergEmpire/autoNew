namespace Tests
{
    class PRIVATE_DATA
    {
        static void Main()
        {
            using (SPWeb oWebsiteRoot = SPContext.Current.Site.RootWeb)
            {
                // +PRIVATE_DATA to return
                var roles = oWebsiteRoot.AllRolesForCurrentUser;
                SPUser oUser = oWebsite.AllUsers["User_Name"];
                // +PRIVATE_DATA to return
                string xml = oUser.Xml;
                DirectoryEntry entry = new DirectoryEntry();
                // +PRIVATE_DATA to return
                var password = entry.Password;
                HtmlInputPassword input = new HtmlInputPassword();
                // +PRIVATE_DATA to return
                // <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
                string pwd = input.Value;
                ArrayList list = new ArrayList();
                // +PRIVATE_DATA to this from arg0
                list.AddRange(pwd);
                // +PRIVATE_DATA to arg1 from this
                list.CopyTo(1, myTargetArray, 1, 1);
                Array.Copy(myTargetArray, taintedArray, 100);
                // check
                a.DoSmth(taintedArray);
                // +PRIVATE_DATA to return
                var privateData = ProtectedData.Unprotect( data, s_aditionalEntropy, DataProtectionScope.CurrentUser );
                TripleDESCng tripleDes = new TripleDESCng();
                // +PRIVATE_DATA to return
                var key = tripleDes.Key;
            }
        }
    }
}