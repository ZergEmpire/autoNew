namespace Tests
{
    class SYSTEM_INFO
    {
        static void Main()
        {
        Exception myException= new Exception("This is an exception test");
           ErrorEventArgs myErrorEventArgs = new ErrorEventArgs(myException);
           // +SYSTEM_INFO to return
           Exception myReturnedException = myErrorEventArgs.GetException();
           // +SYSTEM_INFO to return
           IDataObject iData = Clipboard.GetDataObject();
           // +SYSTEM_INFO to return
          string e = myException.ToString();
        BinaryWriter writer = new BinaryWriter();
        ControlCollection control = new ControlCollection();
        if (smth)
        {
          // <yes> <report> CS_INFORMATION_LEAK 15er43
            while (writer.Write(e))
            {
               //do_smth
            }
        }
        else if (operators.Equals("-")) 
        {
          // +SYSTEM_INFO to this from arg1 (passthrough)
            control.AddAt(smth, e);
        }
        // <yes> <report> CS_INFORMATION_LEAK_INTERNAL 12e2k4 <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
        Console.Write(control);
        Exception ex = new Exception();
        // +SYSTEM_INFO to return
        var info = ex.Message;
        try{}
        catch (Exception excep){
          // <yes> <report> CS_INFORMATION_LEAK_INTERNAL 12e2k4 <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
          Console.WriteLine("SAP HR User Import " + excep.Message + " " + excep.StackTrace);
        }
        HttpConfiguration config = new HttpConfiguration();
        // +SYSTEM_INFO to return
        var sInfo = config.Filters;
        OdbcInfoMessageEventArgs message = new OdbcInfoMessageEventArgs();
        // +SYSTEM_INFO to return
        string text = message.Message;
        RowUpdatedEventArgs eventArgs = new RowUpdatedEventArgs();
        // +SYSTEM_INFO to return
        var error = eventArgs.Errors;
        ProcessStartInfo process = new ProcessStartInfo();
        // +SYSTEM_INFO to return
        var environment = process.EnvironmentVariables;
        HttpApplicationStateWrapper wrap = new HttpApplicationStateWrapper();
        // +SYSTEM_INFO to return
        var inform = wrap[5];
        HttpSessionState state = new HttpSessionState();
        // +SYSTEM_INFO to return
        var sesID = state.SessionID;
        Object MyObject;
        // +SYSTEM_INFO to return
        MyObject = Application["MyAppVar1"];
        ProcessInfo pi;
        pi = ProcessModelInfo.GetCurrentProcessInfo();
        // +SYSTEM_INFO to return
        var age = pi.Age;
        // +SYSTEM_INFO to return
        var path = HttpRuntime.AspClientScriptVirtualPath;
        // +SYSTEM_INFO to return
        var time = Environment.TickCount;
        Assembly systemAssembly = integer1.GetType().Assembly;
        // +SYSTEM_INFO to return
        string codeBase = systemAssembly.CodeBase;
        SqlException ex = new SqlException();
        // +SYSTEM_INFO to return
        var errors = ex.Errors;

        }
    }
}

