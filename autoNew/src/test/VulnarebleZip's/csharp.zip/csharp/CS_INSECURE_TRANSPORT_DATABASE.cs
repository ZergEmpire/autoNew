namespace Tests
{
    class CS_INSECURE_TRANSPORT_DATABASE
    {
        static void Foo()
        {
            // <yes> <report> CS_INSECURE_TRANSPORT_DATABASE itrada
            String connectionString = "Data Source = "+dbserver+"; Initial Catalog="+dbname+"; User Id="+dbusername+"; Password="+dbpassword+";Integrated Security=false";
            // <no> <report>
            String connectionString2 = "Data Source = "+dbserver+"; Initial Catalog="+dbname+"; User Id="+dbusername+"; Password="+dbpassword+";Encrypt=true";
            // <yes> <report> CS_INSECURE_TRANSPORT_DATABASE intrda
            conn.ConnectionString = "Data Source = "+dbserver+"; Initial Catalog="+dbname+"; User Id="+dbusername+"; Password="+dbpassword+";Encrypt=false";
        }
    }
}