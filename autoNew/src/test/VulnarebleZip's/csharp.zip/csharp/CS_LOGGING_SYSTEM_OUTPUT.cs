namespace Tests
{
    class CS_LOGGING_SYSTEM_OUTPUT
    {
        static void Main()
        {
            // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.Write(info);
            // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.WriteLine(info);
            // <yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17
            Console.Error.WriteLine(info);
        }
    }
}