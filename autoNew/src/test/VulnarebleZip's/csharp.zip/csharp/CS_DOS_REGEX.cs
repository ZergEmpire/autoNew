using System.Text.RegularExpressions;

namespace Tests
{
    class CS_DOS_REGEX
    {
        static void foo(String userInput)
        {
            string name = ctx.Request.QueryString["name"];
            // <yes> <report> CS_DOS_REGEX gjrgnk
            new Regex(name).Match(userInput);
            string safeName = Regex.Escape(name);
            // <no> <report>
            new Regex(safeName).Match(userInput);
        }
    }
}