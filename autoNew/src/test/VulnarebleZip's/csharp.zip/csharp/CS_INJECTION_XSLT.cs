using System.Xml;

namespace Tests
{
    class CS_INJECTION_XSLT
    {
        static void Main()
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml("<item><name>wrench</name></item>");

            XslTransform xslt = new XslTransform();
            // <yes> <report> CS_INJECTION_XSLT 245b3f
            xslt.Load(doc);
            XsltCompiler compiler = processor.NewXsltCompiler();
            // <yes> <report> CS_INJECTION_XSLT 435j2k
            compiler.Compile(doc);
        }
    }
}