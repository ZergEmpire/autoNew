namespace Tests
{
    class CS_AUTHENTICATION_PERSISTENT
    {
        static void Main()
        {
            boolean notTrue = false;
            // <yes> <report> CS_AUTHENTICATION_PERSISTENT 10ddd9
            FormsAuthentication.RedirectFromLoginPage("userName", true);
            // <yes> <report> CS_AUTHENTICATION_PERSISTENT 10ddd9
            FormsAuthentication.RedirectFromLoginPage("userName", 1);
            // <no> <report>
            FormsAuthentication.RedirectFromLoginPage("userName", notTrue);
        }
    }
}

