using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Tests
{
    class CS_PASSWORD_MANAGEMENT_NULL_PASSWORD
    {
        // <yes> <report> CS_PASSWORD_NULL a81d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap22
        public string MyPassword = null;
        // <yes> <report> CS_PASSWORD_NULL a81d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap02
        private string password = null;
        static void Main()
        {
            // <yes> <report> CS_PASSWORD_NULL b81d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap21
            string StoredPassword = null;
            // <yes> <report> CS_PASSWORD_NULL b81d5b <yes> <report> CS_PRIVACY_VIOLATION_HEAP heap01
            string Password = null;
            // <yes> <report> CS_PASSWORD_NULL c81d5b
            byte[] Mypassword = enc.GetBytes(null);
            // <yes> <report> CS_PASSWORD_NULL c81d5b
            byte[] password = enc.GetBytes(null);
            // <yes> <report> CS_CORRECTNESS_EQUALS_NULL 215966 <yes> <report> CS_PASSWORD_NULL d86d5b
            Password.Equals(null);
            // <yes> <report> CS_PASSWORD_NULL d87d5b
            null.Equals(Password);
            // <yes> <report> CS_PASSWORD_NULL d88d5b
            Compare(null, Password, true);
            // <yes> <report> CS_PASSWORD_NULL d89d5b
            Compare(Password, null, false);

            ConnectionString cs = new ConnectionString();
            // <yes> <report> CS_PASSWORD_NULL 97bcf0
            cs.Password = null;
            // <yes> <report> CS_PASSWORD_NULL b73fd7 <yes> <report> CS_ACCESS_CONTROL_LDAP_BIND agf8ca
            DirectoryEntry de = new DirectoryEntry("","",null);
            // <yes> <report> CS_PASSWORD_NULL 97acf0 <yes> <report> CS_ACCESS_CONTROL_LDAP_BIND 75afc7
            de.Password = null;
            // <yes> <report> CS_PASSWORD_NULL a76c89
            NetworkCredential nc1 = new NetworkCredential("",null);
            // <yes> <report> CS_PASSWORD_NULL 97ccf0
            nc1.Password = null;
            // <yes> <report> CS_PASSWORD_NULL a82c5a
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(null, salt, "sha256", 100000);
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            // <yes> <report> CS_PASSWORD_NULL 84hrq3
            builder.Add("Password", null);
            // <yes> <report> CS_PASSWORD_NULL tk4lew
            builder["password"] = null;
        }
    }
}