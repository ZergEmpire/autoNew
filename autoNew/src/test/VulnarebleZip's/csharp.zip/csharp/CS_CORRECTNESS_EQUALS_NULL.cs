namespace Tests
{
    class CS_CORRECTNESS_EQUALS_NULL
    {
        static void Main()
        {
            // <yes> <report> CS_CORRECTNESS_EQUALS_NULL 215966
            x.Equals(null);
            // <no> <report>
            y.Equals(z, null);
        }
    }
}