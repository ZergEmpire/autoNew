namespace Tests
{
    class CS_CRYPTO_KEY_NULL
    {
        // <yes> <report> CS_CRYPTO_KEY_NULL htefwr
        private string encryptionKey = null;
        static void Main()
        {
            // <yes> <report> CS_CRYPTO_KEY_NULL wgrege
            string cryptoKey = null;
        }
    }
}