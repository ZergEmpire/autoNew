namespace Tests
{
    class CS_BACKDOOR_SECURITY_PARAMS
    {
        static void Main()
        {
            string login;
            string authorized;
            // <yes> <report> CS_BACKDOOR_SECURITY_PARAMS b11sp1 
            if (login = "user1")
            {
                 //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17 
                 Console.WriteLine("backdoor!");
            }
            // <yes> <report> CS_BACKDOOR_SECURITY_PARAMS b11sp1 
            while (authorized = "user1")
            {
                 //<yes> <report> CS_LOGGING_SYSTEM_OUTPUT 10ad17 
                 Console.WriteLine("backdoor!");
            }
        }
    }
}