using Microsoft.VisualBasic;

namespace Tests
{
    class CS_COMMAND_INJECTION
    {
        static void Main()
        {
            RouteData rd = HttpContext.Request.RequestContext.RouteData;
            string cmd = rd.GetRequiredString("cmd");
            Interaction i = new Interaction();
            // <yes> <report> CS_INJECTION_COMMAND fkelrf
            i.Shell(cmd);
            // <yes> <report> CS_INJECTION_COMMAND grekse
            ProcessStartInfo psi1 = new ProcessStartInfo(cmd);
            // <yes> <report> CS_INJECTION_COMMAND grekse
            ProcessStartInfo psi2 = new ProcessStartInfo("smth",cmd);
            // <yes> <report> CS_INJECTION_COMMAND rj3223
            psi1.Arguments = cmd;
            // <yes> <report> CS_INJECTION_COMMAND rj3223
            psi2.FileName = cmd;
            ManagementObject o = new ManagementObject();
            // <yes> <report> CS_INJECTION_COMMAND injcom0
            o.InvokeMethod(smth, cmd, "params", options);
            string param = ctx.Request.QueryString["param"];
            // <yes> <report> CS_INJECTION_COMMAND injcom1
            Process.Start("process.exe", "/c " + param);
        }
    }
}