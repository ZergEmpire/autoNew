package main

//<yes> <report> GO_SSRF netin1
func HttpClientIP(r *http.Request) string {
	err := net.SplitHostPort(r.RemoteAddr); err == nil {
		return remoteAddr
	}

	return ""
}