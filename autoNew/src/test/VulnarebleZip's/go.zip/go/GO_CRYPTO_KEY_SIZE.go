package main

import (
		"crypto/rand"
		"crypto/rsa"
		"golang.org/x/crypto/pbkdf2"
)

func main() {
	
	reader := rand.Reader
	bitSize := 2048
	// <yes> <report> GO_CRYPTO_KEY_SIZE 000009
	key, err := rsa.GenerateKey(reader, 1024)
	// <no> <report> GO_CRYPTO_KEY_SIZE 000006
	key, err := rsa.GenerateKey(reader, 2048)
	// <yes> <report> GO_CRYPTO_KEY_SIZE lk0010 <yes> <report> GO_PASSWORD_HARDCODED 00020t
	dk := pbkdf2.Key([]byte("some text"), salt, 10001, 20, sha256.New)
}
