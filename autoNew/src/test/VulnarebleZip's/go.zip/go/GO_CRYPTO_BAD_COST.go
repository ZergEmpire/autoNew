package main

import (
	"golang.org/x/crypto/bcrypt",
	"golang.org/x/crypto/scrypt"
)

func main() {
	// <yes> <report> GO_CRYPTO_BAD_COST 600000 <yes> <report> GO_PASSWORD_HARDCODED 000lkt
	bcrypt.GenerateFromPassword([]byte("some text"), 5)
	// <yes> <report> GO_CRYPTO_BAD_COST 600001 <yes> <report> GO_PASSWORD_HARDCODED 00020t
	scrypt.Key([]byte("some password"), salt, 32760, 8, 1, 32)
	// <yes> <report> GO_CRYPTO_BAD_COST 600002 <yes> <report> GO_PASSWORD_HARDCODED 00020t
	scrypt.Key([]byte("some password"), salt, 32768, 2, 1, 32)
	// <yes> <report> GO_PASSWORD_HARDCODED 00020t
	scrypt.Key([]byte("some "), salt, 32768, 8, 1, 32)
}

