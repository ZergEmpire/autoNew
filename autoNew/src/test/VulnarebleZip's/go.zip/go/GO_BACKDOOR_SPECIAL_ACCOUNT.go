package main

import "fmt"

func main() {
// <yes> <report> GO_BACKDOOR_SPECIAL_ACCOUNT a00002
for password == "abc" {
// <yes> <report> GO_LOGGING_SYSTEM_OUTPUT a00003
fmt.Println("a")
}
// <yes> <report> GO_BACKDOOR_SPECIAL_ACCOUNT a00006
if user == "abc" {
// <yes> <report> GO_LOGGING_SYSTEM_OUTPUT a00003
fmt.Println("a")
}
// <no> <report>
for password == "" {}
}