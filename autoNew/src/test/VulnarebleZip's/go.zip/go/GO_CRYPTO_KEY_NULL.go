package main

import "crypto/hmac"
import "golang.org/x/crypto/blowfish"

func main() {
    // <yes> <report> GO_CRYPTO_KEY_NULL 000030
    mac := hmac.New(sha256.New, nil)
    mac.Write(message)
    expectedMAC := mac.Sum(nil)
    // <yes> <report> GO_CRYPTO_KEY_NULL 000033
    bf, _ := blowfish.NewCipher(nil)
    // <yes> <report> GO_CRYPTO_KEY_NULL 000033
    bf, _ := blowfish.NewSaltedCipher(nil, salt)
    return hmac.Equal(messageMAC, expectedMAC)
    // <yes> <report> GO_CRYPTO_KEY_NULL rjkesd
    var store = sessions.NewCookieStore(securecookie.GenerateRandomKey(),
	nil)
}
