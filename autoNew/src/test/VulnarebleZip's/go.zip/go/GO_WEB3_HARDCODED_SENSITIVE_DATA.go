package main

import (
    "crypto/ecdsa"
    "github.com/ethereum/go-ethereum/accounts/abi/bind"
    "github.com/elementrem/go-elementrem/accounts/keystore"
)

func main() {
    var pk = crypto.HexToECDSA("my_private_key")
    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA ag66kh
    auth := bind.NewKeyedTransactor(pk)
    pk2 := crypto.HexToECDSA("my_private_key")
    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA ag66kh
    auth = bind.NewKeyedTransactor(pk2)
    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA ag66kh
    auth = bind.NewKeyedTransactor("my_private_key")
    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA ag66kh
    auth = bind.NewKeyedTransactor(crypto.HexToECDSA("my_private_key"))
    prKey := key
    auth = bind.NewKeyedTransactor(prKey)
    var prKey2 = key
    auth = bind.NewKeyedTransactor(prKey2)

    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA sf5jf9
    res, _ := keystore.DecryptKey(json, "my_passphrase")
    var phrase1 = "my_passphrase"
    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA sf5jf9
    res, _ = keystore.DecryptKey(json, phrase1)
    phrase2 := "my_passphrase"
    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA sf5jf9
    res, _ = keystore.DecryptKey(json, phrase2)

    var res2, _ = keystore.DecryptKey(json, passphrase)


    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA j4f9kf
    ks.GetKey(key.Address, tmpName, "my_passphrase")

    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA j4f9kf
    ks.GetKey(key.Address, tmpName, phrase1)

    // <yes> <report> GO_WEB3_HARDCODED_SENSITIVE_DATA j4f9kf
    ks.GetKey(key.Address, tmpName, phrase2)

    ks.GetKey(key.Address, tmpName, passphrase)
}
