package main

import (
    "golang.org/x/crypto/scrypt"
    "fmt"
)

func main() {
    // <yes> <report> GO_CRYPTO_SALT_NULL 000027
    dk, err := scrypt.Key(pwd, nil, 1<<15, 8, 1, 32)
    if err != nil {
        log.Fatal(err)
    }
    // <yes> <report> GO_CRYPTO_SALT_NULL 000034
    bf, _ := blowfish.NewSaltedCipher(key, nil)
    fmt.Println(base64.StdEncoding.EncodeToString(dk))
}