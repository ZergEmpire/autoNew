package encrypt

import "github.com/gorilla/sessions"

func Session() ([]byte, error) {
	// <yes> <report> GO_BROKEN_AUTHENTICATION_AND_SESSION_MANAGEMENT tjekds 
	var store = sessions.NewCookieStore([]byte("something-very-secret"))
}