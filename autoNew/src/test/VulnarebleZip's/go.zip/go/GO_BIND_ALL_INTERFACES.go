package main

import "net"

func main() {
	//<yes> <report> GO_BIND_ALL_INTERFACES 400001 <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", ":50051")
	//<yes> <report> GO_BIND_ALL_INTERFACES 400005 <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "0.0.0.0" + ":50051")
	//<yes> <report> GO_BIND_ALL_INTERFACES 400002 <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "0.0.0.0")
	//<yes> <report> GO_BIND_ALL_INTERFACES 400002 <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "0.0.0.0:34534")
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "10.0.0.0")
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "10.0.0.0:534")
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "10.0.0.0" + ":534")

	//<yes> <report> GO_BIND_ALL_INTERFACES 400003 <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "[::]:534")
	//<yes> <report> GO_BIND_ALL_INTERFACES 400004 <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "[::]" + ":534")
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]" + ":534")
	//<yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY a00004
	net.Listen("tcp", "[2001:0db8:85a3::8a2e:0370:7334]")
}