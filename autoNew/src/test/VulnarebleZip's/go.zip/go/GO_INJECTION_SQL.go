package main

import "database/sql"
import "fmt"

func main() {
	// <yes> <report> GO_INJECTION_SQL 8ru4kw
	db.Query("SELECT username FROM users WHERE id=" + id)
	// <no> <report>
	db.Query("SELECT username FROM users WHERE id=?", id)
	// <yes> <report> GO_INJECTION_SQL fvksmk
	db.Exec("SELECT username FROM users WHERE id=?"+ id)
	// <yes> <report> GO_INJECTION_SQL fvksm5
	sql := "SELECT * FROM products WHERE name LIKE '%" + prod + "%'"
	// <yes> <report> GO_INJECTION_SQL fvksm1
	db.Exec(sql)
	// <yes> <report> GO_INJECTION_SQL fvksm3
	db.Query("SELECT username FROM users WHERE id=?", id).Iter
	// <yes> <report> GO_INJECTION_SQL fvksm4
	fmt.Sprintf("SELECT sql FROM sqlite_master WHERE tbl_name = '%s'", stmt.OnTable.Name.String())
	// <yes> <report> GO_INJECTION_SQL fvksm6
	sql := "SELECT 1 FROM " + db.Quote("sqlite_master") + " WHERE " + db.Quote("type") + "='index' AND " + db.Quote("tbl_name") + "=? AND " + db.Quote("name") + "=?"
	// <yes> <report> GO_INJECTION_SQL fvksm7
	sql("SELECT 1 FROM " + db.Quote("sqlite_master") + " WHERE " + db.Quote("type") + "='index' AND " + db.Quote("tbl_name") + "=? AND " + db.Quote("name") + "=?")
	// <no> <report>
	sql := "select me from my heart"
	// <no> <report>
	sql := "select" + "me" + "my" + string
	// <yes> <report> GO_INJECTION_SQL fvksm6
	sql := "select" + "me" + "my" + db.Quote("sqlite_master")
}