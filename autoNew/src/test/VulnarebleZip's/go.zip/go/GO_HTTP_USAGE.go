package main

import "net/http"
import "github.com/gorilla/http"

func main() {
	
	// <yes> <report> GO_HTTP_USAGE regjkw <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	resp, err := http.Get("http://example.com/")
	// <yes> <report> GO_HTTP_USAGE lregjk <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne001
    resp, err := http.Get("http://localhost")
	// <yes> <report> GO_HTTP_USAGE rjkmmm
	http.NewRequest(method, "http://www.google.com", body)
	// <yes> <report> GO_HTTP_USAGE lrjkmm
    http.NewRequest(method, "http://127.0.0.1", body)
	// <yes> <report> GO_HTTP_USAGE peowmd <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne000
	if _, err := Get(os.Stdout, "http://www.gorillatoolkit.org/"); err != nil {
    log.Fatalf("could not fetch: %v", err)
    // <yes> <report> GO_HTTP_USAGE lpeowm <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne001
    if _, err := Get(os.Stdout, "http://127.0.0.1");
    //<no> <report>
    Schema{TargetNS: "http://schema.url"}
    // <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> GO_HTTP_USAGE jdewsf
    MyStruct{Url: "http://schema.url"}
    // <yes> <report> GO_BACKDOOR_NETWORK_ACTIVITY bne003 <yes> <report> GO_HTTP_USAGE lldews
    MyStruct{Url: "http://localhost"}
}

}
func redirect(w http.ResponseWriter, r *http.Request) {
	// <yes> <report> GO_HTTP_USAGE 4u38ee
    http.Redirect(w, r, "http://www.google.com", 301)
    // <yes> <report> GO_HTTP_USAGE l4u38e
    http.Redirect(w, r, "http://localhost", 301)
}

func (w *W) PostForm(path string, v url.Values) (*http.Response, error) {
    // <yes> <report> GO_HTTP_USAGE jkwod2
	return w.Client.PostForm("http://"+w.host+path, v)
    // <yes> <report> GO_HTTP_USAGE ljkwod
    return w.Client.PostForm("http://127.0.0.1", v)
}