package main

import "fmt"
import "math/rand"

func main() {

    // <yes> <report> GO_CRYPTO_BAD_RANDOM 000004
    fmt.Print(rand.Intn(123))
}
