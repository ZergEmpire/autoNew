package encrypt

import (
    "crypto/rsa"
    "crypto/rand"
)

func Encrypt(in []byte, pub rsa.PublicKey) ([]byte, error) {

    // <yes> <report> GO_CRYPTO_BAD_PADDING 000003
    out, err := rsa.EncryptPKCS1v15(rand.Reader, &pub, in)

    if err != nil {
    log.Fatalf("Failed to encrypt message %v", err)
    return nil, err
    }

return out, nil
}