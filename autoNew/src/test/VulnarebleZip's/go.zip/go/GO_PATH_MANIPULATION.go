package main

import (
	"os"
	"io/ioutil"
)

func main() {
	// <yes> <report> GO_PATH_MANIPULATION 100001
	ioutil.ReadFile(filePath)
	// <no> <report>
	ioutil.ReadFile("file")
	// <yes> <report> GO_PATH_MANIPULATION 100002
	os.Open(cleanSrc)
}