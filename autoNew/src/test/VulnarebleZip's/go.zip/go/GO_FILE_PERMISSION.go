package main

import (
	"os"
)

func main() {
	// <yes> <report> GO_FILE_PERMISSION 200001
	os.MkdirAll(cfg.DataDir, 0755)
	// <no> <report>
	os.MkdirAll(cfg.DataDir, 0700)
	// <yes> <report> GO_FILE_PERMISSION 200002
	os.OpenFile(ctx.Args().Get(0), os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0644)
	// <yes> <report> GO_FILE_PERMISSION 200003
	os.Chmod(UploadFile, 0644)
}