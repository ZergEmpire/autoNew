package main

import (
    "github.com/ethereum/go-ethereum/ethclient"
)

func main() {
    var Client = ethclient.Dial(apiKey)
    // <yes> <report> GO_WEB3_TX_COUNT 67kjlj
    var nonceFromGeth = Client.PendingNonceAt(context.Background(), fromAddress)
}
