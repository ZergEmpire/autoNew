package main

import (
    "github.com/ethereum/go-ethereum/ethclient"
)

var Client *ethclient.Client

func main() {
    Client, err = ethclient.Dial("https://ropsten.infura.io/api/v3/" + apiKey)
    Client, err = ethclient.Dial(apiLink)
    // <yes> <report> GO_WEB3_HARDCODED_API_KEY as96bn
    Client, err = ethclient.Dial("https://ropsten.infura.io/api/v3/myinfurakey")
}
