package main

import (
	"os/exec"
	"os"
	"strings"
)

func main() {
	args := []string{}
	// <yes> <report> GO_INJECTION_COMMAND 300001
	exec.Command(bin, args...)
	// <yes> <report> GO_INJECTION_COMMAND 300001
	exec.Command("swarm", "--bzzaccount", pkFile.Name(), "--bzzapi", endpoints[0], "feed", "update", "--topic", topicHex, "--name", subTopicHex, multihashHex)
	// <no> <report>
	exec.Command("f", "s")
	// <yes> <report> GO_INJECTION_COMMAND 300001
	exec.Command(os.Args[0], "a")
}