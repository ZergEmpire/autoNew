package newIntegration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class JAVA_SSRF {

    public void test1(HttpRequest request, HttpClient client) throws IOException, InterruptedException
    {
        URI uri = URI.create(client.send(request, HttpResponse.BodyHandlers.ofString()).body()); //@ JAVA_INJECTION_RESOURCE-607b50
        HttpRequest.newBuilder()
            .uri(uri) //@ JAVA_SSRF-nfhrje
            .build();
    }
}
