package newIntegration;

import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.ProxySelector;
import java.net.http.HttpClient;

public class JAVA_UNTRUSTED_PROXY {

    public void test1()
    {
        var tainted = System.getenv("env"); //@ JAVA_USE_GETENV-f9b0b0
        HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_2)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .proxy(ProxySelector.of(new InetSocketAddress(tainted, 8080))) //@ JAVA_UNTRUSTED_PROXY-mgjfke
            .authenticator(Authenticator.getDefault())
            .build();
        HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_2)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .proxy(ProxySelector.of(new InetSocketAddress("www-proxy.com", 8080)))
            .authenticator(Authenticator.getDefault())
            .build();
    }
}
