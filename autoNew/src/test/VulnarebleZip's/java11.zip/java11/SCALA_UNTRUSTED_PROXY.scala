package newIntegration

import java.net.http.HttpClient
import java.net.{Authenticator, InetSocketAddress, ProxySelector}

class SCALA_UNTRUSTED_PROXY {
  def test1(): Unit = {
    val tainted = System.getenv("env") //@ SCALA_USE_GETENV-f9b0b0
    HttpClient.newBuilder
      .version(HttpClient.Version.HTTP_2)
      .followRedirects(HttpClient.Redirect.NORMAL)
      .proxy(ProxySelector.of(new InetSocketAddress(tainted, 8080))) //@ SCALA_UNTRUSTED_PROXY-mgjfke
      .authenticator(Authenticator.getDefault)
      .build

    HttpClient.newBuilder
      .version(HttpClient.Version.HTTP_2)
      .followRedirects(HttpClient.Redirect.NORMAL)
      .proxy(ProxySelector.of(new InetSocketAddress("www-proxy.com", 8080)))
      .authenticator(Authenticator.getDefault)
      .build
  }
}
