package integration.java11;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Authenticator;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.servlet.ServletResponse;

public class JAVA_XSS_REFLECTED {
    public void test(
        HttpRequest request,
        ServletResponse response) throws IOException, InterruptedException
    {
        HttpClient client = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(20))
            .authenticator(Authenticator.getDefault())
            .build();
        HttpResponse<String> res = client.send(request, HttpResponse.BodyHandlers.ofString());
        final PrintWriter writer = response.getWriter();
        writer.println(res.body()); //@ JAVA_XSS_REFLECTED-5527c6
    }

    public void test2(
        HttpRequest request,
        ServletResponse response) throws IOException, InterruptedException, ExecutionException
    {
        HttpClient client = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(20))
            .authenticator(Authenticator.getDefault())
            .build();
        final PrintWriter writer = response.getWriter();
        final HttpResponse<String> asyncRes = client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).get();
        writer.println(asyncRes.body()); //@ JAVA_XSS_REFLECTED-5527c6
    }

    public void test3(ServletResponse response, URI uri) throws IOException
    {
        var cookieManager = new CookieManager();
        final HttpCookie cookie = cookieManager.getCookieStore().getCookies().get(0);

        final PrintWriter writer = response.getWriter();
        writer.println(cookie.getValue()); //@ JAVA_XSS_REFLECTED-5527c6

        final HttpCookie cookie2 = cookieManager.getCookieStore().get(uri).get(0);
        writer.println(cookie2.getValue()); //@ JAVA_XSS_REFLECTED-5527c6
    }

}
