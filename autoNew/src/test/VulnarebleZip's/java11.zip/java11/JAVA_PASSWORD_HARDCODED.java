import java.net.PasswordAuthentication;

public class JAVA_PASSWORD_HARDCODED {

    public void test()
    {
        final String s = "s";
        new PasswordAuthentication("username", s.toCharArray()); //@ JAVA_PASSWORD_HARDCODED-frw4jw
    }
}
