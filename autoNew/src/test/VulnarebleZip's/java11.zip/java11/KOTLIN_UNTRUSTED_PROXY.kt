package newIntegration

import java.net.Authenticator
import java.net.InetSocketAddress
import java.net.ProxySelector
import java.net.http.HttpClient

class KOTLIN_UNTRUSTED_PROXY {
    fun test1() {
        val tainted = System.getenv("env") //@ KOTLIN_USE_GETENV-f9b0b0
        HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .followRedirects(HttpClient.Redirect.NORMAL)
                .proxy(ProxySelector.of(InetSocketAddress(tainted, 8080))) //@ KOTLIN_UNTRUSTED_PROXY-mgjfke
                .authenticator(Authenticator.getDefault())
                .build()
        HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .followRedirects(HttpClient.Redirect.NORMAL)
                .proxy(ProxySelector.of(InetSocketAddress("www-proxy.com", 8080)))
                .authenticator(Authenticator.getDefault())
                .build()
    }
}