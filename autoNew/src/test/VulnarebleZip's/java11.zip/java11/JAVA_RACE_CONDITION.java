import java.util.concurrent.locks.ReentrantLock;

public class JAVA_RACE_CONDITION {

    static private final ReentrantLock REENTRANT_LOCK_BAD1 = new ReentrantLock();
    static private final ReentrantLock REENTRANT_LOCK_GOOD1 = new ReentrantLock();
    static private final ReentrantLock REENTRANT_LOCK_BAD2 = new ReentrantLock();
    static private final ReentrantLock REENTRANT_LOCK_GOOD2 = new ReentrantLock();

    void test() {
        REENTRANT_LOCK_BAD1.unlock(); //@ JAVA_RACE_CONDITION-gjfsej
        REENTRANT_LOCK_GOOD1.lock();
        REENTRANT_LOCK_GOOD1.unlock();
        REENTRANT_LOCK_BAD2.unlock(); //@ JAVA_RACE_CONDITION-gjfsej
        REENTRANT_LOCK_GOOD2.lock();
        REENTRANT_LOCK_GOOD2.unlock();
    }
}
