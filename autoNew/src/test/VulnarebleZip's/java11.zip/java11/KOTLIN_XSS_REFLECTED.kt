package integration.java11

import io.ktor.application.call
import io.ktor.freemarker.FreeMarkerContent
import io.ktor.http.ContentType
import io.ktor.response.respond
import io.ktor.response.respondText
import io.ktor.routing.get
import io.ktor.routing.routing
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty

fun main(args: Array<String>) {
    embeddedServer(Netty, 8080) {//@ JAVA_J2EE_DEBUG_CODE-514398
        routing {
            get("/") {//@ JAVA_BACKDOOR_DEAD_CODE-d27d09
                call.respondText("Hello, world!" + args[0], ContentType.Text.Html) //@ KOTLIN_XSS_REFLECTED-kp1388
            }

            get("/html-freemarker") {//@ JAVA_BACKDOOR_DEAD_CODE-d27d09
                call.run {
                    respond(
                            FreeMarkerContent(
                                    "index.ftl",
                                    args[0],
                                    ""
                            )
                    )
                }
            }
        }
    }.start(wait = true)
}
