<?php
// <yes> <report> PHP_INJECTION_CODE p22in3
eval($_GET);
eval($not_tainted);
$upload = new Zend_File_Transfer();
// +WEB to return
$taintWeb = $upload->getFileInfo();
// +ARGS to return
$options = getopt("f:hp:");
// <yes> <report> PHP_INJECTION_CODE t0h9cd
create_function('', $options);
// <yes> <report> PHP_INJECTION_CODE mgh97d
php_eval($options);

$serializer = new Zend\Serializer\Adapter\PhpSerialize();
// <yes> <report> PHP_INJECTION_CODE dsssdm
$unserialized = $serializer->unserialize($taintWeb);
?>