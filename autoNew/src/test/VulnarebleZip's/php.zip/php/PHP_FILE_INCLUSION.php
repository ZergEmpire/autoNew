<?php

$whilelist = array("index", "loadme");
// <yes> <report> PHP_OPEN_BASEDIR 7d8acf
ini_set("open_basedir", "/var/www/"); // This will stop them openinging anything below /var/www

require_once 'common.php';

$file = $_GET['load'] . '.php'; // This will stop them for sure!!!

$file = str_replace(chr(0), "", $file); // Null bytes removed! awesome
// <yes> <report> PHP_FILE_INCLUSION gelwdj
require_once($file);

// <yes> <report> PHP_FILE_INCLUSION gelwdj
include $file;
// <yes> <report> PHP_FILE_INCLUSION fwjkss
virtual($file);
// <yes> <report> PHP_FILE_INCLUSION fg3eaw
App::import($file);
// <no> <report>
App::import('','','','','', $file);
// <yes> <report> PHP_FILE_INCLUSION gelwdj
include "../modules/".$_GET['module_name']."/html.php";
// <yes> <report> PHP_FILE_INCLUSION gelwdj
include "../modules/".$_GET['module_name'];
// <yes> <report> PHP_FILE_INCLUSION gelwdj
include $_GET['module_name'];
// <no> <report>
include "../modules/"."/html.php";


$a = $_SERVER['argv'][0];
// <yes> <report> PHP_FILE_INCLUSION gelwdj1
include $a;


$a = intval($_GET['load']);
// <no> <report>
include $a;

$a = floatval($_GET['load']);
// <no> <report>
include $a.'.php';
// <no> <report>
require_once $a;

$b=$_COOKIE["name"];
// <yes> <report> PHP_FILE_INCLUSION gelwdj
include $b.".php";
?>