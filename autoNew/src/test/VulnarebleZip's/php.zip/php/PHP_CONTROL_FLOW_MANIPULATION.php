<?php
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
while ($_SERVER['HTTP_USER_AGENT']) {
}
do {
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
} while ($_SERVER['HTTP_USER_AGENT']);
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
if ($_SERVER['HTTP_USER_AGENT']) {
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
} elseif ($_SERVER['HTTP_USER_AGENT']) {
} else {
}
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
switch ($_SERVER['HTTP_USER_AGENT']) {
    case 0:
        break;
}
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
for ($i = 1; $_SERVER['HTTP_USER_AGENT']; $i++) {
}
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb3
$a = ($_SERVER['HTTP_USER_AGENT']) ? 'default' : 'default';
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb3
$a = $_SERVER['HTTP_USER_AGENT'] ? 'default' : 'default';
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb5
if (array_key_exists('QUERY_STRING', $_SERVER)) {
    $uri = $_SERVER['QUERY_STRING'];
} else {
    $uri = '';
}
// <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb5
if (array_key_exists("QUERY_STRING", $_SERVER)) {
    $uri = $_SERVER["QUERY_STRING"];
} else {
    $uri = '';
}
?>
