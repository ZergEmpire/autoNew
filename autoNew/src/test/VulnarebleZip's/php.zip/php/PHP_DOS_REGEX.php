<?php
$subject = "abcdef";
$pattern = 'const';
$HttpSocket = new HttpSocket();
// +WEB to return
$pattern_user = $HttpSocket->put('https://www.google.com/search', 'q=cakephp');
// <yes> <report> PHP_DOS_REGEX s71167
preg_match($pattern_user, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
// список функций, которые мы ищем: preg_match(_all)?|preg_(grep|replace|replace_callback|split)|ereg(_replace)?|split(i)?|eregi(_replace)?|mb_ereg|sql_regcase

// <no> <report>
preg_match_all(
    $pattern,
    'foo bar',
    $matches,
    PREG_PATTERN_ORDER
);
?>