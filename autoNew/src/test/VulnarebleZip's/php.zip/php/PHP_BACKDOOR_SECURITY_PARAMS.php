<?php
// <yes> <report> PHP_BACKDOOR_SECURITY_PARAMS 000007
if ($login = "user1") 
	{ echo "hello"; };
// <yes> <report> PHP_BACKDOOR_SECURITY_PARAMS 000007
while ($authorized = "user1") 
	{ echo "hello"; };
?>
