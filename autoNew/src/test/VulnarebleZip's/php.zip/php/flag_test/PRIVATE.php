<?php
$uri = Zend_Uri_Http::fromString($url);
$class->_client = new Zend_Rest_Client($uri);
// +PRIVATE_DATA to return
Zend_Service_Abstract::getHttpClient()->setAuth($class->getUsername(),$class->getPassword());

$filter = new Zend_Filter_Decrypt($key);
$filter->setVector('myvector');
// +PRIVATE_DATA to return
$decrypted = $filter->filter($encrypted);

$consumer = new Zend_Oauth_Consumer($params);
// +PRIVATE_DATA to return
$acessToken = $consumer->getAccessToken($_GET, $requestToken);

$utility = new Zend_Oauth_Http_Utility();
$params = array('oauth_consumer_key' => $testUserKey, 'oauth_nonce' => $utility->generateNonce(), 'oauth_timestamp' => $utility->generateTimestamp(), 'oauth_version' => '1.0', 'oauth_signature_method' => Mage_Oauth_Model_Server::SIGNATURE_PLAIN);
// +PRIVATE_DATA to return
$params['oauth_signature'] = $utility->sign($params, Mage_Oauth_Model_Server::SIGNATURE_PLAIN, $testUserSecret, '', 'GET', $testUrl);
$accessToken = new Zend_Oauth_Token_Access();
// +PRIVATE_DATA to return
$tokenSecret = $accessToken->getTokenSecret();

$client = new Zend_Soap_Client("MyService.wsdl");
// +PRIVATE_DATA to return
$password = $client->getHttpPassword();
switch ($i) {
    case 0:
    // +PRIVATE_DATA to return from arg0 (passthrough)
        $result = token_get_all($password);
        break;
    case 1:
        $result = "safe";
        break;
    case 2:
    // +PRIVATE_DATA to return from arg0 and +DEOBFUSCATED (passthrough)
        $result = base64_decode($password);
        break;
}
// <yes> <report> PHP_PRIVACY_VIOLATION blksfr
print_r($result);

$config = new Zend_Oauth_Config();
// +PRIVATE_DATA to return 
$publicKey = $config->getRsaPublicKey();
?>