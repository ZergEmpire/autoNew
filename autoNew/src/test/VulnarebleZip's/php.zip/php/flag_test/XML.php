<?php
	$xml = new DOMDocument( "1.0", "ISO-8859-15" );
	// +XML to return and this
	$xml->loadHTMLFile($url);

	$reader = new XMLReader();
	// +XML to return and this
	while ($reader->read())
	{
		//dosmth
	}
	// +XML to return and this
	$sxe = new SimpleXMLElement($xmlstr);
	$deb = new Debugger();
	// +XML to return (passthrough)
	$str = $deb->trimPath($sxe);
	// +XML to return (passthrough)
	$form = $class->Form->create($str, array('type' => 'file'));
	// +XML to return
	$xml3 = Xml::build('<example>text</example>');
	// +XML to return (passthrough)
	$arr = array('first', $xml3, 'third');
	// +XML to return (passthrough)
	$mode = current($arr);
?>