<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$con=mysqli_connect("localhost","my_user","my_password","my_db");
// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$mysqli = new mysqli("localhost", "my_user", "my_password", "world");
$dbhandle = sqlite_open('sqlitedb');
// +DATABASE to return
$query = sqlite_query($dbhandle, 'SELECT name, email FROM users LIMIT 25');
$filter = new Zend_Filter_Digits();
// +NUMBER to return
$digits = $filter->filter($query);
// $n = $mysqli->update('bugs', $digits, 'bug_id = 2');
// +NUMBER to return
$var = intval('42');
if ($a == 5):
	// +NUMBER to return from arg0 (passthrough)
	$number = var_export($digits);
	echo $number;
elseif ($a == 6):
    $number = "5";
    echo $number;
else:
	// +NUMBER to return from arg0 (passthrough)
    $number = html_entity_decode($var);
    echo $number;
endif;
while ($i <= 10):
    echo $number;
    $i++;
endwhile;
// +NUMBER, +WEB to return rg5fsh
$msgnos = imap_search($conn, 'ALL');
// $n = $mysqli->update('bugs', $msgnos, 'bug_id = 2');
// +NUMBER, +WEB to return qopalx
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_BOOLEAN);

?>