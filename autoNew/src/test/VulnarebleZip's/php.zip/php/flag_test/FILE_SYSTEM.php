<?php
// +FILE_SYSTEM to return
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$lines = file('https://www.example.com/');
$reader = new XMLReader();
// +FILE_SYSTEM to this
$reader->open();
// +FILE_SYSTEM to return
$f = Debugger::excerpt(ROOT.DS.LIBS.'debugger.php', 321, 2);
do {
	// +FILE_SYSTEM to arg0 from arg1
    define($param, $f);
} while ($i > 0);

$file = new File($dir->pwd() . DS . $file);
// +FILE_SYSTEM to return
$contents = $file->read();
if ($arg)
{
	// +FILE_SYSTEM to return from arg0
	$tainted = Router::url($param);
}
else 
{
	$tainted = "not tainted";
	// no flag
	echo $tainted;
}
// <yes> <report> PHP_XSS_PERSISTENT 12lds8
echo $tainted;
while ($i <= 10) {
// +FILE_SYSTEM to return from arg0
$bad = each ($tainted);
}
?>