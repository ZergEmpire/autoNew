<?php
// +ARGS to return
$options = getopt("f:hp:");
// +ARGS to return rejk32
$web = $HTTP_SERVER_VARS['argv'];
// +ARGS to return brtj3s
$arg = $argv[0];
?>