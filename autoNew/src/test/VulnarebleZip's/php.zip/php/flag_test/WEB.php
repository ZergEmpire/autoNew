<?php
    // +WEB to return
    $comment['referrer'] = RequestHandlerComponent::getReferrer();
    $upload = new Zend_File_Transfer();
    // +WEB to return
    $files = $upload->getFileInfo();

    $request = new Zend_Controller_Request_Http();
    // +WEB to return
    $myCookie = $request->getCookie('cookieName');

    $response = new Zend_Json_Server_Response();
    // +WEB to return
    $result = $response->getResult();
    // вот так не работает
    $resp = Zend_Http_Response::fromString($str);
    echo $resp->getBody();

    $client = new Zend_Rest_Client('https://framework.zend.com/rest');
    // +WEB to return
    // <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST 8e877c  <yes> <report> PHP_XSS_REFLECTED 43lds8
    echo $client->sayHello('Davey', 'Day')->get();

    $request = new Zend_XmlRpc_Request();
    // +WEB to return
    $res = $request->getRawRequest();

    $form = new Zend_Form;
    // +WEB to return
    $unfiltered = $form->getUnfilteredValues();
    $normalized_unfiltered = StringTool::remove_trailing(Router::normalize(Router::url($unfiltered)), '?');
    $unfiltered = Sanitize::stripWhitespace($unfiltered);

    // echo $ajax->editor($unfiltered,array(
    //   'controller'=>'users',
    //   'action'=>'edit',$user['User']['id']),
    //   array(
    //   'submit'=>'Accept',
    //   'style'=>'inherit',
    //   'submitdata'=>array('id'=>2),
    //   'tooltip'=>'sdsg'));

    $HttpSocket = new HttpSocket();
    // +WEB to return
    $results = $HttpSocket->put('https://www.google.com/search', 'q=cakephp');
    $socket = new CakeSocket( array('host'=>$ip,'port'=>$port));
    // +WEB to return
    $soc = $socket->read();

    $res = Zend_Http_Response::fromString($soc);
    $Dispatcher = new Dispatcher();
    // +WEB to return
    $url = $Dispatcher->getUrl($url);
    $router = new Router();
    // +WEB to return
    $par = $router->getParam('url', true);
    // +WEB to rerurn (passthrough)
    $arrayToString = Debugger::exportVar($par);
    // +WEB to return
    $title = $class->request->getData('MyModel.title');
    // +WEB to return
    $value = $class->request->data('key');
    // +WEB to return
    $page = $class->request->getQuery('page');
    // +WEB to return
    $userName = $class->request->session()->read('Auth.User.name');
    // +WEB to return
    $cook = $class->Cookie->read('name');
    // +WEB to return
    $bad = $_GET['tainted'];
    // +WEB to return ed51bh
    $taint_web = imap_body($imap, $num);
    // passthrough kf4grh +WEB to return
    $line_web = trim(socket_read($socket, MAXLINE));
    $client = new Zend_Http_Client($url);
    $client->setMethod(Zend_Http_Client::POST);
    // +WEB to return ed51bh
    $response_web = $client->request();
    // <yes> <report> PHP_DOS_REGEX s71167
    preg_match($response_web, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
    // +WEB to return ergtjn
    $web = $_SERVER['HTTP_smth'];
    // +WEB to return kn3f32
    $web2 = $GLOBALS[_SERVER]['QUERY_STRING'];
    $doc = new DOMDocument;
    //passthrough from arg0 to return
    $headNode = $doc->createElement($web);
    // passthrough from arg0 to this and return
    $doc->appendChild($headNode);
    // +WEB to return f11gc1
    file("php://input")
?>
