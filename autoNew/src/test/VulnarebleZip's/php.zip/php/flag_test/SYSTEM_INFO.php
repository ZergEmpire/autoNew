<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$link = mysql_connect("localhost", "mysql_user", $pass);
// +SYSTEM_INFO to return
$error = mysql_error($link);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf +SYSTEM_INFO to return
$info = mysql_get_client_info();

$smarty = new Smarty();
// +SYSTEM_INFO to return
$myVar = $smarty->get_config_vars('foo');
//
$lasterror = pg_last_error($link);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
pg_connect("host=localhost port=5432 dbname=mary");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf +SYSTEM_INFO to return
$name = pg_dbname();
// +SYSTEM_INFO to return
$lerr = preg_last_error();
// +SYSTEM_INFO to return
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL fgelws
print_r(apd_dump_persistent_resources());

$p = xml_parser_create();
// +SYSTEM_INFO to return
$err = xml_error_string(xml_get_error_code($p));

$file = new File('/path/to/file');
// +SYSTEM_INFO to return
$path = $file->pwd();
// +SYSTEM_INFO to return
$ip = getenv('REMOTE_ADDR');
// +SYSTEM_INFO to return
$env = env('USER');

$fa = SplFixedArray::fromArray($env);

$sxe = new SimpleXMLElement($xml);
// +SYSTEM_INFO to return
$namespaces = $sxe->getNamespaces(true);
// +SYSTEM_INFO to return
$arr = Cache::settings();
$e = new Exception;
// +SYSTEM_INFO to return
$message = $e->getMessage();
// +SYSTEM_INFO to return fgnek3
$sys = $GLOBALS[_ENV];
// +SYSTEM_INFO && NUMBER to return grem3l
$search_url = filter_input(INPUT_ENV, 'search', FILTER_VALIDATE_FLOAT);
// +SYSTEM_INFO && NUMBER to return rekewk
$search_url2 = filter_input(INPUT_ENV, 'search', 258);
// passthrough from arg0 to return
$cookie = Zend_Http_Cookie::fromString($sys, $ref_uri, false);
$arr = Configure::$behaviorPaths;
?>