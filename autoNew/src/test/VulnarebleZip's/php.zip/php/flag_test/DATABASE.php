<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$con=mysqli_connect("localhost","my_user","my_password","my_db");
// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$mysqli = new mysqli("localhost", "my_user", "my_password", "world");
$dbhandle = sqlite_open('sqlitedb');
$dbhandle2 = new SQLiteDatabase('sqlitedb');
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$db = pg_connect("dbname=publisher") or die("Could not connect");

$pdo = new PDO("localhost","my_user","my_password","my_db");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf +DATABASE to return
$result = mysqli_query($con,"SELECT * FROM Persons");
if ($stmt = $mysqli->prepare("SELECT District FROM City WHERE Name=?"))
{
//do smth
}
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
if ($stmt = mysqli_prepare($link, "SELECT Code, Name FROM Country ORDER BY Name LIMIT 5")) {
    // <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
    mysqli_stmt_execute($stmt);
    // <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf +DATABASE to arguments
    mysqli_stmt_bind_result($stmt, $col1, $col2);
    // <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
    mysqli_stmt_close($stmt);
}

// +DATABASE to return
$query = sqlite_query($dbhandle, 'SELECT name, email FROM users LIMIT 25');
// +DATABASE to return
$query2 = $dbhandle2->query('SELECT name, email FROM users LIMIT 25');
// +DATABASE to return
while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC)) {
    //dosmth
}
// +DATABASE to return
while ($entry2 = $query2->fetchAll(SQLITE_ASSOC)) {
   //dosmth
}
// +DATABASE to return
$stmt = $pdo->prepare('SELECT name FROM users');
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf +DATABASE to return
$rows = pg_copy_to($db, $table_name);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$smth = pg_fetch_array($rows);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
mysqli_close($con);
$mysqli->close();
$connection = new Connection();
// +DATABASE to return
$res = $connection->prepare("SELECT District FROM City WHERE Name=?");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf passthrough from arg0 to return
$result = mysql_result($res, 2);
?>

