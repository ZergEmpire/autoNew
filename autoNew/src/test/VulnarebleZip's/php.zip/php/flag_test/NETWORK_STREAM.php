<?php
// +NETWORK_STREAM
$fp = stream_socket_client("tcp://www.example.com:80", $errno, $errstr, 30);
// passthrough from arg0 to return
echo json_encode($fp);
?>