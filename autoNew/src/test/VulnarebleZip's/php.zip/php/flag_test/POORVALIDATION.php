<?php
// +POOR_VALIDATION to return
$escaped_string = JavascriptHelper::escapeScript($string);
// +POOR_VALIDATION to return
$changed_string = htmlspecialchars($string);
// +POOR_VALIDATION to return
$decoded_string = urlencode($string);
// +POOR_VALIDATION to return wek3ns
$email = filter_input(INPUT_ENV, 'email', FILTER_VALIDATE_EMAIL);
// +POOR_VALIDATION to return jnertb
$html = Flay::toHtml($text, false, $allowHtml);
// +POOR_VALIDATION to return fgekws
$sanitize = Sanitize::paranoid($badString, $arr);
// passthrough from arg0 to this
$smarty->append($sanitize);
// passthrough from this to return 
$myVar = $smarty->getTemplateVars('foo');
?>
