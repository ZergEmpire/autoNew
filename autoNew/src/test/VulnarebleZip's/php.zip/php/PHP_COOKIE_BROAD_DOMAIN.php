<?php
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report> PHP_COOKIE_NOT_OVER_SSL 528a3b <yes> <report> PHP_COOKIE_BROAD_DOMAIN 72d3cd
setcookie('','','','','.abc.abc');
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL fee34a <yes> <report> PHP_COOKIE_BROAD_DOMAIN cfa075 <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659
session_set_cookie_params('','','.abc.abc');
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN d3dacd
ini_set('session.cookie_domain', '.abc.abc');
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 71d3cd
Configure::write('Session', [
    'defaults' => 'php',
    'ini' => [
        'session.cookie_domain' => '.yourdomain.com'
    ]
]);
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 3465km
$cookie = (new Cookie('remember_me'))
    ->withValue('1')
    ->withExpiry(new DateTime('+1 year'))
    ->withPath('/path')
    ->withDomain('.example.com')
    ->withSecure(true)
    ->withHttpOnly(true);
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 126qkm
$class->Cookie->config('domain', '.example.com');
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 026qkm
$class->Cookie->config([
    'domain' => '.example.com',
    'httpOnly' => true
]);
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 2lemfn
$class->Cookie->domain = '.example.com';
$response = new Response();
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 296qkm
$response = $response->withExpiredCookie('remember_me', ['domain' => '.example.com']);
// <yes> <report> PHP_COOKIE_BROAD_DOMAIN 246qkm
$class->response->withExpiredCookie('remember_me', ['domain' => '.example.com']);
?>