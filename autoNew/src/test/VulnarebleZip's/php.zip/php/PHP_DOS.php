<?php
// +WEB to return
$taint_timeout = $_GET['url'];
// <yes> <report> PHP_DOS p22dos1
imap_timeout(IMAP_OPENTIMEOUT, $taint_timeout);
?>