<?php
// <yes> <report> PHP_REGISTER_GLOBALS 891729
ini_set('register_globals','On');
?>