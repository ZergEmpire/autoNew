<?php
$table = $_GET['table'];
$delete_query  = "DELETE $table";
try {
    // <yes> <report> PHP_CSRF igor01 <yes> <report> PHP_INJECTION_SQL q0ffw1
    pg_query($delete_query);
} catch (Exception $e) {
     echo 'Exception!';
}
?>
