<?php
// <yes> <report> PHP_ENABLE_DL s77e67
ini_set('enable_dl', 'On');
?>