<?php
// <yes> <report> PHP_MAGIC_QUOTES cbe05a
ini_set('magic_quotes_sybase','On');
// <yes> <report> PHP_MAGIC_QUOTES cbe05a
ini_set('magic_quotes_gpc','On');
// <yes> <report> PHP_MAGIC_QUOTES cbe05a
ini_set('magic_quotes_runtime','On');
?>