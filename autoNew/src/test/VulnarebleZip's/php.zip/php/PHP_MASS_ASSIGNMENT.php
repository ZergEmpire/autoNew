<?php
class UserController
{

public function save()
{
// <yes> <report> PHP_MASS_ASSIGNMENT f0e74e
$user = new User(Input::all()) ;
$user->save();
// Do other stuff here
}

}

