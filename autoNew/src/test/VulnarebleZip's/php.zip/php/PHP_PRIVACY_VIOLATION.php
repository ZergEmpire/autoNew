<?php
    $consumer = new Zend_Oauth_Consumer($params);
    $accessToken = $consumer->getAccessToken($_GET, $requestToken);

    $client = new Zend_Soap_Client("MyService.wsdl");
    $password = $client->getHttpPassword();

    $filter = new Zend_Filter_Decrypt($key);
    $filter->setVector('myvector');
    $decrypted = $filter->filter($encrypted_password);

    // <yes> <report> PHP_PRIVACY_VIOLATION ydjsnd
    error_log($accessToken, 3, "~/Documents/log");

    $writer = new Zend_Log_Writer_Stream('php://output');
    $logger = new Zend_Log($writer);
    // <yes> <report> PHP_PRIVACY_VIOLATION plfde8
    $logger->log('user with password:' . $password, Zend_Log::INFO);

    if (file_exists('data.txt')) {
        // <no> <report>
        $fp = fopen('data.txt', 'w');
    }
    // <yes> <report> PHP_PRIVACY_VIOLATION yfdsnd
    fwrite($fp, $password);
    // <yes> <report> PHP_PRIVACY_VIOLATION kdlsnd
    prnMsg('User with token' . ' ' . $accessToken, 'error');

    $temp = new SplTempFileObject();
    // <yes> <report> PHP_PRIVACY_VIOLATION pkdde8
    $temp->fwrite($password . "\n");
    // <yes> <report> PHP_PRIVACY_VIOLATION ydj00d
    debug_zval_dump($accessToken);
    // <yes> <report> PHP_PRIVACY_VIOLATION ydjsnd
    trigger_error("The right password" . $password, E_USER_ERROR);
    // <yes> <report> PHP_PRIVACY_VIOLATION ydjsnd
    LogError('User with token:' . ' ' . $accessToken);
    // <yes> <report> PHP_PRIVACY_VIOLATION pldmnr
    CakeLog::write('warning', $decrypted);
    // <yes> <report> PHP_PRIVACY_VIOLATION pmmdle
    Debugger::dump($decrypted);

    $obj = new Object();
    // <yes> <report> PHP_PRIVACY_VIOLATION kf4n2l
    $obj->cakeError($meth, $password);

    $file = new File($dir->pwd() . DS . $file);
    // <yes> <report> PHP_PRIVACY_VIOLATION 1kdde8
    $file->write($decrypted, 'w');
    // <yes> <report> PHP_PRIVACY_VIOLATION 2mmdle
    File::prepare($password);
    // <yes> <report> PHP_PRIVACY_VIOLATION 6qlde8
    $class->Session->setFlash($password, 'flash_good');
    // <yes> <report> PHP_PRIVACY_VIOLATION gerkw4
    print_r ($password, false);
    // <yes> <report> PHP_PRIVACY_VIOLATION 33ll9m
    Log::error($password);
    // <yes> <report> PHP_PRIVACY_VIOLATION gr1000
    echo $settings['private_key'];
?>