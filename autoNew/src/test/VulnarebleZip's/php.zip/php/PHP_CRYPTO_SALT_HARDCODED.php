<?php
// <yes> <report> PHP_CRYPTO_SALT_HARDCODED 977e67 <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 744c2c
crypt('', 0);
// <yes> <report> PHP_CRYPTO_SALT_HARDCODED p11sh1
openssl_pbkdf2($password, "lkk", $key_length, $iterations, 'sha256');
// <yes> <report> PHP_CRYPTO_SALT_HARDCODED p11sh1
openssl_pbkdf2($password, "salt", $key_length, $iterations, 'sha256');
// <yes> <report> PHP_CRYPTO_SALT_NULL p12sn1
openssl_pbkdf2($password, null, $key_length, $iterations, 'sha256');

?>