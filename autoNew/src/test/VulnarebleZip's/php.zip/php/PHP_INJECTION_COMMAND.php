<?php
$upload = new Zend_File_Transfer();
// +WEB to return
$file = $upload->getFileInfo();

// <yes> <report> PHP_INJECTION_COMMAND d456m3
$output = shell_exec($file);

$substitutions = array('&'  => '',);
$file2 = str_replace(array_keys($substitutions), $substitutions, $file);
// <yes> <report> PHP_INJECTION_COMMAND sfg3ht <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY 000005
$output = shell_exec($file2);

$file3 = escapeshellarg($file);
$output = shell_exec($file3);

// <yes> <report> PHP_INJECTION_COMMAND u45wm1
$stream=ssh2_exec($conn_id, $file);
// <yes> <report> PHP_INJECTION_COMMAND krne3m
mail('nobody@example.com', 'the subject', 'the message', null, $file);

preg_replace('.*\/.*\/\w*e\w*', $replacement, $file);
// No report
preg_replace('.*\/.*\/\w*e\w*', $replacement, $not_tainted);
?>