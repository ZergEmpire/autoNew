<?php
$response = new Zend_Json_Server_Response();
// +WEB to return
$result = $response->getResult();
// <yes> <report> PHP_INJECTION_OBJECT p11io1
$myInstance = unserialize($result);
?>