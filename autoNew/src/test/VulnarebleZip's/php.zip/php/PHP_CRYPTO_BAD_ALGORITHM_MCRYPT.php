<?php
function NTLMResponse($challenge,$password)
	{
		$unicode=$class->ASCIIToUnicode($password);
		// <yes> <report> PHP_CRYPTO_BAD_HASH 23b4b4 <yes> <report> PHP_CRYPTO_BAD_HASH 1d0afd
		$md4=mhash(MHASH_MD4,$unicode);
		$padded=$md4.str_repeat(chr(0),21-strlen($md4));
		// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM bde6c7
		$iv_size=mcrypt_get_iv_size(MCRYPT_DES,MCRYPT_MODE_ECB);
		$iv=mcrypt_create_iv($iv_size,MCRYPT_RAND);
		for($response="",$third=0;$third<21;$third+=7)
		{
			for($packed="",$p=$third;$p<$third+7;$p++)
				$packed.=str_pad(decbin(ord(substr($padded,$p,1))),8,"0",STR_PAD_LEFT);
			for($key="",$p=0;$p<strlen($packed);$p+=7)
			{
				$s=substr($packed,$p,7);
				$b=$s.((substr_count($s,"1") % 2) ? "0" : "1");
				$key.=chr(bindec($b));
			}
			// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM e7719c <yes> <report> PHP_CRYPTO_BAD_ALGORITHM bde6c7
			$ciphertext=mcrypt_encrypt(MCRYPT_DES,$key,$challenge,MCRYPT_MODE_ECB,$iv);
			$response.=$ciphertext;
		}
		return $response;
	}

// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM bde6c7
mcrypt_get_iv_size(MCRYPT_DES);
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM bde6c7
mcrypt_encrypt(1);
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM bde6c7
mcrypt_get_iv_size(des);
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 74b646 <yes> <report> PHP_CRYPTO_BAD_ALGORITHM e7719c
mcrypt_encrypt(MCRYPT_RC2);
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 74b646
mcrypt_encrypt(rc2);
?>