<?php
$titul_id = " ";
$fname = $_POST['file_name'];
$fext = " ";
$key = "key";
$who = "who";
$pathav = "defect/".$titul_id.'/'.$fname.'.'.$fext;
// <yes> <report> PHP_UNTRUSTED_SOURCE f6ffe1 <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_FILE_MANIPULATION yuokgk <yes> <report> PHP_PATH_MANIPULATION df1wm0
@move_uploaded_file($_SERVER['HTTP_HOST'], any_function($pathav));
// <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_PATH_MANIPULATION qw5wm6 <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_FILE_MANIPULATION yuokgk
copy($_FILES[$who]['tmp_name'][$key],$pathav);

$Folder =& new Folder($path);
$upload = new Zend_File_Transfer();
// +WEB to return
$file = $upload->getFileInfo();
$newfile = $_GET['new_file_path'];
$result = Folder::addPathElement($file, 'test');
$to = $Folder->addPathElement($file, $item);
// <yes> <report> PHP_PATH_MANIPULATION qw5wm6 <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_FILE_MANIPULATION yuokgk
copy($file, $newfile);

// <yes> <report> PHP_PATH_MANIPULATION swhwm0
parse_ini_file($file);

// <yes> <report> PHP_PATH_MANIPULATION df1wm0
move_uploaded_file($tmp_name, $file);

$doc = new DOMDocument();
// <yes> <report> PHP_PATH_MANIPULATION duuudm
$doc->load($file);

// <yes> <report> PHP_PATH_MANIPULATION drujd2
$fileObject = new SplFileObject($file);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PATH_MANIPULATION vf2wm1
pg_lo_export($database, $oid, $file);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PATH_MANIPULATION ss2wm2
pg_trace($file);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PATH_MANIPULATION ts2wh5
pg_lo_import($database, $file);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PATH_MANIPULATION ts2wh5
pg_lo_import($file);

// <yes> <report> PHP_PATH_MANIPULATION mp2wh9 <yes> <report> PHP_FILE_MANIPULATION sdh63k
error_log("You messed up!", 3, $file);

// <yes> <report> PHP_PATH_MANIPULATION dd2wh5
clearCache( $file, $type, $ext );

// <yes> <report> PHP_PATH_MANIPULATION swhwm0
delete($dir_path . $file);
// <yes> <report> PHP_PATH_MANIPULATION krtn64
fileExistsInPath($dir_path . $file);

// +WEB to return
$comment['referrer'] = RequestHandlerComponent::getReferrer();
// <yes> <report> PHP_PATH_MANIPULATION dbpudm
CakeLog::write($comment, 'Something did not work');

// <yes> <report> PHP_PATH_MANIPULATION stpukm
Configure::buildPaths($file);

// <yes> <report> PHP_PATH_MANIPULATION vwpuk4
Configure::store('Model', $file, array('Users' => array( 'path' => 'users', 'plugin' => true )));

$folder = new Folder('/foo');
// <yes> <report> PHP_PATH_MANIPULATION cgpu84
$folder->cd($file);

$Db = new MagicDb();
// $class->Db =& new MagicDb();
// <yes> <report> PHP_PATH_MANIPULATION mwpu86
$Db->analyze($file, $options);

$Ini = new IniAcl();
// <yes> <report> PHP_PATH_MANIPULATION ghpu32
$Ini->config = $Ini->readConfigFile($file);

$helperTags = new Helper();
// <yes> <report> PHP_PATH_MANIPULATION ktpu37
$tags = $helperTags->loadConfig($file);

$c = new Cache(array(
  'name'      => 'YOUR-CACHE-NAME',
// <yes> <report> PHP_PATH_MANIPULATION md7fg6
  'path'      => $file,
  'extension' => '.cache'
));

// <yes> <report> PHP_PATH_MANIPULATION dddj32
$writer = new Zend_Log_Writer_Stream($file);

$adapter = new Zend_File_Transfer_Adapter_Http();
// <yes> <report> PHP_PATH_MANIPULATION wqpu99
$adapter->setDestination($file);

$client = new Zend_Http_Client($url, array(
    'keepalive' => true
));
// <yes> <report> PHP_PATH_MANIPULATION sqpf59
$client->setFileUpload($file, 'upload', $text, 'text/plain');
// <yes> <report> PHP_PATH_MANIPULATION 43ll9m
Storage::delete($file);
?>
