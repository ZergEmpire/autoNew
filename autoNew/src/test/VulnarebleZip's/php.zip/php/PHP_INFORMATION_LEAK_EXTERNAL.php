<?php
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL f7cca9
phpinfo();
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL e64753
error_reporting($a);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL e64753
error_reporting(E_ALL ^ E_WARNING);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL e64753
error_reporting(-1);
// <no> <report>
error_reporting(0);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 9becad
apd_dump_function_table();
$d = new Debugger();
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 5c03fe
$d->trace();
$ds = new DboSource();
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 5fd285
$ds->showLog();
$c = new Configure();
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 3734b6
$c->write('debug', 1);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 44b7cf
ini_set('expose_php','On');

$p = xml_parser_create();
// +SYSTEM_INFO to return
$err = xml_error_string(xml_get_error_code($p));
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 54bwcq
echo 'error:' . $err;
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL r4bqcq
print 'error:' . $err;
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL dtc69t
printf("%.1f",$err);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL mjc68t
trigger_error($err, E_USER_ERROR);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL opj42n
e($err);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL fgelws
var_export($err);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 7f25a9
highlight_string($err);
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 7f25a9
highlight_string($err, false);
highlight_string($err, true);
highlight_string();
?>