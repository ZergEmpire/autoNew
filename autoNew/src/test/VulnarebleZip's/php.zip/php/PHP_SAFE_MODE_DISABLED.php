<?php
// <yes> <report> PHP_SAFE_MODE_DISABLED 78bb8a
ini_set('safe_mode','Off');
// <yes> <report> PHP_SAFE_MODE_DISABLED b950ea
ini_set('safe_mode_exec_dir','');
?>