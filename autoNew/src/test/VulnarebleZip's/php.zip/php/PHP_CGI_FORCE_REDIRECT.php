<?php
// <yes> <report> PHP_CGI_FORCE_REDIRECT 698996
ini_set('cgi.force_redirect','Off');
?>