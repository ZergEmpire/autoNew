<?php
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL 528a3b <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report> PHP_COOKIE_BROAD_PATH 3f28d3
setcookie('','','','/');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659 <yes> <report> PHP_COOKIE_NOT_OVER_SSL fee34a <yes> <report> PHP_COOKIE_BROAD_PATH a2a5bf
session_set_cookie_params('','/');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 640f58
ini_set('session.cookie_path', '/');
// <yes> <report> PHP_COOKIE_BROAD_PATH a1d3cd
Configure::write('Session', [
    'defaults' => 'php',
    'ini' => [
        'session.cookie_path' => '/',
    ]
]);
// <yes> <report> PHP_COOKIE_BROAD_PATH 346qkm
$cookie = (new Cookie('remember_me'))
    ->withValue('1')
    ->withExpiry(new DateTime('+1 year'))
    ->withPath('/')
    ->withDomain('example.com')
    ->withSecure(true)
    ->withHttpOnly(true);
// <yes> <report> PHP_COOKIE_BROAD_PATH 146qkm
$class->Cookie->config('path', '/');
// <yes> <report> PHP_COOKIE_BROAD_PATH 046qkm
$class->Cookie->config([
    'path' => '/',
    'httpOnly' => true
]);
// <yes> <report> PHP_COOKIE_BROAD_PATH plemfn
$class->Cookie->path = '/';

$response = new Response();
// <yes> <report> PHP_COOKIE_BROAD_PATH 396qkm
$response = $response->withExpiredCookie('remember_me', ['path' => '/']);
// <yes> <report> PHP_COOKIE_BROAD_PATH 946qkm
$class->response->withExpiredCookie('remember_me', ['path' => '/']);
?>