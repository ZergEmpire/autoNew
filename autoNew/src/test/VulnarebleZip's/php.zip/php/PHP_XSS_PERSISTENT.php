<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_XSS_PERSISTENT ed67f8
pg_lo_read_all();
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$con=mysqli_connect("localhost","my_user","my_password","my_db");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$result = mysqli_query($con,"SELECT * FROM Persons");
$dbhandle = sqlite_open('sqlitedb');
$message = sqlite_query($dbhandle, 'SELECT name, email FROM users LIMIT 25');

// <yes> <report> PHP_XSS_PERSISTENT ed6ds8
debug_zval_dump($result);

$smarty = new Smarty();
// <yes> <report> PHP_XSS_PERSISTENT ed6de8
$smarty->trigger_error($result);
$smarty->append($result);
// <yes> <report> PHP_XSS_PERSISTENT ed00e8
$smarty->display( "{$template}" );

// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$lines = file('https://www.example.com/');
// <yes> <report> PHP_XSS_PERSISTENT ewwde8
$json = new Zend_Json_Expr($lines);

$doc = new DOMDocument();
// <yes> <report> PHP_XSS_PERSISTENT eq6de8
$doc->loadHTML($lines);

// <yes> <report> PHP_XSS_PERSISTENT eq11e8
$class->Session->setFlash($message, 'flash_good');
// <yes> <report> PHP_XSS_PERSISTENT we6ds8
Debugger::dump($message);
// <yes> <report> PHP_XSS_PERSISTENT pq6ds8
e($message);

// <yes> <report> PHP_XSS_PERSISTENT 12lds8
echo 'Employee name: ', $result;
// <yes> <report> PHP_XSS_PERSISTENT 12lds8
echo "Employee name: $result";
// <yes> <report> PHP_XSS_PERSISTENT 12lqd8
print 'Employee name: '. $result;
// <yes> <report> PHP_XSS_PERSISTENT 12lqd8
print $result;
// <yes> <report> PHP_XSS_PERSISTENT 12lqd8
print "Employee name: $result";
// <yes> <report> PHP_XSS_PERSISTENT 0923je
debug($result, true, true);

use Yii;
use yii\web\Controller;

class VulnerabilityController extends Controller
{
    public function actionSql11()
    {
        $conn = new \PDO(Yii::$app->db->dsn, Yii::$app->db->username, Yii::$app->db->password);
        $stmt = $conn->query("SELECT * FROM user where id = 5");
        $stmt;
        // <yes> <report> PHP_XSS_PERSISTENT yiibmd
        return $this->render('sql', ['result' => $stmt->fetchAll()]);
    }
}

// Test for static JS file


$basedir="/editor/tinymce/tiny_mce/";
$content = file_get_contents("$basedir/langs/en.js");
// <yes> <report> PHP_XSS_PERSISTENT 12lds9
echo $content;
?>