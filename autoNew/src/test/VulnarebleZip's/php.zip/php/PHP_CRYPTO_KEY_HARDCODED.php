<?php
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 927ff8
$zfe = new Zend_Filter_Encrypt(1);
$zo = new Zend_OpenId();
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED f4cd76
$zo->createDhKey('','','abc');
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028465
$something_secret_key_something = 'abc';
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028557
$encryption_key = 1;
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028647 <yes> <report> PHP_PASSWORD_HARDCODED 026972
$class->$something_passphrase_something = 1.0;
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028739
$class->$pass_phrase = true;
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028832
$truth = (1 != $something_secrets_key_something);
// <no> <report>
$truth = (1 != $something_secrets_key_something++);
// <no> <report>
$truth = (1 <= $something_secrets_key_something);
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028896
$encryption_key == 'abc';
// <no> <report> PHP_CRYPTO_KEY_HARDCODED 028844
$class->$something_passphrase_something == true;
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 028908 <yes> <report> PHP_PASSWORD_HARDCODED 027169
1.0 != $class->$pass_phrase;
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 128490
$class->Cookie->key = 'qSI232qs*&sXOw!adre@34SAv!@*(XSL#$%)asGb$@11~_+!@#HKis~#^';
// <no> <report>
$sequence_start_key = '16R';
// <no> <report>
if (false === $publicKey) {}
// <yes> <report> PHP_CRYPTO_KEY_HARDCODED 027hdk
switch ($key) {
    case 'string1':
        return 'rio';
    case 'string2':
        return 'kio';
}
?>