<?php
// <yes> <report> PHP_CRYPTO_BAD_RANDOM 1649a4
rand();
$v1 = random_int(1000,9999);
?>