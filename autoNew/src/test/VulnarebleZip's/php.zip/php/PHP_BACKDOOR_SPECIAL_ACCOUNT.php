<?php
// <yes> <report> PHP_BACKDOOR_SPECIAL_ACCOUNT 000010 <yes> <report> PHP_PASSWORD_HARDCODED 027221
if ($password == "qwerty") 
	{ echo "hello"; }
// <no> <report>
if ($existpassword == true) 
	{ echo "hello"; }
// <yes> <report> PHP_BACKDOOR_SPECIAL_ACCOUNT 000011
if ($hash == "8743b52063cd84097a65d1633f5c74f5") 
	{ echo "hello"; }
// <no> <report>
if ($url == "http://www.example.com/wpstyle/?p=364") 
	{ echo "hello"; }
// <no> <report>
if ($user->is_banned == 'yes')
	{ echo "hello"; }
// <no> <report>
if ($password == "") 
	{ echo "invalid password"; }
// <no> <report>
$isErrorStatus = $statusReportStatus === 'RJCT';
// <yes> <report> PHP_BACKDOOR_SPECIAL_ACCOUNT 000010
$isErrorStatus = $usrName === 'RJCT';
?>
