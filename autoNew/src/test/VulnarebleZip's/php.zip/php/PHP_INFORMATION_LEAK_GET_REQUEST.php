<?php
$zhc = new Zend_Http_Client();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST 8fea8f
$zhc->request('GET');
$zrc = new Zend_Rest_Client();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST 8e877c
$zrc->get();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST 12ea8f
$zhc->request(Zend_Http_Client::GET);
$http = new Client();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST kfennn
$http->get('/users', [], ['type' => 'json']);
$request = new Request();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST poikwj
$request->method('GET');
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST plwmee
$class->request->method('GET');
$HttpSocket = new HttpSocket();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST kfennn
$response = $HttpSocket->get('https://cakephp.org');
?>