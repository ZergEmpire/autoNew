<?php
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 814efd
setcookie('','','','','',true,false);
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 
setcookie('','','','','',true);
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659
session_set_cookie_params('','','','');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659 <yes> <report> PHP_COOKIE_NOT_OVER_SSL fee34a
session_set_cookie_params('','','');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 7778c4
ini_set('session.cookie_httponly','Off');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 7778c4
ini_set('session.cookie_httponly','0');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 7778c4
ini_set('session.cookie_secure','Off');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 7778c4
ini_set('session.cookie_secure','0');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 11d3cd
Configure::write('Session', [
    'defaults' => 'php',
    'ini' => [
        'session.cookie_name' => 'MyCookie',
        'session.cookie_httponly' => false
    ]
]);
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 34wqkm
$cookie = (new Cookie('remember_me'))
    ->withValue('1')
    ->withExpiry(new DateTime('+1 year'))
    ->withPath('/path')
    ->withDomain('example.com')
    ->withSecure(true)
    ->withHttpOnly(false);
class WebApp {

    function workWithCookie() {
        // <yes> <report> PHP_COOKIE_NOT_HTTPONLY 1464km
        $this->Cookie->config('httponly', false);
        // <yes> <report> PHP_COOKIE_NOT_HTTPONLY 0464km
        $this->Cookie->config([
            'path' => '/path',
            'httpOnly' => false
        ]);
        // <yes> <report> PHP_COOKIE_NOT_HTTPONLY 22emfn
        $this->Cookie->httpOnly = false;
    }

    function workWithResponse() {
        $response = new Response();
        // <yes> <report> PHP_COOKIE_NOT_HTTPONLY 196qkm
        $response = $response->withExpiredCookie('remember_me', ['httpOnly' => false]);
        // <yes> <report> PHP_COOKIE_NOT_HTTPONLY 246qke
        $this->response->withExpiredCookie('remember_me', ['httpOnly' => false]);
    }
}
?>