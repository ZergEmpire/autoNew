<?php
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna001
$host = "127.0.0.1";
// <yes> <report> PHP_HTTP_USAGE phttp00 <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url = "http://www.example.com/wpstyle/?p=364";
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna005
socket_connect($socket, "127.0.0.1", $port);
// <yes> <report> PHP_HTTP_USAGE phttp02 <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna004
socket_connect($socket, "http://www.example.com/wpstyle/?p=364", $port);
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url1 = "https://url.url";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url1 = 'https://url.url';
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "1.1.1.1";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna001
$url3 = "https://localhost";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna001
$url3 = 'https://localhost';
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$url4 = cl("https://url.irl");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$url4 = cl('https://url.irl');
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna003
$url5 = cl("https://localhost");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna003
$url5 = cl('https://localhost');
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna004
cl("https://url.url");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna004
cl('https://url.url');
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna005
cl("https://localhost");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna005
cl('https://localhost');
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY 000012
if ($ip == "127.0.0.1")
	{ echo "hello"; }

//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "1.1.1.1/er";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "https://[::1]";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "https://[1762:0:0:0:0:B03:1:AF18]";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "https://[fe80::219:7eff:fe46:6c42]";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "https://[::00:192.168.10.184]";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]";

?>
