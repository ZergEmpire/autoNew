<?php
$socket = new CakeSocket( array('host'=>$ip,'port'=>$port));
$soc = $socket->read();
$upload = new Zend_File_Transfer();
$files = $upload->getFileInfo();

// <yes> <report> PHP_XSS_REFLECTED 2d6ds8
debug_zval_dump($soc);

$smarty = new Smarty();
// <yes> <report> PHP_XSS_REFLECTED 3d6de8
$smarty->trigger_error($soc);
$smarty->append($soc);
// <yes> <report> PHP_XSS_REFLECTED ed0008
$smarty->display ( "{$template}" );

// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$lines = file('https://www.example.com/');
// <yes> <report> PHP_XSS_REFLECTED 4wwde8
$json = new Zend_Json_Expr($files);

$doc = new DOMDocument();
// <yes> <report> PHP_XSS_REFLECTED 5q6de8
$doc->loadHTML($files);

// <yes> <report> PHP_XSS_REFLECTED 6q11e8
$class->Session->setFlash($files, 'flash_good');
// <yes> <report> PHP_XSS_REFLECTED 7e6ds8
Debugger::dump($soc);
// <yes> <report> PHP_XSS_REFLECTED 8q6ds8
e($soc);
// <yes> <report> PHP_XSS_REFLECTED opwke2
debug($soc, true, true);
$upload = new Zend_File_Transfer();
$files2 = $upload->getFileInfo();
// <yes> <report> PHP_XSS_REFLECTED gekejs
__dcn($domain, $files2, $plural, 10, 3, false);

Route::get('user/{id}', function ($id) {
    // <yes> <report> PHP_XSS_REFLECTED dsfewf
    return 'User '.$id;
    // <no> <report>
    return $me;
    $socket = new CakeSocket( array('host'=>$ip,'port'=>$port));
    $soc = $socket->read();
    // <yes> <report> PHP_XSS_REFLECTED dsppwf
    return $soc;
});


use Yii;
use yii\web\Controller;

class VulnerabilityController extends Controller
{
    public function actionXss1()
    {
        $this->layout = null;
        $x = $_GET['x'];
        // <yes> <report> PHP_XSS_REFLECTED 43lds8
        echo "<html><body>$x</body></html>";
    }

    public function actionXss2()
    {
        $x = $_GET['x'];
        // <yes> <report> PHP_XSS_REFLECTED yiiamd
        return $this->render('xss', ['x' => $x]);
    }

    public function actionXss3()
    {
        $x = Yii::$app->request->get('x');
        // <yes> <report> PHP_XSS_REFLECTED yiia4d
        return $this->renderContent($x);
    }

        public function xss()
        {
            $controller = new yii\web\Controller();
            $x = Yii::$app->request->get('x');
            // <yes> <report> PHP_XSS_REFLECTED yiia4d
            return $controller->renderContent($x);
        }
}
// Test argv
// <yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 54bwcq <yes> <report> PHP_XSS_REFLECTED 43lds9
echo $_SERVER['argv'];
$result = $_GET['x'];
// <yes> <report> PHP_XSS_REFLECTED 43lqd8
print 'Employee name: '. $result;
// <yes> <report> PHP_XSS_REFLECTED 43lqd8
print $result;
// <yes> <report> PHP_XSS_REFLECTED 43lqd8
print "Employee name: $result";
$result = (int)$_GET['x'];
// <no> <report> PHP_XSS_REFLECTED 43lqd8
print $result;
?>