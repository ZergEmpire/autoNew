<?php
// +WEB to return
$url = $_GET['url'];
// +WEB to return
$taint_hostname = $_GET['url'];
// +WEB to return
$taint_port = $_GET['url'];
// <yes> <report> PHP_SSRF gergjk
curl_setopt($ch, CURLOPT_URL, $url);
// <yes> <report> PHP_SSRF vffsss <yes> <report> PHP_INJECTION_RESOURCE fndd11
$cakeSocket = new CakeSocket($url);
// <yes> <report> PHP_SSRF p11ssrf1
stream_socket_client($url, $errno);
// No report
stream_socket_client($url_not_taint, $errno);
// <yes> <report> PHP_SSRF p11ssrf2
socket_connect($socket, $url, $not_taint_port);
// <yes> <report> PHP_SSRF p11ssrf2
socket_connect($socket, $not_taint_url, $taint_port);
// No report
socket_connect($socket, $not_taint_address, $not_taint_port);
// <yes> <report> PHP_SSRF p11ssrf1
fsockopen($url);
?>