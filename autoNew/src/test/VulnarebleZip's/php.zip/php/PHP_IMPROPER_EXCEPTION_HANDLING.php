<?php
$unsafe_query  = "SELECT * FROM `users` WHERE user='igor' AND password='$pass';";
try {
    oci_execute($unsafe_query);
} catch (Exception $e) {
    echo 'Exception!';
}
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
oci_execute($unsafe_query);
?>
