<?php
// <yes> <report> PHP_OVERWRITE_LOCAL c84d8d
parse_str('');
$web = $_SERVER['HTTP_smth'];
// <yes> <report> PHP_OVERWRITE_LOCAL rgwldj
parse_str($web);
// No report
parse_str($web, $ouptput);
?>