<?php
// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$mysqli = new mysqli("localhost", "my_user", "my_password", "my_db");
// <yes> <report> PHP_MISSING_AUTHORIZATION kts443 <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$link = mysqli_connect("localhost", "my_user", "my_password", "my_db");

$username = "user";
// <yes> <report> PHP_PASSWORD_HARDCODED 026882
$password = "qwerty123";
// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$conn = new mysqli($servername, $username, $password);

$password1 = file('httpd.conf');
// <no> <report>
$conn = new mysqli($servername1, $username1, $password1);
?>