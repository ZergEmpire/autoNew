<?php
$filter = new Zend_Filter_Digits();
// +NUMBER to return
$digits = $filter->filter($query);

$pdo = new PDO("localhost","my_user","my_password","my_db");
$db = Zend_Db::factory("localhost","my_user","my_password","my_db");
$select = new Zend_Db_Select($db);
// +DATABASE to return
$stmt = $pdo->prepare('SELECT name FROM users');
// +WEB and NUMBER to return
$search_url = filter_input(INPUT_GET, 'search', FILTER_VALIDATE_IP);

// <yes> <report> PHP_ACCESS_CONTROL_DATABASE uwmshw
$count = $pdo->exec('smth' . $search_url);

// <yes> <report> PHP_ACCESS_CONTROL_DATABASE dw4swx
DboSource::execute($search_url, $options = Array, $params = Array);

// <yes> <report> PHP_ACCESS_CONTROL_DATABASE jt30w1
DboSource::fetchAssociated( $model , $search_url , $ids );

// <yes> <report> PHP_ACCESS_CONTROL_DATABASE vmx0w2
DboSource::update($model, $fields, $search_url, $conditions);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE f03k24
$result = odbc_exec($Conn, $search_url);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE k0r802
$result = mysql_query($search_url);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE p0w8e2
$result = mysql_db_query($db, $search_url);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE qsff41
$result = pg_query($conn, $search_url);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE m0gf12
pg_send_prepare($conn, "my_query", $search_url);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$link = mysqli_connect("localhost", "my_user", "my_password", "world");
$userName = getAuthenticated($_SESSION['userName']);
$id = $_POST['id'];
$userid = intval($id);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE s0tf11
$stmt = mysqli_prepare($link, "SELECT * FROM invoices WHERE id = ".$userid."AND user = ?");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
mysqli_stmt_bind_param($stmt, "s", $userName);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
mysqli_stmt_execute($stmt);

// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$mysqli = new mysqli("localhost", "my_user", "my_password", "world");
// <yes> <report> PHP_ACCESS_CONTROL_DATABASE s1tf11
$stmt2 = $mysqli->prepare("SELECT * FROM invoices WHERE id = ".$userid."AND user = ?");
$stmt2->bind_param('s',$userName);
$stmt2->execute();
$connection = new Connection($config);
// <yes> <report> PHP_ACCESS_CONTROL_DATABASE ekfre2
$connection->delete($search_url);
$next = Select::create('dual')->addField('px.' . $sq['name'] . '.nextval')->fetchCell();
// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$mysqli = new mysqli("localhost", "my_user", "my_password", "world");
// <yes> <report> PHP_ACCESS_CONTROL_DATABASE s1tf11
$mysqli->multi_query($search_url);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_ACCESS_CONTROL_DATABASE 90iwl2
oci_execute($search_url);
// <yes> <report> PHP_ACCESS_CONTROL_DATABASE pokem0
DB::insert('insert into users (id) values (' + $search_url + ')');
Schema::table('users', function (Blueprint $table) {
    // <yes> <report> PHP_ACCESS_CONTROL_DATABASE okemo1
    $table->dropColumn([$search_url, 'avatar', 'location']);
    // <yes> <report> PHP_ACCESS_CONTROL_DATABASE okemo1
    $table->dropColumn($search_url);
});
// <yes> <report> PHP_ACCESS_CONTROL_DATABASE kemon2
Schema::drop($search_url);
?>