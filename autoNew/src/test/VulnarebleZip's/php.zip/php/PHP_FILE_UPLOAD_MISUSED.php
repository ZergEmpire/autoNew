<?php

// <yes> <report> PHP_FILE_UPLOAD_MISUSED 1d2c97
ini_set('file_uploads','On');

$upload = new Zend_File_Transfer();
// +WEB to return
$file = $upload->getFileInfo();
// <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_FILE_MANIPULATION yuokgk
move_uploaded_file($_FILES["pictures"]["error"]);

$uploaded_tmp  = $_FILES['uploaded']['tmp_name'];
// <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_FILE_MANIPULATION yuokgk
move_uploaded_file( $uploaded_tmp, $target_path );
// <yes> <report> PHP_FILE_UPLOAD_MISUSED dfb53s <yes> <report> PHP_FILE_MANIPULATION yuokgk
rename($uploaded_tmp, $new_path);

?>