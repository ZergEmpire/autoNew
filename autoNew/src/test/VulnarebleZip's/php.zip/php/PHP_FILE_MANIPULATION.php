<?php
$unsafe_year = $_GET['year'];
$validated_year = round($unsafe_year);
// <yes> <report> PHP_FILE_MANIPULATION dmjg7s
fprintf($fp, "%04d-%02d-%02d", $unsafe_year, $month, $day);
fprintf($fp, "%04d-%02d-%02d", $year, $month, $day);
fprintf($fp, "%04d-%02d-%02d", $validated_year, $month, $day);

$page_num = $_GET['page_num'];
fprintf($fp, get_permalink(185, true));
// <yes> <report> PHP_FILE_MANIPULATION sjf35u
fprintf($fp, get_permalink($page_num, true));

$old_version = 'archive-1.0.tgz';
$patch = 'archive.bpatch';
$unsafe_patch = $_GET['patch'];
$new_version = $_GET['last_version'];
$validated_new_version = stripslashes($new_version);
$result = xdiff_file_patch_binary($old_version, $patch, 'archive-1.1.tgz');
$result = xdiff_file_patch_binary($old_version, $unsafe_patch, 'archive-1.1.tgz');
// <yes> <report> PHP_FILE_MANIPULATION sdh63k
$result = xdiff_file_patch_binary($old_version, $patch, $new_version);
// <yes> <report> PHP_FILE_MANIPULATION fk3kp9
$result = xdiff_file_patch_binary($old_version, $patch, $validated_new_version);

$str = "uncompressed data";
$unsafe_str = $_GET['data'];
$bz = bzopen("/tmp/foo.bz2", "w");
bzwrite($bz, $str, strlen($str));
// <yes> <report> PHP_FILE_MANIPULATION ghgghj
bzwrite($bz, $unsafe_str, strlen($str));
bzwrite($bz, strlen($unsafe_str));

$file_name= "foo.php";
$unsafe_file_name= $_GET['file_name'];
$path = "/home/sites/php.net/public_html/sandbox/" . $file_name ;
$user_name = "root";
// <yes> <report> PHP_FILE_MANIPULATION yuokgk
chown("/home/sites/php.net/public_html/sandbox/" . $unsafe_file_name, $user_name);
chown($path, $user_name);

$unsafe_cli_arg = $_SERVER['argv'][0];
// <yes> <report> PHP_FILE_MANIPULATION dmjg7s1
fprintf($unsafe_cli_arg);

?>