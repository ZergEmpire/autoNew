<?php
$request = new Zend_XmlRpc_Request();
// +WEB to return
$taint = $request->getRawRequest();

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_RESOURCE hfj0a1
$link = mysql_connect($taint, 'mysql_user', $mysql_password);
// <yes> <report> PHP_INJECTION_RESOURCE zzj021 
$ch = curl_init($taint);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_RESOURCE ztjy23
$db = pg_connect($taint);
// <yes> <report> PHP_INJECTION_RESOURCE tujy88 
apd_set_socket_session_trace($taint,APD_AF_INET,$taint,0);
// <yes> <report> PHP_INJECTION_RESOURCE rs5d8w 
ClassRegistry::init($taint);
// <yes> <report> PHP_INJECTION_RESOURCE ff5d85
Configure::delete($taint);
$http = new HttpSocket('https://www.example.org');
// <yes> <report> PHP_INJECTION_RESOURCE kkksd9
$url = $http->post($taint);
// <yes> <report> PHP_INJECTION_RESOURCE kkksd9
$response = $http->post($url, array('q' => $taint, 'client' => 'safari'));
// <yes> <report> PHP_INJECTION_RESOURCE fndd11 <yes> <report> PHP_SSRF vffsss
$Socket = new \CakeSocket($taint);
// <yes> <report> PHP_INJECTION_RESOURCE mujw71 
Controller::loadModel($taint);
// <yes> <report> PHP_INJECTION_RESOURCE pome32
config($taint, 'config2');
// <yes> <report> PHP_INJECTION_RESOURCE o9je3h
App::uses('MyCustomController', $taint);
// <yes> <report> PHP_INJECTION_RESOURCE je3h42
Cache::delete($taint);
// <yes> <report> PHP_INJECTION_RESOURCE 3e3h42
Plugin::load($taint);
// <yes> <report> PHP_INJECTION_RESOURCE p11ir1
imap_renamemailbox($stream, '{imap.example.com}INBOX.Foo', $taint);
?>