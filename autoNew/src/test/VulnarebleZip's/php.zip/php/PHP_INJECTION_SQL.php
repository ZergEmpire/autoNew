<?php
$select = new Zend_Db_Select($db);
$pos = $_POST['positions'];
$select->from('products');
$select->where($pos);
// <yes> <report> PHP_INJECTION_SQL fja7ks
$stmt = $select->query();
// <yes> <report> PHP_INJECTION_SQL dfgh46
$result = $stmt->fetchAll();

// <yes> <report> PHP_INJECTION_SQL dg4swm
DboSource::execute($stmt, $options = Array, $params = Array);

// <yes> <report> PHP_INJECTION_SQL dt40w1
DboSource::fetchAssociated($model, $stmt, $ids);

// <yes> <report> PHP_INJECTION_SQL sm40w9
DboSource::update($model, $fields, $stmt, $conditions);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL f03824
$result = odbc_exec($conn, $select);

$a = $_GET['a'];
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$odbc_stmt = odbc_prepare($conn, 'CALL myproc(?,?,?)');
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL f03824
$odbc_success = odbc_execute($odbc_stmt, array($a, $b, $c));

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL k0r822
$result = mysql_query($stmt);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL h0w862
$result = mysql_db_query($db, $stmt);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL q0ffw1
$result = pg_query($conn, $stmt);

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL m0hfw2
pg_send_prepare($conn, "my_query", $stmt);

$user = $_POST['username'];
$pass = $_POST['password'];
$unsafe_query  = "SELECT * FROM `users` WHERE user='$user' AND password='$pass';";

$connection = new Connection($config);
// <yes> <report> PHP_INJECTION_SQL eklre2
$connection->delete($stmt, $str);
$driver = new Driver();
// <yes> <report> PHP_INJECTION_SQL 31lre2
$driver->compileQuery($stmt);
$query = new Query();
$query->select($stmt);
// <yes> <report> PHP_INJECTION_SQL fgjmkf
$query->execute();

// <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$mysqli = new mysqli("localhost", "my_user", "my_password", "world");
// <yes> <report> PHP_INJECTION_SQL ejksaa
$mysqli->multi_query($unsafe_query);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL fjwkww
oci_execute($unsafe_query);

$id = $_POST['id'];
// <yes> <report> PHP_INJECTION_SQL pokemo
DB::insert('insert into users (id) values (' + $id + ')');
// <yes> <report> PHP_INJECTION_SQL pokemo
DB::insert('insert into users (id, name) values (?, ?)', [$id, 'Dayle']);

$col = $_POST['column'];
Schema::table('users', function (Blueprint $table) {
    // <yes> <report> PHP_INJECTION_SQL okemon
    $table->dropColumn([$col, 'avatar', 'location']);
    // <yes> <report> PHP_INJECTION_SQL okemon
    $table->dropColumn($col);
});
$table = $_GET['table'];
// <yes> <report> PHP_INJECTION_SQL kemons
Schema::drop($table);

$fields = $_POST['fields'];
$values = $_POST['values'];
$db = Zend_Db::factory("localhost","my_user","my_password","my_db");

$str = "insert into `".$table."` (".$fields.") values (".$values.")";
$db->prepare($str);
// <yes> <report> PHP_INJECTION_SQL fgjmkf
$db->execute();

// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL s0wf61
$result = @mysqli_query($GLOBALS["___mysqli_ston"], $unsafe_query);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$user2 = mysqli_real_escape_string($GLOBALS["___mysqli_ston"], $user);
$query2  = "SELECT * FROM `users` WHERE user='$user2';";
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL sdfhs9
$result2 = @mysqli_query($GLOBALS["___mysqli_ston"], $query2);

$user3 = mysqli::escape_string($user);
$query3  = "SELECT * FROM `users` WHERE user='$user3';";
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL sdfhs9
$result3 = @mysqli_query($GLOBALS["___mysqli_ston"], $query3);

$user4 = $mysqli->escape_string($user);
$query4  = "SELECT * FROM `users` WHERE user='$user4';";
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL sdfhs9
$result4 = @mysqli_query($GLOBALS["___mysqli_ston"], $query4);

$pdo = new PDO("localhost","my_user","my_password","my_db");

$user5 = $pdo->quote($user);
$query5  = "SELECT * FROM `users` WHERE user='$user5';";
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL sdfhs9
$result5 = @mysqli_query($GLOBALS["___mysqli_ston"], $query5);

$user5 = $pdo->quote($user);
$query5  = "SELECT * FROM `users` WHERE user='$user5';";
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_INJECTION_SQL sdfhs9
$result5 = @mysqli_query($GLOBALS["___mysqli_ston"], $query5);

$calories = $_POST['calories'];
$colour = $_POST['colour'];

$sth = $pdo->prepare('SELECT name FROM fruit
    WHERE calories < :calories AND colour LIKE :colour');
$sth->bindParam(':calories', $calories, PDO::PARAM_INT);
$sth->bindValue(':colour', "%{$colour}%");
// <yes> <report> PHP_INJECTION_SQL fgh46y
$sth->execute();

$sth2 = $pdo->prepare('SELECT name FROM fruit
    WHERE calories < :calories AND colour LIKE :colour');
// <yes> <report> PHP_INJECTION_SQL ejksaa
$sth2->execute(array(':calories' => $calories, ':colour' => $colour));
// <yes> <report> PHP_INJECTION_SQL ejksaa
$pdo->exec($unsafe_query);

$sth4 = $pdo->prepare('SELECT name FROM fruit WHERE calories < 150');
$sth4->execute();

$sth5 = $pdo->prepare("SELECT * FROM `users` WHERE user='$user';");
// <yes> <report> PHP_INJECTION_SQL fgjmkf
$sth5->execute();

use Yii;
use yii\web\Controller;

class VulnerabilityController extends Controller
{
    public function actionSql11()
    {
        $conn = new \PDO(Yii::$app->db->dsn, Yii::$app->db->username, Yii::$app->db->password);
        // <yes> <report> PHP_INJECTION_SQL ejksaa
        $stmt = $conn->query("SELECT * FROM user where id = {$_GET['id']}");
        // <yes> <report> PHP_INJECTION_SQL dfgh46
        return json_encode($stmt->fetchAll(), JSON_PRETTY_PRINT);
    }

    public function actionSql12()
    {
        $id = $_GET['id'];
        $conn = new \PDO(Yii::$app->db->dsn, Yii::$app->db->username, Yii::$app->db->password);
        // <yes> <report> PHP_INJECTION_SQL ejksaa
        $stmt = $conn->query("SELECT * FROM user where id = $id");
        // <yes> <report> PHP_INJECTION_SQL dfgh46
        return json_encode($stmt->fetchAll(), JSON_PRETTY_PRINT);
    }

    public function actionSql13()
    {
        $conn = new \PDO(Yii::$app->db->dsn, Yii::$app->db->username, Yii::$app->db->password);
        // <yes> <report> PHP_INJECTION_SQL ejksaa
        $stmt = $conn->query("SELECT * FROM user where id = " . $_GET['id']);
        // <yes> <report> PHP_INJECTION_SQL dfgh46
        return json_encode($stmt->fetchAll(), JSON_PRETTY_PRINT);
    }

    public function actionSql2()
    {
        $conn = new \PDO(Yii::$app->db->dsn, Yii::$app->db->username, Yii::$app->db->password);
        // <yes> <report> PHP_INJECTION_SQL ejksaa
        $stmt = $conn->query("SELECT * FROM user where id = " . Yii::$app->request->get('id', 'null'));
        // <yes> <report> PHP_INJECTION_SQL dfgh46
        return json_encode($stmt->fetchAll(), JSON_PRETTY_PRINT);
    }

    public function actionSql4()
    {
        $id = $_GET['id'];
        $users = Yii::$app->getDb()->createCommand(
            "SELECT * FROM user where id = $id" // <yes> <report> PHP_INJECTION_SQL yiildf
        )->queryAll();
        return json_encode($users, JSON_PRETTY_PRINT);
    }

    public function actionSql5()
    {
        $id = Yii::$app->request->get('id');
        $users = Yii::$app->getDb()->createCommand(
            "SELECT * FROM user where id = $id" // <yes> <report> PHP_INJECTION_SQL yiildf
        )->queryAll();
        return json_encode($users, JSON_PRETTY_PRINT);
    }

    public function actionSql7()
    {
        $id = $_GET['id'];
        $users = (new \yii\db\Query())
            ->select(['id', 'email'])
            ->from('user')
            ->where("id = $id") // <yes> <report> PHP_INJECTION_SQL yiildf
            ->all();
        return json_encode($users, JSON_PRETTY_PRINT);
    }

    public function actionSql8()
    {
        $id = Yii::$app->request->get('id');
        $users = (new \yii\db\Query())
            ->select(['id', 'email'])
            ->from('user')
            ->where("id = $id") // <yes> <report> PHP_INJECTION_SQL yiildf
            ->all();
        return json_encode($users, JSON_PRETTY_PRINT);
    }
 }
?>