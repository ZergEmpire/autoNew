<?php
// <yes> <report> PHP_CRYPTO_KEY_EMPTY 8428ae
$zfe = new Zend_Filter_Encrypt('');
$zo = new Zend_OpenId();
// <yes> <report> PHP_CRYPTO_KEY_EMPTY eea399
$zo->createDhKey('','','');
// <yes> <report> PHP_CRYPTO_KEY_EMPTY 028116
$encryption_key = '';
// <yes> <report> PHP_CRYPTO_KEY_EMPTY 028028
$something_secret_key_something = '';
// <yes> <report> PHP_CRYPTO_KEY_EMPTY 028290 <yes> <report> PHP_PASSWORD_EMPTY 026527
$class->$pass_phrase = '';
// <yes> <report> PHP_CRYPTO_KEY_EMPTY 028202 <yes> <report> PHP_PASSWORD_EMPTY 026527
$class->$something_passphrase_something = '';
?>