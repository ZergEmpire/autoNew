<?php
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report> PHP_COOKIE_NOT_OVER_SSL ffadd5 
setcookie('','','','','',false);
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report> PHP_COOKIE_NOT_OVER_SSL 528a3b
setcookie('','','','','');
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659 <yes> <report> PHP_COOKIE_NOT_OVER_SSL d8fa8f
session_set_cookie_params('','','',false);
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL fee34a <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659
session_set_cookie_params('','','');
$cc = new CookieComponent();
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL 030193
$cc->secure = true;
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL 030193
$cc->secure = 'true';
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL z1d3cd
Configure::write('Session', [
    'defaults' => 'php',
    'ini' => [
        'session.cookie_secure' => false
    ]
]);
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL 44wqkm
$cookie = (new Cookie('remember_me'))
    ->withValue('1')
    ->withExpiry(new DateTime('+1 year'))
    ->withPath('/path')
    ->withDomain('example.com')
    ->withSecure(false)
    ->withHttpOnly(true);
class WebApp {
    function workWithCookie() {
        // <yes> <report> PHP_COOKIE_NOT_OVER_SSL 1464k1
        $this->Cookie->config('secure', false);
        // <yes> <report> PHP_COOKIE_NOT_OVER_SSL 0464k1
        $this->Cookie->config([
            'path' => '/path',
            'secure' => false
        ]);
        // <yes> <report> PHP_COOKIE_NOT_OVER_SSL 222mfn
        $this->Cookie->secure = false;
    }
    function workWithResponse() {
        $response = new Response();
        // <yes> <report> PHP_COOKIE_NOT_OVER_SSL 096qkm
        $response = $response->withExpiredCookie('remember_me', ['secure' => false]);
        // <yes> <report> PHP_COOKIE_NOT_OVER_SSL 846qkm
        $this->response->withExpiredCookie('remember_me', ['secure' => false]);
    }
}
?>