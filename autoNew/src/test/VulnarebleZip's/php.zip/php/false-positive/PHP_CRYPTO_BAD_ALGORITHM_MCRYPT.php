<?php
mcrypt_get_iv_size(desede);
?>