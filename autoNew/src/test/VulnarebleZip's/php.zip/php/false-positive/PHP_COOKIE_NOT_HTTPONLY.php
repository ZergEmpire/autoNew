<?php
setcookie('','','','','',true,true);
session_set_cookie_params('','','','',true);
ini_set('session.cookie_httponly','On');
ini_set('session.cookie_httponly','1');
ini_set('session.cookie_secure','On');
ini_set('session.cookie_secure','1');
?>