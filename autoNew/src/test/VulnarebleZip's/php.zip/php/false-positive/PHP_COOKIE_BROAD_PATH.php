<?php
setcookie('','','','/abc/','',true,true);
session_set_cookie_params('','/abc/','','',true);
ini_set('session.cookie_path', '/abc/');
?>