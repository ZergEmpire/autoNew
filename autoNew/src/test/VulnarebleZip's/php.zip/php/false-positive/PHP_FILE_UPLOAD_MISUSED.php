<?php
ini_set('file_uploads','Off');
?>