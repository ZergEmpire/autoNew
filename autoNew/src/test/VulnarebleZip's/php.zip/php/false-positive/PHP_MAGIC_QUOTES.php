<?php
ini_set('magic_quotes_sybase','Off');
ini_set('magic_quotes_gpc','Off');
ini_set('magic_quotes_runtime','Off');
?>