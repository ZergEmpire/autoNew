<?php
ini_set('session.use_trans_sid','Off');
?>