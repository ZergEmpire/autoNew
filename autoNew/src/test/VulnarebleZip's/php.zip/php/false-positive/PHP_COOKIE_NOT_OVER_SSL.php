<?php
setcookie('','','','','',true,true);
session_set_cookie_params('','','','',true);
$cc = new CookieComponent();
$cc->secure = false;
$cc->secure = 'false';
?>