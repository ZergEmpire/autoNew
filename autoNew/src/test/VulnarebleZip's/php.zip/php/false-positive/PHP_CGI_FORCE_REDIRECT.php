<?php
ini_set('cgi.force_redirect','On');
?>