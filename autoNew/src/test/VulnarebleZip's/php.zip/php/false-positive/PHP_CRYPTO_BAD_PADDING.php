<?php
openssl_encrypt('', '', '');
openssl_encrypt('', '', '', OPENSSL_PKCS1_PADDING);
openssl_encrypt('', '', '', OPENSSL_PKCS1_OAEP_PADDING);
?>