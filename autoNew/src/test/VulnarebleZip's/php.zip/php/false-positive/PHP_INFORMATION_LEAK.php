<?php
$conf = new Configure();
$conf->debug = 0;
$conf->debug = "0";
$ec = new EmailComponent();
$ec->_debug = true;
$ec->_debug = "true";
$ds = new DataSource();
$ds->fullDebug = false;
$ds->fullDebug = "false";
?>