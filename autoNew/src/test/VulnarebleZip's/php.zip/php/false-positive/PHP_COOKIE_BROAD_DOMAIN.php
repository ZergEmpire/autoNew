<?php
ini_set('session.cookie_domain', '.abc.abc.abc');
?>