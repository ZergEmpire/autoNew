<?php
ini_set('register_globals','Off');
?>