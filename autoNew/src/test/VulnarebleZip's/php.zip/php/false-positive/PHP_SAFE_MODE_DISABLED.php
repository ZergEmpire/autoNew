<?php
ini_set('safe_mode','On');
?>