<?php
extract($some_array,'EXTR_SKIP');
?>