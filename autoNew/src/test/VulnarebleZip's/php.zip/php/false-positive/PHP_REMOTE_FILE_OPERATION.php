<?php
ini_set('allow_url_fopen','Off');
ini_set('allow_url_include','Off');
?>