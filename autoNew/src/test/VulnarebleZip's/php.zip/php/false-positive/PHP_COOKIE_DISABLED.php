<?php
ini_set('session.use_cookies','On');
?>