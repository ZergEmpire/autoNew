<?php
ini_set('expose_php','Off');
?>