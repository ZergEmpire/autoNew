<?php
ini_set('session.use_trans_sid','0');
$cc = new CookieComponent();
$cc->time = 0;
$cc->time = 'now';
?>