<?php
// <yes> <report> PHP_CRYPTO_BAD_HASH f0b5ff
md5_file();
// <yes> <report> PHP_CRYPTO_BAD_HASH 2d5311
hash_hmac('md2');
// <yes> <report> PHP_CRYPTO_BAD_HASH 2d5311
hash_pbkdf2('md2', $password, $salt, $iterations, 20);
$s = new Security();
// <yes> <report> PHP_CRYPTO_BAD_HASH 6524d5
$s->hash('sha1');
// <yes> <report> PHP_CRYPTO_BAD_HASH 6524d5
$s->hash('');
// <yes> <report> PHP_CRYPTO_BAD_HASH 6524d5
$s->hash(null);
// <yes> <report> PHP_CRYPTO_BAD_HASH 8759b6
$s->setHash('');
// <yes> <report> PHP_CRYPTO_BAD_HASH 030149
$s->hashType = 'md5';
// <yes> <report> PHP_CRYPTO_BAD_HASH 030149
$s->hashType = '';
// <yes> <report> PHP_CRYPTO_BAD_HASH 030149
$s->hashType = null;
// <yes> <report> PHP_CRYPTO_BAD_HASH 23b4b4
mhash_get_block_size(MHASH_MD2);
// <yes> <report> PHP_CRYPTO_BAD_HASH 23b4b4
mhash_get_hash_name(16);
// <yes> <report> PHP_CRYPTO_BAD_HASH 23b4b4
mhash(257);
// <yes> <report> PHP_CRYPTO_BAD_HASH e20271
openssl_sign('','','');
// <yes> <report> PHP_CRYPTO_BAD_HASH e20271
openssl_verify('','','',OPENSSL_ALGO_SHA1);
// <yes> <report> PHP_CRYPTO_BAD_HASH e20271
openssl_verify('','','',SHA);
// <yes> <report> PHP_CRYPTO_BAD_HASH bdjtkd
$generated_key = openssl_pbkdf2($password, $salt, $keyLength, $iterations, 'sha');
?>