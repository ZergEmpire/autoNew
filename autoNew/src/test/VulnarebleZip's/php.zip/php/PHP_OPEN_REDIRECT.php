<?php
$request = new Zend_XmlRpc_Request();
// +WEB to return
$taint = $request->getRawRequest();
// <yes> <report> PHP_OPEN_REDIRECT rjdfy2 
Zend_OpenId::redirect($taint);
$client = new Zend_Soap_Client($args);
// <yes> <report> PHP_OPEN_REDIRECT 568bgt 
$client->setLocation($taint);
// <yes> <report> PHP_OPEN_REDIRECT fff7bq 
$client = new Zend_XmlRpc_Client($taint);
// <yes> <report> PHP_OPEN_REDIRECT 3j24be
header('Location: ' . $taint);
// <yes> <report> PHP_OPEN_REDIRECT p11op1
http_redirect($taint, array("name" => "value"), true, HTTP_REDIRECT_PERM);
// +WEB to return 
$bad_value = file("php://input");
// <yes> <report> PHP_OPEN_REDIRECT p11op1
http_redirect($bad_value, array("name" => "value"), true, HTTP_REDIRECT_PERM);

?>
