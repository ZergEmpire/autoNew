<?php
// <yes> <report> PHP_COOKIE_DISABLED b15ebf
ini_set('session.use_cookies','Off');
?>