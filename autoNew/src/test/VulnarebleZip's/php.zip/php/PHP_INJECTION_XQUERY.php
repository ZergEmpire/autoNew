<?php
$HttpSocket = new HttpSocket();
// +WEB to return
$store = $HttpSocket->post('https://www.google.com/search', 'q=cakephp');

$xquery = new XQueryProcessor(); 
// <yes> <report> PHP_INJECTION_XQUERY trp0dq
$xquery->importQuery($store);
?>