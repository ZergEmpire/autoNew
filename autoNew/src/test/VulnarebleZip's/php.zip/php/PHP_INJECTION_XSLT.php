<?php

$xml = new DOMDocument;
$xml->load('local.xml');

$xsl = new DOMDocument;
// <yes> <report> PHP_PATH_MANIPULATION duuudm
$xsl->load($_GET['key']);

$processor = new XSLTProcessor;
$processor->registerPHPFunctions();
// <yes> <report> PHP_INJECTION_XSLT 5fp0ds
$processor->importStyleSheet($xsl);

$xh = xslt_create();
// <yes> <report> PHP_INJECTION_XSLT 12khqs
$result = xslt_process($xh, 'sample.xml', $xsl);
?>