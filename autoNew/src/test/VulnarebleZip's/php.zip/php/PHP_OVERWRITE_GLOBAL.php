<?php
// <yes> <report> PHP_OVERWRITE_GLOBAL a442b1
mb_parse_str('');
// <yes> <report> PHP_OVERWRITE_GLOBAL 027446
extract($some_array);
// <yes> <report> PHP_OVERWRITE_GLOBAL 027446
extract($some_array, EXTR_OVERWRITE);
$web = $_SERVER['HTTP_smth'];
// <yes> <report> PHP_OVERWRITE_GLOBAL bdksls
mb_parse_str($web);
// <yes> <report> PHP_OVERWRITE_GLOBAL gwlmss
extract($web, EXTR_PREFIX_SAME, "wddx");
?>