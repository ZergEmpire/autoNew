<?php
$HttpSocket = new HttpSocket();
// +WEB to return
$pwd = $HttpSocket->put('https://www.google.com/search', 'q=cakephp');
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PASSWORD_MANAGEMENT ft108f
mysql_connect('','',$pwd);
$pwd_decoded = base64_decode($pwd);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <no> <report>
mysql_connect('','',base64_decode($pwd));
?>