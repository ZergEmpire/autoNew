<?php
// +FILE_SYSTEM to return
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$filter = file('https://www.base_dn_example.com/');
// <yes> <report> PHP_INJECTION_LDAP p11il1
ldap_search($link_id, $base_dn, $filter, $atributes);
?>