<?php
$date2 = "2011-10-12";
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000114
if ($date1->diff("Mon, 15 Aug 05 15:52:01 +0000") >= 10)
	{ echo "hello";} 
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000114
if ( ($interval2 = $date1->diff($date2)) == 0)
	{ echo "hello";}
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000014
if ($date4 == strtotime("2008-09-01"))
	{ echo "hello";}
date_diff($date3, $date4);
// <no> <report>
date("l, d-M-Y H:i:s T", 1388516401);
// <no> <report>
date_diff(123);
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000016
time() == 123;
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000016
microtime() <= 123.2;
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000016
date("l, d-M-Y H:i:s T") < 1234;
// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000016
microtime() >= 123.2;

// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000014
if ($date = strtotime("2018-18-12")) {
	echo "timebomb!";}

// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000014
while ($date = strtotime("2018-18-12")) {
	echo "timebomb!";}

do {
	echo "timebomb!";

// <yes> <report> PHP_BACKDOOR_TIMEBOMB 000014
} while ($date = strtotime("2018-18-12"));

?>