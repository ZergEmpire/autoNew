<?php
// <yes> <report> PHP_COOKIE_PERSISTENT 5acf80 <yes> <report> PHP_COOKIE_NOT_OVER_SSL 528a3b <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1
setcookie('','',$a);
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report> PHP_COOKIE_NOT_OVER_SSL 528a3b <yes> <report> PHP_COOKIE_PERSISTENT 5acf80
setcookie('','',1);
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL fee34a <yes> <report> PHP_COOKIE_PERSISTENT 871d3d <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659
session_set_cookie_params($a);
// <yes> <report> PHP_COOKIE_NOT_OVER_SSL fee34a <yes> <report> PHP_COOKIE_NOT_HTTPONLY 4c7659 <yes> <report> PHP_COOKIE_PERSISTENT 871d3d
session_set_cookie_params(1);
// <yes> <report> PHP_COOKIE_PERSISTENT d83aaf
ini_set('session.cookie_lifetime','12');
$cc = new CookieComponent();
// <yes> <report> PHP_COOKIE_PERSISTENT 030238
$cc->time = 1;
// <yes> <report> PHP_COOKIE_PERSISTENT 030238
$cc->time = 'not now';
// <yes> <report> PHP_COOKIE_PERSISTENT b1d3cd
Configure::write('Session', [
    'defaults' => 'php',
    'ini' => [
        'session.cookie_lifetime' => 1800
    ]
]);
// <yes> <report> PHP_COOKIE_PERSISTENT b1d3cd
Configure::write('Session', [
    'defaults' => 'php',
    'cookie' => 'my_app',
    'timeout' => 4320 // 3 days
]);
// <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report>  PHP_COOKIE_PERSISTENT lfkdcd
setcookie("TestCookie", $value, time()+157680000, "/app/", "forum.example.com", 1); //157680000 = 5*365*24*3600
class WebApp {
    function workWithCookie() {
        // <yes> <report> PHP_COOKIE_PERSISTENT 2222fn
        $this->Cookie->time = 3600;
    }
}
// <yes> <report> PHP_COOKIE_PERSISTENT 2002fn
Cookie::queue(Cookie::make('name', 'value', 9500));
// <yes> <report> PHP_COOKIE_PERSISTENT 2002fn
Cookie::queue('name', 'value', 9500);
// <no> <report> PHP_COOKIE_PERSISTENT
Cookie::queue('name', 'value', 90);
// <yes> <report> PHP_COOKIE_PERSISTENT 5acf80 <yes> <report> PHP_COOKIE_NOT_HTTPONLY e8c7e1 <yes> <report> PHP_COOKIE_NOT_OVER_SSL 528a3b
cookie('name', 'value', 65656);
?>