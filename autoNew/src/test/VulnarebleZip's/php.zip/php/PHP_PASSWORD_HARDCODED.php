<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PASSWORD_HARDCODED d7100f
mysql_connect('','',1);
$adoc = new ADOConnection();
// <yes> <report> PHP_PASSWORD_HARDCODED d77fcf
$adoc->Connect('','','abc');
$zfe = new Zend_Filter_Encrypt();
// <yes> <report> PHP_PASSWORD_HARDCODED 669471
$zfe->setPassphrase(true);
$zsc = new Zend_Soap_Client();
// <yes> <report> PHP_PASSWORD_HARDCODED b6a68b
$zsc->setHttpPassword(1.0);
// <yes> <report> PHP_PASSWORD_HARDCODED 026790
$somethingpasswordsomething = 'abc';
// <yes> <report> PHP_PASSWORD_HARDCODED 02679t
$somethingpasswordsomething = 'a bc';
// <yes> <report> PHP_PASSWORD_HARDCODED 026882
$password = 1;
// <yes> <report> PHP_PASSWORD_HARDCODED 026972
$class->$somethingpasswordsomething = 1.0;
// <yes> <report> PHP_PASSWORD_HARDCODED 027064
$class->$password = true;
// <yes> <report> PHP_PASSWORD_HARDCODED 027157 <yes> <report> PHP_BACKDOOR_SPECIAL_ACCOUNT 000010
$somethingpasswordsomething == 'abc';
// <yes> <report> PHP_PASSWORD_HARDCODED 02715t <yes> <report> PHP_BACKDOOR_SPECIAL_ACCOUNT 000010
$somethingpasswordsomething == 'a bc';
// <yes> <report> PHP_PASSWORD_HARDCODED 027221
$truth = (12345 != $password);
// <no> <report>
$truth = (12345 != $password--);
// <no> <report>
$truth = (12345 <= $password);
// <yes> <report> PHP_PASSWORD_HARDCODED 027169
1.0 != $class->$somethingpasswordsomething;
// <yes> <report> PHP_PASSWORD_HARDCODED 027233
$class->$password == true;
// <no> <report>
$password = false;
// <no> <report>
$mypassword = true;
// <no> <report>
$newPassword = clone $password;
array(
    'user' => 'admin',
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => 'hardcoded'
);
array(
    'user' => 'admin',
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => 'hard coded'
);
$http = new Client([
    'host' => 'api.example.com',
    'scheme' => 'https',
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'auth' => ['username' => 'mark', 'password' => 'testing']
]);
$http = new Client([
    'host' => 'api.example.com',
    'scheme' => 'https',
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'auth' => ['username' => 'mark', 'password' => 'test ing']
]);
// <yes> <report> PHP_PASSWORD_HARDCODED fhh567
$mbox = imap_open("{localhost:143}INBOX", "user_id", "mypwd");
// <yes> <report> PHP_PASSWORD_HARDCODED gfwjkd
$ldapbind = ldap_bind($ldapconn, $ldaprdn, "ldappass");


array(
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => '$%#$x%x%ADSFBNYI*&WBV$i',
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => '6574573645',
);
array(
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => '$%#$x%x%AD SFBNYI*&WBV$i',
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => '65745 73645',
);
$user = $usersAPIController->post([
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => "$%#$x%x%ADSFBNYI*&WBV$i",
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => "6574573645",
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => '6574573645',
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => '$%#$x%x%ADSFBNYI*&WBV$i',
]);

$user = $usersAPIController->post([
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => "$%#$x%x%A DSFBNYI*&WBV$i",
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => "65745 73645",
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => '65745 73645',
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => '$%#$x%x%ADS FBNYI*&WBV$i',
]);

$email_array = array(
    // No report
    'password' => SMTP_PWORD,
    // No report
    'password' => $SMTP_PWORD,
    // <yes> <report> PHP_PASSWORD_HARDCODED 027333
    'password' => 'SMTP_PWORD',
    // <yes> <report> PHP_PASSWORD_HARDCODED 02733t
    'password' => 'SMTP PWORD',
        'timeout' => '30',
    'client' => WEB_DOMAIN
);

class AuthorFixture extends CakeTestFixture {

    public $records = array(
        // <yes> <report> PHP_PASSWORD_HARDCODED 127333
        array('user' => 'mariano', 'password' => '5f4dcc3b5aa765d61d8327deb882cf99', 'created' => '2007-03-17 01:16:23', 'updated' => '2007-03-17 01:18:31'),
        // <yes> <report> PHP_PASSWORD_HARDCODED 12733t
        array('user' => 'mariano', 'password' => '5f4dcc3b5aa765d 61d8327deb882cf99', 'created' => '2007-03-17 01:16:23', 'updated' => '2007-03-17 01:18:31'),
        // No report
        array('user' => 'mariano', 'password' => SMTP_PWORD, 'created' => '2007-03-17 01:16:23', 'updated' => '2007-03-17 01:18:31'),
    );

    public function testPerformIdentityCheck()
        {
            // No report
            $passwordString = \Magento\TestFramework\Bootstrap::ADMIN_PASSWORD;
            // <yes> <report> PHP_PASSWORD_HARDCODED 026790
            $somethingpasswordsomething = 'abc';
            // <yes> <report> PHP_PASSWORD_HARDCODED 02679t
            $somethingpasswordsomething = 'ab c';
        }
}
$desc = new \ProtocolBuffers\DescriptorBuilder();
// <yes> <report> PHP_PASSWORD_HARDCODED fyyh13
$desc->addField(1, new \ProtocolBuffers\FieldDescriptor(array(
  "type"     => \ProtocolBuffers::TYPE_STRING,
  "name"     => "password",
  "required" => true,
  "optional" => false,
  "repeated" => false,
  "packable" => false,
  "default"  => "svsdv",
)));
// <yes> <report> PHP_PASSWORD_HARDCODED fyyh1t
$desc->addField(1, new \ProtocolBuffers\FieldDescriptor(array(
  "type"     => \ProtocolBuffers::TYPE_STRING,
  "name"     => "password",
  "required" => true,
  "optional" => false,
  "repeated" => false,
  "packable" => false,
  "default"  => "svs dv",
)));
// <yes> <report> PHP_PASSWORD_HARDCODED 027hdr
switch ($password) {
    case 'string1':
        return 'rio';
    case 'string2':
        return 'kio';
}
?>