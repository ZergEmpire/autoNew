<?php
$request = new Zend_XmlRpc_Request();
// +WEB to return
$res = $request->getRawRequest();
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_SETTING_MANIPULATION hh97c7
pg_copy_to($db, $res);
// <yes> <report> PHP_SETTING_MANIPULATION kk93c7
putenv($res);
// <yes> <report> PHP_SETTING_MANIPULATION km99cc
Configure::store('user_1234', 'default', $res);
// <yes> <report> PHP_SETTING_MANIPULATION kee9c8
Configure::write('Company', [
    'name' => $res,
    'slogan' => 'Pizza for your body and soul'
]);
// <yes> <report> PHP_SETTING_MANIPULATION ukdd76
$dir = new Folder('/path/to/folder', true, $res);
// <yes> <report> PHP_SETTING_MANIPULATION rrdd88
$dir->chmod('/path/to/folder', 0755, true, $res);
// <yes> <report> PHP_SETTING_MANIPULATION trde80
mkdir("/path/to/my/dir", $res);
// <no> <report>
Something::create("", $res);
// <yes> <report> PHP_SETTING_MANIPULATION keg9c3
$found[] = Folder::findRecursive($res, $sort);
// <yes> <report> PHP_SETTING_MANIPULATION keg9c0
DboSource::reconnect($res);
// <yes> <report> PHP_SETTING_MANIPULATION jenrj3
Cache::clear(true, $res);
$component = new AclComponent();
// <yes> <report> PHP_SETTING_MANIPULATION ooek32
$component->allow($res);
$auth = new AuthComponent();
// <yes> <report> PHP_SETTING_MANIPULATION pwkrmm
$auth->allow($res);
// <yes> <report> PHP_SETTING_MANIPULATION p11sm1
imap_setacl($domains , "user/bad.goat/".$Maildir , $res, "all_rights");
// No report
imap_setacl($domains , "user/bad.goat/".$Maildir , $not_tainted, "all_rights");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_SETTING_MANIPULATION p11sm2
oci_set_edition($res);
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
oci_set_edition($not_tainted);
?>