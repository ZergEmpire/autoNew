<?php
// <yes> <report> PHP_COOKIE_RELIANCE hndfgj
if (isset($HTTP_COOKIE_VARS['sessionID']) && $HTTP_COOKIE_VARS['sessionID'] != '') {}
// <yes> <report> PHP_COOKIE_RELIANCE hndfgj
if ($_COOKIE['user_agent'] != $_SERVER['HTTP_USER_AGENT']) {}

$cookie_vars = $HTTP_COOKIE_VARS['sessionID'];
$cookie = $_COOKIE['user_agent'];
// <yes> <report> PHP_COOKIE_RELIANCE hndfgj
if (isset($cookie_vars) && $cookie_vars != '') {}
// <yes> <report> PHP_COOKIE_RELIANCE hndfgj
if (isset($cookie_vars)) {}
// <yes> <report> PHP_COOKIE_RELIANCE hndfgj
if ($cookie != $_SERVER['HTTP_USER_AGENT']) {}
?>
