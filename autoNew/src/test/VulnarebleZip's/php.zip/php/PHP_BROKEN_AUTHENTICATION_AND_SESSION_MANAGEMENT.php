<?php
// <yes> <report> PHP_BROKEN_AUTHENTICATION_AND_SESSION_MANAGEMENT 5ffadf
ini_set('session.use_trans_sid','On');
?>