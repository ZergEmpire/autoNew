<?php

// <yes> <report> PHP_HTTP_USAGE 5d2d45
curl_setopt ( $Curl, CURLOPT_SSL_VERIFYHOST, 0 );
// <yes> <report> PHP_HTTP_USAGE 6442ad
curl_setopt ( $Curl, CURLOPT_SSL_VERIFYPEER, false );
// <yes> <report> PHP_HTTP_USAGE b7857f
curl_setopt ( $Curl, CURLOPT_SSL_VERIFYHOST, false );
