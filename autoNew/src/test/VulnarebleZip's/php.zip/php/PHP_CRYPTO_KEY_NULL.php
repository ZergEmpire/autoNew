<?php
// <yes> <report> PHP_CRYPTO_KEY_NULL 98997d
$zfe = new Zend_Filter_Encrypt('null');
$zo = new Zend_OpenId();
// <yes> <report> PHP_CRYPTO_KEY_NULL 20a377
$zo->createDhKey('','',null);
// <yes> <report> PHP_CRYPTO_KEY_NULL 027683
$encryption_key = null;
// <yes> <report> PHP_CRYPTO_KEY_NULL 027595
$something_secret_key_something = null;
// <yes> <report> PHP_CRYPTO_KEY_NULL 027857 <yes> <report> PHP_PASSWORD_NULL 026094
$class->$pass_phrase = null;
// <yes> <report> PHP_CRYPTO_KEY_NULL 027769 <yes> <report> PHP_PASSWORD_NULL 026094
$class->$something_passphrase_something = null;
?>