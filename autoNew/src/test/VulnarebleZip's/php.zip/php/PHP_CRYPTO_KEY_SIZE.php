<?php
// <yes> <report> PHP_CRYPTO_KEY_SIZE p21ks1
openssl_pbkdf2($password, $salt, 64, 20000, sha1);
// No report
openssl_pbkdf2($password, $salt, 256, 20000, sha1);
?>