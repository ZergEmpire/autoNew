<?php
$dc = new DboSource();
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL 69ec83
$dc->logQuery('GET');
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL 76c54a
ini_set('display_errors','On');
$p = xml_parser_create();
// +SYSTEM_INFO to return
$err = xml_error_string(xml_get_error_code($p));
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL vvc57a
fprintf($fp, "%d", $err);

// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL rrc57t
prnMsg($ErrorMessage . '<br />' . xml_error_string(xml_get_error_code($p)), 'error', _('Database Error') . ' ' . DB_error_no($db_oc));

$file = new SplFileObject('file.csv', 'w');
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL yhc54t
$file->fputcsv($err);

// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL phc50t
LogError($err);

// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL hhpu8m
CakeLog::write($act, $err);

// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL hs5u8w
Debugger::dump($err);

// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL phc50t
error_log($err, 0);

$logger = new Zend_Log();
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL rtc64t
$logger->log($err, Zend_Log::INFO);
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL 3tc64t
$exc = new MissingHelperException($err);

try {
    Anchor::setup();
} catch (Exception $e) {
    if (ini_get('display_errors') != "1") {
        echo "<h1>Something went wrong, please notify the owner of the site</h1>";
    } else {
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL sys00li2
        Error::exception($e);
    }
    // <yes> <report> PHP_INFORMATION_LEAK_INTERNAL sys00li2
    Error::log($e);
    die();
}

try {
    echo("message");
} catch (PDOException $e) {
// <yes> <report> PHP_INFORMATION_LEAK_INTERNAL sys00li3
    throw new ErrorException($e->getMessage());
}
?>
