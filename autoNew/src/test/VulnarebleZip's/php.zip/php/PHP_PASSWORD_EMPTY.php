<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PASSWORD_EMPTY df7d59
mysql_connect('','','');
$adoc = new ADOConnection();
// <yes> <report> PHP_PASSWORD_EMPTY 9f6f33
$adoc->Connect('','','');
$zfe = new Zend_Filter_Encrypt();
// <yes> <report> PHP_PASSWORD_EMPTY 338bbd
$zfe->setPassphrase('');
$zsc = new Zend_Soap_Client();
// <yes> <report> PHP_PASSWORD_EMPTY 9063aa
$zsc->setHttpPassword('');
// <yes> <report> PHP_PASSWORD_EMPTY 026441
$password = '';
// <yes> <report> PHP_PASSWORD_EMPTY 026353
$somethingpasswordsomething = '';
// <yes> <report> PHP_PASSWORD_EMPTY 026615
$class->$password = '';
// <yes> <report> PHP_PASSWORD_EMPTY 026527
$class->$somethingpasswordsomething = '';
array(
	'user' => 'admin',
	// <yes> <report> PHP_PASSWORD_EMPTY 025333
	'password' => ''
);
// <yes> <report> PHP_PASSWORD_EMPTY hhhd50
$mbox = imap_open("{localhost:143}INBOX", "user_id", "");
// <yes> <report> PHP_PASSWORD_EMPTY fdkjss 
$ldapbind = ldap_bind($ldapconn, $ldaprdn, "");

array(
// <yes> <report> PHP_PASSWORD_EMPTY 025333
	'password' => '',
);
$user = $usersAPIController->post([
                // <yes> <report> PHP_PASSWORD_EMPTY 025333
                'password' => " ",
                // <yes> <report> PHP_PASSWORD_EMPTY 025333
                'password' => "",
                // <yes> <report> PHP_PASSWORD_EMPTY 025333
                'password' => ' ',
            ]);
$desc = new \ProtocolBuffers\DescriptorBuilder();
// <yes> <report> PHP_PASSWORD_EMPTY fddjss
$desc->addField(1, new \ProtocolBuffers\FieldDescriptor(array(
  "type"     => \ProtocolBuffers::TYPE_STRING,
  "name"     => "password",
  "required" => true,
  "optional" => false,
  "repeated" => false,
  "packable" => false,
  "default"  => "",
)));
?>