<?php
// <yes> <report> PHP_HARDCODED_ABSOLUTE_PATH adhrwq
$path = 'c:/windows/system32/';
// <yes> <report> PHP_HARDCODED_ABSOLUTE_PATH adhrwq
$path = "D:/windows/system32/";
?>
