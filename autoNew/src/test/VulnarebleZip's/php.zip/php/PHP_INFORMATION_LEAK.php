 <?php
$zb = new Zend_Debug();
// <yes> <report> PHP_INFORMATION_LEAK 76e5cc
$zb->dump();
$conf = new Configure();
// <yes> <report> PHP_INFORMATION_LEAK 030105
$conf->debug = 1;
// <yes> <report> PHP_INFORMATION_LEAK 030105
$conf->debug = "1";
$sm = new Smarty();
// <yes> <report> PHP_INFORMATION_LEAK 029832
$sm->debugging = true;
$ec = new EmailComponent();
// <yes> <report> PHP_INFORMATION_LEAK 030282
$ec->_debug = false;
// <yes> <report> PHP_INFORMATION_LEAK 030282
$ec->_debug = "false";
$ds = new DataSource();
// <yes> <report> PHP_INFORMATION_LEAK 030326
$ds->fullDebug = true;
// <yes> <report> PHP_INFORMATION_LEAK 030326
$ds->fullDebug = "true";
// <yes> <report> PHP_INFORMATION_LEAK 31d3cd
Configure::write('debug', 2); //для cakephp 2.x (нужно, чтобы константа была равна нулю)
// <yes> <report> PHP_INFORMATION_LEAK 31d3cd
Configure::write('debug', true); //для cakephp 3.x
// <no> <report>
Configure::write('debug', 0);
?>