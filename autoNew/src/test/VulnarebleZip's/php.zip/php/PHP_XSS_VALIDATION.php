<?php
$socket = new CakeSocket( array('host'=>$ip,'port'=>$port));
$string = $socket->read();
$upload = new Zend_File_Transfer();
$files = $upload->getFileInfo();
// +POOR_VALIDATION to return
$escaped_files = JavascriptHelper::escapeScript($files);

// +POOR_VALIDATION to return
$escaped_string = JavascriptHelper::escapeScript($string);

// <yes> <report> PHP_XSS_VALIDATION rw6ds2
debug_zval_dump($escaped_string);
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$lines = file('https://www.example.com/');
// <yes> <report> PHP_XSS_VALIDATION hhwd58
$json = new Zend_Json_Expr($escaped_files);

// <yes> <report> PHP_XSS_VALIDATION uqs1e3
$class->Session->setFlash($escaped_files, 'flash_good');

// <yes> <report> PHP_XSS_VALIDATION tt6ds2
Debugger::dump($escaped_string);

// <yes> <report> PHP_XSS_VALIDATION 7q1dr8
e($escaped_string);
// <yes> <report> PHP_XSS_VALIDATION okew42
debug($escaped_string, true, true);
// <yes> <report> PHP_XSS_VALIDATION tklwsj
print_r ($escaped_string, false);
// <yes> <report> PHP_XSS_VALIDATION gejwls
var_export($escaped_string);

$ErrorLines = @file($File);
$LineCount = count($ErrorLines);
if (is_array($ErrorLines) && $Line > -1) {
    echo "\nLOCATION: ", $File, "\n";
}
// <yes> <report> PHP_XSS_VALIDATION xss0val01
echo str_pad($i, $Padding, " ", STR_PAD_LEFT), ': ', htmlentities($ErrorLines[$i], ENT_COMPAT, 'UTF-8');
$filename = (string)@$_GET['filename'];
$filename .= '.txt';
// <yes> <report> PHP_PATH_MANIPULATION swhwm0 <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
if (file_exists($filename)) {
// <yes> <report> PHP_XSS_VALIDATION xss0val01 <yes> <report> PHP_PATH_MANIPULATION swhwm0
echo htmlspecialchars(file_get_contents($filename));
}
else {
echo "Error!"; }
?>
