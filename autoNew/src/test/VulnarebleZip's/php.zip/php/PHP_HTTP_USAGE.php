<?php
// <yes> <report> PHP_HTTP_USAGE 6af7b9
$zxc = new Zend_XmlRpc_Client('http://abc');
// <yes> <report> PHP_HTTP_USAGE laf7b9
$zxc = new Zend_XmlRpc_Client('http://localhost');
// <yes> <report> PHP_HTTP_USAGE 6af7b1
$zxc->setParams('http://abc');
// <yes> <report> PHP_HTTP_USAGE laf7b1
$zxc->setParams('http://127.0.0.1');
// <yes> <report> PHP_HTTP_USAGE b032ac
$zuh = new Zend_Uri_Http('http');
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000 <yes> <report> PHP_HTTP_USAGE phttp00
$url1 = "http://url.url";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000 <yes> <report> PHP_HTTP_USAGE phttp00
$url1 = 'http://url.url';
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna000
$url2 = "1.1.1.1";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna001 <yes> <report> PHP_HTTP_USAGE phttpl0
$url3 = "http://localhost";
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002 <yes> <report> PHP_HTTP_USAGE phttp01
$url4 = cl("http://url.url");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002 <yes> <report> PHP_HTTP_USAGE phttp01
$url4 = cl('http://url.url');
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna003 <yes> <report> PHP_HTTP_USAGE phttpl1
$url5 = cl("http://localhost");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna004 <yes> <report> PHP_HTTP_USAGE phttp02
cl("http://url.url");
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna004 <yes> <report> PHP_HTTP_USAGE phttp02
cl('http://url.url');
//  <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna005 <yes> <report> PHP_HTTP_USAGE phttpl2
cl("http://localhost");

// <no> <report>
$whitelist = "http://javax.xml.XMLConstants";
// <no> <report>
$whitelist = "http://apache.org";
// <no> <report>
$whitelist = "http://xml.org/sax";
?>