<?php
$client = new Zend_Soap_Client("MyService.wsdl");
// +PRIVATE_DATA to return
$password = $client->getHttpPassword();
// No report
ldap_bind($conn, $name, $password);
// +DEOBFUSCATED to return
$bad_password = base64_decode("bad_password!");
// <yes> <report> PHP_PASSWORD_CRYPTO p11pc1
ldap_bind($conn, $name, $bad_password);
?>