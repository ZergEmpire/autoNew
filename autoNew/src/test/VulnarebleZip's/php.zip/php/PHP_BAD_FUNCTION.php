<?php
// <yes> <report> PHP_BAD_FUNCTION 0bf02f
import_request_variables();
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_BAD_FUNCTION 4447cb
mysql_escape_string();
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_BAD_FUNCTION f0a643
pg_meta_data();
// <yes> <report> PHP_BAD_FUNCTION 204de0
rename_function();
?>