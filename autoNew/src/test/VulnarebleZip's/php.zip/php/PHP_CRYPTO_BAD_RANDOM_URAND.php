<?php

function phpbb_hash($password)
{
	$itoa64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

	$random_state = unique_id();
	$random = '';
	$count = 6;

    // <yes> <report> PHP_CRYPTO_BAD_RANDOM 1cd98f
    if (($fh = @fopen('/dev/urandom', 'rb')))
	{
		$random = fread($fh, $count);
		fclose($fh);
	}

	if (strlen($random) < $count)
	{
		$random = '';

		for ($i = 0; $i < $count; $i += 16)
		{
			// <yes> <report> PHP_CRYPTO_BAD_HASH f0b5ff
			$random_state = md5(unique_id() . $random_state);
			// <yes> <report> PHP_CRYPTO_BAD_HASH f0b5ff
			$random .= pack('H*', md5($random_state));
		}
		$random = substr($random, 0, $count);
	}

	$hash = _hash_crypt_private($password, _hash_gensalt_private($random, $itoa64), $itoa64);

	if (strlen($hash) == 34)
	{
		return $hash;
	}

	// <yes> <report> PHP_CRYPTO_BAD_HASH f0b5ff
	return md5($password);
}

?>