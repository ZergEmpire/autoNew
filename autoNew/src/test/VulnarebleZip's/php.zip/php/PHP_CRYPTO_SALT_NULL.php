<?php
// <yes> <report> PHP_CRYPTO_SALT_NULL p11sn1
hash_pbkdf2('sha-256', $password, null, $iterations, 20);
// <yes> <report> PHP_CRYPTO_SALT_NULL p12sn1
openssl_pbkdf2($password, null, 128, 10000, sha1);
?>