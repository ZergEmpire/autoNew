<?php
$id = $_POST['id'];
$concat_unsafe = $id . 'jpg';
$concat_safe = 'jpg/' . $id;
// <yes> <report> PHP_PATH_MANIPULATION swhwm0
file_exists($concat_safe);
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_CRYPTO_BAD_HASH f0b5ff
md5_file($concat_unsafe);
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_PATH_MANIPULATION swhwm0
filemtime($concat_unsafe);
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_PATH_MANIPULATION swhwm0
filesize($concat_unsafe);
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_PATH_MANIPULATION swhwm0
file_exists($_POST['id']);
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard0 <yes> <report> PHP_PATH_MANIPULATION 34c54t
new File($concat_unsafe);
// <yes> <report> PHP_PATH_MANIPULATION 34c54t
new File($concat_safe);

$concat_phar = 'phar://' . $_POST['m'];
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard2 <yes> <report> PHP_PATH_MANIPULATION swhwm0
file_exists($concat_phar);
// <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard3 <yes> <report> PHP_PATH_MANIPULATION 34c54t
new File($concat_phar);