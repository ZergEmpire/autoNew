<?php
$HttpSocket = new HttpSocket();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST kfennn +WEB to return
$owner = $HttpSocket->get('https://www.google.com/search', 'q=cakephp');
// <yes> <report> PHP_FILE_PERMISSIONS f19019 <yes> <report> PHP_CONTROL_FLOW_MANIPULATION sdfgb2
if (@chown($filename, $owner))
		{
			clearstatcache();
			$file_uid = @fileowner($filename);
		}

?>