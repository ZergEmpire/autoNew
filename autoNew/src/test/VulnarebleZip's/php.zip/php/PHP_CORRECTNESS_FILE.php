<?php
//<yes> <report> PHP_CORRECTNESS_FILE p1gr7b
$file=fopen("welcome.txt","rb");
//<yes> <report> PHP_CORRECTNESS_FILE p1gr7b
$fp=fopen($FILE, "r+");
//<yes> <report> PHP_CORRECTNESS_FILE p1gr7b
$fp=fopen( "$FILE/style.css", 'r');

//<no> <report>
$handle=fopen( $path, 'w' );
//<no> <report>
$handle=fopen( $path, 'r' );// no report, because above fopen() in 'w'-mode file has already been created

//<yes> <report> PHP_CORRECTNESS_FILE p1gr7b
$handle=fopen( $path1, 'r' );
//<no> <report>
$handle=fopen( $path1, 'w' );

try {
    //<no> <report>
    $file=fopen("example.txt", "r");
    if (false === $file) throw new Exception("Failed to open file");
} catch ( Exception $e ) {
    //<yes> <report> PHP_INFORMATION_LEAK_EXTERNAL 54bwcq
    echo $e->getMessage();
}

//<no> <report>
$handle = fopen( $path2, 'w' );
//<no> <report>
$handle = fopen( $path2, 'x+' );

if (is_file($file_path)) {
    //<no> <report>
    $fp=fopen($file_path, "r");
} else {
    echo ("error");
}

if (is_readable($file_path)) {
    //<no> <report>
    $fp=fopen($file_path, "r");
} else {
    echo ("error");
}

if (file_exists($file_path)) {
    //<no> <report>
    $fp=fopen($file_path, "r");
} else {
    echo ("error");
}

//<no> <report>
if (@fopen($url, "r")) {
    echo "Файл существует";
} else {
    echo "Файл не найден";
}

if (!file_exists($file_path1)) {
    return;
}
//<no> <report>
$handle=fopen( $file_path1, 'r' );

if (!is_readable($file_path2)) {
    return;
}
//<no> <report>
$handle=fopen( $file_path2, 'r' );

if (!is_file($file_path3)) {
    return;
}
//<no> <report>
$handle=fopen( $file_path3, 'r' );
?>