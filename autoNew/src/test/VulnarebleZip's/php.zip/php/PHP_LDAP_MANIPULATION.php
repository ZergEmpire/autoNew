<?php
// +FILE_SYSTEM to return
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$base_dn = file('https://www.base_dn_example.com/');
// <yes> <report> PHP_LDAP_MANIPULATION p11lm1
ldap_search($link_id, $base_dn, $filter, $atributes);
// +FILE_SYSTEM to return
// <yes> <report> PHP_BACKDOOR_NETWORK_ACTIVITY bna002
$link = file('https://www.link_identifier.com/');
// <yes> <report> PHP_LDAP_MANIPULATION p12lm1
ldap_add($link, $dn, $entry);
// <yes> <report> PHP_LDAP_MANIPULATION p13lm1
ldap_mod_replace($link, $ldap_object_name, $entry);
// <yes> <report> PHP_LDAP_MANIPULATION p14lm1
ldap_rename($link, $ldap_object_name, $new_ldap_object_name, $newparent, TRUE);
?>