<?php
// <yes> <report> PHP_TRUST_BOUNDARY_VIOLATION sdbmjl
memcache_set($memcache_obj, $_GET['df'], 'some variable', 0, 30);
$memcache_obj = new Memcache;
// <yes> <report> PHP_TRUST_BOUNDARY_VIOLATION aahgip
$memcache_obj->set('var_key', $_GET['df'], MEMCACHE_COMPRESSED, 50);
// <yes> <report> PHP_TRUST_BOUNDARY_VIOLATION rtyujf
$_SESSION['f'] = $_GET['df'];
?>
