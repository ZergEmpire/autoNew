<?php
	$doc = new DOMDocument();

	$upload = new Zend_File_Transfer();
	$files = $upload->getFileInfo();

	// <yes> <report> PHP_INJECTION_XML qwkeds
	$xml = new SimpleXMLElement($files);
	// <yes> <report> PHP_INJECTION_XML qwkeds
	$dom = new Zend_Dom_Query($files);

	$lines = file('somefile.xml');
	// <yes> <report> PHP_INJECTION_XML jdkeds
	$doc->loadXML($lines);
	$parser = xml_parser_create('ISO-8859-1');
	// <yes> <report> PHP_INJECTION_XML w0khqs
	xml_parse($parser, $doc);
	// <yes> <report> PHP_INJECTION_XML wwkhqs 
	$xml2 = simplexml_load_string($xml);
	// <yes> <report> PHP_INJECTION_XML wwkhqs
	$xml3 = simplexml_load_file($xml);
?>
