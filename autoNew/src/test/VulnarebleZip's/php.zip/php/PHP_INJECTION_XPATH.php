<?php
$doc = new DOMDocument;
$doc->load('book.xml');
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_MISSING_AUTHORIZATION kts443
$con=mysqli_connect("localhost","my_user","my_password","my_db");
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf
$result = mysqli_query($con,"SELECT Name FROM Persons");

$xpath = new DOMXpath($doc);
// <yes> <report> PHP_INJECTION_XPATH 5f50ds
$entries = $xpath->evaluate("//" . $result);

$xml = new SimpleXMLElement($string);
// <yes> <report> PHP_INJECTION_XPATH a7gr9i
$res = xpath($result);
// <yes> <report> PHP_INJECTION_XPATH a7gr9i
$result = $xml->xpath("//" . $result);
?>