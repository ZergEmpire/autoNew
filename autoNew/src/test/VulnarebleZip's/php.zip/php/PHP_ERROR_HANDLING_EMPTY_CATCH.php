<?php
try {
    $file=fopen("1.txt");
}
catch (Exception $e) {
    // <yes> <report> PHP_ERROR_HANDLING_EMPTY_CATCH gr1001
}
try {
    $file=fopen("2.txt");
}
catch (Exception $e) {
    // <no> <report>
    echo "hello";
}
?>