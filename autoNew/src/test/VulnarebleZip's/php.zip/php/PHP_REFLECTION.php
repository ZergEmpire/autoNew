<?php
$HttpSocket = new HttpSocket();
// <yes> <report> PHP_INFORMATION_LEAK_GET_REQUEST kfennn +WEB to return
$args = $HttpSocket->get('https://www.google.com/search', 'q=cakephp');
$ctl = $_GET["ctl"];
$cmdClass = new ReflectionClass(ctl . "Command");
// <yes> <report> PHP_REFLECTION dd172e
$ao = $cmdClass->newInstance($args);
$ao->doAction(request);

// <yes> <report> PHP_REFLECTION ttddy9
$reflectMethod = new ReflectionMethod('One', $args);
$server = new Zend_Rest_Server();
// <yes> <report> PHP_REFLECTION hg171q
$server->addFunction($args);
// <yes> <report> PHP_REFLECTION zz123e
$server->setClass($args);
// <yes> <report> PHP_REFLECTION th127w
$dispatchable = Zend_Server_Reflection::reflectClass($args, $argv, $namespace);
?>