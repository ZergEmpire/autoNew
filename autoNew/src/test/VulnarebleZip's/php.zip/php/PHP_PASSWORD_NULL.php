<?php
// <yes> <report> PHP_IMPROPER_EXCEPTION_HANDLING 56yujf <yes> <report> PHP_PASSWORD_NULL 2c48c7
mysql_connect('','',null);
$adoc = new ADOConnection();
// <yes> <report> PHP_PASSWORD_NULL e1d9ff
$adoc->Connect('','',null);
$zfe = new Zend_Filter_Encrypt();
// <yes> <report> PHP_PASSWORD_NULL 991866
$zfe->setPassphrase(null);
$zsc = new Zend_Soap_Client();
// <yes> <report> PHP_PASSWORD_NULL 35ef1f
$zsc->setHttpPassword(null);
// <yes> <report> PHP_PASSWORD_NULL 026008
$password = null;
// <yes> <report> PHP_PASSWORD_NULL 025920
$somethingpasswordsomething = null;
// <yes> <report> PHP_PASSWORD_NULL 026182
$class->$password = null;
// <yes> <report> PHP_PASSWORD_NULL 026094
$class->$somethingpasswordsomething = null;
array(
	'user' => 'admin',
	// <yes> <report> PHP_PASSWORD_NULL 026333
	'password' => null
);
// <yes> <report> PHP_PASSWORD_NULL yyh667
$mbox = imap_open("{localhost:143}INBOX", "user_id", null);
$desc = new \ProtocolBuffers\DescriptorBuilder();
// <yes> <report> PHP_PASSWORD_NULL fyyh66
$desc->addField(1, new \ProtocolBuffers\FieldDescriptor(array(
  "type"     => \ProtocolBuffers::TYPE_STRING,
  "name"     => "password",
  "required" => true,
  "optional" => false,
  "repeated" => false,
  "packable" => false,
  "default"  => null,
)));
?>