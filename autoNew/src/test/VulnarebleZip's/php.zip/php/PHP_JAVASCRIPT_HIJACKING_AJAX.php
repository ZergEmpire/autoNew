<?php
	$pwd = getpassword();
	// <yes> <report> PHP_JAVASCRIPT_HIJACKING_AJAX fgejn3
	$class->data = json_decode($pwd);
?>