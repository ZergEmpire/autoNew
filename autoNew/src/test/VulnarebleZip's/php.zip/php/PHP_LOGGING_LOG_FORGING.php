<?php
$request = new Zend_Controller_Request_Http();
// +WEB to return
$taint = $request->getCookie('name');
// <yes> <report> PHP_LOGGING_LOG_FORGING 1jc68t
trigger_error($taint, E_USER_ERROR);
// <yes> <report> PHP_LOGGING_LOG_FORGING ryc57t
LogError($taint);
// <yes> <report> PHP_LOGGING_LOG_FORGING wwpu9m
CakeLog::write($act, $taint);
// <yes> <report> PHP_LOGGING_LOG_FORGING kcc944
Debugger::log($taint, $level = 7, $depth = 3);
// <yes> <report> PHP_LOGGING_LOG_FORGING ryc57t
error_log($taint, 0);
$logger = new Zend_Log();
// <yes> <report> PHP_LOGGING_LOG_FORGING hhc60t
$logger->log($taint, Zend_Log::INFO);
// <yes> <report> PHP_LOGGING_LOG_FORGING wwll9m
Log::error($taint);
?>