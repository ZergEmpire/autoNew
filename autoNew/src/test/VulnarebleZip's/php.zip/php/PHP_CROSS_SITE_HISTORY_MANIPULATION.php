<?php
if( isset( $file ) ) {
    include( $file );
    // <yes> <report> PHP_CROSS_SITE_HISTORY_MANIPULATION ff367a
    header( 'Location:?page=include.php');
} else {
    header( 'Location:?page=include' . '.php');
    // <yes> <report> PHP_CROSS_SITE_HISTORY_MANIPULATION ff367a
    header( 'Location:?page=include.php');
    exit;
}

switch ($i) {
    case 0:
        header( 'Location:?page=include' . '.php');
        // <yes> <report> PHP_CROSS_SITE_HISTORY_MANIPULATION ff367a
        header( 'Location:?page=include.php');
    case 1:
        // <yes> <report> PHP_CRYPTO_BAD_RANDOM 1649a4
        header( 'Location:?page=include' . rand() . '.php');
        // <yes> <report> PHP_CROSS_SITE_HISTORY_MANIPULATION ff367a
        header( 'Location:?page=include.php');
    default:
        // <yes> <report> PHP_CROSS_SITE_HISTORY_MANIPULATION ff367a
        header ("location: ?default=English");
        exit;
}
?>