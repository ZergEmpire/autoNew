<?php
// <yes> <report> PHP_CRYPTO_SALT_EMPTY p11se1
hash_pbkdf2('sha-256', $password, "", $iterations, 20);
// <yes> <report> PHP_CRYPTO_SALT_EMPTY p11se1
hash_pbkdf2('sha-256', $password, '', $iterations, 20);
// <yes> <report> PHP_CRYPTO_SALT_EMPTY p12se1
openssl_pbkdf2($password, "", 128, 20000, sha1);
// <yes> <report> PHP_CRYPTO_SALT_EMPTY p12se1
openssl_pbkdf2($password, '', 128, 20000, sha1);
?>