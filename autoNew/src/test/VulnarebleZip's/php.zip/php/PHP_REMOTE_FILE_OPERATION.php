<?php
// <yes> <report> PHP_REMOTE_FILE_OPERATION 6384bd
ini_set('allow_url_fopen','On');
// <yes> <report> PHP_REMOTE_FILE_OPERATION ed08b3
ini_set('allow_url_include','On');
?>