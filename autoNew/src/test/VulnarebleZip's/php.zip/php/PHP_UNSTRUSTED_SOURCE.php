<?php
$titul_id = " ";
$fname = " ";
$fext = " ";
$key = "key";
$who = "who";
$pathav = "defect/".$titul_id.'/'.$fname.'.'.$fext;
// <yes> <report> PHP_UNTRUSTED_SOURCE f6ffe1 <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_FILE_MANIPULATION yuokgk
@move_uploaded_file($_SERVER['HTTP_HOST'],$pathav);
// <yes> <report> PHP_FILE_UPLOAD_MISUSED 4a65dc <yes> <report> PHP_UNTRUSTED_DATA_DESERIALIZATION_PHAR phard1 <yes> <report> PHP_FILE_MANIPULATION yuokgk
copy($_FILES[$who]['tmp_name'][$key],$pathav);
