<?php
// <yes> <report> PHP_CRYPTO_BAD_PADDING 7ee57e
openssl_public_encrypt('', '', '', OPENSSL_NO_PADDING);
// <yes> <report> PHP_CRYPTO_BAD_PADDING 7ee57e
openssl_public_decrypt('', '', '', OPENSSL_NO_PADDING);
// <yes> <report> PHP_CRYPTO_BAD_PADDING 7ee57e
openssl_private_encrypt('', '', '', OPENSSL_NO_PADDING);
// <yes> <report> PHP_CRYPTO_BAD_PADDING 7ee57e
openssl_private_decrypt('', '', '', OPENSSL_NO_PADDING);
// <yes> <report> PHP_CRYPTO_BAD_PADDING 12e27e
$ciphertext = openssl_encrypt($plaintext,  'AES-128-CBC', $key, OPENSSL_ZERO_PADDING, $iv);
?>