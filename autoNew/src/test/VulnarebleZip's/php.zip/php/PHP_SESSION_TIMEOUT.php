<?php
$c = new Configure();
// <yes> <report> PHP_SESSION_TIMEOUT 0297c7
$c->write('Security.level', '');
// <yes> <report> PHP_SESSION_TIMEOUT b1a3cd
Configure::write('Security.level', 'low');
// <yes> <report> PHP_SESSION_TIMEOUT ldk7c7
Configure::write('Session.timeout', '1440');
?>