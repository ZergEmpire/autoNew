<?php
// <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY 000008
$output = `ls -al`;
// <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY p11hf2
eval(base64_decode("very_very_bad!"));
// <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY 000005
exec(base64_decode("something"));
// <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY 000005
exec(str_replace("something", "something_new", "something_else"));
$str = "something";
passhtru();
// <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY 000006
preg_replace('/.*/e','');
// <yes> <report> PHP_BACKDOOR_HIDDEN_FUNCTIONALITY 000009
$_GET['func_name']($_GET['argument']);
$func = new ReflectionFunction($_GET['func_name']);
$func->invoke();
$func->invokeArgs(array());
// <no> <report>
shell_exec(static::CSPTEST_EXECUTABLE_PATH . ' -keyset -verifycontext');
?>
