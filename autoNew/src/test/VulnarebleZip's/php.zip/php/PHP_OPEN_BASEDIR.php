<?php
// <yes> <report> PHP_OPEN_BASEDIR 7d8acf
ini_set('open_basedir', $var);
// <yes> <report> PHP_OPEN_BASEDIR_POOR rt8agg 
ini_set('open_basedir','foo/:.:bar/');
?>