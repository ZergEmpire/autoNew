<?php
// <yes> <report> PHP_CRYPTO_BAD_ITERATION_COUNT p11ic1
hash_pbkdf2('sha-256', $password, $salt, 1500, 20);
// <yes> <report> PHP_CRYPTO_BAD_ITERATION_COUNT p12ic1
hash_pbkdf2('sha-256', $password, $salt, 998, 20);
?>