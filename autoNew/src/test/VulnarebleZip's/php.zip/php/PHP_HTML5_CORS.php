<?php
// <yes> <report> PHP_HTML5_CORS 068eae
header('Access-Control-Allow-Origin: *');
$c = new Controller();
// <yes> <report> PHP_HTML5_CORS 75545e
$c->header('Access-Control-Allow-Origin: *');
?>