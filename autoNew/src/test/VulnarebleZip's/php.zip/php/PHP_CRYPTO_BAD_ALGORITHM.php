<?php
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 744c2c
crypt();
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 23fcd3
openssl_seal();
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 100002
new Crypt_DES();
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 100002
new Crypt_RC4();
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 100003
new Crypt_TripleDES(CRYPT_DES_MODE_ECB);
$cipher = new Crypt_RSA();
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 100001
$cipher->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 100004
openssl_encrypt('', OPENSSL_CIPHER_DES, '');
// <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 100004
openssl_decrypt('', OPENSSL_CIPHER_RC2_40, '');
class WebApp {
    function workWithCookie() {
        // <yes> <report> PHP_CRYPTO_BAD_ALGORITHM 110004
        $this->Cookie->type('des');
    }
}
?>