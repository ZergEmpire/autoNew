<?php
// <yes> <report> PHP_SESSION_STRICT_MODE_DISABLED s297c7
ini_set('session.use_strict_mode','Off');
//http://fi2.php.net/manual/ru/session.security.ini.php
?>