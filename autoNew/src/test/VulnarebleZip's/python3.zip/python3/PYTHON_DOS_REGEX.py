import re


# <yes> <report> PYTHON_DOS_REGEX 6af533
re.compile(regex)

# <yes> <report> PYTHON_DOS_REGEX 6af533
result = re.match(pattern, string)

# <no> <report>
re.compile('[a-z]+')

# <no> <report>
re.compile(r'[a-z]+', re.I)

# <no> <report>
result = re.match('pattern', 'string')
