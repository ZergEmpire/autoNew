# http://www-01.ibm.com/support/docview.wss?uid=isg3T1024732
import smtplib

server = smtplib.SMTP('smtp.gmail.com', 587)
# <yes> <report> PYTHON_BAD_FUNCTION tgee77
server.starttls()
# https://hynek.me/articles/hasattr/
# # yes> <report> PYTHON_BAD_FUNCTION true73
# hasattr(x, "y")

# http://www.securityfocus.com/bid/56578/references
# https://bugs.launchpad.net/ubuntu/+source/python-keyring/+bug/1031465
# # yes> <report> PYTHON_BAD_FUNCTION hkue22
# import keyring
