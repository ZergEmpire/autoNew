import rsa
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.PublicKey import ElGamal

# <yes> <report> PYTHON_CRYPTO_KEY_SIZE 64a8d6
encryption_suite = AES.new('key123', AES.MODE_CBC, 'This is an IV456')

cipher_text = encryption_suite.encrypt("A really secret message. Not for prying eyes.")

# <yes> <report> PYTHON_CRYPTO_KEY_SIZE 9917ca
(pub_key, priv_key) = rsa.newkeys(1024)

# <yes> <report> PYTHON_CRYPTO_KEY_SIZE 2117ca
key = RSA.generate(1024)

# <yes> <report> PYTHON_CRYPTO_KEY_SIZE kvlemd
key = ElGamal.generate(1024, Random.new().read)
