# <yes> <report> PYTHON_FILE_TMP_HARDCODED hrctmp
f = open('/tmp/abc', 'w')

# <yes> <report> PYTHON_FILE_TMP_HARDCODED hrctmp
f2 = open('/dev/shm/lok', 'w')

# <yes> <report> PYTHON_FILE_TMP_HARDCODED hrctmp
f3 = open('/var/tmp/dav', 'w')
