import cgi as cgii


form = cgii.FieldStorage()
for item in form.getlist("item"):
    # <yes> <report> PYTHON_XSS_REFLECTED_CGI cgi001 <yes> <report> PYTHON_INFORMATION_LEAK wedqb9
    print(item)
    # <yes> <report> PYTHON_XSS_REFLECTED_CGI cgi001 <yes> <report> PYTHON_INFORMATION_LEAK wedqb9
    print(item + "format {}".format("abc"))

print("abc")
