# https://docs.python.org/2/library/xml.etree.elementtree.html#module-xml.etree.ElementTree

# <yes> <report> PYTHON_INJECTION_XXE dtf5re
import xml.sax

# <yes> <report> PYTHON_INJECTION_XXE dtf5re
import xml.dom.pulldom

# <yes> <report> PYTHON_INJECTION_XXE ccf5r8
from xml.dom.pulldom import getDOMImplementation
