import os
from flask import Flask, redirect, request, send_file

app = Flask(__name__)

@app.route('/')
def cat_picture():
    image_name = request.args.get('image_name')
    if not image_name:
        return 404
    # <yes> <report> PYTHON_PATH_TRAVERSAL abctrn
    return send_file(os.path.join(os.getcwd(), image_name))


if __name__ == '__main__':
    app.run()