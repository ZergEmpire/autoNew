from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from peewee import *
from ftplib import FTP

# <yes> <report> PYTHON_PASSWORD_EMPTY 1kmm67
hash = pbkdf2('', salt, iterations, digest=self.digest)

# <yes> <report> PYTHON_PASSWORD_EMPTY 607f01
password = ""

# <yes> <report> PYTHON_PASSWORD_EMPTY 22d164
user2 = User.objects.create_user('paul', 'maccartney@thebeatles.com', '')

# <no> <report>
u = User.objects.get(username='john')

# <yes> <report> PYTHON_PASSWORD_EMPTY 17kf67
user = authenticate(username='john', password='')

# <yes> <report> PYTHON_PASSWORD_EMPTY 17kf67
db = MySQLDatabase('jonhydb', user='john', passwd='')

# <yes> <report> PYTHON_PASSWORD_EMPTY 17kf67
hash = pbkdf2(salt, iterations, password='', digest=self.digest)

M = poplib.POP3('localhost')

# <yes> <report> PYTHON_PASSWORD_EMPTY op3klw
M.apop(getpass.getuser(), '')

ftps = FTP_TLS('ftp.pureftpd.org')

# <yes> <report> PYTHON_PASSWORD_EMPTY foijkd
ftps.login('anonymous', '', '')

M = imaplib.IMAP4()

# <yes> <report> PYTHON_PASSWORD_EMPTY jk322w
M.login_cram_md5(getpass.getuser(), "")

h = httplib2.Http()

# <yes> <report> PYTHON_PASSWORD_EMPTY hjlwmm
h.add_credentials( 'username', '' )

# <yes> <report> PYTHON_PASSWORD_EMPTY fhbdos
ftp = FTP('ftp.cse.buffalo.edu', "user", "")
