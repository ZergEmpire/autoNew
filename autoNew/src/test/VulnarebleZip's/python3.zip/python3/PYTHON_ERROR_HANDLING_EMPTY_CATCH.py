try:
    print("Hello, world!")
# <yes> <report> PYTHON_ERROR_HANDLING_EMPTY_CATCH b0eb34
except ZeroDivisionError:
    pass    # empty catch
