from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from Crypto.Cipher import DES

# <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM 14b8d3
cipher = Cipher(algorithm=algorithms.ARC4(key), mode=modes.ECB, backend=default_backend())

# <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM 14b8d3
cipher = Cipher(algorithm=Blowfish(key), mode=modes.ECB, backend=default_backend())

encryptor = cipher.encryptor()
ct = encryptor.update(b"a secret message")

# <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM b36e09
encryption_suite = DES.new('This is a key123', DES.MODE_CBC, 'This is an IV456')

# <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM b36e09
cipher = PKCS1_v1_5.new(key)

# <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM 741df1
context.set_ciphers("TLS_RSA_WITH_RC4_128_SHA: TLS_ECDHE_RSA_WITH_RC4_128_SHA")

# <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM hrj3wh
xor1 = strxor(s3, s4)
