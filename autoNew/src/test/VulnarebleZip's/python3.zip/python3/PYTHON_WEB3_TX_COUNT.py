from web3 import Web3

w3 = Web3(Web3.HTTPProvider("https://ropsten.infura.io/api/v3/" + api_key))

# <yes> <report> PYTHON_WEB3_TX_COUNT mm6df9
txn = contract.functions.return1543().buildTransaction({
    'gas': 70000,
    'chainId': 3,
    'nonce': w3.eth.getTransactionCount(sender_addr)
})

txn = contract.functions.return1543().buildTransaction({
    'gas': 70000,
    'chainId': w3.eth.getTransactionCount(sender_addr),
    'nonce': 3
})
