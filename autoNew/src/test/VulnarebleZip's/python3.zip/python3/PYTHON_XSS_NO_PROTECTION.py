# <yes> <report> PYTHON_XSS_NO_PROTECTION ghuq23
SECURE_BROWSER_XSS_FILTER = False

#<yes> <report> PYTHON_XSS_NO_PROTECTION jinja2
templateEnv = jinja2.Environment(autoescape=False, loader=templateLoader)

#<yes> <report> PYTHON_XSS_NO_PROTECTION maco34
mako.template.Template("hern")

#<yes> <report> PYTHON_XSS_NO_PROTECTION temple
template.Template("hern")
