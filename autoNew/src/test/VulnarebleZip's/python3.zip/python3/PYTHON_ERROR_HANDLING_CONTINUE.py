# <yes> <report> PYTHON_ERROR_HANDLING_CONTINUE b0eb50
self.logger.error(message, exc_info=True)

# <no> <report>
self.logger.error(message, exc_info=False)
