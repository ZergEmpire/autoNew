

# <yes> <report> PYTHON_CRYPTO_BAD_HMAC fmdmkf
dk = pbkdf2_hmac('sha1', password, salt, 1000000)

# <yes> <report> PYTHON_CRYPTO_BAD_HMAC rmca34
PBKDF2HMAC("kek", "RIPEMD")

# <yes> <report> PYTHON_CRYPTO_BAD_HMAC rmca35
PBKDF2HMAC("pass", "SHA256")
