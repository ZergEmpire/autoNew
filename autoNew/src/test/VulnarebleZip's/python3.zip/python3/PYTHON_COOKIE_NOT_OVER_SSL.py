from http.cookies import SimpleCookie
from WebKit.HTTPResponse import HTTPResponse
from django.conf import settings

response = HTTPResponse()
cookie = SimpleCookie()
cookie['foo'] = 'bar'

# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL 2a61c4
cookie['foo']['secure'] = notSoSure

# <no> <report>
cookie['foo']['secure'] = True

# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL 1lf1c4
CSRF_COOKIE_SECURE = False

# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL 1er1c4
settings.configure(SESSION_COOKIE_SECURE=False)

import os
from flask import Flask, redirect, request, send_file

app = Flask(__name__)
# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL abctry
app.config['SESSION_COOKIE_SECURE'] = False

@app.route('/')
def cat_picture():
    return "Hello, world!"


if __name__ == '__main__':
    app.run()
