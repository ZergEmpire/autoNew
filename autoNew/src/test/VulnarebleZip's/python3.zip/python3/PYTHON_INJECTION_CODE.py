from flask import Flask, request, render_template_string

app = Flask(__name__)


@app.route('/')
def flask_ssti():
    name = "World"
    if request.args.get('name'):
        name = request.args.get('name')
    # <yes> <report> PYTHON_INJECTION_CODE exptrn
    return render_template_string('''
                                    <!doctype html>
                                    <h1>Hello %s!</h1>
                                    <form>
                                        <input type="text" name="name">
                                    </form>
                                    ''' % (name))

@app.route('/')
def flask_ssti():
    name = "World"
    if request.args.get('name'):
        name = request.args.get('name')
    # <yes> <report> PYTHON_INJECTION_CODE exptrm
    return render_template_string('''
                                    <!doctype html>
                                    <h1>Hello {}!</h1>
                                    <form>
                                        <input type="text" name="name">
                                    </form>
                                    '''.format(name))


if __name__ == "__main__":
    app.run()

    # <yes> <report> PYTHON_INJECTION_CODE exec34
    exec("do evil")