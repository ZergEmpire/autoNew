from web3 import Web3

# <yes> <report> PYTHON_WEB3_HARDCODED_API_KEY n6g4bo
w3 = Web3(Web3.HTTPProvider("https://ropsten.infura.io/api/v3/hardcoded_api_key"))

# TODO add this case as another pattern
# api_key = "hardcoded_api_key"
# # <yes> <report> PYTHON_WEB3_HARDCODED_API_KEY
# w3 = Web3(Web3.HTTPProvider("https://ropsten.infura.io/api/v3/" + api_key))

w3 = Web3(Web3.HTTPProvider("https://ropsten.infura.io/api/v3/" + a_k))
