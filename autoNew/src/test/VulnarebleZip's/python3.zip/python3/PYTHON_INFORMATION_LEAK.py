# <yes> <report> PYTHON_INFORMATION_LEAK wedqb9
print(system_info)

import logging

LOG_FILENAME = 'example.log'
logging.basicConfig(filename=LOG_FILENAME, level=logging.DEBUG)
# <yes> <report> PYTHON_INFORMATION_LEAK 8eeebv
logging.debug(system_info)
# <no> <report>
logging.debug("This message should go to the log file")

import logging.Logger
logger = logging.getLogger('tcpserver')
# <yes> <report> PYTHON_INFORMATION_LEAK he7ebk
logger.warning('Protocol problem: %s', 'connection reset', extra=d)

import warnings
# <yes> <report> PYTHON_INFORMATION_LEAK je7ebq
warnings.warn(depr, DeprecationWarning)

import cgitb
 
# <yes> <report> PYTHON_INFORMATION_LEAK dete9q
cgitb.enable ()
# <yes> <report> PYTHON_INFORMATION_LEAK rrte55
cgitb.enable(display=1)

from django.conf import settings
# <yes> <report> PYTHON_INFORMATION_LEAK lkte9q
settings.configure(DEBUG=True)
# <yes> <report> PYTHON_INFORMATION_LEAK lkte21
settings.DEBUG = True   # Don't do this! (c)DjangoDoc

# Содержимое settings.py библиотеки Django
# <yes> <report> PYTHON_INFORMATION_LEAK lkte21
DEBUG = True

from flask import Flask, render_template, request
# <yes> <report> PYTHON_INFORMATION_LEAK cfghkl
app.run(debug=True)


