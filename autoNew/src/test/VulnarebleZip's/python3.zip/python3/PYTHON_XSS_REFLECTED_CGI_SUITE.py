def func():
    import cgi
    val = cgi.FieldStorage().getvalue("dasd")
    # <yes> <report> PYTHON_XSS_REFLECTED_CGI cgi001 <yes> <report> PYTHON_INFORMATION_LEAK wedqb9
    print(val)
