CREATE PROCEDURE grant_test AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_GRANT_ALL 129882
  GRANT ALL ON PROCEDURE TO george;
  -- <yes> <report> PLSQL_GRANT_ALL 129882
  GRANT all ON TABLE table to PUBLIC;
  -- <yes> <report> PLSQL_GRANT_ALL 129882
  GRANT all privileges ON SEQUENCE order_id TO sales_role;
  -- <yes> <report> PLSQL_GRANT_ALL 129882
  GRANT ALL PRIVILEGES ON TYPE price TO finance_role;
END;