create procedure dsql2(tcl in varchar2) AUTHID CURRENT_USER as
begin
    -- <yes> <report> PLSQL_CRYPTO_BAD_HASH 43c631
    DBMS_OBFUSCATION_TOOLKIT.MD5();
    -- <yes> <report> PLSQL_CRYPTO_BAD_HASH bac60e
    dbms_crypto.hash(); -- SHA1 by default; other options are MD4 and MD5
    -- <yes> <report> PLSQL_CRYPTO_BAD_HASH 94a603
    DBMS_OUTPUT.PUT_LINE(dbms_crypto.hash( l_src, dbms_crypto.HASH_MD5 ));
    -- <yes> <report> PLSQL_CRYPTO_BAD_HASH 94a603
    DBMS_CRYPTO.Hash(str, HASH_MD4);
    -- <yes> <report> PLSQL_CRYPTO_BAD_HASH 94a603
    DBMS_CRYPTO.Hash(str, HASH_MD5);
    -- <yes> <report> PLSQL_CRYPTO_BAD_HASH 94a603
    DBMS_CRYPTO.Hash(str, HASH_SH1);
end dsql2;