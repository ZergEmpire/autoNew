CREATE PROCEDURE xss AUTHID CURRENT_USER
AS
BEGIN
  s := 'tainted string';
  -- <yes> <report> PLSQL_XSS 50e052
  htp.p(s);
  -- <yes> <report> PLSQL_XSS 50e052
  htp.prn('not safe' || s);
  -- <no> <report>
  htp.p('safe');
END xss;
