CREATE PROCEDURE test AUTHID CURRENT_USER AS
DECLARE
BEGIN
    -- no matter the expression, detect constant string with value equal to one of default passwords
    -- <yes> <report> PLSQL_DEFAULT_CREDENTIALS ba14ee
    drowssap := 'WKADMIN';    
    -- <yes> <report> PLSQL_DEFAULT_CREDENTIALS ba14ee
    drowssap := '!DEMO_USER';
    -- <yes> <report> PLSQL_DEFAULT_CREDENTIALS ba14ee
    drowssap := '#INTERNAL';
    -- <yes> <report> PLSQL_DEFAULT_CREDENTIALS ba14ee
    drowssap := 'AURORA$JIS$UTILITY$';
    -- <no> <report>
    drowssap := '$$$#';
    -- <no> <report>
    drowssap := 'VERYSECUREPASSWORD';
END;