CREATE PROCEDURE test_dos AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_OPEN_REDIRECT 6e9345
  owa_util.redirect_url(bad_url);
  -- <yes> <report> PLSQL_OPEN_REDIRECT 32a0fb
  redirect_url(bad_url);
END test_dos;