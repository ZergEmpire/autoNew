CREATE PROCEDURE empty_exception AUTHID CURRENT_USER AS
BEGIN
  DBMS_OUTPUT.enable;
EXCEPTION
  WHEN ZERO_DIVIDE THEN
    DBMS.output('division by zero');
-- <yes> <report> PLSQL_ERROR_HANDLING_EMPTY_CATCH d4baa3
  WHEN OTHERS THEN
    NULL;
    --DBMS.output('unknown error');
DECLARE
      d VARCHAR2(1);
    BEGIN
      DBMS_OUTPUT.enable;
    EXCEPTION
    -- <yes> <report> PLSQL_ERROR_HANDLING_EMPTY_CATCH nrjwka
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
END;
