CREATE PROCEDURE test_network AUTHID CURRENT_USER
AS
   reply UTL_SMTP.REPLY;
BEGIN
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000 <yes> <report> PLSQL_HTTP_USAGE http01
  req := utl_http.begin_request('http://www.example.com');
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000 <yes> <report> PLSQL_HTTP_USAGE http01
  url := 'http://url.url';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000 <yes> <report> PLSQL_HTTP_USAGE http01
  url1 := 'http://1.1.1.1';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna001 <yes> <report> PLSQL_HTTP_USAGE httpl1
  url2 := 'http://localhost';
  -- <no> <report>
  url3 := xml('http://1.1.1.1');
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000 <yes> <report> PLSQL_HTTP_USAGE http01
  url4 := cl('http://url.irl');
END;