CREATE PROCEDURE test_default_sid AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_DEFAULT_SID 1095ac
  db_sid := 'DB2PROD';
  -- report any occurrence of a string that matches one of default SIDs
  -- <no> <report>
  db_sid_2 := 'VERYSECURE';
END;
