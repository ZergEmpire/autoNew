CREATE PROCEDURE test_bad_function AUTHID CURRENT_USER AS
BEGIN

-- <yes> <report> PLSQL_BAD_FUNCTION 12128e
  dbms_xmlgen.GETXML();
/* В описании к уязвимости есть только использование 
функции exec_dll_statement и пакета DBMS_XMLGEN, 
по каким именно причинам остальные функции небезопасны непонятно  
<yes> <report> PLSQL_BAD_FUNCTION beabb4
  dbms_aw_xml.execute(clb);

<yes> <report> PLSQL_BAD_FUNCTION 5d4b43
  dbms_pipe.send_message('TESTTEST');
  
<yes> <report> PLSQL_BAD_FUNCTION b1efff
  DBMS_OUTPUT.PUT_LINE(os_command.exec_clob('ls -la /'));
  
<yes> <report> PLSQL_BAD_FUNCTION fd0da0
  DBMS_OUTPUT.PUT_LINE(ctxsys.drithsx.sn(1,query));
  
<yes> <report> PLSQL_BAD_FUNCTION c2020f
  ordsys.ord_dicom_admin_priv(); -- don't care about parameters for now
  
<yes> <report> PLSQL_BAD_FUNCTION b459a3
  sys.kupp$proc.change_user('SYSMANNN');
*/
  -- <yes> <report> PLSQL_BAD_FUNCTION 08128e
  dbms_utility.exec_ddl_statement('create table tab1(col1 number)');
END;
