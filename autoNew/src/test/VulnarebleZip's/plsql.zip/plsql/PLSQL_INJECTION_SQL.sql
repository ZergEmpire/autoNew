--REVOKE EXECUTE ON SYS.DBMS_EXPORT_EXTENSION FROM PUBLIC FORCE;

create procedure test_injection_sql AUTHID CURRENT_USER as
  query varchar2(1024);
begin
    cursor_id := 
    -- <yes> <report> PLSQL_INJECTION_SQL ed33d9
    owa_util.bind_variables(query,
        'cc',cnum,'tt',trm,'ll',lnum);
    -- <yes> <report> PLSQL_INJECTION_SQL 3e64ed
    DBMS_SQL.PARSE(cursor_name, v, DBMS_SQL.NATIVE);
    -- <yes> <report> PLSQL_INJECTION_SQL 8fbca5
    DBMS_ADVISOR.ADD_SQLWKLD_STATEMENT(workload_name, 'MONTHLY', 'ROLLUP',
                                     100,400,5041,103,640445,680000,2,
                                     1,SYSDATE,1,'SHHH',func());
    
    -- DBMS_SYS_SQL
    -- <yes> <report> PLSQL_INJECTION_SQL 00f358    
    sys.dbms_sys_sql.parse_as_user(myint, sqltext, dbms_sql.native, uid);
    
    -- EXECUTE IMMEDIATE
    -- <yes> <report> PLSQL_INJECTION_SQL 1b1bdc
    EXECUTE IMMEDIATE query;
    -- <no> <report>
    EXECUTE IMMEDIATE 'CREATE TABLE bonus (id NUMBER, amt NUMBER)';
    sql_stmt := 'INSERT INTO dept VALUES (:1, :2, :3)';
    -- <no> <report>
    EXECUTE IMMEDIATE sql_stmt USING dept_id, dept_name, location;
    -- <no> <report>
    EXECUTE IMMEDIATE 'SELECT * FROM emp WHERE empno = :id' INTO emp_rec USING emp_id;
    -- <no> <report>
    EXECUTE IMMEDIATE 'BEGIN emp_pkg.raise_salary(:id, :amt); END;' USING 7788, 500;
    
    -- OPEN FOR
    -- <no> <report> PLSQL_INJECTION_SQL d8add4
    OPEN emp_cv FOR 'SELECT ename, sal FROM emp WHERE sal > :s' USING my_sal;
    
    -- EXEC_DDL_STATEMENT
    -- <yes> <report> PLSQL_INJECTION_SQL aa8561 <yes> <report> PLSQL_BAD_FUNCTION 08128e
    DBMS_UTILITY.EXEC_DDL_STATEMENT(query);
    -- <yes> <report> PLSQL_INJECTION_SQL gf8531
    DBMS_AW.INTERP(‘SQLPROCEDUREDBMS_OUTPUT.PUT_LINE(USER)’);

    -- <yes> <report> PLSQL_INJECTION_SQL d2ade6
    ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­
end;

    -- <yes> <report> PLSQL_INJECTION_SQL bb8569 <yes> <report> PLSQL_DEFAULT_CREDENTIALS ba14ee
select SYS.DBMS_EXPORT_EXTENSION.GET_DOMAIN_INDEX_TABLES('FOO','BAR','DBMS_OUTPUT".PUT(:P1);EXECUTE IMMEDIATE ''DECLAREPRAGMA AUTONOMOUS_TRANSACTION;BEGIN EXECUTE IMMEDIATE '''' grant dba to public'''';END;'';END;-- ','SYS',0,'1',0) 
        from dual

-- <yes> <report> PLSQL_INJECTION_SQL bg85h3
SELECT APEX_ITEM.POPUPKEY_FROM_QUERY (1,deptno, query) dt 
FROM emp

-- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
CREATE OR REPLACE PROCEDURE ckpwd (p_user IN VARCHAR2, p_pass IN VARCHAR2)
IS
 v_query  VARCHAR2(100);
 v_output NUMBER;
BEGIN
 v_query :=    q'{SELECT COUNT(*) FROM user_pwd }'
         ||    q'{WHERE username = '}'
         ||    p_user
         ||    q'{' AND password = '}'
         ||    p_pass
         ||    q'{'}';
         -- <yes> <report> PLSQL_INJECTION_SQL 1b1bdc
 EXECUTE IMMEDIATE v_query
  INTO v_output;
END;

-- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
CREATE OR REPLACE PROCEDURE ckpwd_bind (p_user IN VARCHAR2, p_pass IN VARCHAR2)
IS
 v_query  VARCHAR2(100);
 v_output NUMBER;
BEGIN
 v_query :=
   q'{SELECT COUNT(*) FROM user_pwd WHERE username = :1 AND password = :2}';
   -- <yes> <report> PLSQL_INJECTION_SQL 1b1bdc
 EXECUTE IMMEDIATE v_query
  INTO v_output
  USING p_user, p_pass;
END;

-- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
CREATE OR REPLACE PROCEDURE ckpwd_bind (p_user IN VARCHAR2, p_pass IN VARCHAR2)
IS
 v_query  VARCHAR2(100);
 v_output NUMBER;
BEGIN
   -- <yes> <report> PLSQL_INJECTION_SQL 3b1bdc <yes> <report> PLSQL_CONCATENATION 54acad
 EXECUTE IMMEDIATE  'SELECT '
|| field
|| ' FROM tb_purchases WHERE customer = :customer'
USING customer;
END;

CREATE OR REPLACE -- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
FUNCTION fn_getUser (login IN VARCHAR2, password IN VARCHAR2)
RETURN cursorresult.cur
IS
cur cursorresult.cur;
BEGIN  -- <yes> <report> PLSQL_INJECTION_SQL 2b1bdr
OPEN cur FOR 'SELECT * FROM tb_users WHERE login = '''
|| login
|| ''' AND password = '''
|| getSHA1(password)
|| '''';
RETURN cur;
END fn_getUser;

BEGIN -- <no> <report> 
OPEN cur FOR 'SELECT * FROM tb_users WHERE login = '''
|| ''' AND password = '''
|| '''';
RETURN cur;
END fn_getUser;

CREATE OR REPLACE -- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
FUNCTION fn_getUser (login IN VARCHAR2, password IN VARCHAR2)
RETURN cursorresult.cur
IS
cur cursorresult.cur;

BEGIN -- <no> <report>
OPEN cur FOR 'SELECT * FROM tb_users WHERE login = :login AND password = :passwordhash'
USING login, getSHA1(password);
RETURN cur;
END fn_getUser;

CREATE OR REPLACE -- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
FUNCTION fn_customSelect(field IN VARCHAR2, customer IN VARCHAR2) RETURN cursorresult.cur
IS
res cursorresult.cur;
BEGIN -- <yes> <report> PLSQL_INJECTION_SQL 3b1bdr
OPEN res FOR 'SELECT '
|| field
|| ' FROM tb_purchases WHERE customer = :customer'
USING customer;
RETURN res;
END fn_customSelect;