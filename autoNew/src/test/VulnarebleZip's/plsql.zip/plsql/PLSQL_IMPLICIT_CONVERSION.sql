CREATE PROCEDURE conversion_test (START_DATE IN DATE) AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_IMPLICIT_CONVERSION bbd732
  END_DATE := TO_DATE(TRUNC(LAST_DAY(START_DATE)), 'DD-MON-RRRR');
  
  -- <no> <report>
  TO_DATE('20160531','YYYYMMDD');
  -- <yes> <report> PLSQL_IMPLICIT_CONVERSION 22965d
  TO_DATE('08-JUN-16');  -- don't use default date format, it may change
  
  -- <yes> <report> PLSQL_IMPLICIT_CONVERSION fb7513
  bad_conv := 'foo ' || some_date || ' bar';
  -- <no> <reprort>
  OK_CONV := 'FOO ' || var || ' bar';
END;
