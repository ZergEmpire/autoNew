create PROCEDURE test_dos AUTHID CURRENT_USER AS
BEGIN
  sleep(100);
  -- <yes> <report> PLSQL_DOS eab350
  sleep(s);
  dbms_lock.sleep(200);
  -- <yes> <report> PLSQL_DOS c2b083
  DBMS_OUTPUT.PUT_LINE(dbms_lock.sleep(ss));
  -- <yes> <report> PLSQL_DOS c2b083
  DBMS_LOCK.sleep(TO_NUMBER(util.trim(util.cutout(v_sleep_cond, ':', '', strict => TRUE))));
  
  -- <yes> <report> PLSQL_DOS 72fbdd
  DBMS_SCHEDULER.set_attribute(
    name=>'event_raising_job',
    attribute=>'max_run_duration',
    value=>interval tainted second
    );
  -- <no> <report>
  DBMS_SCHEDULER.set_attribute(
    name=>'event_raising_job',
    attribute=>'max_run_duration',
    value=>interval '60' second
    );
END test_dos;
