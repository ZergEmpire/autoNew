CREATE PROCEDURE test_deadcode AUTHID CURRENT_USER
AS
   reply UTL_SMTP.REPLY;
BEGIN
    IF TRUE THEN
        do_something;
    END IF;
-- <yes> <report> PLSQL_BACKDOOR_DEAD_CODE fwerkf
    IF FALSE THEN
        do_something_else;
    END IF;

    IF smth=FALSE THEN
        do_something_else;
    END IF;

END;