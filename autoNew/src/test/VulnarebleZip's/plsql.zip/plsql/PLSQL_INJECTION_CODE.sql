CREATE PROCEDURE test_injection_code AUTHID CURRENT_USER AS
DECLARE
BEGIN
  -- FIXME: incorrect parsing of CREATE
  
  -- C  
  CREATE OR REPLACE FUNCTION ext_func_c () 
  RETURN BINARY_INTEGER AS EXTERNAL LIBRARY ext_lib
    NAME "ext_func"  -- quotes preserve lower case
  LANGUAGE C;
  
  CREATE OR REPLACE LIBRARY DS_Lib AS  
     '/data_cartridge_dir/libdatastream.so';
  
  -- Java  
  CREATE JAVA CLASS USING BFILE (dir, 'some.class');
  
END;