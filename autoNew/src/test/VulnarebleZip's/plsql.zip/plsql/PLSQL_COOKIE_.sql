CREATE PROCEDURE test_cookie AUTHID CURRENT_USER AS
BEGIN
-- <yes> <report> PLSQL_COOKIE_BROAD_DOMAIN d41b7f
OWA_COOKIE.SEND(
           NAME => 'cookie_name',
           VALUE => cookie_value,
           EXPIRES => SYSDATE + INTERVAL '5' MINUTE,
           PATH => '/app',
           DOMAIN => '.example.com',    -- _BROAD_DOMAIN
           SECURE => TRUE,
           HTTPONLY => TRUE);
           
-- <yes> <report> PLSQL_COOKIE_BROAD_PATH 5a06e0
DBMS_OUTPUT.PUT_LINE(OWA_COOKIE.SEND(
           NAME => 'cookie_name',
           VALUE => cookie_value,
           EXPIRES => SYSDATE + INTERVAL '5' MINUTE,
           PATH => '/',                     -- _BROAD_PATH
           DOMAIN => 'www.example.com',
           SECURE => TRUE,
           HTTPONLY => TRUE));

-- <yes> <report> PLSQL_COOKIE_NOT_HTTPONLY 8b2ed4
OWA_COOKIE.SEND(
           NAME => 'cookie_name',
           VALUE => cookie_value,
           EXPIRES => SYSDATE + INTERVAL '5' MINUTE,
           PATH => '/app',
           SECURE => TRUE,
           DOMAIN => 'www.example.com',
           HTTPONLY => FALSE);   -- FALSE or not defined (NULL by default)

-- <yes> <report> PLSQL_COOKIE_NOT_OVER_SSL 28c5c9
OWA_COOKIE.SEND(
           NAME => 'cookie_name',
           VALUE => cookie_value,
           EXPIRES => SYSDATE + INTERVAL '5' MINUTE,
           PATH => '/app',
           DOMAIN => 'www.example.com',
           SECURE => NULL,      -- FALSE or not defined (NULL by default)
           HTTPONLY => TRUE);

-- <yes> <report> PLSQL_COOKIE_PERSISTENT b0209c
OWA_COOKIE.SEND(
           NAME => 'cookie_name',
           VALUE => cookie_value,
           EXPIRES => SYSDATE + INTERVAL '20' MINUTE,   -- max 15 min; inf by default
           PATH => '/app',
           DOMAIN => 'www.example.com',
           SECURE => TRUE,
           HTTPONLY => TRUE);

-- <no> <report>
OWA_COOKIE.SEND(
           NAME => 'cookie_name',
           VALUE => cookie_value,
           EXPIRES => SYSDATE + INTERVAL '5' MINUTE,  -- _PERSISTENT --  default: never expire; max secure is 15 min
           PATH => '/app',                 -- _BROAD_PATH
           DOMAIN => 'www.example.com',    -- _BROAD_DOMAIN
           SECURE => TRUE,              -- _NOT_OVER_SSL    -- default: NULL
           HTTPONLY => TRUE);           -- _NOT_HTTPONLY    -- default: NULL
END;



























