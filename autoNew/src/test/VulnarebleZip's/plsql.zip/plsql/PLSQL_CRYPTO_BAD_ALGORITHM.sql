CREATE PROCEDURE test AUTHID CURRENT_USER AS
DECLARE
BEGIN
  -- <yes> <report> PLSQL_CRYPTO_BAD_ALGORITHM 893jwk
  dbms_crypto.encrypt( l_src, dbms_crypto.ENCRYPT_DES);
  -- <yes> <report> PLSQL_CRYPTO_BAD_ALGORITHM 45c220
  DBMS_OUTPUT.PUT_LINE(DBMS_OBFUSCATION_TOOLKIT.desencrypt());
  -- <yes> <report> PLSQL_CRYPTO_BAD_ALGORITHM 893jwk
  PLS_INTEGER := DBMS_CRYPTO.ENCRYPT_DES
                           + DBMS_CRYPTO.CHAIN_CBC
                           + DBMS_CRYPTO.PAD_PKCS5;
END;