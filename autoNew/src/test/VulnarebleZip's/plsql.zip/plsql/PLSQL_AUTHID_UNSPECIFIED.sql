-- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
CREATE FUNCTION test
RETURN NUMBER
AS
BEGIN
  DBMS_OUTPUT.enable;
  EXECUTE IMMEDIATE 'drop table students';
  RETURN 0;
END test;
/
CREATE OR REPLACE PROCEDURE create_dept (

    v_deptno NUMBER,
    v_dname  VARCHAR2,
    v_mgr    NUMBER,
    v_loc    NUMBER)
    AUTHID CURRENT_USER AS
BEGIN
    INSERT INTO departments.a VALUES (v_deptno, v_dname, v_mgr, v_loc);
END;
/
-- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 65c6d5
CREATE OR REPLACE PROCEDURE create_dept (

    v_deptno NUMBER,
    v_dname  VARCHAR2,
    v_mgr    NUMBER,
    v_loc    NUMBER)
AS
BEGIN
    INSERT INTO departments VALUES (v_deptno, v_dname, v_mgr, v_loc);
END;
/