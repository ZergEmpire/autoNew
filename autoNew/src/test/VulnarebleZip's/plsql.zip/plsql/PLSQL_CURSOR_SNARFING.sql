CREATE OR REPLACE PROCEDURE PWD_COMPARE(P_USER VARCHAR) 
AUTHID CURRENT_USER 
IS
    CURSOR_NAME INTEGER;
    V_PWD VARCHAR2(30);
    I INTEGER;
BEGIN
    -- <yes> <report> PLSQL_CURSOR_SNARFING ba5841
    CURSOR_NAME := DBMS_SQL.OPEN_CURSOR;                -- opening cursor
    DBMS_OUTPUT.PUT_LINE('CURSOR: ' ||CURSOR_NAME);     -- what if exception happens here
    DBMS_SQL.CLOSE_CURSOR(CURSOR_NAME);                 -- cursor is never closed
    
    EXCEPTION WHEN BLAH THEN
        IF DBMS_SQL.IS_OPEN(CURSOR_NAME) THEN
            DBMS_SQL.CLOSE_CURSOR(CURSOR_NAME);         -- close cursor in EXCEPTION WHEN OTHERS
        END IF;

END;


create function build_cursor(
    q in varchar2,
    n in owaSylkArray,
    v in owaSylkArray ) return integer
AUTHID CURRENT_USER 
is
  -- <yes> <report> PLSQL_CURSOR_SNARFING ba5841
  c integer := dbms_sql.open_cursor;
  i number := 1;
begin
  DBMS_OUTPUT.PUT_LINE('CURSOR: ' ||CURSOR_NAME);
  return c;
end build_cursor;
-- <yes> <report> PLSQL_AUTHID_UNSPECIFIED 9442f6 <yes> <report> PLSQL_GLOBAL_CURSOR 7sjfa8
CREATE OR REPLACE PACKAGE SECCHECK AS CURSOR X (USERNAME IN VARCHAR2) IS SELECT PASSWORD FROM SYS.USER$
WHERE NAME=USERNAME;
PROCEDURE CHECK_PASSWORD;
END; 