CREATE PROCEDURE test_download_file AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_TRUST_BOUNDARY_VIOLATION 3dea02
  htmldb_util.set_session_state(a);
  -- <yes> <report> PLSQL_TRUST_BOUNDARY_VIOLATION 3dea02
  apex_util.set_session_state(b);
END test_download_file;