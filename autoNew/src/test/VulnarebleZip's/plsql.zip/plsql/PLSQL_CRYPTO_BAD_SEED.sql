CREATE PROCEDURE test_rand AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_CRYPTO_BAD_SEED 61dc5a
  dbms_random.initialize(1234);
  -- <yes> <report> PLSQL_CRYPTO_BAD_SEED 61dc5a
  dbms_random.seed('qwer');
  -- <yes> <report> PLSQL_CRYPTO_BAD_SEED 61dc5a
  DBMS_OUTPUT.PUT_LINE(dbms_random.seed(421));
  -- <no> <report>
  dbms_random.seed;
END test_rand;