CREATE PROCEDURE test_injection_command AUTHID CURRENT_USER AS
DECLARE
BEGIN
  action := 'BEGIN DBMS_STATS.GATHER_TABLE_STATS(''oe'',''sales''); END;';
  -- <yes> <report> PLSQL_INJECTION_COMMAND cd2cdd
  DBMS_SCHEDULER.CREATE_JOB (
   job_name             => 'oe.my_job1',
   job_type             => 'PLSQL_BLOCK',
   job_action           => action,  -- who knows where this came from?
   start_date           => '15-JUL-08 1.00.00AM US/Pacific',
   repeat_interval      => 'FREQ=DAILY', 
   end_date             => '15-SEP-08 1.00.00AM US/Pacific',
   enabled              =>  TRUE,
   comments             => 'Gather table statistics');
 
  foo := '26-MAY-16';
  sd := foo || ' 1.00.00AM US/Pacific';
  -- <yes> <report> PLSQL_INJECTION_COMMAND cd2cdd
  DBMS_SCHEDULER.CREATE_JOB (
    job_name            =>  'my_job',
    program_name        =>  'my_program',
    start_date          =>  sd,
    event_condition     =>  'tab.user_data.event_name = ''FILE_ARRIVAL''',
    queue_spec          =>  'my_events_q',
    enabled             =>  TRUE,
    comments            =>  'my event-based job');
 
  -- <yes> <report> PLSQL_INJECTION_COMMAND 0d0eb9
  DBMS_SCHEDULER.ENABLE(PROG1);

  -- <yes> <report> PLSQL_INJECTION_COMMAND 0d0eb9
  DBMS_OUTPUT.PUT_LINE(DBMS_SCHEDULER.CREATE_JOBS(newjobarr, 'TRANSACTIONAL'));
  
  -- <yes> <report> PLSQL_INJECTION_COMMAND 5f2f4d
  DBMS_SCHEDULER.CREATE_JOB_CLASS (
    job_class_name              =>  'my_class1',
    service                     =>  my_service1, 
    comments                    =>  'This is my first job class');
   
  -- <yes> <report> PLSQL_INJECTION_COMMAND 49eaa5
  DBMS_SCHEDULER.CREATE_PROGRAM (
    program_name           => 'oe.my_saved_program1',
    program_action         => dangerous_path,
    program_type           => 'EXECUTABLE',
    comments               => 'My comments here');
   
  -- <yes> <report> PLSQL_INJECTION_COMMAND f13b5b
   DBMS_SCHEDULER.SET_ATTRIBUTE (
   name           =>   'my_emp_job1',
   attribute      =>   'start_date',
   value          =>   dangerous_value);
  
  dangerous_value := 0;
  -- <yes> <report> PLSQL_INJECTION_COMMAND e5930c
  DBMS_SCHEDULER.SET_SCHEDULER_ATTRIBUTE (
   attribute     =>   log_history,
   value         =>   dangerous_value);
   
  -- <yes> <report> PLSQL_INJECTION_COMMAND 75de27
   DBMS_SCHEDULER.SET_JOB_ATTRIBUTES(start_date, dangerous_value);
   
   DBMS_SCHEDULER.CREATE_CHAIN (
   chain_name            =>  'my_chain1',
   rule_set_name         =>  NULL,
   evaluation_interval   =>  NULL,
   comments              =>  NULL);
  
  tainted_program := 'my_program1';
  -- <yes> <report> PLSQL_INJECTION_COMMAND e24543
  DBMS_SCHEDULER.DEFINE_CHAIN_STEP('my_chain1', 'stepA', tainted_program);
  tainted_rule := 'START stepA';
  -- <yes> <report> PLSQL_INJECTION_COMMAND e24543
  DBMS_SCHEDULER.DEFINE_CHAIN_RULE('my_chain1', 'TRUE', tainted_rule);
  DBMS_SCHEDULER.ENABLE('my_chain1');
  
  -- <yes> <report> PLSQL_INJECTION_COMMAND 3a4710 <yes> <report> PLSQL_INJECTION_COMMAND d43945
  DBMS_SCHEDULER.CREATE_EVENT_SCHEDULE (
   schedule_name     =>  'scott.file_arrival',
   start_date        =>  systimestamp,
   event_condition   =>  tainted_event,
   queue_spec        =>  'my_events_q');
   
  -- <yes> <report> PLSQL_INJECTION_COMMAND d43945
   DBMS_SCHEDULER.CREATE_EVENT_SCHEDULE (
   schedule_name     =>  'scott.file_arrival',
   start_date        =>  not_systimestamp,
   event_condition   =>  'tab.user_data.object_owner = ''SCOTT'' 
      and tab.user_data.event_name = ''FILE_ARRIVAL'' 
      and extract hour from tab.user_data.event_timestamp < 9',
   queue_spec        =>  'my_events_q');
     
END;























