CREATE PROCEDURE test_download_file AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_INJECTION_RESOURCE 357613
  wpg_docload.download_file(bad_url);
  -- <yes> <report> PLSQL_INJECTION_RESOURCE a7eb2a
  download_file(bad_url);
END test_download_file;