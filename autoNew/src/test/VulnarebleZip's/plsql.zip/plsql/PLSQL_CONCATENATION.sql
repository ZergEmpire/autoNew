CREATE FUNCTION concat_test RETURN VARCHAR AUTHID CURRENT_USER AS
    v_c varchar2(200);
    v_d varchar2(200);
BEGIN
    -- <yes> <report> PLSQL_CONCATENATION 9e99f1
    v_c := 'select col1 from ' || p_filename;
    -- <yes> <report> PLSQL_CONCATENATION be9527
    v_d := CONCAT('select col2 from ', p_filename);

  tainted := 'STUDENTS';
  -- <yes> <report> PLSQL_CONCATENATION be9527
  query := CONCAT('DROP TABLE', tainted);
  -- <yes> <report> PLSQL_CONCATENATION 9e99f1
  query2 := 'SELECT * FROM table ' || tainted;
  -- <no> <report>
  s := 'qwe' || 'rty';
  -- <yes> <report> PLSQL_CONCATENATION 9e99f1
  SQLQUERY.query := 'drop table ' || tainted || ' WHERE id = 3';
  
  -- <yes> <report> PLSQL_CONCATENATION e0c07b
  SELECT a.mailbox ||'@'|| a.host, 'email', NULL
    FROM sch.address a
    WHERE message_stat_from.addr = a.id;
   -- <yes> <report> PLSQL_INJECTION_SQL 2b1bdc
  EXECUTE IMMEDIATE
  -- <yes> <report> PLSQL_CONCATENATION 54acad
    'select archived from part_mgr_ where part_no=' || p_no
  into v_res;
  
  -- <no> <report>
  SELECT * FROM TABLE(CAST(p_person AS Num_List));
  
  
END;