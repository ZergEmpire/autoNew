CREATE PROCEDURE test_obsolete AUTHID CURRENT_USER AS
DECLARE
 -- <yes> <report> PLSQL_OBSOLETE rgdskr
  foo MLSLABEL;
BEGIN
    -- <yes> <report> PLSQL_OBSOLETE e1f40c
    DBMS_JOB.RUN(1543);
    -- report every DBMS_JOB call: it is deprecated in favor of DBMS_SCHEDULER

    -- <no> <report>
    FOR dept IN (
    SELECT t1.department_id, department_name, staff
    FROM departments t1,
    ( SELECT department_id, COUNT(*) AS staff
    FROM employees
    GROUP BY department_id
    ) t2
    WHERE (t1.department_id = t2.department_id) AND staff >= 5
    ORDER BY staff
    )
    LOOP
    DBMS_OUTPUT.PUT_LINE ('Department = ' || dept.department_name || ', staff = ' || dept.staff);
    END LOOP;
END;

-- https://www.techonthenet.com/oracle/loops/cursor_for.php
