CREATE PROCEDURE test AUTHID CURRENT_USER AS
DECLARE
BEGIN
  -- <yes> <report> PLSQL_CRYPTO_KEY_EMPTY 68fea0
  veryImportantKey2 := '';
  -- <yes> <report> PLSQL_CRYPTO_KEY_HARDCODED ca3f94
  okey := 'qwerty';
  -- <yes> <report> PLSQL_CRYPTO_KEY_NULL 9e8d44
  key123 := NULL;  
  -- <yes> <report> PLSQL_CRYPTO_KEY_HARDCODED serdgd
  encrypted_raw := DBMS_CRYPTO.ENCRYPT
      (
         src => UTL_I18N.STRING_TO_RAW (input_string,  'AL32UTF8'),
         typ => encryption_type,
         key => 'key',
         iv => iv
      ); 
  -- <yes> <report> PLSQL_CRYPTO_KEY_NULL sfrpak
  encrypted_raw := DBMS_CRYPTO.ENCRYPT
      (
         src => UTL_I18N.STRING_TO_RAW (input_string,  'AL32UTF8'),
         typ => encryption_type,
         key => NULL,
         iv => iv
      );
  -- <yes> <report> PLSQL_CRYPTO_KEY_HARDCODED 45c00h
  Dbms_Obfuscation_Toolkit.DES3Encrypt ( input_string => input_string
                                          ,key_string => 'key_string'
                                          ,encrypted_string => encrypted_string
                                         );
  END;
