CREATE PROCEDURE test_network AUTHID CURRENT_USER
AS
   reply UTL_SMTP.REPLY;
BEGIN
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  req := utl_http.begin_request('https://www.example.com');
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url := 'https://url.url';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url1 := 'https://1.1.1.1';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna001
  url2 := 'https://localhost';
  -- <no> <report>
  url3 := xml('https://1.1.1.1');
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url4 := cl('https://url.irl');
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url1 := 'https://1.1.1.1/less';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url1 := 'https://[::1]';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url1 := 'https://[1762:0:0:0:0:B03:1:AF18]';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url1 := 'https://[fe80::219:7eff:fe46:6c42]';
  -- <yes> <report> PLSQL_BACKDOOR_NETWORK_ACTIVITY bna000
  url1 := 'https://[2001:0db8:0000:0000:0000:ff00:0042:8329]';

END;