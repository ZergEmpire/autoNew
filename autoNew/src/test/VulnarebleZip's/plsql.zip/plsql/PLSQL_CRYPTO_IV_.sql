CREATE PROCEDURE test AUTHID CURRENT_USER AS
DECLARE
BEGIN
  -- <yes> <report> PLSQL_CRYPTO_IV_HARDCODED ffdddd
  encrypted_raw := DBMS_CRYPTO.ENCRYPT
      (
         src => UTL_I18N.STRING_TO_RAW (input_string,  'AL32UTF8'),
         typ => encryption_type,
         key => key_bytes_raw,
         iv => 'qwerty'
      );
END;
