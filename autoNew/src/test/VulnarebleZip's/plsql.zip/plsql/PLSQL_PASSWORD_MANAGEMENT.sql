create procedure test01 AUTHID CURRENT_USER as
BEGIN
  -- <yes> <report> PLSQL_PASSWORD_MANAGEMENT 14278f
  DBMS_OUTPUT.PUT_LINE(owa_sec.get_password);
END test01;

create procedure test01 AUTHID CURRENT_USER as
BEGIN
v_handle := UTL_FILE.Fopen (
                      'v_location',
                      'v_filename',
                      'w',
                      32767 );
                      
        -- <yes> <report> PLSQL_PASSWORD_MANAGEMENT 14278f
         UTL_FILE.put_line(v_handle, owa_sec.get_password); 
        
         UTL_FILE.FClose(v_handle);
END test01;

create procedure test02 AUTHID CURRENT_USER as
BEGIN
  -- <yes> <report> PLSQL_PASSWORD_MANAGEMENT 14278f
  owa_sec.get_password;
END test02;

  CREATE PROFILE prof LIMIT
   FAILED_LOGIN_ATTEMPTS 4
-- <yes> <report> PLSQL_PASSWORD_MANAGEMENT sqlpm2
   PASSWORD_LOCK_TIME 29
-- <yes> <report> PLSQL_PASSWORD_MANAGEMENT sqlpm3
   PASSWORD_LIFE_TIME 91
-- <yes> <report> PLSQL_PASSWORD_MANAGEMENT sqlpm4
   PASSWORD_REUSE_TIME 2
-- <yes> <report> PLSQL_PASSWORD_MANAGEMENT sqlpm5
   PASSWORD_REUSE_MAX 9;

  CREATE PROFILE very_bad_prof LIMIT
-- <yes> <report> PLSQL_PASSWORD_MANAGEMENT sqlpm0
    PASSWORD_REUSE_TIME UNLIMITED
    PASSWORD_REUSE_TIME 1;
