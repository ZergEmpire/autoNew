CREATE PROCEDURE file_access_test AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_FILE_ACCESS dce0c9
  utl_file.fopen(dir, file1, 'W');
  --f := utl_file.fopen(dir, file1, 'W');
  
  -- <yes> <report> PLSQL_FILE_ACCESS 9ea7d3
  dbms_lob.fileopen( l_bfile );
  EXCEPTION WHEN OTHERS THEN dbms_lob.fileclose( l_bfile );
  
  -- <yes> <report> PLSQL_FILE_ACCESS d2729e
  DBMS_ADVISOR.CREATE_TASK(adv, task_id, task_name);
  
  -- <yes> <report> PLSQL_FILE_ACCESS aed198
  DBMS_OUTPUT.PUT_LINE(file_pkg.get_file('/tmp'));
    
END;
