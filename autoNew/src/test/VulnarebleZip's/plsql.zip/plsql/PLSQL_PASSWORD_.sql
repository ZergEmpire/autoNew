CREATE PROCEDURE test AUTHID CURRENT_USER AS
DECLARE
  password1 varchar2(25);
  password2 varchar2(25);
  password3 varchar2(25);
BEGIN
  -- <yes> <report> PLSQL_PASSWORD_NULL rwjksd
  password1 := NULL;
  -- <yes> <report> PLSQL_PASSWORD_EMPTY 85f093
  password2 := '';
  -- <yes> <report> PLSQL_PASSWORD_HARDCODED 452d80
  password3 := 'qwerty';
  -- <yes> <report> PLSQL_PASSWORD_HARDCODED 452d8t
  password_field := 'qwe rty';
  
  -- FIXME: incorrect parsing
  -- <todo> <report> PLSQL_PASSWORD_NULL
--   ALTER USER user1 IDENTIFIED BY NULL;
  -- <todo> <report> PLSQL_PASSWORD_EMPTY
--   CREATE USER user2 IDENTIFIED BY '';
  -- <todo> <report> PLSQL_PASSWORD_HARDCODED
--   CREATE USER user3 IDENTIFIED BY 'new_password';

--     ip_address := OWA_SEC.get_client_ip;

    -- <yes> <report> PLSQL_PASSWORD_MANAGEMENT 14278f <yes> <report> PLSQL_PASSWORD_HARDCODED r5l5sd
    IF OWA_SEC.get_password = 'pwejrijef' THEN
    RETURN TRUE;
    ELSE
    RETURN FALSE;
    END IF;
    -- <yes> <report> PLSQL_PASSWORD_MANAGEMENT 14278f <yes> <report> PLSQL_PASSWORD_HARDCODED r5l5st
    IF OWA_SEC.get_password = 'pwejr ijef' THEN
    RETURN TRUE;
    ELSE
    RETURN FALSE;
    END IF;

    ip_address := OWA_SEC.get_client_ip;
    -- <yes> <report> PLSQL_PASSWORD_HARDCODED r5l5sd
    IF ((password1 = 'pwejrijef') AND
    (ip_address(1) = 144) and (ip_address(2) = 25)) THEN
    RETURN TRUE;
    ELSE
    RETURN FALSE;
    END IF;
    -- <yes> <report> PLSQL_PASSWORD_HARDCODED r5l5st
    IF ((password_field = 'pwejr ijef') AND
    (ip_address(1) = 144) and (ip_address(2) = 25)) THEN
    RETURN TRUE;
    ELSE
    RETURN FALSE;
    END IF;

END;
