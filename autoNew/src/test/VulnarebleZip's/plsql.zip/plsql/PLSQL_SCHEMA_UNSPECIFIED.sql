CREATE PROCEDURE no_schema_test1
AUTHID CURRENT_USER
AS
BEGIN
  -- <yes> <report> PLSQL_SCHEMA_UNSPECIFIED 5bfc6e
  UPDATE people SET FM = 'foobar' WHERE FM IS NULL;
  -- <no> <report>
  SELECT * INTO var2 FROM s.user_tables;
END;

CREATE FUNCTION no_schema_test2
RETURN NUMBER
AUTHID DEFINER
AS
BEGIN
  -- <no> <report>
  SELECT * INTO var FROM user_tables;
  RETURN 0;
END;