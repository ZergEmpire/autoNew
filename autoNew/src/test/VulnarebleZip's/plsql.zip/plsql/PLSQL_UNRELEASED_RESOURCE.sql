CREATE OR REPLACE PROCEDURE PWD_COMPARE(P_USER VARCHAR) 
AUTHID CURRENT_USER 
IS
BEGIN
    -- <yes> <report> PLSQL_UNRELEASED_RESOURCE 92116f <yes> <report> PLSQL_FILE_ACCESS 9ea7d3
    dbms_lob.fileopen (handle, dbms_lob.lob_readwrite);
    DBMS_OUTPUT.PUT_LINE('EXCEPTIONAL');    -- what if exception happens here
    dbms_lob.fileclose(handle);                 -- cursor is never closed
    EXCEPTION WHEN BLAH THEN
        IF dbms_lob.fileisopen(handle) THEN
            dbms_lob.fileclose(handle);         -- close cursor in EXCEPTION WHEN OTHERS
        END IF;
        /*
    EXCEPTION WHEN OTHERS THEN
        dbms_lob.fileclose(handle);
        */
END; 
