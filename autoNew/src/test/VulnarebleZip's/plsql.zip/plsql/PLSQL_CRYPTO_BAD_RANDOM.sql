create procedure dsql2(tcl in varchar2) AUTHID CURRENT_USER as
  query varchar2(1024);
begin
    -- <yes> <report> PLSQL_CRYPTO_BAD_RANDOM 21dc5a
    DBMS_UTILITY.dosmth(dbms_random.random);
    -- <yes> <report> PLSQL_CRYPTO_BAD_RANDOM 21dc5a
    dbms_random.NORMAL;
end dsql2;