CREATE PROCEDURE leak_test1 AUTHID CURRENT_USER AS
BEGIN
  -- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL ba1716
  print_cgi_env;
  -- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL 927bfa
  DBMS_OUTPUT.PUT_LINE(owa_util.print_cgi_env);
  -- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL 689984
  dbms_output.put_line('Error: ' || SQLERRM);
  if CONDITION THEN
    -- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL 689984
    dbms_output.put_line(SQLCODE);
  End IF;
  -- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL 3c2923
  UTL_FILE.PUT(handle, SQLERRM);
-- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL 927bfa
  owa_util.print_cgi_env;
  -- <yes> <report> PLSQL_INFORMATION_LEAK_EXTERNAL 937bfa
  OWA_UTIL.SHOWSOURCE('smth');

  CAST ( expression AS date);

  CONVERT ( varchar ( 20 ) , SYSDATETIME () );
END leak_test1;

