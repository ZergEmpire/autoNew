extern crate chrono;
use chrono::offset::{TimeZone, Utc};

fn main( ) {
    let utc = Utc;
    let date = Utc::now();
    // <yes> <report> RUST_BACKDOOR_TIMEBOMB time01
    if (date >= Utc.datetime_from_str(&"2020 01 10 02:19:17", "%Y %m %d %H:%M:%S").unwrap()) {
        print!("Something bad");
    }
}