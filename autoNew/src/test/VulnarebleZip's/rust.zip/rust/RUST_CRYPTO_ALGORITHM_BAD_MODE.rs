use rand::Rng;

fn main() {
    use aes::Aes128;
    use block_modes::{BlockMode, Ecb};
    use block_modes::block_padding::Pkcs7;

    // <yes> <report> RUST_CRYPTO_ALGORITHM_BAD_MODE cabm01
    type Aes128Cbc = Ecb<Aes128, Pkcs7>;
    // <yes> <report> RUST_CRYPTO_ALGORITHM_BAD_MODE cabm01
    type Aes128Cbc = block_modes::Ecb<Aes128, Pkcs7>;
}