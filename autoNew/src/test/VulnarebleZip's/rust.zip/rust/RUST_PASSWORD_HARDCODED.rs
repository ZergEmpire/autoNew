fn main( ) {
// <yes> <report> RUST_PASSWORD_HARDCODED 000003
    let my_password = "admin";
// <yes> <report> RUST_PASSWORD_HARDCODED 000003
    let mut my_password = "admin";
// <yes> <report> RUST_PASSWORD_HARDCODED 000004
    let password = "admin";
// <yes> <report> RUST_PASSWORD_HARDCODED 000004
    let mut password = "admin";
// <yes> <report> RUST_PASSWORD_HARDCODED 00003t
    let my_password = "adm in";
// <yes> <report> RUST_PASSWORD_HARDCODED 00003t
    let mut my_password = "adm in";
// <yes> <report> RUST_PASSWORD_HARDCODED 00004t
    let password = "adm in";
// <yes> <report> RUST_PASSWORD_HARDCODED 00004t
    let mut password = "adm in";
}