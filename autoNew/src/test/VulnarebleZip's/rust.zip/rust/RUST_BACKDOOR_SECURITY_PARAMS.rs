fn main () {
    // <yes> <report> RUST_BACKDOOR_SECURITY_PARAMS gr0008
    if login = "user1"
	    { print!("hello"); }
    // <yes> <report> RUST_BACKDOOR_SECURITY_PARAMS gr0008
    while authorized = "user1"
	    { print!("hello"); }
	// <yes> <report> RUST_BACKDOOR_SPECIAL_ACCOUNT gr0006 <no> <report> RUST_BACKDOOR_SECURITY_PARAMS
	if login == "user1"
    	{ print!("hello"); }
}