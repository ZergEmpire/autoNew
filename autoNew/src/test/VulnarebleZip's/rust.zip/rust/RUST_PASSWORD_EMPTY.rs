fn main( ) {
// <yes> <report> RUST_PASSWORD_EMPTY 000001
    let my_password = "";
// <yes> <report> RUST_PASSWORD_EMPTY 000001
    let mut my_password = "";
// <yes> <report> RUST_PASSWORD_EMPTY 000002
    let password = "";
// <yes> <report> RUST_PASSWORD_EMPTY 000002
    let mut password = "";
}