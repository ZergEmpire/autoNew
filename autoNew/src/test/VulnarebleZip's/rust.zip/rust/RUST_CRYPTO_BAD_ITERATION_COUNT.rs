#[macro_use]
use ring::pbkdf2;
use sha2::Sha256;
use argon2;

fn hash_password(password: &str, salt: &str, output: &mut [u8]) {
    // <yes> <report> RUST_CRYPTO_BAD_ITERATION_COUNT cbic01
    pbkdf2::derive(Sha256, 500, salt,
                   password.as_bytes(), &mut output);
    // <yes> <report> RUST_CRYPTO_BAD_ITERATION_COUNT cbic03
    pbkdf2::derive(Sha256, 5000, salt,
                    password.as_bytes(), &mut output);
    // <yes> <report> RUST_CRYPTO_BAD_ITERATION_COUNT cbic02
    argon2::d_hash_encoded(
        500,
        m_cost,
        parallelism,
        password,
        salt,
        hashlen,
        ouutput
    );
    // <yes> <report> RUST_CRYPTO_BAD_ITERATION_COUNT cbic02
    argon2::d_hash_row(
            500,
            m_cost,
            parallelism,
            password,
            salt,
            output
    );
    // <yes> <report> RUST_CRYPTO_BAD_ITERATION_COUNT cbic04
    argon2::d_hash_row(
            5000,
            m_cost,
            parallelism,
            password,
            salt,
            output
    );
}