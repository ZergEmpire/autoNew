#[macro_use]
use ring::pbkdf2;
use sha2::Sha256;
use argon2::{self, Config};

fn hash_password(password: &str, output: &mut [u8]) {
    // <yes> <report> RUST_CRYPTO_SALT_HARDCODED rcsh01 <yes> <report> RUST_CRYPTO_BAD_ITERATION_COUNT cbic03
    pbkdf2::derive(Sha256, 5000, "salt",
                   password.as_bytes(), &mut output);

    let config = Config::default();
    // <yes> <report> RUST_CRYPTO_SALT_HARDCODED rcsh02
    let hash = argon2::hash_encoded(password, b"randomsalt", &config).unwrap();
}