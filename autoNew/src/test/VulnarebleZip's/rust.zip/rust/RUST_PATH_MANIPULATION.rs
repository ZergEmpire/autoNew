use std::{env, fs, error::Error};

struct Request {
    file: String,
    something_more: i32
}

fn main() -> Result<(), Box<dyn Error>> {
    let request = Request { file: "../".to_string(), something_more: 42 };
    let user_input = request.file;
// <yes> <report> RUST_PATH_MANIPULATION 000013
    std::fs::read("/tmp/".to_string() + user_input);
// <yes> <report> RUST_PATH_MANIPULATION 000013
    fs::read_dir("/tmp/".to_string() + request.file);
// <yes> <report> RUST_PATH_MANIPULATION 000013
    let tmp = fs::read_to_string("path/to/dir/".to_string() + user_input)?;
// <yes> <report> RUST_PATH_MANIPULATION 000013
    fs::rename("/tmp/".to_string() + user_input, "/tmp/".to_string() + user_input);
// <yes> <report> RUST_PATH_MANIPULATION 000013
    fs::write("/tmp/".to_string() + request.file, "content")?;
// <yes> <report> RUST_PATH_MANIPULATION 000013
    fs::remove_dir("path/to/dir/".to_string() + user_input);
// <yes> <report> RUST_PATH_MANIPULATION 000013
    fs::remove_dir_all("path/to/dir/".to_string() + user_input);
// <yes> <report> RUST_PATH_MANIPULATION 000013
    fs::remove_file("path/to/dir/".to_string() + user_input);

    let var = "const";
// <no> <report>
    fs::read("/tmp/".to_string() + var)?;
// <no> <report>
    fs::read("fixed/path")?;
}
