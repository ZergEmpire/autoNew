fn main( ) {
    use std::io::{stdin,stdout,Write};
    // <yes> <report> RUST_LOGGING_SYSTEM_OUTPUT debug01
    print!("Hello, World!");
    // <yes> <report> RUST_LOGGING_SYSTEM_OUTPUT debug02
    io::stdout().write_all(b"hello world")?;
}