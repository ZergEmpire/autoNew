fn main() {
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0018
    let something_secret_key_something = null;
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0018
    let encryption_key = null;
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0019 <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let rc4 = Rc4::new(null);
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0019 <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let blowfish = Blowfish::new(null);
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0020
    let hmac = Hmac::new(digest, null);
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0021
    let blake2b = Blake2b::new_keyed(size, null);
    // <yes> <report> RUST_CRYPTO_KEY_NULL gr0022
    let hc = Hc128::new(null, &nonce);
}