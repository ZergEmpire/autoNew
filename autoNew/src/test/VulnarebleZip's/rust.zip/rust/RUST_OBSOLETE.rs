fn main( ) {
    // <yes> <report> RUST_OBSOLETE obsol01
    use typename::TypeName;
    // <yes> <report> RUST_OBSOLETE obsol02
    use lru_cache_macros::lru_cache;
}