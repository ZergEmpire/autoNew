fn main( ) {
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> RUST_HTTP_USAGE rhhtp0
    let url1 = "http://url.irl";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> RUST_HTTP_USAGE rhhtp0
    let url2 = "http://1.1.1.1";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> RUST_HTTP_USAGE rhhtp0
    let url3 = "http://localhost";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> RUST_HTTP_USAGE rhhtp0
    let mut url4 = cl("http://url.url");
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> RUST_HTTP_USAGE rhhtp0
    let url5: &str = cl("http://localhost");
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> RUST_HTTP_USAGE rhhtp0
    let url6 = String::from("http://1.1.1.1") + "/page";
}