use time::Duration;
use cookie::Cookie;

fn main(){
    // <yes> <report> RUST_COOKIE_PERSISTENT gr0003
    let c1 = Cookie::build("name", "1")
        .domain("example.com")
        .path("/path")
        .secure(true)
        .http_only(true)
        .max_age(Duration::minutes(30))
        .finish();

    // <no> <report>
    let c2 = Cookie::build("name", "1")
        .domain("example.com")
        .path("/path")
        .secure(true)
        .http_only(true)
        .max_age(Duration::minutes(10))
        .finish();

    c2.set_max_age(Duration::hours(10)); //will be added when there will be propagation of type
    c2.make_permanent(); //will be added when there will be propagation of type
}