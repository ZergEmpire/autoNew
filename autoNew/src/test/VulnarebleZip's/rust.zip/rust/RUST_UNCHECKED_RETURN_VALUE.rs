#[macro_use]
extern crate shells;
use std::io::prelude::*;

fn main() {
    // <yes> <report> RUST_UNCHECKED_RETURN_VALUE unch01
    sh!("echo '{} + {}' | cat", 1, 3);
    // <no> <report> RUST_UNCHECKED_RETURN_VALUE unch01
    assert_eq!(wrap_sh!("echo '{} + {}' | cat", 1, 3).unwrap(), "1 + 3\n");
    // <yes> <report> RUST_UNCHECKED_RETURN_VALUE unch01
    wrap_sh!("echo '{} + {}' | cat", 1, 3).unwrap();

    let mut b = "This string will be read".as_bytes();
    let mut buffer = [0; 10];
    // <yes> <report> RUST_UNCHECKED_RETURN_VALUE unch02
    b.read(&mut buffer);
    // <no> <report> RUST_UNCHECKED_RETURN_VALUE unch02
    b.read(&mut buffer).expect("Something wrong!");
    // <no> <report> RUST_UNCHECKED_RETURN_VALUE unch02
    b.read(&mut buffer)?;
    Ok(())
}