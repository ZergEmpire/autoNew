fn main() {
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0009
    let something_secret_key_something = "abc";
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0009
    let encryption_key = 1;
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0011 <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let rc4 = Rc4::new("key".as_bytes());
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0010 <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let blowfish = Blowfish::new(1);
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0012
    let hmac = Hmac::new(digest, 1);
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0015
    let blake2b = Blake2b::new_keyed(size, "key".as_bytes());
    // <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0016
    let hc = Hc128::new(1, &nonce);
}