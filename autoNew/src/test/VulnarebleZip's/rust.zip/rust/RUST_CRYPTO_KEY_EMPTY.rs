fn main() {
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0023
    let something_secret_key_something = "";
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0023
    let encryption_key = "";
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0024 <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let rc4 = Rc4::new("");
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0024 <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let blowfish = Blowfish::new("");
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0025
    let hmac = Hmac::new(digest, "");
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0026
    let blake2b = Blake2b::new_keyed(size, "");
    // <yes> <report> RUST_CRYPTO_KEY_EMPTY gr0027
    let hc = Hc128::new("", &nonce);
}