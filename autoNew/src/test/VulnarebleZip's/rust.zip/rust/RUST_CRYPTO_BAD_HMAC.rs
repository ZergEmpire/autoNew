use rand::Rng;

fn main() {
    use sha2::Sha256;
    use sha1::Sha1;
    use md5::Md5;
    use md2::Md2;
    use md4::Md4;
    use hmac::{Hmac, Mac, NewMac};

    // <no> <report> RUST_CRYPTO_BAD_HMAC rcbh01
    type HmacSha256 = Hmac<Sha256>;
    // <yes> <report> RUST_CRYPTO_BAD_HMAC rcbh01
    type HmacSha256 = Hmac<Sha1>;
    // <yes> <report> RUST_CRYPTO_BAD_HMAC rcbh01
    type HmacMd5 = Hmac<Md5>;
    // <yes> <report> RUST_CRYPTO_BAD_HMAC rcbh01
    type HmacMd4 = Hmac<Md4>;
    // <yes> <report> RUST_CRYPTO_BAD_HMAC rcbh01
    type HmacMd2 = Hmac<Md2>;
    // <yes> <report> RUST_CRYPTO_BAD_HMAC rcbh02 <yes> <report> RUST_CRYPTO_BAD_HASH 000009
    let mut mac= Hmac::new(Sha1::new(), KEY);
    // <no> <report> RUST_CRYPTO_BAD_HMAC rcbh02
    let mut mac= Hmac::new(Sha256::new(), KEY);
}