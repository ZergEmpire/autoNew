use rand::Rng;

fn main() {
    // <yes> <report> RUST_CRYPTO_BAD_RANDOM rand01
    let mut rng = rand::thread_rng();

    let n1: u8 = rng.gen();
    println!("Random u8: {}", n1);
    println!("Random u32: {}", rng.gen::<u32>());
}