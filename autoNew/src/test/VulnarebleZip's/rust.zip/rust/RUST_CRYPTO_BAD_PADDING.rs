extern crate openssl;

use openssl::rsa::{Rsa, Padding};

fn main() {
// <yes> <report> RUST_CRYPTO_KEY_SIZE 000006
    let rsa = Rsa::generate(512).unwrap();
    let data: Vec<u8> = String::from("foobarfoobarfoobarfoobarfoobarfoobarfoobarfoobarfoobarfoobarfoob").into_bytes();
    let mut encrypted_data: Vec<u8>  = vec![0; 512];
// <yes> <report> RUST_CRYPTO_BAD_PADDING badpad
    let _ = rsa.public_encrypt(&data, encrypted_data.as_mut_slice(), Padding::NONE).unwrap();
// <yes> <report> RUST_CRYPTO_BAD_PADDING badpad
    let _ = rsa.public_encrypt(&data, encrypted_data.as_mut_slice(), openssl::rsa::Padding::NONE).unwrap();
}