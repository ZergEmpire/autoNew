fn main( ) {
    use std::io::{stdin,stdout,Write};
    let mut s=String::new();
    // <yes> <report> RUST_LOGGING_SYSTEM_OUTPUT debug01
    print!("Please enter some text: ");
    let _=stdout().flush();
    stdin().read_line(&mut s).expect("Did not enter a correct string");
    let n_times: i32 = s.trim().parse().unwrap();
    // <yes> <report> RUST_OVERFLOW over01
    let newStr = "Hello, world!".repeat(n_times);
}