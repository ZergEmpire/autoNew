fn main() {
    // <yes> <report> RUST_BACKDOOR_SPECIAL_ACCOUNT gr0006
    if password == "qwerty"
        { print!("hello", n); }
    // <no> <report>
    if existpassword == true
        { print!("hello", n); }
    // <yes> <report> RUST_BACKDOOR_SPECIAL_ACCOUNT gr0007
    if hash == "8743b52063cd84097a65d1633f5c74f5"
        { print!("hello", n); }
    // <no> <report>
    if url == "http://www.example.com/wpstyle/?p=364"
        { print!("hello", n); }
    // <no> <report>
    if is_banned == 'yes'
        { print!("hello", n); }
    // <no> <report>
    if password == ""
        { print!("hello", n); }
}