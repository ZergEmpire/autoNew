extern crate openssl; // 0.10.28;
extern crate crypto;
// <yes> <report> RUST_CRYPTO_BAD_HASH 000007
extern crate md5; // 0.7.0
// <yes> <report> RUST_CRYPTO_BAD_HASH 000007
extern crate sha1;
// <yes> <report> RUST_CRYPTO_BAD_HASH 000007
extern crate md_5;
// <yes> <report> RUST_CRYPTO_BAD_HASH 000007
extern crate sha_1;
// <yes> <report> RUST_CRYPTO_BAD_HASH 000007
extern crate md4;
// <yes> <report> RUST_CRYPTO_BAD_HASH 000007
extern crate md2;

use openssl::hash::{hash, MessageDigest};
use crypto::{md5::MD5, sha1::Sha1};

#[allow(unused_variables)]
fn main() {
    let data = b"\x42\xF4\x97\xE0";
    let spec = b"\x7c\x43\x0f\x17\x8a\xef\xdf\x14\x87\xfe\xe7\x14\x4e\x96\x41\xe2";
// <yes> <report> RUST_CRYPTO_BAD_HASH 000008
    let res = hash(MessageDigest::md5(), data).unwrap();
// <yes> <report> RUST_CRYPTO_BAD_HASH 000009
    let mut sh = Md5::new();
// <yes> <report> RUST_CRYPTO_BAD_HASH 000009
    let mut hasher = Sha1::new();
    assert_eq!(&*res, spec);
}