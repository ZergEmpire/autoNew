extern crate rand; // 0.7.3;

use rand::{Rng, SeedableRng, rngs::StdRng};

fn main() {
// <yes> <report> RUST_CRYPTO_BAD_SEED 000005
    let mut r = StdRng::seed_from_u64(42);
    println!("{}", r.gen::<f64>());
}
