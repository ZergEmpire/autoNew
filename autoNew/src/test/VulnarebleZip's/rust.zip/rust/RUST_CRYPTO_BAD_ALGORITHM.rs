extern crate openssl; // 0.10.28
extern crate crypto;

// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000010
extern crate rc2;
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000010
extern crate des;
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000010
extern crate blowfish;

use crypto::{blowfish::Blowfish, rc4::Rc4};

#[allow(unused_variables)]
fn main() {
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000011
    let rc4 = openssl::symm::Cipher::rc4();
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000011
    let des = openssl::symm::Cipher::des_cbc();
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000011
    let des2 = openssl::symm::Cipher::des_ede3();
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000011
    let blowfish = openssl::symm::Cipher::bf_cbc();

// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012 <yes> <report> RUST_CRYPTO_KEY_HARDCODED gr0011
    let mut rc4_2 = Rc4::new("key".as_bytes());
    let key = [0u8; 16];
// <yes> <report> RUST_CRYPTO_BAD_ALGORITHM 000012
    let blowfish_2 = Blowfish::new(&key);
}