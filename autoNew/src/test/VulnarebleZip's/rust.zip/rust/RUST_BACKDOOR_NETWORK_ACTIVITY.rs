fn main( ) {
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url1 = "https://url.irl";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url2 = "https://1.1.1.1";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne002
    let url3 = "https://localhost";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "1.1.1.1";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url5 = cl("https://url.url");
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne002
    let url6 = cl("https://localhost");
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "1.1.1.1/yourself";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "https://[::1]";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "https://[1762:0:0:0:0:B03:1:AF18]";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "https://[fe80::219:7eff:fe46:6c42]";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]";
// <yes> <report> RUST_BACKDOOR_NETWORK_ACTIVITY bne001
    let url4 = "https://[2001:db8::ff00:42:8329]";
}