extern crate openssl; // 0.10.28;

use openssl::rsa::{Rsa, Padding};
use openssl::bn::{BigNum};

// TODO: var propagation with BigNum's num_bytes for other constructors
#[allow(unused_variables)]
fn main() {
    let e = BigNum::from_u32(65537).unwrap();
// <yes> <report> RUST_CRYPTO_KEY_SIZE 000006
    let rsa = openssl::rsa::Rsa::generate(1024).unwrap();
// <no> <report>
    let rsa = Rsa::generate(2048).unwrap();
// <yes> <report> RUST_CRYPTO_KEY_SIZE 000006
    let rsa = Rsa::generate_with_e(1024, &e).unwrap();
// <no> <report>
    let rsa = Rsa::generate_with_e(2048, &e).unwrap();

    let data = b"foobar";
    let mut buf = vec![0; rsa.size() as usize];
    let encrypted_len = rsa.public_encrypt(data, &mut buf, Padding::PKCS1).unwrap();
}