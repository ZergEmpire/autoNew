extern crate cookie;
use cookie::Cookie;

fn main(){
    // <yes> <report> RUST_COOKIE_NOT_OVER_SSL gr0005
    let c1 = Cookie::build("name1", "value")
        .domain("example.com")
        .path("/path")
        .secure(false)
        .http_only(true)
        .finish();
    // <no> <report>
    let c2 = Cookie::build("name2", "value")
        .domain("example.com")
        .path("/path")
        .secure(true)
        .http_only(true)
        .finish();

    c2.set_secure(false); //will be added when there will be propagation of type
}