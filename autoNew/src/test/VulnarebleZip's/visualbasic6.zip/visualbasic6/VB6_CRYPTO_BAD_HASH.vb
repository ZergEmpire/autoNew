Private Sub useHash()
Dim myHashedData As HashedData

Set myHashedData = New HashedData
' <yes> <report> VB6_CRYPTO_BAD_HASH 000048
myHashedData.Algorithm = CAPICOM_HASH_ALGORITHM_SHA1
' <yes> <report> VB6_CRYPTO_BAD_HASH 000048
myHashedData.Algorithm = 1
End Sub

Private Sub ChilkatCrypt2()
Dim crypt As ChilkatCrypt2
' <yes> <report> VB6_CRYPTO_BAD_HASH 000666
crypt.HashAlgorithm = "sha1"
End Sub

Private Sub ChilkatCrypt2()
Dim crypt As ChilkatCrypt2
' <yes> <report> VB6_CRYPTO_BAD_HASH 000666
crypt.HashAlgorithm = "md2"
End Sub

Private Sub ChilkatCrypt2()
Dim crypt As ChilkatCrypt2
' <yes> <report> VB6_CRYPTO_BAD_HASH 000666
crypt.HashAlgorithm = "md4"
End Sub

Private Sub ChilkatCrypt2()
Dim crypt As ChilkatCrypt2
' <yes> <report> VB6_CRYPTO_BAD_HASH 000666
crypt.HashAlgorithm = "md5"
End Sub

Private Sub ChilkatCrypt2()
Dim crypt As ChilkatCrypt2
crypt.HashAlgorithm = "sha256"
End Sub