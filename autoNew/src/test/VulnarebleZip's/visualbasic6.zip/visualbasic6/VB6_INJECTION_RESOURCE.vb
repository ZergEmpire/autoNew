Dim myRecord As Record

Set myRecord = New Record
' <yes> <report> VB6_INJECTION_RESOURCE 000088
res = myRecord.CopyRecord("", strRecordURL, , , adCopyOverWrite) 
' <yes> <report> VB6_INJECTION_RESOURCE 000088
myRecord.CopyRecord source, strRecordURL, , , adCopyOverWrite
' <yes> <report> VB6_INJECTION_RESOURCE 000089
myRecord.DeleteRecord source

Dim conn As Connection
' <yes> <report> VB6_INJECTION_RESOURCE 000094
conn.Open ConnectionString, UserID, Password, Options
