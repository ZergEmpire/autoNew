Dim value As Integer
' <yes> <report> VB6_CRYPTO_BAD_SEED 030052
Call Randomize(3)
' <yes> <report> VB6_CRYPTO_BAD_SEED 000152
Randomize 3
' <yes> <report> VB6_CRYPTO_BAD_RANDOM 000002
value = Rnd()