Private Sub useConnectionExecute()
Dim myConnection As Connection

Set myConnection = New Connection
' <yes> <report> VB6_INJECTION_SQL 000006
myConnection.Execute commandText, recordsAffected, Nothing
End Sub


Private Sub useCommandText()
Dim myCommand As Command
Dim someCommandText As String

Set myCommand = New Command
' <yes> <report> VB6_INJECTION_SQL 000009
myCommand.CommandText = someCommandText
End Sub


Private Sub useOpen_SourceRecordSet()
Dim myRecord As RecordSet
Dim someRecordText As String

Set myRecord = New RecordSet

' <yes> <report> VB6_INJECTION_SQL 000010
myRecord.Open someRecordText, someActiveConnection, someCursorType, someLockType, someOptions
' <yes> <report> VB6_INJECTION_SQL 000010
res = myRecord.Open(someRecordText, someActiveConnection, someCursorType, someLockType, someOptions)
' <yes> <report> VB6_INJECTION_SQL 000010
myRecord.Source = someRecordText
End Sub


Private Sub useOpen_SourceRecord()
Dim myRecord As Record
Dim someRecordText As String

Set myRecord = New Record

' <yes> <report> VB6_INJECTION_SQL 000017
myRecord.Open someRecordText, someActiveConnection, someCursorType, someLockType, someOptions
' <yes> <report> VB6_INJECTION_SQL 000017
res = myRecord.Open(someRecordText, someActiveConnection, someCursorType, someLockType, someOptions)

' <yes> <report> VB6_INJECTION_SQL 000017
myRecord.Source = someRecordText
End Sub


Private Sub useSet_SQL()
Dim myData As RemoteData

Set myData = New RemoteData
' <yes> <report> VB6_INJECTION_SQL 000026
myData.SQL = someSQL
End Sub


Private Sub useCreateQuery()
Dim myConnection As rdoConnection

Set myConnection = New rdoConnection
' <yes> <report> VB6_INJECTION_SQL 000027
myConnection.CreateQuery arg1, arg2
End Sub

Private Sub useExecute()
Dim myConnection As rdoConnection

Set myConnection = New rdoConnection
' <yes> <report> VB6_INJECTION_SQL 000028
myConnection.Execute arg1, arg2
End Sub


Private Sub useExecute()
Dim myTable As rdoTable

Set myTable = New rdoTable
' <yes> <report> VB6_INJECTION_SQL 000035
myTable.OpenResultset arg1
End Sub