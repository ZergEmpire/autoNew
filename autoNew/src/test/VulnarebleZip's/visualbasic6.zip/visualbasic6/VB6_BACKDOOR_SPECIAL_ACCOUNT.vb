'  <yes> <report> VB6_BACKDOOR_SPECIAL_ACCOUNT 000065 <yes> <report> VB6_PASSWORD_HARDCODED 000053
If password = "qwerty" and authorised = "true" Then
    MsgBox "Hello!"
' <yes> <report> VB6_BACKDOOR_SPECIAL_ACCOUNT 000066
     	ElseIf hash = "8743b52063cd84097a65d1633f5c74f5" Then
  	MsgBox "Hello!"
End If
'  <no> <report>
If password = "" Then
    MsgBox "Hello!"
End If