Dim srv As Server
' VB6_PATH_MANIPULATION 000078
srv.MapPath myFile
' <no> <report>
srv.MapPath "myFile"
' VB6_PATH_MANIPULATION 000078
result = srv.Transfer(myFile)  	 

Dim CADObject As Object
' VB6_PATH_MANIPULATION 000083
CADObject = GetObject(path)
' <no> <report>
CADObject = GetObject("C:\CAD\schema.cad")	
	
Private Sub Form_Load()
' VB6_PATH_MANIPULATION 000083
Picture = LoadPicture(Picture)
End Sub

Dim err As ASPError
' VB6_PATH_MANIPULATION 000085
err.HelpFile = path

' VB6_PATH_MANIPULATION 000086
Call err.Raise(number, source, description, helpfile)
' VB6_PATH_MANIPULATION 000086
err.Raise number, source, description, helpfile

Dim myStream As Stream
' VB6_PATH_MANIPULATION 000093
myStream.SaveToFile path

Dim obj As FileSystemObject
' VB6_PATH_MANIPULATION 000095
obj.BuildPath path, name
' VB6_PATH_MANIPULATION 000095
obj.BuildPath "path", name
' VB6_PATH_MANIPULATION 000096
obj.CreateFolder foldername

Dim f As File
' VB6_PATH_MANIPULATION 000097
f.Copy foldername
' VB6_PATH_MANIPULATION 000097
f.Name = name

Dim fold As Folder
' VB6_PATH_MANIPULATION 000098
fold.CreateTextFile filename

Dim MyStamp As Date
' VB6_PATH_MANIPULATION 000101
MyStamp = FileDateTime(path)