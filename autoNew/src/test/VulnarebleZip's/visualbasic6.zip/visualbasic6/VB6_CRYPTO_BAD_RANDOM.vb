Private Sub Number_Random()
Dim value As Integer

' <yes> <report> VB6_CRYPTO_BAD_RANDOM 000002
value = Rnd()
End Sub
