
' <yes> <report> VB6_INFORMATION_LEAK_INTERNAL 000057 
MsgBox Err.Description, MsgBoxStyle.Information, "Error"

Dim myTextStream As TextStream
' <yes> <report> VB6_INFORMATION_LEAK_INTERNAL 000087 
res = myTextStream.Write(something)
' <yes> <report> VB6_INFORMATION_LEAK_INTERNAL 000087 
myTextStream.Write something
' <yes> <report> VB6_INFORMATION_LEAK_INTERNAL 000087 
myTextStream.WriteLine something

Dim dbg As Debug
' <yes> <report> VB6_INFORMATION_LEAK_INTERNAL 000087 
res = dbg.WriteLine(something)

