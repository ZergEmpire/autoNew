Dim http As New ChilkatHttp

' <yes> <report> VB6_COOKIE_BROAD_PATH 000055
http.CookieDir = "/"