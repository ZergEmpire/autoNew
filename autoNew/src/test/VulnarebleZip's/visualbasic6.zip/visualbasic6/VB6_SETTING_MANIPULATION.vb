Dim ses As Session
' <yes> <report> VB6_SETTING_MANIPULATION 000080
ses.Timeout = number
' <no> <report> 
ses.Timeout = 3600

Dim con As Connection
' <yes> <report> VB6_SETTING_MANIPULATION 000081
con.ConnectionTimeout = number
' <yes> <report> VB6_SETTING_MANIPULATION 000102
con.Mode = txt

Dim com As Command
' <yes> <report> VB6_SETTING_MANIPULATION 000082
com.CommandTimeout = number