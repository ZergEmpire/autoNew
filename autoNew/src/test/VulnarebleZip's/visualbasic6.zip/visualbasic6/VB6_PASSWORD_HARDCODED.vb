' <yes> <report> VB6_PASSWORD_HARDCODED 300053
Private Const REALM_PASSWORD    As String = "password"

Private Sub Open_Connection()
Dim myConnection As Connection

Set myConnection = New Connection
' <yes> <report> VB6_PASSWORD_HARDCODED 000008
myConnection.Open "someURL", "someUser", "somePswd"
' <yes> <report> VB6_PASSWORD_HARDCODED 000046 <yes> <report> VB6_PASSWORD_HARDCODED 000008
myConnection.Open "fileWithPasswords", UserName, "somePswd"  
' <yes> <report> VB6_PASSWORD_HARDCODED 000047
myConnection.ConnectionString = "fileWithPasswords"
End Sub


Private Sub useCopy_MoveRecord()
Dim myRecord As Record

Set myRecord = New Record
' <yes> <report> VB6_PASSWORD_HARDCODED 000015 <yes> <report> VB6_INJECTION_RESOURCE 000088
myRecord.CopyRecord someSource, someDestination, someUserName, "somePswd", someOptions, someAsync  
' <yes> <report> VB6_PASSWORD_HARDCODED 000016 <yes> <report> VB6_INJECTION_SQL 000017
myRecord.Open Source, ActiveConnection, Mode, CreateOptions, Options, UserName, "somePswd" 
End Sub


Private Sub Open_Stream()
Dim myStream As Stream

Set myStream = New Stream
' <yes> <report> VB6_PASSWORD_HARDCODED 000019 <yes> <report> VB6_INJECTION_RESOURCE 000094
myStream.Open Source, Mode , OpenOptions, UserName, "somePsw"
End Sub


Private Sub useConnect()
Dim myData As RemoteData

Set myData = New RemoteData
' <yes> <report> VB6_PASSWORD_HARDCODED 000021
myData.Connect =  Pwd
End Sub


Private Sub useOpenConnection()
Dim myEnv As rdoEnvironment

Set myEnv = New rdoEnvironment
' <yes> <report> VB6_PASSWORD_HARDCODED 000022
myEnv.OpenConnection arg1, arg2, arg3, Pswd
End Sub


Private Sub usePassword()
Dim myEnv As rdoEnvironment

Set myEnv = New rdoEnvironment
' <yes> <report> VB6_PASSWORD_HARDCODED 000024 <yes> <report> VB6_PASSWORD_HARDCODED 000045
myEnv.Password = "somePassword"
' <yes> <report> VB6_PASSWORD_HARDCODED 00024t <yes> <report> VB6_PASSWORD_HARDCODED 00045t
myEnv.Password = "some Password"
End Sub


Private Sub useRdoDefaultPassword()
Dim myEngine As rdoEngine

Set myEngine = New rdoEngine
' <yes> <report> VB6_PASSWORD_HARDCODED 000033 <yes> <report> VB6_PASSWORD_HARDCODED 000044
myEngine.rdoDefaultPassword =  "somePswd"
' <yes> <report> VB6_PASSWORD_HARDCODED 00033t <yes> <report> VB6_PASSWORD_HARDCODED 00044t
myEngine.rdoDefaultPassword =  "some Pswd"
End Sub


Private Sub useRdoCreateEnvironment()
Dim myEngine As rdoEngine

Set myEngine = New rdoEngine
' <yes> <report> VB6_PASSWORD_HARDCODED 000034
myEngine.rdoCreateEnvironment arg1, arg2, "somePswd"
End Sub


Private Sub Func()
Dim myPassword As String
Dim Password As String
Dim myNewPassword As Integer
Dim myEnv As rdoEnvironment
Dim boolValue As Boolean 

Set myEnv = New rdoEnvironment
' <yes> <report> VB6_PASSWORD_HARDCODED 000042
myPassword = "somePswd"
' <yes> <report> VB6_PASSWORD_HARDCODED 00042t
myPassword = "some Pswd"
' <yes> <report> VB6_PASSWORD_HARDCODED 000043
Password = "somePswd"
' <yes> <report> VB6_PASSWORD_HARDCODED 00043t
Password = "some Pswd"
' <yes> <report> VB6_PASSWORD_HARDCODED 000052
boolValue = myNewPassword < 1234567
' <yes> <report> VB6_PASSWORD_HARDCODED 000052
boolValue = myPassword <> "abcdefg"
' <yes> <report> VB6_PASSWORD_HARDCODED 00052t
boolValue = myPassword <> "abc defg"
' <yes> <report> VB6_PASSWORD_HARDCODED 000053
boolValue = Password <> "abcdefg"
' <yes> <report> VB6_PASSWORD_HARDCODED 00053t
boolValue = Password <> "abc defg"
' <yes> <report> VB6_PASSWORD_HARDCODED 000052
boolValue = myEnv.defaultPassword <= "1234567"
' <yes> <report> VB6_PASSWORD_HARDCODED 00052t
boolValue = myEnv.defaultPassword <= "123 4567"
End Sub
' <no> <report>
If (Len(Password) > 0) Then
End If