' <yes> <report> VB6_PASSWORD_EMPTY 100053
Private Const PASSWORD    As String = ""

Private Sub Open_Connection()
Dim myConnection As ADODB.Connection

Set myConnection = New ADODB.Connection
' <yes> <report> VB6_PASSWORD_EMPTY 000001
myConnection.Open "someURL", "someUser", ""
End Sub


Private Sub useCopy_MoveRecord()
Dim myRecord As Record

Set myRecord = New Record
' <yes> <report> VB6_PASSWORD_EMPTY 000013 <yes> <report> VB6_INJECTION_RESOURCE 000088
myRecord.CopyRecord someSource, someDestination, someUserName, "", someOptions, someAsync  
' <yes> <report> VB6_PASSWORD_EMPTY 000014 <yes> <report> VB6_INJECTION_SQL 000017
myRecord.Open Source, ActiveConnection, Mode, CreateOptions, Options, UserName, "" 
End Sub

Private Sub Open_Stream()
Dim myStream As Stream
Set myStream = New Stream
' <yes> <report> VB6_PASSWORD_EMPTY 000020 <yes> <report> VB6_INJECTION_RESOURCE 000094
myStream.Open Source, Mode , OpenOptions, UserName, ""
End Sub


Private Sub usePassword()
Dim myEnv As rdoEnvironment

Set myEnv = New rdoEnvironment
' <yes> <report> VB6_PASSWORD_EMPTY 000025 <yes> <report> VB6_PASSWORD_EMPTY 000041
myEnv.Password = ""
End Sub


Private Sub useRdoDefaultPassword()
Dim myEngine As rdoEngine

Set myEngine = New rdoEngine
' <yes> <report> VB6_PASSWORD_EMPTY 000031 <yes> <report> VB6_PASSWORD_EMPTY 000040
myEngine.rdoDefaultPassword =  ""
End Sub


Private Sub useRdoCreateEnvironment()
Dim myEngine As rdoEngine

Set myEngine = New rdoEngine
' <yes> <report> VB6_PASSWORD_EMPTY 000032
myEngine.rdoCreateEnvironment arg1, arg2, ""
End Sub


Private Sub Func()
Dim myPassword As String
Dim Password As String

' <yes> <report> VB6_PASSWORD_EMPTY 000038
myPassword = ""
' <yes> <report> VB6_PASSWORD_EMPTY 000039
Password = ""
End Sub



