' <yes> <report> VB6_PASSWORD_NULL 500053
Private Const PASSWORD As String = Nothing

Private Sub Func()
Dim myPassword As String
Dim Password As String

' <yes> <report> VB6_PASSWORD_NULL 000004
myPassword = Nothing
' <yes> <report> VB6_PASSWORD_NULL 000005
Password = Nothing
End Sub


Private Sub Open_Connection()
Dim myConnection As ADODB.Connection

Set myConnection = New ADODB.Connection
' <yes> <report> VB6_PASSWORD_NULL 000007
myConnection.Open "someURL", "someUser", Nothing
End Sub


Private Sub useCopy_MoveRecord()
Dim myRecord As Record

' <yes> <report> VB6_PASSWORD_NULL 000011 <yes> <report> VB6_INJECTION_RESOURCE 000088
myRecord.CopyRecord someSource, someDestination, someUserName, Nothing, someOptions, someAsync 
' <yes> <report> VB6_PASSWORD_NULL 000012 <yes> <report> VB6_INJECTION_SQL 000017
myRecord.Open Source, ActiveConnection, Mode, CreateOptions, Options, UserName, Nothing 
End Sub


Private Sub Open_Stream()
Dim myStream As Stream

Set myStream = New Stream
' <yes> <report> VB6_PASSWORD_NULL 000018 <yes> <report> VB6_INJECTION_RESOURCE 000094
myStream.Open Source, Mode , OpenOptions, UserName, Nothing
End Sub


Private Sub usePassword()
Dim myEnv As rdoEnvironment

Set myEnv = New rdoEnvironment
' <yes> <report> VB6_PASSWORD_NULL 000023 <yes> <report> VB6_PASSWORD_NULL 000037 
myEnv.Password =  Nothing
End Sub


Private Sub useRdoDefaultPassword()
Dim myEngine As rdoEngine

Set myEngine = New rdoEngine
' <yes> <report> VB6_PASSWORD_NULL 000029 <yes> <report> VB6_PASSWORD_NULL 000036
myEngine.rdoDefaultPassword =  Nothing
End Sub


Private Sub useRdoCreateEnvironment()
Dim myEngine As rdoEngine

Set myEngine = New rdoEngine
' <yes> <report> VB6_PASSWORD_NULL 000030
myEngine.rdoCreateEnvironment arg1, arg2, Nothing
End Sub


Private Sub usePassword()
Dim myEnv As rdoEnvironment

Set myEnv = New rdoEnvironment
' <yes> <report> VB6_PASSWORD_NULL 000036
myEnv.defaultPassword =  Nothing
' <yes> <report> VB6_PASSWORD_NULL 000037 <yes> <report> VB6_PASSWORD_NULL 000023
myEnv.Password =  Nothing
End Sub