Dim value As Integer
'iCS_S_ProcedureOrArrayCall
' <yes> <report> VB6_BACKDOOR_HIDDEN_FUNCTIONALITY 000061 <yes> <report> VB6_INJECTION_COMMAND 000003
value = Shell(Base64DecodeString("SGVsbG8=")) 
'eCS_ProcedureCall
' <yes> <report> VB6_BACKDOOR_HIDDEN_FUNCTIONALITY 000161 <yes> <report> VB6_INJECTION_COMMAND 000003
Call Shell(Base64DecodeString("SGVsbG8=")) 
'iCS_B_ProcedureCall
' <yes> <report> VB6_BACKDOOR_HIDDEN_FUNCTIONALITY 000261 <yes> <report> VB6_INJECTION_COMMAND 000103
Shell Base64DecodeString("SGVsbG8=") 

Dim myConnection As Connection
Set myConnection = New Connection
'iCS_B_MemberProcedureCall
' <yes> <report> VB6_INJECTION_SQL 000006 <yes> <report> VB6_BACKDOOR_HIDDEN_FUNCTIONALITY 000361
myConnection.Execute Base64DecodeString("SGVsbG8="), recordsAffected, Nothing


