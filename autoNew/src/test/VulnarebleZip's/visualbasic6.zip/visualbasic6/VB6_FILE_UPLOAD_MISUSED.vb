Dim req As New ChilkatHttpRequest
req.HttpVerb = "POST"
req.ContentType = "multipart/form-data"
req.Path = "rcvFormDataUpload.aspx"

Dim success As Long
' <yes> <report> VB6_FILE_UPLOAD_MISUSED 000060
success = req.AddFileForUpload2(fileName, inputPath.Text,"image/jpg")