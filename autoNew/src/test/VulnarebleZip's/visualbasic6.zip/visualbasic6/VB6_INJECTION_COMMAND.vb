Private Sub Run_Calc()
Dim procID As Integer
' <yes> <report> VB6_INJECTION_COMMAND 000003
procID = Shell("C:\Windows\system32\calc.exe", AppWinStyle.NormalFocus)
End Sub