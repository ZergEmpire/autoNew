Dim response As New Response
' <yes> <report> VB6_HTML5_CORS aswq79
response.AddHeader "Access-Control-Allow-Origin", "*"

' <yes> <report> VB6_HTML5_CORS aswq79
success = response.AddHeader ("Access-Control-Allow-Origin", "*")


