Private Sub useHashAlgorithm()
Dim myData As EnvelopedData

Set myData = New EnvelopedData
' <yes> <report> VB6_CRYPTO_BAD_ALGORITHM 000049
myData.Algorithm.Name = CAPICOM_ENCRYPTION_ALGORITHM_DES
' <yes> <report> VB6_CRYPTO_BAD_ALGORITHM 000049
myData.Algorithm.Name = 1
' <yes> <report> VB6_CRYPTO_BAD_ALGORITHM 000050
myData.Algorithm.Name = CAPICOM_ENCRYPTION_ALGORITHM_RC2
End Sub