Dim res As New Response
' <yes> <report> VB6_HEADER_MANIPULATION 100075	
res.AddHeader "HeaderName", HeaderValue
' <yes> <report> VB6_HEADER_MANIPULATION 100075	
success = res.AddHeader ("HeaderName", HeaderValue)
' <yes> <report> VB6_HEADER_MANIPULATION 000076	
res.Redirect HeaderName, value
' <no> <report>
res.Status = "value"
' <yes> <report> VB6_HEADER_MANIPULATION 000077	
res.Charset = value