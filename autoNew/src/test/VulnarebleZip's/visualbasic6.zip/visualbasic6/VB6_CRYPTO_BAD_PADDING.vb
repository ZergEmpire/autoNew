Dim rsa As New ChilkatRsa

' <yes> <report> VB6_CRYPTO_BAD_PADDING 000051
rsa.OaepPadding = 0