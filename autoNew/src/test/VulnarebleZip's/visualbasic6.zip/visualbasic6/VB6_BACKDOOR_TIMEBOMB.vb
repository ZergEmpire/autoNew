Dim date2 As Date
' <yes> <report> VB6_BACKDOOR_TIMEBOMB 000069
If date2 = "2011-10-12" Then
    ' Backdoor
End If
' <yes> <report> VB6_BACKDOOR_TIMEBOMB 000074
If dateTimestamp2 = CDate(date2) Then
    ' Backdoor
End If
' <yes> <report> VB6_BACKDOOR_TIMEBOMB 000071
If dateTimestamp2 = CDate("2011-10-12") Then
    ' Backdoor
End If
'<yes> <report> VB6_BACKDOOR_TIMEBOMB 000075
If (Sgn(DateDiff("s", UtcNow, CharDate)) >= 0) Then
    ' Backdoor
End If
' <yes> <report> VB6_BACKDOOR_TIMEBOMB ldk074
If Timer() < 1234 Then
    ' Backdoor
End If
' <yes> <report> VB6_BACKDOOR_TIMEBOMB ldk074 
If Year(date)=2017 Then
	activateBackdoor();
End If
