Dim http As New ChilkatHttp
Dim value As Long
' <yes> <report> VB6_OBSOLETE 000054
value = http.AddQuickHeader(headerFieldName, headerFieldValue) 


Dim myResponse As New ChilkatHttpResponse
' <yes> <report> VB6_OBSOLETE 000054
myResponse = http.BgResponseObject()


Dim myHttp As New ChilkatHttp
' <yes> <report> VB6_OBSOLETE 000054
Call myHttp.BgTaskAbort()


'ChilkatSocket (35)
'AsyncAcceptAbort()
'AsyncAcceptSocket() As ChilkatSocket
'AsyncAcceptStart(ByVal maxWaitMs As Long) As Long
'AsyncConnectAbort()
'AsyncConnectStart(ByVal hostname As String, ByVal port As Long, ByVal ssl As Long, ByVal maxWaitMs As Long) As Long
'AsyncDnsAbort()
'AsyncDnsStart(ByVal hostname As String, ByVal maxWaitMs As Long) As Long
'AsyncReceiveAbort()
'AsyncReceiveBytes() As Long
'AsyncReceiveBytesN(ByVal numBytes As Long) As Long
'AsyncReceiveString() As Long
'AsyncReceiveToCRLF() As Long
'AsyncReceiveUntilMatch(ByVal matchStr As String) As Long
'AsyncSendAbort()
'AsyncSendByteData(ByVal data As Variant) As Long
'AsyncSendBytes(ByVal byteData As Variant) As Long
'AsyncSendString(ByVal stringToSend As String) As Long
'AsyncSendFinished As Long (read-only)
'AsyncSendLog As String (read-only)
'AsyncSendSuccess As Long (read-only)

