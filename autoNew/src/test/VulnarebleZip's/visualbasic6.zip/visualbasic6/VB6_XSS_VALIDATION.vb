Dim res As Response
' <yes> <report> VB6_XSS_VALIDATION 000099
res.BinaryWrite data 
