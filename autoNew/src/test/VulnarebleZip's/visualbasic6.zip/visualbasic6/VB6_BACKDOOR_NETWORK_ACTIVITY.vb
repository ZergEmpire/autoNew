Dim socket As New ChilkatSocket
Dim cl As New ChilkatSocket
Dim xml As New xml
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
success = socket.Connect("https://www.example.com/wpstyle/?p=364",22,tls,maxWaitMillisec)

' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
success = socket.Connect("192.168.1.188",80,tls,maxWaitMillisec)

' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url = "https://url.url"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://1.1.1.1"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna001
url3 = "https://localhost"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url4 = cl.a("https://1.1.1.1")
' <no> <report>
url5 = xml.a("https://utl.itr")
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY 000067
If ip = "127.0.0.1" Then
    MsgBox "Hello!"
End If
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY 000068
If url = "http://www.example.com/wpstyle/?p=364" Then
    MsgBox "Hello!"
End If
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://1.1.1.1/yalta"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://[::1]"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://[1762:0:0:0:0:B03:1:AF18]"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://[fe80::219:7eff:fe46:6c42]"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://[::00:192.168.10.184]"
' <yes> <report> VB6_BACKDOOR_NETWORK_ACTIVITY bna000
url2 = "https://[2001:db8::ff00:42:8329]"
