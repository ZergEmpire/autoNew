Dim myValue As Object
' <yes> <report> VB6_INFORMATION_LEAK_EXTERNAL 000084
myValue = InputBox(message, title, defaultValue)

Dim myStream As Stream
' <yes> <report> VB6_INFORMATION_LEAK_EXTERNAL 000092
myStream.Write text