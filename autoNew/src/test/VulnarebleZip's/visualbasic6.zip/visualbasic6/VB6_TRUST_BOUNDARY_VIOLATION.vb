Dim cnt As Contents
' <yes> <report> VB6_TRUST_BOUNDARY_VIOLATION 000078
cnt.Remove something
' <yes> <report> VB6_TRUST_BOUNDARY_VIOLATION 000078
success = cnt.Remove(something)
' <no> <report>
cnt.Remove "something"	

Dim ses As Session
' <yes> <report> VB6_TRUST_BOUNDARY_VIOLATION 000079
ses.LCID = number
' <no> <report> 
ses.LCID = 2057

Dim Response As Response
Dim Request As Request
Dim Session As Session
Dim Application As Application
Dim Server As Server
Set Response = objContext("Response")
Set Request = objContext("Request")
Set Session = objContext("Session")
Set Application = objContext("Application")


If IsNull(Session("ATTR_USR")) Then
' <yes> <report> VB6_TRUST_BOUNDARY_VIOLATION 0fd091
	Session("ATTR_USR") = Request.Form("usrname")
' <no> <report>
	Session.Content("foo") = Response
End If