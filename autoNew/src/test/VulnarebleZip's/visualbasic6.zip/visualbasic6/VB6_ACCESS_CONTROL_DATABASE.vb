Dim myCommand As Command

Set myCommand = New Command
' <yes> <report> VB6_ACCESS_CONTROL_DATABASE 000090
myCommand.CreateParameter Name, Type, Direction, Size, Value

Dim parameter As Parameter
' <yes> <report> VB6_ACCESS_CONTROL_DATABASE 000090
Set parameter = myCommand.CreateParameter (Name, Type, Direction, Size, Value)
' <yes> <report> VB6_ACCESS_CONTROL_DATABASE 000091
parameter.AppendChunk data