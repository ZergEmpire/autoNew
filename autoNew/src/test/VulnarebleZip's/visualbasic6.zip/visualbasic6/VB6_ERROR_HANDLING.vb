Public Property Get Child(ByVal Key As Variant) As MicroDOM
    If mChildren Is Nothing Then
        Set mChildren = New Collection
    End If
    ' <yes> <report> VB6_ERROR_HANDLING 8hi2es
    On Error Resume Next
    Set Child = mChildren(Key)
    If Err Then
    ' <yes> <report> VB6_ERROR_HANDLING 3479rs
        On Error GoTo 0
        If VarType(Key) = vbString Then
            Key = Trim$(Key)
            Set Child = New MicroDOM
            Child.Key = Key
            mChildren.Add Child, Key
        Else
            Err.Raise 9 'Subscript error as thrown by the Collection.
        End If
    End If
End Property