int f()
{
    return 1/0;
}
