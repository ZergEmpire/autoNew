package integration.java8

import io.ktor.application.Application
import io.ktor.application.ApplicationCall
import io.ktor.application.install
import io.ktor.features.CallLogging
import io.ktor.features.DefaultHeaders
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.routing.routing
import io.ktor.sessions.Sessions
import io.ktor.sessions.cookie
import io.ktor.sessions.get
import io.ktor.sessions.sessions
import mu.KotlinLogging


class MySession {
    companion object {
        fun foo() {}
    }
}


fun Application.infomationLeakInternal(builder: StringBuilder, call: ApplicationCall, application: Application) {
    install(CallLogging)
    install(DefaultHeaders)
    install(CallLogging)
    val sessionCookie = call.response.cookies["name"]
    val sessionId = sessionCookie!!.value
    val logger = KotlinLogging.logger {}

    install(Routing) {


        builder.appendln(sessionId) //@ KOTLIN_INFORMATION_LEAK_INTERNAL-k12il1
    }

    application.install(Sessions) {
        cookie<MySession>("SESSION")
    }
    application.routing {
        get("/") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
            val mySession: MySession? = call.sessions.get<MySession>()
        }
    }


    logger.info(sessionId) //@ KOTLIN_INFORMATION_LEAK_INTERNAL-k11il1

    logger.info("hola!")

    logger.error(sessionId) //@ KOTLIN_INFORMATION_LEAK_INTERNAL-k11il1

    logger.warn(sessionId) //@ KOTLIN_INFORMATION_LEAK_INTERNAL-k11il1

}
