package integration.java8;


public class ANDROID_CORRECTNESS_ROOT_CHECKING {
	private boolean basicIntegrity;
	private boolean ctsProfileMatch;

	public boolean isBasicIntegrity() {
		return basicIntegrity; //@ ANDROID_CORRECTNESS_ROOT_CHECKING-root01
	}

	public boolean isCtsProfileMatch() {
		return ctsProfileMatch; //@ ANDROID_CORRECTNESS_ROOT_CHECKING-root01
	}

	private void runSafetyNetTest(ANDROID_CORRECTNESS_ROOT_CHECKING response) {
		if (!response.isCtsProfileMatch() || !response.isBasicIntegrity()) { //@ ANDROID_CORRECTNESS_ROOT_CHECKING-root02
			return;
		}
	}
}