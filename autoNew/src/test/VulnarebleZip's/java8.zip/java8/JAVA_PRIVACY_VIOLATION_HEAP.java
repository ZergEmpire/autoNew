package integration.java8;

import java.security.Key;

public class JAVA_PRIVACY_VIOLATION_HEAP {
    public static void PRIVACY_VIOLATION_HEAP_1a46d2 (Key key) {
        String password = key.getFormat(); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin, JAVA_BACKDOOR_DEAD_CODE-d27d09
        String privateDate = new String (FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(key)); //@ JAVA_PRIVACY_VIOLATION_HEAP-1a46d2,JAVA_OBSOLETE-bts001,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
