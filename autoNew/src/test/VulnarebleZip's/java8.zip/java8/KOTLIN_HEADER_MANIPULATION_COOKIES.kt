package integration.java8

import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.client.response.HttpResponse
import io.ktor.features.CallLogging
import io.ktor.features.DefaultHeaders
import io.ktor.http.Cookie
import io.ktor.http.renderSetCookieHeader
import io.ktor.response.ApplicationResponse
import io.ktor.response.ResponseCookies
import io.ktor.response.respondText
import io.ktor.routing.Routing
import io.ktor.routing.get

fun Application.cookieHeaderManipulation(response: ApplicationResponse, responseCon: HttpResponse) {
    var somevalue: String = "value"
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            val somevalue = responseCon.receiveContent().toString()

            val cookie = Cookie(name = "name", value = somevalue, secure = true, httpOnly = true) //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_HEADER_MANIPULATION_COOKIES-gggr31

            ResponseCookies(response, true).append(name = "name", value = somevalue, secure = true, httpOnly = true) //@ KOTLIN_HEADER_MANIPULATION_COOKIES-tswr77

            renderSetCookieHeader(name = "name", value = somevalue, secure = true, httpOnly = true) //@ KOTLIN_HEADER_MANIPULATION_COOKIES-zzzw88
        }
    }
}
