package integration.java8

import com.firefly.`$`
import com.iyanuadelekan.kanary.helpers.http.response.send
import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.client.response.HttpResponse
import io.ktor.features.*
import io.ktor.response.*
import io.ktor.routing.*
import java.sql.CallableStatement
import java.util.concurrent.Phaser
import javax.mail.Store
import javax.servlet.http.HttpServletResponse

fun Application.xssReflected(response: HttpResponse, servlet : HttpServletResponse, store : Store) {
    var pwd: String?
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_BACKDOOR_DEAD_CODE-d27d09
            // + WEB 3serc9 +PRIVATE_DATA
            pwd = call.parameters["pwd"]
            // +WEB
            val someContent = response.receiveContent()

            call.respondText(someContent.toString()) //@ KOTLIN_XSS_REFLECTED-kp1388
        }

        servlet.send(store.getFolder("dsc").toString()) //@ KOTLIN_XSS_REFLECTED-jkw111

        val writer = servlet.getWriter()
        writer.print(store.getFolder("dsc").toString()) //@ KOTLIN_XSS_REFLECTED-5527c6
//        get("/") {
//            // PRIVACY XSS
//            call.respondText(pwd.toString())
//        }
//        get("/") {
//                call.respondText(pwd)
//        }
//        get("/") {
//            call.respondHtml {
//                head {
//                    title("ktor Example Application")
//                }
//                body {
//                    h1 { +"Hello DZone Readers" }
//                    p {
//                        +"How are you doing?"
//                    }
//                }
//            }
//        }
    }

    fun main(args: Array<String>, cs: CallableStatement) { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        var str : String = store.getFolder("dsc").toString();
        val phaser = Phaser(2)
        val httpServer = `$`.httpServer()

        httpServer.router().get("/").handler { ctx -> ctx.write(str).next() } //@ KOTLIN_XSS_REFLECTED-jkw134
                .router().get("/").handler { ctx -> ctx.end("end message") }
                .listen("localhost", 8080)
        `$`.httpClient().get("http://localhost:8080/").submit() //@ JAVA_HTTP_USAGE-fa824a
                .thenAccept { res -> println(res.stringBody) } //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
                .thenAccept { res -> phaser.arrive() }
        phaser.arriveAndAwaitAdvance()
        httpServer.stop()
        `$`.httpClient().stop()
    }
}


