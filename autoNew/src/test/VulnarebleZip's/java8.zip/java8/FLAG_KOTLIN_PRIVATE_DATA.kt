package integration.java8

import io.ktor.application.Application
import io.ktor.application.ApplicationCall
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.client.response.HttpResponse
import io.ktor.client.response.readText
import io.ktor.features.*
import io.ktor.response.*
import io.ktor.routing.*
import io.ktor.sessions.SessionTransportHeader
import io.ktor.sessions.SessionTransportTransformer

fun Application.privateData(
        response: ApplicationResponse,
        transformers: List<SessionTransportTransformer>,
        call: ApplicationCall
): String {
    var somevalue = "value"
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            somevalue = call.parameters["pwd"].orEmpty()
        }
    }

    var pwd = SessionTransportHeader("pswd", transformers).receive(call).toString() //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PRIVACY_VIOLATION_HEAP-heapin
    return somevalue
}
