package integration.java8;

import java.net.InetAddress;

public class JAVA_AUTHENTICATION_MISUSED {

    public void success() throws Exception {

        InetAddress addr = InetAddress.getLocalHost(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa,JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        String host = addr.getHostAddress(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa,JAVA_BACKDOOR_DEAD_CODE-d27d09
        addr.getHostName(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        addr.getCanonicalHostName(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        addr.getAddress(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        InetAddress.getAllByName("name"); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        InetAddress.getByAddress("addr".getBytes()); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        InetAddress.getLocalHost(); //@ JAVA_AUTHENTICATION_MISUSED-de24aa
    }

}
