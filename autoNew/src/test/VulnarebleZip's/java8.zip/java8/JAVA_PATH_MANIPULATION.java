package integration.java8;


import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.ServerSocket;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class JAVA_PATH_MANIPULATION {
    public void foo(ServerSocket serverSocket) throws IOException {

        File f = new File(FLAG_WEB.WEB_chp0rr(serverSocket).toString() + "_names.dat"); //@ JAVA_PATH_MANIPULATION-b1b30c
        try {

            RandomAccessFile raf = new RandomAccessFile(f.getAbsolutePath(), "r"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PATH_MANIPULATION-b1b30c

            File file = File.createTempFile("prefix", "suffix", f); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PATH_MANIPULATION-9fdc6c,JAVA_ESAPI_DEPRECATED-rt3s89
        } catch (FileNotFoundException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }

    public static void main(String[] args) throws Exception {

        String baseFilename = args[0]; //@ JAVA_J2EE_DEBUG_CODE-514398

        File file = new File(baseFilename); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PATH_MANIPULATION-b1b30c

        new File(new URI(args[0])); //@ JAVA_PATH_MANIPULATION-b1b30c,JAVA_INJECTION_RESOURCE-b87909
    }

    public static void PATH_MANIPULATION_lambda() throws IOException {

        String propertyValue = FLAG_FILE_SYSTEM.FILE_SYSTEM_PROPERTIES_STREAM().toString();
        String[] resourcePaths = propertyValue.split(",");
        for (String resourcePath : resourcePaths) {

            File file = new File(resourcePath); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_PATH_MANIPULATION-b1b30c
        }
    }

    protected Writer createWriter(HttpServletRequest request) throws FileNotFoundException {

        String path = (String) request.getAttribute("path");

        File file = new File(path); //@ JAVA_PATH_MANIPULATION-b1b30c


        return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file))); //@ JAVA_PATH_MANIPULATION-b1b30c
    }

    public static class FTPClientExample {
        public List<File> getFiles(String path, String fileMask, FTPClient ftp) throws IOException {
            List<File> files = new ArrayList<>();

            FTPFile ftpFile = ftp.listFiles()[0];
            String pattern = "(.*)(\\\\d+)(.*)";
            Pattern filePattern = Pattern.compile(pattern);

            Matcher fileMatcher = filePattern.matcher(ftpFile.getName());
            if (ftpFile.isFile() && fileMatcher.matches()) {

                files.add(this.convertFTPFileToFile(ftp, ftpFile.getName()));
            }
            convertFTPFileToFile(ftp, ftpFile.getName());
            return files;
        }

        private File convertFTPFileToFile(FTPClient ftp, String fileName) throws IOException {

            FTPFile ftpFile = ftp.listFiles()[0];
            File file = File.createTempFile("tmp", fileName); //@ JAVA_ESAPI_DEPRECATED-rt3s89
            File file1 = new File(fileName); //@ JAVA_PATH_MANIPULATION-b1b30c,JAVA_BACKDOOR_DEAD_CODE-d27d09

            OutputStream os = new FileOutputStream(ftpFile.getName()); //@ JAVA_PATH_MANIPULATION-b1b30c

            OutputStream os1 = new FileOutputStream(fileName); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1,JAVA_PATH_MANIPULATION-b1b30c,JAVA_BACKDOOR_DEAD_CODE-d27d09
            ftp.retrieveFile(fileName, os);
            return file;
        }

        private void bar(){
            String smth = "af";

            File file = new File(smth+FTPClient.SYSTEM_TYPE_PROPERTIES); //@ JAVA_FILE_SEPARATOR_HARDCODED-52kd79,JAVA_BACKDOOR_DEAD_CODE-d27d09
            File file1 = new File (FTPClient.FTP_SYSTEM_TYPE_DEFAULT); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        }

        private void test_const(){

            String sep1 = "/user/Desktop/";
            String sep2 = "1.txt";

            File file = new File(sep1+sep2); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_FILE_SEPARATOR_HARDCODED-52kd79
        }

        private void doubleParam(File exclusiveFile) {

            new File(exclusiveFile.getParentFile(), exclusiveFile.getName());
        }
    }
}
