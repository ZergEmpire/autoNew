package integration.java8;

import android.webkit.WebView;

public class ANDROID_ADDJAVASCRIPTINTERFACE {
    public void makeWebView(WebView webView) {

        webView.addJavascriptInterface(new Object(), "injectedObject"); //@ ANDROID_ADDJAVASCRIPTINTERFACE-0857fe
        webView.loadData("", "text/html", null);
        webView.loadUrl("https://www.example.com"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr01
    }
}
