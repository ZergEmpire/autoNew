package integration.java8

import javax.servlet.http.HttpServletResponse
import javax.xml.soap.{MimeHeader, SOAPMessage}

class SCALA_HEADER_MANIPULATION {

  protected def addAuthorization(message: SOAPMessage, response: HttpServletResponse): Unit = {
    val headers = message.getMimeHeaders
    val it = headers.getAllHeaders
    val header = it.next.asInstanceOf[MimeHeader]
    response.setHeader(header.getName, header.getValue) //@ SCALA_HEADER_MANIPULATION-07bff5
  }

}
