package integration.java8;

import android.content.Context;
import android.content.ContextWrapper;
import android.net.Uri;

public class ANDROID_BAD_PERMISSION_CHECK {

    private void test(Context context, Uri uri) {
        context.checkCallingOrSelfUriPermission(uri, 1); //@ ANDROID_BAD_PERMISSION_CHECK-a0fd5b
        context.checkCallingOrSelfPermission("A"); //@ ANDROID_BAD_PERMISSION_CHECK-a0fd5b
    }
    private void test(ContextWrapper context, Uri uri) {
        context.checkCallingOrSelfUriPermission(uri, 1); //@ ANDROID_BAD_PERMISSION_CHECK-a0fd5b
        context.checkCallingOrSelfPermission("A"); //@ ANDROID_BAD_PERMISSION_CHECK-a0fd5b
    }
}
