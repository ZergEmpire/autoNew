package integration.java8;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JAVA_NULL_DEREFERENCE {
    public void test(Connection connection, String query) throws SQLException {
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);
        ResultSet results = statement.executeQuery(query);
        if ((results != null) && (results.first() == true)) {
            results.last();
        }

    }

    public void bad() {
        String data;

        data = null;

        System.out.println("" + data.length()); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_NULL_DEREFERENCE-66jnpd
    }
}
