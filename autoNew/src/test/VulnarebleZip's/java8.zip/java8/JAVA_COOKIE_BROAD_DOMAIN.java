package integration.java8;

import com.google.gwt.user.client.Cookies;
import org.springframework.web.util.CookieGenerator;

import java.util.Date;
import javax.servlet.http.Cookie;
import javax.ws.rs.core.NewCookie;

public class JAVA_COOKIE_BROAD_DOMAIN{
    public void test1() {
        Cookie terminate = new Cookie("name", "value");
        terminate.setDomain(".ya.ru"); //@ JAVA_COOKIE_BROAD_DOMAIN-257c47
        terminate.setDomain("ya.ru");
    }

    void test(CookieGenerator cookieGenerator) {
        cookieGenerator.setCookieDomain(".ya.ru"); //@ JAVA_COOKIE_BROAD_DOMAIN-d0eb32
        cookieGenerator.setCookieDomain("ya.ru");
    }

    void test2(javax.ws.rs.core.Cookie cookie) {
        NewCookie newCookie1 = new NewCookie("a", "b", "c", ".ya.ru", "e", 1, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_COOKIE_BROAD_DOMAIN-781a6b
        NewCookie newCookie2 = new NewCookie(cookie, "val", 1000, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_COOKIE_PERSISTENT-e6c667
    }

    void test3(Date expires) {
        Cookies.setCookie("name", "value", expires, ".ya.ru", "/er", true); //@ JAVA_COOKIE_BROAD_DOMAIN-b39172
        Cookies.setCookie("name", "value", expires, "ya.ru", "/er", true);
    }
}
