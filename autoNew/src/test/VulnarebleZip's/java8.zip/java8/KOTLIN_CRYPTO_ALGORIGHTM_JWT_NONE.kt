package integration.java8

import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwts
import java.io.UnsupportedEncodingException

class KOTLIN_CRYPTO_ALGORIGHTM_JWT_NONE {
    @Throws(UnsupportedEncodingException::class)
    fun test(jwtPwd: String?) {
        val jwt = Jwts.parser().setSigningKey(jwtPwd).parse("") //@ KOTLIN_UNTRUSTED_JWT_VALIDATION-jw23fn
        val claims = jwt.body as Claims
        val token02 = Jwts.builder().setClaims(claims).setHeaderParam("alg", "none").compact() //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, KOTLIN_CRYPTO_ALGORIGHTM_JWT_NONE-332333
    }
}