package integration.java8

import java.security.MessageDigest

class SCALA_CRYPTO_BAD_HASH {

  def foo(): Unit =
  {
    val md2Digest: MessageDigest = MessageDigest.getInstance("MD2") //@ SCALA_CRYPTO_BAD_HASH-b11hs4
    md2Digest.update("123".getBytes)
    md2Digest.digest

  }
}
