package integration.java8;

public class JAVA_CORRECTNESS_STRING_COMPARE {
    public void test(){
        String a = "1";
        String b = "2";

        boolean bool0 = a == b; //@ JAVA_CORRECTNESS_STRING_COMPARE-j11cs1
        boolean bool1 = a == "12"; //@ JAVA_CORRECTNESS_STRING_COMPARE-j11cs1
        boolean bool3 = "12".equals("ad"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        boolean bool4 = a.equals(b); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        boolean bool5 = a.equals("123"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        boolean bool6 = "123".equals(b); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        if (a == b) { //@ JAVA_CORRECTNESS_STRING_COMPARE-j11cs1
            boolean bool9 = new String("1") != new String("1"); //@ JAVA_CORRECTNESS_STRING_COMPARE-j11cs1
            boolean bool10 = new String("1") == new String("1"); //@ JAVA_CORRECTNESS_STRING_COMPARE-j11cs1
        }

    }
}
