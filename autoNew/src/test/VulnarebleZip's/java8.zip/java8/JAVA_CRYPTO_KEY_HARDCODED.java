package integration.java8;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.TextCodec;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import sun.security.provider.DSAPublicKeyImpl;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyRep;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.KeyManagerFactory;
import javax.security.auth.kerberos.KerberosKey;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

public class JAVA_CRYPTO_KEY_HARDCODED {

    public String encryptionKey = "sqjrhw2i3u4hr2"; //@ JAVA_CRYPTO_KEY_HARDCODED-keyhar
    private final String secretKey = "q3ru2hijkqe"; //@ JAVA_CRYPTO_KEY_HARDCODED-keyhar
    private static final String privateKey = "efbwibtiwbnj"; //@ JAVA_CRYPTO_KEY_HARDCODED-keyhar
    private String secretKey4;
    private static String secretKey5;
    public String encryptionKey2;
    private static String PWD1 = "khvfcd"; //@ JAVA_PASSWORD_HARDCODED-twgk4w
    private static char[] PWD2 = {'s', 'e', 'c', 'r', 'e', 't', '5'};
    private char[] PWD3 = {'s', 'e', 'c', 'r', 'e', 't', '5'};
    public static final String JWT_PASSWORD = TextCodec.BASE64.encode("victory");
    private static String validUsers = "TomJerrySylvester";

    public JAVA_CRYPTO_KEY_HARDCODED(String secretKey4) {
        this.secretKey4 = secretKey4;
    }

    public void bad1(String privKey) throws InvalidKeyException {
        String cryptographicKey = "12345678";

        secretKey5 = "sfskfsgf"; //@ JAVA_CRYPTO_KEY_HARDCODED-keyhar

        secretKey4 = cryptographicKey; //@ JAVA_CRYPTO_KEY_HARDCODED-keyhar
        encryptionKey2 = privKey;
        byte[] key = cryptographicKey.getBytes();

        KerberosKey kerberosKey = new KerberosKey(null, key, 0, 0); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_HARDCODED-bvnc07

        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "alg"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_HARDCODED-bvnc02

        SecretKeySpec secretKeySpec2 = new SecretKeySpec(key, 0, 0, "alg"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_HARDCODED-bvnc02

        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(key); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_HARDCODED-bvnc03

        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(key); //@ JAVA_CRYPTO_KEY_HARDCODED-bvnc04,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_REUSED-kda765

        KeyRep keyRep = new KeyRep(null, "alg", "format", key); //@ JAVA_CRYPTO_KEY_HARDCODED-bvnc05,JAVA_BACKDOOR_DEAD_CODE-d27d09

        DSAPublicKeyImpl publicKey = new DSAPublicKeyImpl(key); //@ JAVA_CRYPTO_KEY_HARDCODED-bvnc06,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void keyStore(String password) throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableKeyException {
        String pwdStr = "secret6"; //@ JAVA_PASSWORD_HARDCODED-8ce2fb,JAVA_PRIVACY_VIOLATION_HEAP-heapin
        KeyStore ks = KeyStore.getInstance("JKS");

        ks.load(new FileInputStream("keystore"), pwdStr.toCharArray()); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1,JAVA_CRYPTO_KEY_HARDCODED-2b64d8

        ks.load(new FileInputStream("keystore"), "password".toCharArray()); //@ JAVA_CRYPTO_KEY_HARDCODED-2b64d8
        char[] passphrase = {'s', 'e', 'c', 'r', 'e', 't', '3'}; //@ JAVA_PASSWORD_HARDCODED-8ce2fb
        KeyStore.getInstance("JKS").load(new FileInputStream("keystore"), passphrase); //@ JAVA_PASSWORD_HARDCODED-twgk4k

        ks.load(new FileInputStream("keystore"), password.toCharArray());
        char[] pwd = "secret7".toCharArray();

        KeyManagerFactory.getInstance("").init(null, pwd); //@ JAVA_PASSWORD_HARDCODED-afhpbd

        ks.load(new FileInputStream("keystore"), PWD1.toCharArray());
        ks.load(new FileInputStream("keystore"), PWD2);
        ks.load(new FileInputStream("keystore"), PWD3);
    }

    @GetMapping("/login")
    public void login(@RequestParam("user") String user, HttpServletResponse response) {
        Jwt jwt = Jwts.parser().setSigningKey(JWT_PASSWORD).parse(""); //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwthar, JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
        Claims claims = (Claims) jwt.getBody();
        String user1 = (String) claims.get("user"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        if (validUsers.contains(user)) {
            Claims claims1 =
                    Jwts.claims().setIssuedAt(Date.from(Instant.now().plus(Duration.ofDays(10)))); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
            claims.put("admin", "false");
            claims.put("user", user);
            String token = Jwts.builder()
                    .setClaims(claims)
                    .signWith(io.jsonwebtoken.SignatureAlgorithm.HS512, JWT_PASSWORD) //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwtkey2
                    .compact();
            Cookie cookie = new Cookie("access_token", token); //@ JAVA_HEADER_MANIPULATION_COOKIES-cb8562
            response.addCookie(cookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09
            response.setStatus(HttpStatus.OK.value());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        } else {
            Cookie cookie = new Cookie("access_token", "");
            response.addCookie(cookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        }
    }
}
