package integration.java8;

public class ANDROID_DEBUG_MODE_ON_BuildConfig { //@ ANDROID_DEBUG_MODE_ON-202dfd
    final int DEBUG = 1;
}
