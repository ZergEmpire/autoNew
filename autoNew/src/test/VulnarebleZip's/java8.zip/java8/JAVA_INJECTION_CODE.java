package integration.java8;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.script.*;
import java.nio.channels.ReadableByteChannel;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class JAVA_INJECTION_CODE {

    public static void INJECTION_CODE_de5196 (ReadableByteChannel channel, ScriptEngine engine) throws ScriptException {
        Scanner scanner = FLAG_STREAM.STREAM_bder8e(channel);
        String code = scanner.toString();
        if (engine instanceof Compilable) {
            Compilable comp = (Compilable) engine;

            comp.compile(code); //@ JAVA_INJECTION_CODE-de5196
        }
    }
    private static final Logger LOG = LogManager.getLogger();
    @ResponseBody
    private static ScriptContext executeScript(String name, CompiledScript script, @RequestBody Map<String, Object> scope) {
        System.out.println(scope); //@ JAVA_XSS_REFLECTED_CGI-rnr008,JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        try {
            ScriptContext newContext = new SimpleScriptContext();
            Bindings engineScope = newContext.getBindings(ScriptContext.ENGINE_SCOPE);
            engineScope.putAll(scope);
            System.out.println(engineScope); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d,JAVA_XSS_REFLECTED_CGI-rnr008

            System.out.println(newContext); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
            script.eval(newContext);

            return newContext;
        } catch (ScriptException ex) {
            LOG.warn("Error while executing script " + name, ex);
            return null;
        }
    }
    public static void main(String args[]) throws ScriptException {
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn"); //@ JAVA_J2EE_DEBUG_CODE-514398
        JAVA_INJECTION_CODE a = new JAVA_INJECTION_CODE();
        String name = "dsdvd";
        String script_name = "dfccsd";
        CompiledScript script = ((Compilable)engine).compile(script_name);
        Map<String, Object> scope = new ConcurrentHashMap<>();
        scope.put("sas",5);
        ScriptContext b = a.executeScript(name,script,scope); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
