package integration.java8;

import java.io.InputStreamReader;

public class JAVA_CORRECTNESS_COMPARE {
    public void compare(InputStreamReader inputReader) {

        if (inputReader.getClass().getName().equals("TrustedName")) { //@ JAVA_CORRECTNESS_COMPARE-9cbc9e
            inputReader.getEncoding();
        }

        Integer name1 = new Integer(42);
        Integer name2 = new Integer(43);

        if (name1.getClass().getSimpleName().equals(name2.getClass().getSimpleName())) { //@ JAVA_CORRECTNESS_COMPARE-9cbc9e
            name2.hashCode();
        }

        if (name1.getClass().equals(name2.getClass())) {
            name2.hashCode();
        }
    }
}
