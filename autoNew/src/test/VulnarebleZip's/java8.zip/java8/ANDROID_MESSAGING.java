package integration.java8;

import android.app.PendingIntent;
import android.telephony.SmsManager;

import java.util.ArrayList;

public class ANDROID_MESSAGING {

    public void test(
        SmsManager smsManager,
        PendingIntent intent)
    {
        smsManager.sendTextMessage("string", "string", "string", intent, intent); //@ ANDROID_MESSAGING-c467b4
        smsManager.sendMultipartTextMessage("string", "string", new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); //@ ANDROID_MESSAGING-c467b4
        smsManager.sendDataMessage("string", "string", (short) 1, "1".getBytes(), intent, intent); //@ ANDROID_MESSAGING-c467b4
    }
    public void test(
        android.telephony.gsm.SmsManager smsManager,
        PendingIntent intent)
    {
        smsManager.sendTextMessage("string", "string", "string", intent, intent); //@ ANDROID_MESSAGING-c467b4
        smsManager.sendMultipartTextMessage("string", "string", new ArrayList<>(), new ArrayList<>(), new ArrayList<>()); //@ ANDROID_MESSAGING-c467b4
        smsManager.sendDataMessage("string", "string", (short) 1, "1".getBytes(), intent, intent); //@ ANDROID_MESSAGING-c467b4
    }
}
