package integration.java8

import scalaj.http.{Http, HttpResponse, Token}
import scala.tools.nsc.interpreter.InputStream

object FLAG_WEB_SCALA {

  def getResponse(urlString: String): HttpResponse[String]
  = Http(urlString).asString

  def getToken(urlString: String): HttpResponse[Token]
    = Http(urlString).asToken

  def getBytes(urlString: String): HttpResponse[Array[Byte]]
    = Http(urlString).asBytes

  def getParams(urlString: String): HttpResponse[Seq[(String, String)]]
    = Http(urlString).asParams

  def getParamMap(urlString: String): HttpResponse[Map[String, String]]
    = Http(urlString).asParamMap

  def execute[T](urlString: String, parser: InputStream => T): HttpResponse[T]
  = Http(urlString).execute(parser)

  def exec[T](urlString: String,
    parser: (Int, Map[String, IndexedSeq[String]], InputStream) => T): HttpResponse[T]
    = Http(urlString).exec(parser)

  def parse(inputStream: InputStream): String = inputStream.toString

  def parse2(num: Int, map: Map[String, IndexedSeq[String]], inputStream: InputStream): String
  = inputStream.toString
}
