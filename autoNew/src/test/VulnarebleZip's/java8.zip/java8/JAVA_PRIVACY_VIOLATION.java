package integration.java8;

import android.location.Location;
import android.location.LocationListener;
import org.apache.log4j.Logger;
import org.springframework.http.ResponseEntity;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Locale;
import java.util.Properties;
import javax.security.auth.callback.PasswordCallback;

public class JAVA_PRIVACY_VIOLATION {
    Properties userCredentials;
    private static final Logger logger = Logger.getLogger("pathcompanion");;

    public void foo() {

        String password = userCredentials.getProperty("password"); //@ JAVA_NULL_DEREFERENCE-j11nd8,JAVA_PRIVACY_VIOLATION_HEAP-heapin
        URL url1 = null;
        try {

            url1 = new URL(password); //@ JAVA_PRIVACY_VIOLATION-nrek3m
            try {
                URLConnection connection = url1.openConnection();

                connection.setRequestProperty("password", password); //@ JAVA_PRIVACY_VIOLATION-grwjjk
            } catch (IOException e) {
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }
        } catch (MalformedURLException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        PasswordCallback passwordCallback = new PasswordCallback("prompt", true); //@ JAVA_PRIVACY_VIOLATION-regwks
        passwordCallback.clearPassword();
        try {
            PrintWriter printwriter = new PrintWriter("string"); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs1

            printwriter.format(Locale.getDefault(), password); //@ JAVA_PRIVACY_VIOLATION-gdrges
        } catch (FileNotFoundException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        JAVA_PRIVACY_VIOLATION.logger.trace(password); //@ JAVA_PRIVACY_VIOLATION-1bfd10

        logger.trace(password); //@ JAVA_PRIVACY_VIOLATION-1bfd10

        final ResponseEntity<String> ok = ResponseEntity.ok(password); //@ JAVA_PRIVACY_VIOLATION-fekwl3,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void test() {
        String cardnumber = "123";
        System.out.println(cardnumber); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        String password = "123"; //@ JAVA_PASSWORD_HARDCODED-8ce2fb, JAVA_PRIVACY_VIOLATION_HEAP-heapin
        System.out.println(password); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        String cvv = "123";
        System.out.println(cvv); //@ JAVA_PRIVACY_VIOLATION-143b17, JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
    }
}

abstract class Test implements LocationListener {
    @Override
    public void onLocationChanged(Location location)
    {
        System.out.println(location); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d, JAVA_PRIVACY_VIOLATION-143b17
    }
}
