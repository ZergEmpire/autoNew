package integration.java8;

import android.content.Context;
import android.content.ContextWrapper;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;

public class ANDROID_WORLD_READABLE_WRITEABLE {

    public void test(
        Context context,
        SQLiteDatabase.CursorFactory cursorFactory,
        DatabaseErrorHandler handler)
    {
        context.openOrCreateDatabase("string", 1, cursorFactory); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", 1, cursorFactory, handler); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_READABLE, cursorFactory); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_READABLE, cursorFactory, handler); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_WRITEABLE, cursorFactory); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_WRITEABLE, cursorFactory, handler); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
    }

    public void test2(
        ContextWrapper context,
        SQLiteDatabase.CursorFactory cursorFactory,
        DatabaseErrorHandler handler)
    {
        context.openOrCreateDatabase("string", 1, cursorFactory); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", 1, cursorFactory, handler); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_READABLE, cursorFactory); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_READABLE, cursorFactory, handler); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_WRITEABLE, cursorFactory); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
        context.openOrCreateDatabase("string", Context.MODE_WORLD_WRITEABLE, cursorFactory, handler); //@ ANDROID_WORLD_READABLE_WRITEABLE-029aff
    }
}
