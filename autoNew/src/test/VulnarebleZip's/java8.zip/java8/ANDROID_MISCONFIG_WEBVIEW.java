package integration.java8;
import android.net.Uri;
import android.webkit.WebView;
import retrofit2.Retrofit;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class ANDROID_MISCONFIG_WEBVIEW {
    public void test1(WebView webView)
    {
        webView.loadDataWithBaseURL("file:///android_asset/","<html><body>Hello Android</body></html>","text/html","UTF-8", null); //@ ANDROID_WEBVIEW_MISCONFIG-mstg66
        webView.loadUrl("javascript:var x=document.getElementsByTagName('form')[0].strCnno2.value='1'"); //@ ANDROID_WEBVIEW_MISCONFIG-mstg66
    }
    public void test2(WebView webView)
    {
        webView.loadUrl("https://rt-solar.ru/"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr01
    }
}