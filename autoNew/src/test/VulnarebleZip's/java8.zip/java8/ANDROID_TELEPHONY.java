package integration.java8;

import android.telephony.TelephonyManager;

public class ANDROID_TELEPHONY {

    public void test(TelephonyManager telephonyManager) {
        telephonyManager.getVoiceMailNumber(); //@ ANDROID_TELEPHONY-a0a8ab
        telephonyManager.getLine1Number(); //@ ANDROID_TELEPHONY-a0a8ab
    }
}
