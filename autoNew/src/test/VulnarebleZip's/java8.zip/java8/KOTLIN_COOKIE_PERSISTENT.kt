package integration.java8

import io.ktor.http.Cookie
import io.ktor.http.HttpMessageBuilder
import io.ktor.http.maxAge
import io.ktor.http.renderSetCookieHeader
import io.ktor.response.ApplicationResponse
import io.ktor.response.ResponseCookies

fun cookiePersistent(response: ApplicationResponse, builder: HttpMessageBuilder) {

    val cookie = Cookie(name = "name", value = "value", maxAge = 5*365*24*3600, secure = true, httpOnly = true) //@ KOTLIN_COOKIE_PERSISTENT-2ftre7,JAVA_BACKDOOR_DEAD_CODE-d27d09

    ResponseCookies(response, true).append(name = "name", value = "value", maxAge = 5*365*24*3600, secure = true, httpOnly = true) //@ KOTLIN_COOKIE_PERSISTENT-trrre7

    renderSetCookieHeader(name = "name", value = "value", maxAge = 5*365*24*3600, secure = true, httpOnly = true) //@ KOTLIN_COOKIE_PERSISTENT-q845e7

    builder.maxAge(5*365*24*3600) //@ KOTLIN_COOKIE_PERSISTENT-sstr88
}
