package integration.java8

import io.ktor.auth.AuthenticationPipeline
import io.ktor.auth.FormAuthChallenge
import io.ktor.auth.formAuthentication
import io.ktor.client.features.auth.basic.BasicAuth

const val password = "foo" //@ KOTLIN_PASSWORD_HARDCODED-twgk4w

fun KOTLIN_PASSWORD_HARDCODED(){
    AuthenticationPipeline().formAuthentication(
            userParamName = "user",
            passwordParamName = "password",
            challenge = FormAuthChallenge.Unauthorized,
            validate = { null }
    )

    BasicAuth(username = "user", password = "pwd") //@ KOTLIN_PASSWORD_HARDCODED-zz345e
}

class Bar {
    companion object {


        fun x() {
            class XX {
                final val password1 = "foo" //@ KOTLIN_PASSWORD_HARDCODED-twgk4w
            }
        }
    }
    class Password {
        companion object {

            /*
            * comment
            */
            const val password2 = "foo" //@ KOTLIN_PASSWORD_HARDCODED-twgk4w
        }
    }

    object JustObject {
        val innerField = "2"
    }
}

class ZZZ {
    companion object {
        const val password3 = "pass3" //@ KOTLIN_PASSWORD_HARDCODED-twgk4w
    }
}

