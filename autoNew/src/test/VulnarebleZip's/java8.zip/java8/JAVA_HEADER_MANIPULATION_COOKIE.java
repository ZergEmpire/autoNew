package integration.java8;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.impl.TextCodec;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

public class JAVA_HEADER_MANIPULATION_COOKIE {
    public static final String JWT_PASSWORD = TextCodec.BASE64.encode("victory");
    private static String validUsers = "TomJerrySylvester";

    @GetMapping("/login")
    public void login(@RequestParam("user") String user, HttpServletResponse response) {
        Cookie cookie2 = new Cookie("access_token", user); //@ JAVA_HEADER_MANIPULATION_COOKIES-cb8562
        response.addCookie(cookie2); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09
        if (validUsers.contains(user)) {
            Claims claims = Jwts.claims().setIssuedAt(Date.from(Instant.now().plus(Duration.ofDays(10))));
            claims.put("admin", "false");
            claims.put("user", user);
            String token = Jwts.builder()
                    .setClaims(claims)
                    .signWith(io.jsonwebtoken.SignatureAlgorithm.HS512, JWT_PASSWORD) //@ JAVA_CRYPTO_KEY_HARDCODED_JWT-jwtkey2
                    .compact();


            Cookie cookie = new Cookie("access_token", token); //@ JAVA_HEADER_MANIPULATION_COOKIES-cb8562
            response.addCookie(cookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09
            response.setStatus(HttpStatus.OK.value());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        } else {

            Cookie cookie = new Cookie("access_token", "");
            response.addCookie(cookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        }
    }
}
