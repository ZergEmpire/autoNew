package integration.java8;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;

public class D06InterProcConstructorTest {
    public void taintMethod(HttpServletRequest request, HttpServletResponse response) {
        String requestURI = request.getRequestURI();
        TestClass test = new TestClass(requestURI);

        File file = new File(test.taint); //@ JAVA_PATH_MANIPULATION-b1b30c,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}

class TestClass {
    String taint;
    public TestClass(String taint) {
        this.taint = taint;
    }
}
