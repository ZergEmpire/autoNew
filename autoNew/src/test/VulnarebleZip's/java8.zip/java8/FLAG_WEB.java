package integration.java8;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class FLAG_WEB {
    public static InputStream WEB_chp0rr (ServerSocket serverSocket) throws IOException {
        Socket connectionsocket = serverSocket.accept(); //@ JAVA_NULL_DEREFERENCE-66jnpd

        return  connectionsocket.getInputStream();
    }
}
