package integration.java8;

import javax.servlet.jsp.JspWriter;
import java.io.IOException;
import java.io.InputStream;

public class B09ExceptionCFG {
    static JspWriter out;
    public static void foo(InputStream stream) throws IOException {

    }

    public static void main(String[] args) throws IOException {
        try {
            InputStream stream = FLAG_WEB.WEB_chp0rr(null); //@ JAVA_J2EE_DEBUG_CODE-514398
            foo(stream);
        } catch (IOException ex) {
            out.print(ex);
        }
    }
}
