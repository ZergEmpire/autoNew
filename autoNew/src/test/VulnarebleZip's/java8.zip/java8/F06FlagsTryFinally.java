package integration.java8;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class F06FlagsTryFinally {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2
        PrintWriter out = response.getWriter();
        try {

            String user = request.getParameter("user");
            Connection conn = null;
            String url = "jdbc:mysql://192.168.2.128:3306/";
            String dbName = "anvayaV2";
            String driver = "com.mysql.jdbc.Driver";
            String userName = "root";
            String password = ""; //@ JAVA_PASSWORD_EMPTY-76458b,JAVA_PRIVACY_VIOLATION_HEAP-heapin
            try {
                Class.forName(driver).newInstance();

                conn = DriverManager.getConnection(url + dbName, userName, password); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd2,JAVA_GETCONNECTION-d0810d,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_PASSWORD_EMPTY-18dc97,JAVA_MISSING_AUTHORIZATION-kts455

                Statement st = conn.createStatement(); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1

                String query = "SELECT * FROM  User where userId=" + user + "";

                out.println("Query : " + query); //@ JAVA_XSS_REFLECTED-5527c6
                System.out.printf(query); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d

                ResultSet res = st.executeQuery(query); //@ JAVA_INJECTION_SQL-33d6f1,JAVA_INJECTION_SQL_PARAMETER_TAMPERING-lri484
                out.println("Results");
                while (res.next()) {

                    String s = res.getString("username");

                    out.println("\t\t" + s); //@ JAVA_XSS_PERSISTENT-rtejle
                }
                conn.close();
            } catch (Exception e) {
                e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }
        }
        finally {
            out.close();
        }

    }
}

