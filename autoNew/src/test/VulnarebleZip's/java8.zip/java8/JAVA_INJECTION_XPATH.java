package integration.java8;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.web.bind.annotation.RequestParam;
import org.xml.sax.InputSource;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

public class JAVA_INJECTION_XPATH {

    private String username;

    public void bar(@RequestParam String data) throws XPathExpressionException
    {
        this.username = data;
        String query2 = "//users/user[name/text()='" + this.username + "']" +
            "/secret/text()";
        String xmlFile = "blabla.xml";
        /* build xpath */
        XPath xPath = XPathFactory.newInstance().newXPath();
        InputSource inputXml = new InputSource(xmlFile);
        xPath.evaluate(query2, inputXml, XPathConstants.STRING); //@ JAVA_INJECTION_XPATH-trjwk3
    }

    public static void main(String[] args) throws XPathExpressionException{
        String input = args.length != 0 ? args[1] : "guess' or '1'='1"; //@ JAVA_J2EE_DEBUG_CODE-514398
        String query = "//groups/group[@id='" + input + "']/writeAccess/text()";
        System.out.println(">> XPath.compile()"); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        {
            XPath xpath = XPathFactory.newInstance().newXPath();

            XPathExpression expr = xpath.compile(query); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_XPATH-trjwk3
        }
    }

    public static String foo(@RequestParam String data) throws XPathExpressionException
    {
        String[] tokens = data.split("||");
        /* FIX: validate input using StringEscapeUtils */
        String username = StringEscapeUtils.escapeXml(tokens[0]);
        String password = StringEscapeUtils.escapeXml(tokens[1]); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        String xmlFile = "./src/testcases/CWE643_Xpath Injection/CWE643_Xpath_Injection__Helper.xml";
        /* build xpath */
        XPath xPath = XPathFactory.newInstance().newXPath();
        InputSource inputXml = new InputSource(xmlFile);
        String query = "//users/user[name/text()='" + username +
                       "' and pass/text()='" + password + "']" +
                       "/secret/text()";
        String secret = (String)xPath.evaluate(query, inputXml, XPathConstants.STRING);

        final String unsafeUsername = StringEscapeUtils.unescapeXml(username);
        final String unsafePassword = StringEscapeUtils.unescapeXml(password);
        String query2 = "//users/user[name/text()='" + unsafeUsername +
                       "' and pass/text()='" + unsafePassword + "']" +
                       "/secret/text()";
        String secret2 = (String)xPath.evaluate(query2, inputXml, XPathConstants.STRING); //@ JAVA_INJECTION_XPATH-trjwk3
        return secret + secret2;
    }
}
