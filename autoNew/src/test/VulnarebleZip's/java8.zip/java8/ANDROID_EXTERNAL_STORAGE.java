package integration.java8;

import java.io.*;

import android.content.Context;
import android.os.Environment;

public class ANDROID_EXTERNAL_STORAGE {
    private String string = "sensitive data such as credit card number";

    public void save(FileOutputStream fos, Context context) throws IOException {
        try {

            File file = context.getExternalFilesDir(null); //@ ANDROID_EXTERNAL_STORAGE-347cab
            fos = new FileOutputStream(file, false);
            fos.write(string.getBytes());
        } finally {
            if (fos != null) {
                fos.close();
            }
        }
    }

    private void WriteToFile(String what_to_write) throws IOException {

        File root = Environment.getExternalStorageDirectory(); //@ ANDROID_EXTERNAL_STORAGE-347caa
        if (root.canWrite()) {
            File dir = new File(root + "write_to_the_SDcard");
            File datafile = new File(dir, ".extension");
            FileWriter datawriter = new FileWriter(datafile);
            BufferedWriter out = new BufferedWriter(datawriter); //@ JAVA_UNRELEASED_RESOURCE_STREAM-j11rs2
            out.write(what_to_write);
            out.close();
        }

    }
}
