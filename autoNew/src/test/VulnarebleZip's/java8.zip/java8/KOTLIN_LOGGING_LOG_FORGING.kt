package integration.java8

import android.app.Activity
import io.ktor.client.response.HttpResponse
import mu.KotlinLogging
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.debug
import org.jetbrains.anko.info
import org.jetbrains.anko.warn
import java.net.ServerSocket


class LoggerLogForging {
    companion object {
        fun foo() {}
    }
}

fun foo(serverSocket: ServerSocket) {
    val input1 = FLAG_WEB.WEB_chp0rr(serverSocket).toString()
    val logger = KotlinLogging.logger {}


    logger.debug(input1) //@ KOTLIN_LOGGING_LOG_FORGING-k11lf1
}

class SomeActivity : Activity(), AnkoLogger {

    private fun someMethod(response: HttpResponse) {


        val someContent = response.receiveContent().toString()


        info(someContent) //@ KOTLIN_LOGGING_LOG_FORGING-k21lf1

        info("London is the capital of Great Britain")
        debug(5)
        warn(null)
    }
}
