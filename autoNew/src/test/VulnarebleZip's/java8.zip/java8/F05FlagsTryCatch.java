package integration.java8;

import java.net.URL;
import java.net.URLConnection;

public class F05FlagsTryCatch {
    public static void main(String[] args) throws Throwable {

        try {
            newException() ; //@ JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2,JAVA_J2EE_DEBUG_CODE-514398
        }
        catch(Throwable taintException2) {
            System.err.println("Exception 2" + taintException2); //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
        }
    }

    public static void newException() throws Exception {
        String taintValue;
        String url = "http://www.pro-java.ru"; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae,JAVA_ERROR_HANDLING_BROAD_THROW-cd28f2,JAVA_HTTP_USAGE-fa824a
        URLConnection urlConnection = new URL(url).openConnection(); //@ JAVA_HTTP_USAGE-fa824a,JAVA_HTTP_USAGE-fa824b,JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e

        taintValue = urlConnection.getHeaderField("KEY");
        try {
            if (true) {

                throw new Exception("Exception 1..." + taintValue);
            }
        } catch (Exception taintException1) {
            taintException1.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        throw new Exception("Exception 2..." + taintValue);
    }
}
