package integration.java8

import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.client.response.HttpResponse
import io.ktor.features.CallLogging
import io.ktor.features.DefaultHeaders
import io.ktor.http.HeadersBuilder
import io.ktor.http.HttpHeaders
import io.ktor.response.header
import io.ktor.routing.Routing
import io.ktor.routing.get
import javax.servlet.http.HttpServletResponse
import javax.xml.soap.MimeHeader
import javax.xml.soap.SOAPMessage

fun Application.mainHeaderManipulation(headers: HeadersBuilder, response: HttpResponse) {
    var name: String?

    val someContent = response.receiveContent()
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            name = call.parameters["name"]

            call.response.header("name", name.toString()) //@ KOTLIN_HEADER_MANIPULATION-nfjswl

            val someContent2 = response.receiveContent()

            call.response.header("name", someContent2.toString()) //@ KOTLIN_HEADER_MANIPULATION-nfjswl
        }
    }

    headers.set(HttpHeaders.ContentLength, someContent.toString()) //@ KOTLIN_HEADER_MANIPULATION-3tghjy
}

fun addAuthorization(message: SOAPMessage, response: HttpServletResponse) {
    val headers = message.mimeHeaders
    val it = headers.allHeaders
    val header = it.next() as MimeHeader

    response.setHeader(header.name, header.value) //@ KOTLIN_HEADER_MANIPULATION-07bff5
}
