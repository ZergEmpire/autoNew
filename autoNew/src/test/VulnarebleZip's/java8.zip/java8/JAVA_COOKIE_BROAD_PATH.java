package integration.java8;

import com.google.gwt.user.client.Cookies;
import org.springframework.web.util.CookieGenerator;

import java.util.Date;
import javax.servlet.http.Cookie;
import javax.ws.rs.core.NewCookie;

public class JAVA_COOKIE_BROAD_PATH {
    public void test1() {
        Cookie terminate = new Cookie("name", "value");
        terminate.setPath("/"); //@ JAVA_COOKIE_BROAD_PATH-038707
    }

    void test(CookieGenerator cookieGenerator) {
        cookieGenerator.setCookiePath("/"); //@ JAVA_COOKIE_BROAD_PATH-08067f
        cookieGenerator.setCookiePath("/a");
    }

    void test2(javax.ws.rs.core.Cookie cookie) {
        NewCookie newCookie1 = new NewCookie("a", "b", "/", "ya.ru", "e", 1, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_COOKIE_BROAD_PATH-6566fc
        NewCookie newCookie2 = new NewCookie("a", "b", "/a", "ya.ru", "e", 1, true); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    void test3(Date expires) {
        Cookies.setCookie("name", "value", expires, "ya.ru", "/", true); //@ JAVA_COOKIE_BROAD_PATH-a9f614
        Cookies.setCookie("name", "value", expires, "ya.ru", "/er", true);
    }
}
