package integration.java8

import java.net.URL

import scala.sys.process._

class SCALA_SSRF {
  def ssrf(url: URL): Unit = {
    url #> new java.io.File("fixed.html") !

    val bad = url.getContent().toString

    new java.net.URL(bad) #> new java.io.File("fixed.html") ! //@ SCALA_SSRF-ssrf00,JAVA_INJECTION_RESOURCE-08999d
  }
}
