package integration.java8;

import javax.crypto.Cipher;

public class JAVA_CRYPTO_BAD_PADDING {
    public static void JAVA_CRYPTO_BAD_PADDING_c60299(String[] args) throws Exception {

        Cipher.getInstance("AES/CBC/NoPadding"); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
        Cipher.getInstance("AES/ECB/NoPadding", "IBMJCE"); //@ JAVA_CRYPTO_ALGORITHM_BAD_MODE-2ascty
        Cipher.getInstance("DES/CBC/PKCS5Padding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("DES/ECB/NoPadding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("DES/ECB/PKCS5Padding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("DESede/CBC/NoPadding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-qtt2ww
        Cipher.getInstance("DESede/CBC/PKCS5Padding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-qtt2ww
        Cipher.getInstance("DESede/ECB/NoPadding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-qtt2ww
        Cipher.getInstance("DESede/ECB/PKCS5Padding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-qtt2ww
        Cipher.getInstance("RSA/ECB/PKCS1Padding"); //@ JAVA_CRYPTO_BAD_PADDING-c60299
        Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
        Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        Cipher.getInstance("RC2/ECB/PKCS5Padding"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("ARCFOUR/ECB/NOPADDING"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("DES/CBC/NoPadding", "SunJCE"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("DES"); //@ JAVA_CRYPTO_BAD_ALGORITHM-7e72e1
        Cipher.getInstance("RSA"); //@ JAVA_CRYPTO_BAD_PADDING-c60299
    }
}
