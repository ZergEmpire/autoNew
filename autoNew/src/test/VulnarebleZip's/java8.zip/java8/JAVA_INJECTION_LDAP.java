package integration.java8;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchResult;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Hashtable;

public class JAVA_INJECTION_LDAP {
    public void test() throws NamingException, IOException {
        Socket socket = new Socket("host.example.org", 39544); //@ JAVA_J2EE_SOCKETS-34473d
        InputStreamReader readerInputStream = new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8);
        BufferedReader readerBuffered = new BufferedReader(readerInputStream);
        String data = readerBuffered.readLine(); //@ JAVA_DOS-9ad0eb
        final Hashtable<String, String> environmentHashTable = new Hashtable<String, String>();
        environmentHashTable.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
        environmentHashTable.put("java.naming.provider.url", "ldap://localhost:389");
        DirContext directoryContext = null;
        directoryContext = new InitialDirContext(environmentHashTable);
        final String search = "(cn=" + data + ")";

        final NamingEnumeration<SearchResult> answer = directoryContext.search("", search, null); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_INJECTION_LDAP-67cf0b
    }

    public javax.naming.NamingEnumeration<javax.naming.directory.SearchResult> doSearch(
        HttpServletRequest request,
        HttpServletResponse response,
        DirContext ctx) throws ServletException, IOException {

        String param = "";
        java.util.Enumeration<String> headers = request.getHeaders("BenchmarkTest00012");
        if (headers != null && headers.hasMoreElements()) {
            param = headers.nextElement(); // just grab first element
        }
        // URL Decode the header value since req.getHeaders() doesn't. Unlike req.getParameters().
        param = java.net.URLDecoder.decode(param, "UTF-8");
        try {
            response.setContentType("text/html");
            String base = "ou=users,ou=system";
            javax.naming.directory.SearchControls sc = new javax.naming.directory.SearchControls();
            sc.setSearchScope(javax.naming.directory.SearchControls.SUBTREE_SCOPE);
            String filter = "(&(objectclass=person))(|(uid="+param+")(street={0}))";
            Object[] filters = new Object[]{"The streetz 4 Ms bar"};
            javax.naming.directory.InitialDirContext idc = (javax.naming.directory.InitialDirContext) ctx;
            return idc.search(base, filter,filters, sc); //@ JAVA_INJECTION_LDAP-67cf0b
        } catch (javax.naming.NamingException e) {
            throw new ServletException(e);
        }
    }

}
