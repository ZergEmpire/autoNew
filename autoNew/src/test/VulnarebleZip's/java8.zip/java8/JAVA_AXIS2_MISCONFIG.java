package integration.java8;

import org.apache.axis2.client.Options;

public class JAVA_AXIS2_MISCONFIG {
    public void AXIS2_MISCONFIG() {
        Options options = new Options();

        options.setProperty("enableREST", true); //@ JAVA_AXIS2_MISCONFIG-1f9387
    }
}
