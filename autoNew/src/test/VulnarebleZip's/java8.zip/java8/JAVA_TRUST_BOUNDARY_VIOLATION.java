package integration.java8;

import javax.servlet.http.HttpServletRequest;

public class JAVA_TRUST_BOUNDARY_VIOLATION {


    public void setSessionAttributeNameTainted1(HttpServletRequest req) {
        String input = req.getParameter("input");
        req.getSession().setAttribute(input,"true"); //@ JAVA_TRUST_BOUNDARY_VIOLATION-f94969
    }


    public void setSessionAttributeValueTainted1(HttpServletRequest req) {
        String input = req.getParameter("input");
        req.getSession().setAttribute("user", input); //@ JAVA_TRUST_BOUNDARY_VIOLATION-f94968
    }


    public void setSessionAttributeValueTainted2(HttpServletRequest req) {
        String input = req.getParameter("input");
        req.getSession().setAttribute("", input); //@ JAVA_TRUST_BOUNDARY_VIOLATION-f94968
    }


    public void setSessionAttributeNameTainted2(HttpServletRequest req) {
        String input = req.getParameter("input");
        req.getSession().setAttribute(input,""); //@ JAVA_TRUST_BOUNDARY_VIOLATION-f94969
    }


    public void setSessionAttributeNameTainted3(HttpServletRequest req) {
        String input = req.getParameter("input");
        req.getSession().setAttribute(input,34); //@ JAVA_TRUST_BOUNDARY_VIOLATION-f94969
    }


    public void setSessionAttributeNameTainted4(HttpServletRequest req) {
        String input = req.getParameter("input");
        req.getSession().setAttribute(input, input);
    }

}
