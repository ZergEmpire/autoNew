package integration.java8;

import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.NewCookie;

import static javax.ws.rs.core.Cookie.DEFAULT_VERSION;
import static javax.ws.rs.core.NewCookie.DEFAULT_MAX_AGE;

public class JAVA_COOKIE_NOT_OVER_SSL {
    public void COOKIE_NOT_OVER_SSL(boolean bool) {

        NewCookie newCookie = new NewCookie("name", "value", "/path", "domain", 1, "comment", DEFAULT_MAX_AGE,false); //@ JAVA_COOKIE_NOT_OVER_SSL-62b996,JAVA_BACKDOOR_DEAD_CODE-d27d09

        NewCookie newCookie2 = new NewCookie("name", "value", "/path", "domain", 1, "comment", DEFAULT_MAX_AGE, bool); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_COOKIE_NOT_OVER_SSL-62b996
    }

    public void login(@RequestParam("user") String user, HttpServletResponse response) {
        Cookie cookie = new Cookie("access_token", "token");
        response.addCookie(cookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09
    }
}
