package integration.java8

import java.net.URL

import javax.servlet.http.{HttpServletRequest, HttpServletResponse}
import org.apache.commons.lang.StringEscapeUtils

class SCALA_XSS_VALIDATION {

  protected def doPost(req: HttpServletRequest, res: HttpServletResponse, url: URL): Unit = {
    var eid: String = req.getParameter("eid")
    eid = StringEscapeUtils.escapeHtml(eid)
    res.getOutputStream.print("Employee ID: " + eid) //@ SCALA_XSS_VALIDATION-005dce
  }
}
