package integration.java8;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;


@WebServlet(name = "BadLoginServlet1", urlPatterns = "/login")
class BadLoginServlet1 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException
    {
        final String login = req.getParameter("login");
        final String password = req.getParameter("password"); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        req.login(login, password); //@ JAVA_SESSION_FIXATION-rnrd00
    }
}

@WebServlet(name = "BadLoginServlet2", urlPatterns = "/login")
class BadLoginServlet2 extends HttpServlet {

    private final ConcurrentMap<String, String> map = new ConcurrentHashMap<>();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        final String login = req.getParameter("login"); //@ JAVA_SESSION_FIXATION-rnrd00
        final String password = req.getParameter("password"); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        if (map.containsKey(login)) {
            if (map.get(login).equals(password)) { //@ JAVA_TIMING_ATTACK-cc081a
                final Cookie cookie = new Cookie("Welcome", "True");
                cookie.setHttpOnly(true);
                cookie.setSecure(true);
                resp.addCookie(cookie); //@ JAVA_ESAPI_DEPRECATED-94fc09
            } else {
                req.setAttribute("wrong password", true);
                req.getRequestDispatcher("/badLogin.html").forward(req, resp); //@ JAVA_ESAPI_DEPRECATED-52048c
            }
        } else if (map.putIfAbsent(login, password) != null) {
            req.setAttribute("login is used", true);
            req.getRequestDispatcher("/badLogin.html").forward(req, resp); //@ JAVA_ESAPI_DEPRECATED-52048c
        }
    }
}

@WebServlet(name = "GoodLoginServlet", urlPatterns = "/login")
class GoodLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException {
        final String login = req.getParameter("login");
        final String password = req.getParameter("password"); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        req.getSession().invalidate(); //@ JAVA_ESAPI_DEPRECATED-2ceec5
        req.login(login, password);
    }
}