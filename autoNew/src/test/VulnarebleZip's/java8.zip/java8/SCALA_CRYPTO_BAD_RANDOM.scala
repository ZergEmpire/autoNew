package integration.java8

import scala.util.Random

class SCALA_CRYPTO_BAD_RANDOM {
  def randomVarious(): Unit = {
    var rand = new Random() //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    rand = new Random(1L)
    rand = new Random(1)

    rand.nextInt(256) //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    rand.nextDouble() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44

    new Random().nextBoolean() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextBytes(Array[Byte](1, 2, 3, 4)) //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextDouble() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextFloat() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextGaussian() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextInt() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextInt(111) //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextLong() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextString(16) //@ SCALA_CRYPTO_BAD_RANDOM-a07c44
    Random.nextPrintableChar() //@ SCALA_CRYPTO_BAD_RANDOM-a07c44

    scala.math.random //@ SCALA_CRYPTO_BAD_RANDOM-407c64
  }
}
