package integration.java8;

public class JAVA_BOOLEAN_GETBOOLEAN {

    public void test() {
        Boolean.getBoolean("name"); //@ JAVA_BOOLEAN_GETBOOLEAN-66c589
    }
}
