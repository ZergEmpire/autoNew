package integration.java8;

import java.sql.*;

public class JAVA_SETTING_MANIPULATION {
    public static void bypass() {

        System.setSecurityManager(null); //@ JAVA_SETTING_MANIPULATION-2a01fj
    }

    public static void setCatalog(){
        String data = data = System.getenv("ADD"); //@ JAVA_USE_GETENV-f9b0b0
        try {
            Connection connection = DriverManager.getConnection("url"); //@ JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1,JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7
            connection.setCatalog(data); //@ JAVA_SETTING_MANIPULATION-43fad3
        } catch (SQLException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
    }
}
