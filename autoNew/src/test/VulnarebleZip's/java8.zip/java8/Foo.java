package integration.java8;

import java.io.BufferedReader;

class Foo {
    void foo() throws Exception {
        BufferedReader br = null; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae
        String line = br.readLine(); //@ JAVA_DOS-7adk6b,JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_NULL_DEREFERENCE-66jnpd
    }

    abstract class Bar {
        abstract void bar();
    }
}
