package integration.java8

import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.features.CallLogging
import io.ktor.features.DefaultHeaders
import io.ktor.http.*
import io.ktor.response.header
import io.ktor.routing.Routing
import io.ktor.routing.get
import io.ktor.server.testing.handleRequest
import io.ktor.server.testing.withTestApplication
import org.junit.Test
import kotlin.test.assertEquals

fun Application.main_content_length(headers: HeadersBuilder, builder: HttpMessageBuilder) {
    var pwd: String? //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            call.response.header("Content-Length", "-100") //@ KOTLIN_NEGATIVE_CONTENT_LENGTH-3ttddw
        }
    }

    headers.set(HttpHeaders.ContentLength, "-100")

    builder.contentLength(-100) //@ KOTLIN_NEGATIVE_CONTENT_LENGTH-swty80

}
