package integration.java8

import io.ktor.application.Application
import io.ktor.application.install
import io.ktor.auth.AuthenticationPipeline
import io.ktor.auth.FormAuthChallenge
import io.ktor.auth.UserHashedTableAuth
import io.ktor.auth.UserPasswordCredential
import io.ktor.http.cookies
import io.ktor.routing.*
import io.ktor.sessions.SessionTransportTransformerDigest
import io.ktor.sessions.Sessions
import io.ktor.sessions.cookie
import io.ktor.util.decodeBase64
import io.ktor.util.getDigestFunction
import io.ktor.websocket.*


fun main(vararg args: String, application: Application) {

    val userTable = UserHashedTableAuth(getDigestFunction("MD5", salt = "ktor"), mapOf( //@ KOTLIN_CRYPTO_SALT_HARDCODED-weeedd,JAVA_BACKDOOR_DEAD_CODE-d27d09,KOTLIN_CRYPTO_BAD_HASH-ww8fdd
            "test" to decodeBase64("VltM4nfheqcJSyH887H+4NEOm2tDuKCl83p5axYXlF0=")
    ))







}
