package integration.java8;

import java.lang.Object;
public class JAVA_CORRECTNESS_NOTIFY{

    void server(){
        Object a = new Object();
        a.notify();
    }
    public synchronized static void main(String[] args){
        JAVA_CORRECTNESS_NOTIFY a = new JAVA_CORRECTNESS_NOTIFY(); //@ JAVA_J2EE_DEBUG_CODE-514398
        a.server();
        Object b = new Object();

        b.notify(); //@ JAVA_CORRECTNESS_NOTIFY-jcn001
    }
}
