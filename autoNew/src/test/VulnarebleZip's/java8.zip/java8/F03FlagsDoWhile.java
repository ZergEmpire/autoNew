package integration.java8;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;



public class F03FlagsDoWhile {




    /*
    public static void getLinks(String link, String file) {

        StringBuilder sb = new StringBuilder();

        try {
            URL url = new URL(link);

            URLConnection connect = url.openConnection();

            BufferedReader br = new BufferedReader(new InputStreamReader(connect.getInputStream()));
            String buffer = "";
            String text = "";


            do {

                buffer = br.readLine();

                if (buffer.indexOf("<a ") > 0) {
                    if (buffer.indexOf("</a") > 0) {

                        StringBuilder stringBuilder = sb.append(buffer.substring(buffer.indexOf("<a ")));
                        text = "";

                        String tainted = stringBuilder.substring(0, 100);
                        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("foo.out"));
                        Writer writer = (Writer)bufferedWriter;

                        writer.write(tainted);

                    } else {

                        text = buffer.substring(buffer.indexOf("<a "));

                        File newFile = File.createTempFile(text, "suffix");
                    }
                } else if (text.length() > 0) {
                    if (buffer.indexOf("</a") > 0) {

                        StringBuilder stringBuilder = sb.append(text).append(text + buffer.substring(1, buffer.indexOf("</a") + 4))
                                .append(System.lineSeparator());
                        text = "";

                        final FilePermission fp =
                                new FilePermission(stringBuilder.toString(), "read");
                    } else {
                        text += buffer;
                    }
                }
            } while ((buffer = br.readLine()) != null);

        } catch (IOException ex) {
            System.out.println(ex);
        }

        try (ObjectOutputStream links = new ObjectOutputStream(new FileOutputStream(file))) {
            OutputStream outputStream = (OutputStream)links;

            outputStream.write(sb.toString().getBytes());
            System.out.println("File " + file + " was saved!");
        } catch (IOException e) {
            System.out.println("Error save file!");
        }
    }*/
}
