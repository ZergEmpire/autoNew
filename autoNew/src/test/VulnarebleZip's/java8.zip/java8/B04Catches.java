package integration.java8;

public class B04Catches {
    public static void main (String[] args)
    {
        Integer i = 0; //@ JAVA_ERROR_HANDLING_CATCH_NULLPOINTEREXCEPTION-cd28f1,JAVA_J2EE_DEBUG_CODE-514398
        try
        {
            i.toString();
        }

        catch(NullPointerException e)
        {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            return;
        }
    }
}
