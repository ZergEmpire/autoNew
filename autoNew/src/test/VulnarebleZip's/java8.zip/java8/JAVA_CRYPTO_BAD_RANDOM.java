package integration.java8;

import java.util.Random;
public class JAVA_CRYPTO_BAD_RANDOM extends Random {
    private static final Random SHARED_RANDOM = null;

    public int nextInt() {

        return this.nextInt(Integer.MAX_VALUE); //@ JAVA_CRYPTO_BAD_RANDOM-c7b353
    }

    public int nextInt(final int n) {

        return JAVA_CRYPTO_BAD_RANDOM.SHARED_RANDOM.nextInt(n); //@ JAVA_CRYPTO_BAD_RANDOM-c7b353
    }

    public void test(com.google.gwt.user.client.Random random){
        com.google.gwt.user.client.Random.nextBoolean(); //@ JAVA_CRYPTO_BAD_RANDOM-70tc68
        com.google.gwt.user.client.Random.nextBoolean(); //@ JAVA_CRYPTO_BAD_RANDOM-70tc68
        com.google.gwt.user.client.Random.nextInt(); //@ JAVA_CRYPTO_BAD_RANDOM-70tc68
        com.google.gwt.user.client.Random.nextInt(1); //@ JAVA_CRYPTO_BAD_RANDOM-70tc68
    }
}
