package integration.java8;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

interface Handler {
    void handle(Object request);
}

class Server {
    private final Handler handler;

    Server(Handler handler) {
        this.handler = handler;
    }

    void serve() {
        handler.handle(new Object());
    }
}

public class JAVA_LAMBDAS {

    private final Server server;

    JAVA_LAMBDAS() throws IOException {

        final InputStream stream = FLAG_WEB.WEB_chp0rr(null);

        server = new Server(new Handler() {
            @Override
            public void handle(Object request) {

                new File(stream.toString()); //@ JAVA_PATH_MANIPULATION-b1b30c

            }
        });

    }

    JAVA_LAMBDAS(int a) throws IOException {

        final InputStream stream = FLAG_WEB.WEB_chp0rr(null);

        List<String> l = new ArrayList<>();
        l.stream()
                .map(s -> s + "foo")
                .collect(Collectors.toList());

        server = new Server(new Handler() {
            @Override
            public void handle(Object request) {

                new File(stream.toString()); //@ JAVA_PATH_MANIPULATION-b1b30c

            }
        });

    }


    JAVA_LAMBDAS(String f) throws IOException {

        final InputStream stream = FLAG_WEB.WEB_chp0rr(null);

        server = new Server(request -> new File(stream.toString())); //@ JAVA_PATH_MANIPULATION-b1b30c

    }

    void serve() {
        server.serve();
    }

}

