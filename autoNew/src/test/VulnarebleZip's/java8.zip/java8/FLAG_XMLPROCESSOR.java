package integration.java8;

import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class FLAG_XMLPROCESSOR {
    public static XMLReader FLAG_XMLPROCESSOR_erj33q() throws SAXException {
        XMLReader reader = XMLReaderFactory.createXMLReader();
        return reader;
    }
}
