package integration.java8;

import com.google.gwt.http.client.Response;
import com.google.gwt.i18n.client.Dictionary;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.web.bindery.requestfactory.shared.Receiver;
import com.google.web.bindery.requestfactory.shared.Request;
import org.restlet.resource.Result;
import org.json.JSONArray;
import org.json.JSONException;
import java.io.PrintWriter;
import java.security.Key;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Set;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Set;

public class JAVA_JAVASCRIPT_HIJACKING_AJAX {
    static public void ReceiverPrint(Request request, HttpServletResponse response, ResultSet results) throws IOException {
        final String[] html = new String[1];
        request.fire(new Receiver() {
                         @Override
                         public void onSuccess(Object o) {
                             html[0] = o.toString();
                             try {
                                 html[0] = o.toString();
                                 html[1] = results.getString(0);
                                 ServletOutputStream out = response.getOutputStream();
                                 response.setContentType("text/html");
                                 out.println("<html><body><h1>");
                                 out.println(html[0]); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-c9497e, JAVA_XSS_PERSISTENT-ebd813
                                 out.println("</h1></body></html>");
                             } catch (IOException | SQLException e) {
                                 e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                             }

                         }
                     }
        );

        ServletOutputStream out = response.getOutputStream();
        response.setContentType("text/html");
        out.println("<html><body><h1>");
        out.println(html[0]);
        out.println("</h1></body></html>");
    }

    static public void ReceiverPrint(Request request, HttpServletResponse response, Key key) throws IOException {
        request.fire(new Receiver() {
                         @Override
                         public void onSuccess(Object o) {
                             try {
                                 final String[] html = new String[2];
                                 html[0] = o.toString();
                                 html[1] = Arrays.toString(FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(key));
                                 ServletOutputStream out = response.getOutputStream();
                                 response.setContentType("text/html");
                                 out.println("<html><body><h1>");
                                 out.println(html[0]); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-c9497e
                                 out.println("</h1></body></html>");
                             } catch (IOException e) {
                                 e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                             }
                         }
                     }
        );
    }

    static public void AcyncCallback(HttpServletResponse response, Key key) {
        final String[] html = new String[1];
        getShapes("db", new AsyncCallback() {
            @Override
            public void onFailure(Throwable throwable) {
                throwable.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }

            @Override
            public void onSuccess(Object o) {
                html[0] = o.toString();
                html[1] = Arrays.toString(FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(key));
                try {
                    ServletOutputStream out = response.getOutputStream();
                    response.setContentType("text/html");
                    out.println("<html><body><h2>");
                    out.println(html[0]); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-c9497e
                    out.println("</h2></body></html>");
                } catch (IOException e) {
                    e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                }
            }
        });
    }

    static public void RestletResult(HttpServletResponse response, Key key) {
        getShapes("db", new Result() {
            @Override
            public void onFailure(Throwable throwable) {
                throwable.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
            }

            @Override
            public void onSuccess(Object o) {
                final String[] html = new String[2];
                html[0] = o.toString();
                html[1] = Arrays.toString(FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(key));
                try {
                    ServletOutputStream out = response.getOutputStream();
                    response.setContentType("text/html");
                    out.println("<html><body><h3>");
                    out.println(html[0]); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-c9497e
                    out.println("</h3></body></html>");
                } catch (IOException e) {
                    e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
                }
            }
        });
    }

    static public void onResponse(Response response, HttpServletResponse servletResponse) throws IOException {
        String text = response.getText();
        ServletOutputStream out = servletResponse.getOutputStream();
        servletResponse.setContentType("text/html");
        out.println("<html><body><h3>");
        out.println(text); //@ JAVA_XSS_REFLECTED-6719bd
        out.println("</h1></body></html>");
    }

    static public void i18nDictionary(HttpServletResponse response, Key mKey) throws IOException {
        Dictionary dictionary = Dictionary.getDictionary("dictionary");
        Set<String> keySet = dictionary.keySet();
        StringBuilder html = new StringBuilder();

        for (String key : keySet) {
            String value = dictionary.get(key);
            html.append(value);
        }
        html.append(Arrays.toString(FLAG_PRIVATE_DATA.PRIVATE_DATA_e12b0f(mKey)));

        ServletOutputStream out = response.getOutputStream();
        response.setContentType("text/html");
        out.println("<html><body><h3>");
        out.println(html.toString()); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-c9497e
        out.println("</h1></body></html>");
    }

    static private void getShapes(String databaseName, Result callback) {
        callback.onSuccess(databaseName);
    }

    static private void getShapes(String databaseName, AsyncCallback callback) {
        callback.onSuccess(databaseName);
    }

    private void jsonTest(HttpServletResponse response, JSONArray jsonArray, Key mKey) throws IOException, JSONException {
        PrintWriter out = response.getWriter();
        JSONArray newArray = jsonArray.put(FLAG_PRIVATE_DATA.PRIVATE_DATA(mKey));
        out.println(newArray); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-b5c4ae
        out.println(newArray.getString(0)); //@ JAVA_JAVASCRIPT_HIJACKING_AJAX-b5c4ae
    }

}
