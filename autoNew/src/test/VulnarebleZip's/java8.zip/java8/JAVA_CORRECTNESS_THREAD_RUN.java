package integration.java8;

public class JAVA_CORRECTNESS_THREAD_RUN {

    public static void test() {
        Thread t = new Thread(); //@ JAVA_THREADS-c030af
        t.run(); //@ JAVA_CORRECTNESS_THREAD_RUN-e05daa
    }
}
