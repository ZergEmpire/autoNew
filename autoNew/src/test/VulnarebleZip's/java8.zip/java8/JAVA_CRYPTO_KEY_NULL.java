package integration.java8;

import java.security.KeyRep;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.kerberos.KerberosKey;
import sun.security.provider.DSAPublicKeyImpl;

public class JAVA_CRYPTO_KEY_NULL {

    public String encryptionKey = null;
    private final String secretKey = null;
    private static final String privateKey = null;

    public void bad1() throws Exception {
        String cryptographicKey = null; //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae

        DESKeySpec key = new DESKeySpec(null); //@ JAVA_CRYPTO_KEY_NULL-bvnc21,JAVA_BACKDOOR_DEAD_CODE-d27d09

        KerberosKey kerberosKey = new KerberosKey(null, null, 0, 0); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_CRYPTO_KEY_NULL-bvnc27

        SecretKeySpec secretKeySpec = new SecretKeySpec(null, "alg"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        SecretKeySpec secretKeySpec1 = new SecretKeySpec(null, 0, 0, "alg"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(null); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(null); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        KeyRep keyRep = new KeyRep(null, "alg", "format", null); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        DSAPublicKeyImpl publicKey = new DSAPublicKeyImpl(null); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

}
