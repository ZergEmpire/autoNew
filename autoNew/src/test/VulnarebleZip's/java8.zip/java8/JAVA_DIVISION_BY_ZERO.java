package integration.java8;

public class JAVA_DIVISION_BY_ZERO {
    public void ttt() {
        int a = 5;
        int b = a / 0; //@ JAVA_DIVISION_BY_ZERO-jdbzd,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }
}
