package integration.java8

case class ScalaCaseClass(bar: String)

class ScalaNoEquals {
  def foo(): Unit = {
    val s1 = new ScalaNoEquals()
    val s2 = new ScalaNoEquals()
    if (s1 == s2) { //@ JAVA_CORRECTNESS_NO_EQUALS-aafc76
      println("equals")
    }
  }
}
