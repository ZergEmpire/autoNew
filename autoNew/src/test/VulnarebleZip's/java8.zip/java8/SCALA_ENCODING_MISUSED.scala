package integration.java8

import org.owasp.esapi.Encoder

class SCALA_ENCODING_MISUSED {
  def encodeForJavaScript(encoder: Encoder, s: String): String = encoder.encodeForJavaScript(s) //@ SCALA_ENCODING_MISUSED-9e310d
}