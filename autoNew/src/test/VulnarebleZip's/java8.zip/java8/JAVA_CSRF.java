package integration.java8;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JAVA_CSRF {

    private static final String USERS_TABLE_NAME = "challenge_users_6";

    @PutMapping
    @ResponseBody
    public void csrf(@RequestParam String username_reg, @RequestParam String email_reg, @RequestParam String password_reg) throws SQLException
    {
        Connection connection = DriverManager.getConnection("url"); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + USERS_TABLE_NAME + " VALUES (?, ?, ?)"); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        preparedStatement.execute();
        preparedStatement.setString(1, username_reg);
        preparedStatement.setString(2, email_reg);
        preparedStatement.setString(3, password_reg);
        preparedStatement.execute(); //@ JAVA_CSRF-csrfdb
    }
}
