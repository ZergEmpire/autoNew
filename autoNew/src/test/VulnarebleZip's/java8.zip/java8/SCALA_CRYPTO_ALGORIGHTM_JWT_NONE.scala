package integration.java8

import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwt
import io.jsonwebtoken.Jwts
import java.io.UnsupportedEncodingException


class SCALA_CRYPTO_ALGORIGHTM_JWT_NONE {
  @throws[UnsupportedEncodingException]
  def test(jwtPwd: String): Unit = {
    val jwt = Jwts.parser.setSigningKey(jwtPwd).parse("") //@ SCALA_UNTRUSTED_JWT_VALIDATION-jw23fn
    val claims = jwt.getBody.asInstanceOf[Claims]
    val token02 = Jwts.builder.setClaims(claims).setHeaderParam("alg", "none").compact //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, SCALA_CRYPTO_ALGORIGHTM_JWT_NONE-332333
  }
}