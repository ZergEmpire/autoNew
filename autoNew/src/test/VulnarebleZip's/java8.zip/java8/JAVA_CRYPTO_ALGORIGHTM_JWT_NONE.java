package integration.java8;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;

import java.io.UnsupportedEncodingException;

public class JAVA_CRYPTO_ALGORIGHTM_JWT_NONE {

    public void test(final String jwtPwd) throws UnsupportedEncodingException
    {
        Jwt jwt = Jwts.parser().setSigningKey(jwtPwd).parse(""); //@ JAVA_UNTRUSTED_JWT_VALIDATION-jw23fn
        Claims claims = (Claims) jwt.getBody();

        String token02 = Jwts.builder().setClaims(claims).setHeaderParam("alg", "none").compact(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09, JAVA_CRYPTO_ALGORIGHTM_JWT_NONE-332333
    }
}