package integration.java8;

import com.google.gwt.user.client.ui.Hidden;

public class JAVA_HIDDEN_FIELD {

    public void test() {
        new Hidden(); //@ JAVA_HIDDEN_FIELD-bcd0d4
        // There is no other tests, because that classes require bad dependencies
    }
}
