package integration.java8;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

public class JAVA_REFLECTION {
    public static void foo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String user = request.getParameter("user");
        URL url1 = null;
        URL url2 = null;
        try {

            url1 = new URL(user); //@ JAVA_INJECTION_RESOURCE-08999d

            url2 = new URL(url1, "licenses/gpl.txt"); //@ JAVA_INJECTION_RESOURCE-08999d
        } catch (MalformedURLException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }
        URL[] urls = new URL[] {url1, url2};

        URLClassLoader urlClassLoader = new URLClassLoader(urls); //@ JAVA_REFLECTION-jrwksm

        urlClassLoader.newInstance(urls); //@ JAVA_REFLECTION-giej3m
    }
}
