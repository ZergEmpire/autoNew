package integration.java8;

import org.apache.commons.lang3.StringUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPMessage;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;

public class JAVA_HEADER_MANIPULATION {
    public void doFilter(ServletRequest pServletRequest, ServletResponse pServletResponse, FilterChain chain) throws IOException, ServletException {

        String typeParam = pServletRequest.getParameter("unsubscription_key");

        ((HttpServletResponse)pServletResponse).sendRedirect(typeParam); //@ JAVA_OPEN_REDIRECT-73a862,JAVA_ESAPI_DEPRECATED-94fc09
        String latestUrl = "string";

        ((HttpServletResponse) pServletResponse).setHeader("Location", StringUtils.join(new String[]{latestUrl, "?", pServletRequest.getParameter("name")})); //@ JAVA_HEADER_MANIPULATION-07bff5
    }
    protected void addAuthorization(SOAPMessage message, HttpServletResponse response) {
        MimeHeaders headers = message.getMimeHeaders();
        Iterator it = headers.getAllHeaders();
        MimeHeader header = (MimeHeader)it.next();

        response.setHeader(header.getName(), header.getValue()); //@ JAVA_HEADER_MANIPULATION-07bff5

    }


    private class LegacyURL {
        private String url;
        private String[] urlArray;

        public LegacyURL(String url) {
            this.url = url;
            this.urlArray = url.split("/");
        }
        public String getDir() {
            return url;

        }
    }
    private String getRedirectURL(JAVA_HEADER_MANIPULATION.LegacyURL legacyUrl) {
        StringBuilder redirectUrlBuilder = (new StringBuilder()).append("/").append(legacyUrl.getDir());
        return redirectUrlBuilder.toString();
    }
    public boolean redirect(HttpServletRequest pServletRequest, HttpServletResponse pServletResponse) {
        String url = null;
        JAVA_HEADER_MANIPULATION.LegacyURL legasyUrl = new JAVA_HEADER_MANIPULATION.LegacyURL(pServletRequest.getRequestURI());
        url = this.getRedirectURL(legasyUrl);

        pServletResponse.setHeader("Location", url);
        return false;
    }
    public void splittingFromEnv(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        String data;
        data = System.getenv("ADD"); //@ JAVA_USE_GETENV-f9b0b0

        Cookie cookie = new Cookie("author", data); //@ JAVA_HEADER_MANIPULATION_COOKIES-cb8562
        response.addCookie(cookie); //@ JAVA_COOKIE_NOT_HTTPONLY-48e556,JAVA_COOKIE_NOT_OVER_SSL-4tiewu,JAVA_ESAPI_DEPRECATED-94fc09

        response.addHeader("Location", "/author.jsp?lang=" + data); //@ JAVA_HEADER_MANIPULATION-07bff5,JAVA_ESAPI_DEPRECATED-94fc09
        data = URLEncoder.encode(data, "UTF-8");
        response.setHeader("Location", "/author.jsp?lang=" + data);
    }
}
