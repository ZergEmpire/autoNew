package integration.java8

import java.sql.{DriverManager, ResultSet, SQLException}

import javax.servlet.http.HttpServletRequest
import org.springframework.web.bind.annotation.{RequestMapping, RequestMethod, RequestParam, ResponseBody}

class SCALA_INJECTION_SQL {

  @RequestMapping(method = Array(RequestMethod.POST))
  @ResponseBody
  @throws[SQLException]
  def completed(@RequestParam userid: String, request: HttpServletRequest): Unit = {
    val query = "SELECT * FROM user_data WHERE userid = " + userid
    val statement = DriverManager.getConnection("url").createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,SCALA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
      ResultSet.CONCUR_READ_ONLY)
    val results = statement.executeQuery(query) //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,SCALA_INJECTION_SQL-33d6f1
  }

}
