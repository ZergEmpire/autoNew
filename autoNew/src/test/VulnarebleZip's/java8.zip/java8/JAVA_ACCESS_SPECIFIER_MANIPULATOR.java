package integration.java8;

import java.lang.reflect.AccessibleObject;

public class JAVA_ACCESS_SPECIFIER_MANIPULATOR {
    public void ACCESS_SPECIFIER_MANIPULATOR(){
        java.lang.management.RuntimeMXBean runtime = java.lang.management.ManagementFactory.getRuntimeMXBean();
        java.lang.reflect.Field jvm = null;
        try {
            jvm = runtime.getClass().getDeclaredField("jvm");
        } catch (NoSuchFieldException e) {
            e.printStackTrace(); //@ JAVA_INFORMATION_LEAK_INTERNAL-2a08f9
        }

        jvm.setAccessible(true); //@ JAVA_NULL_DEREFERENCE_ON_SOME_PATH-j11nd2,JAVA_ACCESS_SPECIFIER_MANIPULATOR-07dca9
    }

}
