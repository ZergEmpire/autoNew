package integration.java8;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidParameterSpecException;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class JAVA_CRYPTO_BAD_IV {

    private static String CIPHER_TRANSFORMATION = "Cipher";
    private static String KEY_TYPE = "type";
    private static int KEY_SIZE_BITS = 256;
    private SecretKey key;
    private Cipher cipher;
    private byte[] ivBytes;

    public JAVA_CRYPTO_BAD_IV() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidParameterSpecException, InvalidKeyException {
        this.cipher = Cipher.getInstance(JAVA_CRYPTO_BAD_IV.CIPHER_TRANSFORMATION);
        final KeyGenerator instance = KeyGenerator.getInstance(JAVA_CRYPTO_BAD_IV.KEY_TYPE);
        instance.init(JAVA_CRYPTO_BAD_IV.KEY_SIZE_BITS);
        this.key = instance.generateKey();
        this.cipher.init(1, this.key);
        this.ivBytes = this.cipher.getParameters().getParameterSpec(IvParameterSpec.class).getIV(); // +FLAG on this.ivBytes
        new IvParameterSpec(this.ivBytes); // No Report JAVA_CRYPTO_BAD_IV-0bf092
    }

    public void encrypt(final String s) throws InvalidKeyException, InvalidAlgorithmParameterException
    {
        final IvParameterSpec algorithmParameterSpec = new IvParameterSpec(this.ivBytes); // No Report JAVA_CRYPTO_BAD_IV-0bf092
        this.cipher.init(1, this.key, algorithmParameterSpec);
    }

    public void badIV() {
        byte[] initializationVector =
                {
                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
                };

        IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector); //@ JAVA_CRYPTO_BAD_IV-0bf092,JAVA_BACKDOOR_DEAD_CODE-d27d09

        Random random = new Random();
        random.nextBytes(initializationVector); //@ JAVA_CRYPTO_BAD_RANDOM-c7b353

        IvParameterSpec ivParameterSpec2 = new IvParameterSpec(initializationVector); //@ JAVA_CRYPTO_BAD_IV-0bf092,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void goodIV() throws NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        int blockSize = cipher.getBlockSize();
        byte[] initializationVector = new byte[blockSize];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(initializationVector);

        IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void anotherGoodIV() throws InvalidParameterSpecException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        final Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        byte[] ivBytes;
        final KeyGenerator instance = KeyGenerator.getInstance("AES");
        instance.init(256);
        final SecretKey key = instance.generateKey();
        new IvParameterSpec(key.toString().getBytes());
        cipher.init(1, key);
        final AlgorithmParameters parameters = cipher.getParameters();
        new IvParameterSpec(parameters.toString().getBytes());
        final IvParameterSpec parameterSpec = parameters.getParameterSpec(IvParameterSpec.class);
        new IvParameterSpec(parameterSpec.toString().getBytes());
        ivBytes = parameterSpec.getIV();
        new IvParameterSpec(ivBytes);
    }
}
