package integration.java8;

import java.sql.DriverManager;
    import java.sql.SQLException;
    import java.util.Properties;

public class JAVA_GETCONNECTION {

    public void test(Properties properties) throws SQLException
    {
        DriverManager.getConnection("string"); //@ JAVA_GETCONNECTION-d0810d, JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7, JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
        DriverManager.getConnection("string", "string", "string"); //@ JAVA_GETCONNECTION-d0810d, JAVA_PASSWORD_HARDCODED-c0d242, JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7, JAVA_MISSING_AUTHORIZATION-kts455
        DriverManager.getConnection("string", properties); //@ JAVA_GETCONNECTION-d0810d, JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7
    }
}
