package integration.java8;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JAVA_ARRAY_OUT_OF_BOUNDS {

    public int intArrayOutOfBounds(int b) {
        if (b < 0) return b;
        int[] ar = {1, 2, 3, 4, 5};
        int a;
        if (b < 5) {
            a = ar[b];
            ar[b] = 100;
        } else {
            a = ar[b]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[b] = 100; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a;
    }

    public Object objectArrayOutOfBounds(int b) {
        if (b < 0) return b;
        Object[] ar = new Object[4];
        Object[] ar2 = ar;
        Object a;
        if (b < 5) {
            a = ar2[b];
            ar2[b] = "bla-bla";
        } else {
            a = ar2[b]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar2[b] = "bla-bla"; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a;
    }

    public long longArrayOutOfBounds(int b) {
        if (b < 0) return b;
        long[] ar = new long[4];
        long a;
        if (b < 5) {
            a = ar[b];
            ar[b] = 3L;
        } else {
            a = ar[b]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[b] = 3L; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a;
    }

    public int typeArrayOutOfBounds(int b) {
        if (b < 0) return b;
        SomeType[] ar = new SomeType[4];
        SomeType a;
        if (b < 5) {
            a = ar[b];
            ar[b] = new SomeType(5, new ArrayList<>());
        } else {
            a = ar[b]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[b] = new SomeType(5, new ArrayList<>()); //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a.field2;
    }

    public int multiDimArrayOutOfBounds(int b) {
        if (b < 0) return b;
        int[][] ar = new int[4][3];
        int a;
        if (b < 5) {
            a = ar[b][1];
            ar[b][1] = 190;
        } else {
            a = ar[1][b]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[b][1] = 190; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[1][b] = 190; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a;
    }

    public long multiDimLongArrayOutOfBounds(int b) {
        if (b < 0) return b;
        long[][][] ar = new long[4][3][5];
        long a;
        if (b < 5) {
            a = ar[1][b][1];
            ar[1][1][b] = 190;
        } else {
            a = ar[1][b][1]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[1][1][b] = 190; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[1][b][1] = 190; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a;
    }

    public int negativeArrayOutOfBounds(int b) {
        int[] ar = {1, 2, 3, 4, 5};
        int a;
        if (b >= 0) {
            a = ar[b];
            ar[b] = 100;
        } else {
            a = ar[b]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
            ar[b] = 100; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb
        }
        return a;
    }

    private class SomeType {
        private static final long field1 = 100L;
        private final int field2;
        private final List<String> field3;

        public SomeType (int field2, List<String> field3) {
            this.field2 = field2;
            this.field3 = field3;
        }
    }

    public void arrayOutOfBoundsFP(final HttpServletRequest request, final HttpServletResponse response) throws IOException
    {
        String[] pathInfo = new String[0];
        String handle = null;
        if (request.getPathInfo() != null) {
            pathInfo = request.getPathInfo().split("/");
        }
        if (pathInfo.length == 0) {
            handle = System.getProperty("site.frontpage.weblog.handle"); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        } else {
            if (pathInfo.length != 1) {
                response.sendError(400, "Malformed URL");
                return;
            }
            handle = pathInfo[0]; // no report
        }
    }

    public void arrayOutOfBoundsTP(int i) throws IOException
    {
        String[] pathInfo;
        if (i > 5) {
            pathInfo = new String[0];
        } else {
            pathInfo = new String[5];
        }
        String noTrigger = pathInfo[3]; //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        String trigger = pathInfo[6]; //@ JAVA_ARRAY_OUT_OF_BOUNDS-aroutb,JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public int deadCode() {
        int a = 0;
        int[] array = new int[10];
        int res;
        if (deadCodeHelper(a) >= 0) {
            res = array[1];
        } else {
            res = array[20];
        }
        return res;
    }

    private int deadCodeHelper(int p) {
        return p * 10;
    }
}
