package integration.java8;

import java.security.Key;
import javax.crypto.interfaces.PBEKey;

public class FLAG_PRIVATE_DATA {
    public static byte[] PRIVATE_DATA_e12b0f (Key key) {
        PBEKey pbeKey;
        pbeKey = (PBEKey) key;

        return pbeKey.getSalt();
    }

    public static String PRIVATE_DATA (Key key) {
        PBEKey pbeKey;
        pbeKey = (PBEKey) key;
        String.valueOf(pbeKey.hashCode());
        return String.valueOf(pbeKey.getPassword()); //@ JAVA_PRIVACY_VIOLATION_HEAP-6a4gd5
    }

}
