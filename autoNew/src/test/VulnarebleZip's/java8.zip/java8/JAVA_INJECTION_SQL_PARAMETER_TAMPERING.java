package integration.java8;

import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JAVA_INJECTION_SQL_PARAMETER_TAMPERING {

    public void parameterTampering(@RequestParam String username_login)
    {
        try {
            Connection connection = DriverManager.getConnection("url"); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            PreparedStatement prpStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?"); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            prpStmnt.setString(1,  username_login);
            prpStmnt.executeQuery(); //@ JAVA_INJECTION_SQL_PARAMETER_TAMPERING-fkergm
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void noParameterTampering(@RequestParam String username_login)
    {
        try {
            Connection connection = DriverManager.getConnection("url"); //@ JAVA_ACCESS_CONTROL_SECURITYMANAGER_BYPASS-518dc7,JAVA_GETCONNECTION-d0810d,JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            PreparedStatement prpStmnt = connection.prepareStatement("SELECT * FROM users WHERE name = ?"); //@ JAVA_UNRELEASED_RESOURCE_DATABASE-j11rd1
            prpStmnt.setString(0,  "login");
            prpStmnt.executeQuery();
            PreparedStatement prpStmnt2 = connection.prepareStatement("SELECT * FROM users WHERE name = ? and password = ?");
            prpStmnt2.setString(0,  username_login);
            prpStmnt2.setString(1,  "abc");
            prpStmnt2.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
