package integration.java8;

import android.net.Uri;
import android.webkit.WebView;
import retrofit2.Retrofit;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class JAVA_BACKDOOR_NETWORK_ACTIVITY {
    Retrofit retrofit = new Retrofit.Builder()
            .baseUrl("https://api.github.com/") //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr00
            .build();

    String URL = "https://api.github.com/"; //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e
    Retrofit retrofit2 = new Retrofit.Builder()
            .baseUrl(URL) //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr00
            .build();


    private static final String URLField = "https://api.github.com/"; //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e

    public void testField(){
        Retrofit retrofit3 = new Retrofit.Builder()
                .baseUrl(URLField) //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr00
                .build(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

        Retrofit retrofit4 = new Retrofit.Builder()
                .baseUrl(URL) //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr00
                .build(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    public void testFP(String newUrl) {
        Retrofit retrofit5 = new Retrofit.Builder()
                .baseUrl(newUrl)
                .build(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
    }

    String IP = "1.1.1.1"; //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e
    Retrofit retrofit6 = new Retrofit.Builder()
            .baseUrl(IP) //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr00
            .build();

    public void testWebView(WebView webView) {
        webView.loadUrl(URL); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr01
        loadLoginPage("https://api.github.com/log", webView);
    }

    public static class Urls {

        private static final String URLField = "https://api.github.com/sdfgds"; //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e

        public static String UrlField2 = "https://api.github.com/ferls"; //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-3a420e,JAVA_CORRECTNESS_NONFINAL_PUBLIC_STATIC_FIELD-j11cn1
    }

    public void testWebView2(WebView webView) {
        webView.loadUrl(Urls.URLField); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr01
        Retrofit retrofit5 = new Retrofit.Builder()
                .baseUrl(Urls.UrlField2) //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr00
                .build(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

    }

    public void testUriBuilder() {
        final Uri.Builder buildUpon = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
        buildUpon.build(); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr02
    }

    public void loadLoginPage(final String s, WebView webView) {
        webView.loadUrl(s); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr01
    }

    public void test() throws UnknownHostException
    {
        final InetAddress host = InetAddress.getAllByName("host")[0]; //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        host.equals("192.168.1.1"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
        "192.168.1.1".equals("1.1.1.1"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10,JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME-fjstnd
        "192.168.1.1".equals("11"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10,JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME-fjstnd
        "1321".equals("15.63.2.5"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
        Object o = new Object();
        "1.1.1.1".equals(o); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10,JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME-fjstnd
        host.equals(o); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
    }

    public void test2() throws UnknownHostException
    {
        final InetAddress host = InetAddress.getAllByName("https://ya.ru")[0]; //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        host.equals("1"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
        "1".equalsIgnoreCase("1.1.1.1"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
        "https://ya.ru".equalsIgnoreCase("ya.ru"); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10,JAVA_IMPROPER_AUTH_FOR_CUSTOM_SCHEME-fjstnd
        final InetAddress host2 = InetAddress.getAllByName("localhost")[0]; //@ JAVA_AUTHENTICATION_MISUSED-de24aa
        host.equals(host2); //@ JAVA_BACKDOOR_NETWORK_ACTIVITY-urlhr10
    }

    public void test3() {
        String URL = "http://purl.org/dc/";
        Retrofit retrofit2 = new Retrofit.Builder()
            .baseUrl(URL)
            .build(); //@ JAVA_BACKDOOR_DEAD_CODE-d27d12
    }
}
