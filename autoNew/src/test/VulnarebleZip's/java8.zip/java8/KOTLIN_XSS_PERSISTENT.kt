package integration.java8

import com.firefly.`$`
import com.iyanuadelekan.kanary.helpers.http.response.send
import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.features.*
import io.ktor.response.*
import io.ktor.routing.*
import java.sql.CallableStatement
import java.util.concurrent.Phaser
import javax.servlet.http.HttpServletResponse

fun Application.xssPersistent(servlet : HttpServletResponse, cs : CallableStatement) {
    var pwd: String?
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09

            pwd = call.parameters["pwd"]

            call.respondText(pwd.toString()) //@ KOTLIN_XSS_REFLECTED-kp1388,JAVA_PRIVACY_VIOLATION_HEAP-6a4gd5,KOTLIN_PRIVACY_VIOLATION-wwr390
        }

        servlet.send(cs.getString("saca")) //@ KOTLIN_XSS_PERSISTENT-jkw112




















    }
    fun main(args: Array<String>, cs: CallableStatement) { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        var str : String = cs.getString("saca");
        val phaser = Phaser(2)
        val httpServer = `$`.httpServer()

        httpServer.router().get("/").handler { ctx -> ctx.write(str).next() } //@ KOTLIN_XSS_PERSISTENT-jkw132
                .router().get("/").handler { ctx -> ctx.end("end message") }
                .listen("localhost", 8080)
        `$`.httpClient().get("http://localhost:8080/").submit() //@ JAVA_HTTP_USAGE-fa824a
                .thenAccept { res -> println(res.stringBody) } //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
                .thenAccept { res -> phaser.arrive() }
        phaser.arriveAndAwaitAdvance()
        httpServer.stop()
        `$`.httpClient().stop()
    }
}



