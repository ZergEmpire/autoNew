package integration.java8

import com.firefly.`$`
import com.iyanuadelekan.kanary.helpers.http.response.send
import io.ktor.application.Application
import io.ktor.application.call
import io.ktor.application.install
import io.ktor.client.response.HttpResponse
import io.ktor.features.*
import io.ktor.response.*
import io.ktor.routing.*
import io.ktor.util.escapeHTML
import java.sql.CallableStatement
import java.util.concurrent.Phaser
import javax.servlet.http.HttpServletResponse

fun Application.xssValidation(response: HttpResponse, servlet : HttpServletResponse, cs : CallableStatement) {
    var pwd: String?
    install(DefaultHeaders)
    install(CallLogging)
    install(Routing) {
        get("/user/{pwd}") { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09,JAVA_BACKDOOR_DEAD_CODE-d27d09

            pwd = call.parameters["pwd"]

            val someContent = response.receiveContent().toString()

            val someContentEncode = someContent.escapeHTML()

            call.respondText(someContentEncode) //@ KOTLIN_XSS_VALIDATION-tutu88

            servlet.send(cs.getString("saca").escapeHTML()) //@ KOTLIN_XSS_VALIDATION-72b111
        }
    }
    fun main(args: Array<String>, cs: CallableStatement) { //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
        var str : String = cs.getString("saca").escapeHTML();
        val phaser = Phaser(2)
        val httpServer = `$`.httpServer()

        httpServer.router().get("/").handler { ctx -> ctx.write(str).next() } //@ KOTLIN_XSS_VALIDATION-jkw133
                .router().get("/").handler { ctx -> ctx.end("end message") }
                .listen("localhost", 8080)
        `$`.httpClient().get("http://localhost:8080/").submit() //@ JAVA_HTTP_USAGE-fa824a
                .thenAccept { res -> println(res.stringBody) } //@ JAVA_LOGGING_SYSTEM_OUTPUT-b4964d
                .thenAccept { res -> phaser.arrive() }
        phaser.arriveAndAwaitAdvance()
        httpServer.stop()
        `$`.httpClient().stop()
    }
}


