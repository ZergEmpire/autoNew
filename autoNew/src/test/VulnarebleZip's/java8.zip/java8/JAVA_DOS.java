package integration.java8;

import javax.servlet.http.HttpServletRequest;
import java.io.*;

public class JAVA_DOS {
    public void DOS_7adk6b(InputStream inputStream) throws IOException {
        BufferedReader ins = new BufferedReader(new InputStreamReader(inputStream));
        String ln = "str";

        while ((ln = ins.readLine()) != null) { //@ JAVA_DOS-7adk6b
            ln = "ololo";
        }
    }

    public void queryString(HttpServletRequest request){

        request.getQueryString(); //@ JAVA_DOS-9a92b8
    }
}
