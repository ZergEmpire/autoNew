package integration.java8;

import org.apache.logging.log4j.Logger;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class D05InterProcFPTest { //@ JAVA_LOGGING_LOGGER_NOT_STATIC_FINAL-6938a1

    Logger logger;

    enum FileKind {
        PlainFile,
        Directory
    }

    private FileKind processPath(Path path) throws IOException {

        if (Files.isDirectory(path)) {
           Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
               @Override
               public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                   processPath(file);
                   return super.visitFile(file, attrs);
               }
           });
           return FileKind.Directory;
        }
        return FileKind.PlainFile;
    }

    public void handleRequest(HttpServletRequest request) throws IOException {

        String filePath = request.getPathInfo();

        Path path = Paths.get(filePath); //@ JAVA_PATH_MANIPULATION-7eab2b
        FileKind fileKind = processPath(path);

        logger.info(fileKind); //@ JAVA_NULL_DEREFERENCE-j11nd8
    }
}
