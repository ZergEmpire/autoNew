package integration.java8;

import java.io.Console;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.util.Collection;
import java.util.HashSet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.jsp.JspWriter;

public class F02FlagsWhile {

    void f02FlagsWhile(JspWriter out) throws IOException {
        Console cons;
        char[] passwd;
        if((cons = System.console()) != null && cons.readPassword("[%s]", "Password:") != null) {
            int i = 0;

            passwd = cons.readPassword("[%s]", "Password:");
            while (i < 10) {

                CharSequence sequence = new String(passwd); //@ JAVA_PRIVACY_VIOLATION_HEAP-1a46d2

                out.append(sequence);
                Collection collection = new HashSet();

                boolean didCollectionChange = collection.add(sequence.toString()); //@ JAVA_BACKDOOR_DEAD_CODE-d27d09
                Object[] array = collection.toArray();

                out.print(array); //@ JAVA_PRIVACY_VIOLATION-cedd64

                collection.clear();
                Object[] array2 = collection.toArray();

                out.print(array2);
                i++;
            }

        }

    }

    public void test1(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException
    {
        final String param = servletRequest.getParameter("param");
        Collection collection = new HashSet();
        collection.add(param);
        collection.clear();
        servletResponse.getWriter().println(collection);
    }

    public void test2(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException
    {
        final String param = servletRequest.getParameter("param");
        Collection collection = new HashSet();
        collection.add(param);
        servletResponse.getWriter().println(collection); //@ JAVA_XSS_REFLECTED-5527c6
    }

    public void test3(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException
    {
        final String param = servletRequest.getParameter("param");
        Collection collection = new HashSet();
        collection.add(param);
        collection.clear();
        Object[] array2 = collection.toArray();
        final PrintWriter writer = servletResponse.getWriter();
        writer.append(param);
        writer.println(array2);
    }

    public void test5(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException
    {
        final String param = servletRequest.getParameter("param");
        Collection collection = new HashSet();
        collection.add(param);
        Object[] array = collection.toArray();
        collection.clear();
        Object[] array2 = collection.toArray();
        final PrintWriter writer = servletResponse.getWriter();
        writer.println(array); //@ JAVA_XSS_REFLECTED-5527c6
        writer.println(array2);
    }

    public void test4(Key key, ServletResponse servletResponse) throws IOException
    {
        final String password = FLAG_PRIVATE_DATA.PRIVATE_DATA(key); //@ JAVA_PRIVACY_VIOLATION_HEAP-heapin
        Collection collection = new HashSet();
        collection.add(password);
        Object[] array = collection.toArray();
        collection.clear();
        Object[] array2 = collection.toArray();
        final PrintWriter writer = servletResponse.getWriter();
        writer.println(array); //@ JAVA_PRIVACY_VIOLATION-143b17
        writer.println(array2);
    }

    public void test6(ServletResponse servletResponse) throws IOException
    {
        final String url = "https://ya.ru";
        Collection collection = new HashSet();
        collection.add(url);
        Object[] array = collection.toArray();
        collection.clear();
        Object[] array2 = collection.toArray();
        final PrintWriter writer = servletResponse.getWriter();
        writer.println(array);
        writer.println(array2);
    }
}
