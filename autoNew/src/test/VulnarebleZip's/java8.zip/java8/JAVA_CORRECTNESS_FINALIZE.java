package integration.java8;

public class JAVA_CORRECTNESS_FINALIZE {

    protected void finalize() throws Throwable {

    } //@ JAVA_CORRECTNESS_FINALIZE-4ff744

    public void callFinalizeOnObject() throws Throwable {
        NOT_CORRECTNESS_FINALIZE badObj = new NOT_CORRECTNESS_FINALIZE(); //@ JAVA_ERROR_HANDLING_BROAD_THROW-f87bae

        try {
            badObj.sayHello();
        } finally {
            badObj.finalize();
        }
    }
}

class NOT_CORRECTNESS_FINALIZE {
    protected void finalize() throws Throwable {
        try {

        } finally {
            super.finalize();
        }
    }
    public void sayHello() {

    }
}

class CORRECTNESS_FINALIZE extends NOT_CORRECTNESS_FINALIZE {
    @Override
    protected void finalize() throws Throwable {
        try {

        } finally {
            super.finalize();
        }
    }
}
