' <yes> <report> VBNET_CRYPTO_KEY_EMPTY mkfelr
encryptionKey = ""
encryptionKey = "" + a + b
' <yes> <report> VBNET_CRYPTO_KEY_EMPTY jfkdkr
publicKey = ""
' <yes> <report> VBNET_CRYPTO_KEY_EMPTY jfkdkr
publicKey = "" + ""
publicKey = "" + a + b
' <yes> <report> VBNET_CRYPTO_KEY_EMPTY mkfelr
myEngine.cryptoKey =  ""
' <yes> <report> VBNET_CRYPTO_KEY_EMPTY mkfelr
myEngine.cryptoKey =  "" + ""
myEngine.cryptoKey =  "" + a
' <yes> <report> VBNET_CRYPTO_KEY_EMPTY mkfelr
myEnv.encryptionKey = ""
myEnv.encryptionKey = "" + a