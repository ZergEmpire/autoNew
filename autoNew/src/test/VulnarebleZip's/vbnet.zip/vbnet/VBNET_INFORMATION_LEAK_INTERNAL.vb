Dim e As New Exception()
' <yes> <report> VBNET_INFORMATION_LEAK_INTERNAL fkrlsr
Files.CreateToFile(path, e.ToString())

Dim logger as Logger = LogManager.GetCurrentClassLogger()
' <yes> <report> VBNET_INFORMATION_LEAK_INTERNAL gkflwr
logger.Trace(e.ToString())