' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
Password = "" + "sadef"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
Password = "sadef"
' <yes> <report> VBNET_PASSWORD_HARDCODED 00043t
Password = "sa def"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
Password = 1
' <yes> <report> VBNET_PASSWORD_HARDCODED 000042
myPassword = "" + "sadef"
' <yes> <report> VBNET_PASSWORD_HARDCODED 00042t
myPassword = "" + "sa def"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000042
myPassword = "sadef"
' <yes> <report> VBNET_PASSWORD_HARDCODED 00042t
myPassword = "sad ef"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000042
myEngine.rdoDefaultPassword = "dfsdf"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000042
myEngine.rdoDefaultPassword = "" + "dfsdf"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
myEnv.Password = "" + "dsfds"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
myEnv.Password = "dsfds"
' <no> <report>
a = myNewPassword < 1234567
' <yes> <report> VBNET_PASSWORD_HARDCODED 000052
if (myNewPassword = 1234567) THEN
    a = c
' <yes> <report> VBNET_PASSWORD_HARDCODED 00052t
if (myNewPassword = "123 4567") THEN
    a = c
' <yes> <report> VBNET_PASSWORD_HARDCODED 000053
if (Password = 1234567) THEN
    a = c
' <yes> <report> VBNET_PASSWORD_HARDCODED 000053
if (Password = "1234567") THEN
    a = c
' <yes> <report> VBNET_PASSWORD_HARDCODED 00053t
if (Password = "1234 567") THEN
    a = c
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
pwd = 0
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
a.b.c.pwd = 0
' <no> <report>
pwd.length = 0
' <no> <report>
a.b.f.pwd.length = 0
' <yes> <report> VBNET_PASSWORD_HARDCODED fjdltm
connectionstring = "Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=adminadmin;"
' <yes> <report> VBNET_PASSWORD_HARDCODED kgmwlt
Dim conn as New SqlConnection("Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=adminadmin;")

Dim builder As New DbConnectionStringBuilder()
' <yes> <report> VBNET_PASSWORD_HARDCODED gejkws
builder.Add("Jet OLEDB:Database Password", "*******")
