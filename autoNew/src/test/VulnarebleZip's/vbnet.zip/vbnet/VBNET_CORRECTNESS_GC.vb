' <yes> <report> VBNET_CORRECTNESS_GC 215968
GC.Collect()