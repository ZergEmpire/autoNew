' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
encryptionKey = "" + "sadef"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
encryptionKey = "sadef"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
encryptionKey = 1
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fngktj
publicKey = "" + "sadef"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fngktj
publicKey = "sadef"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fngktj
myEngine.publicKey =  "dfsdf"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fngktj
myEngine.publicKey =  "" + "dfsdf"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
myEnv.encryptionKey = "" + "dsfds"
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
myEnv.encryptionKey = "dsfds"
' <no> <report>
a = cryptoKey < 1234567
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED mfkepe
if (secretKey = 1234567) THEN
    a = c
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED kfjgte
if (cryptoKey = 1234567) THEN
    a = c
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED kfjgte
if (encryptionKey = 1234567) THEN
    a = c
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
encryptionKey = 0
' <yes> <report> VBNET_CRYPTO_KEY_HARDCODED fmgkep
a.b.c.encryptionKey = 0
' <no> <report>
encryptionKey.length = 0
' <no> <report>
a.b.f.encryptionKey.length = 0
