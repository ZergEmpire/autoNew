' <yes> <report> VBNET_PASSWORD_EMPTY 000038
myPassword = ""
' <no> <report>
myPassword = "" + a + b
' <yes> <report> VBNET_PASSWORD_EMPTY 000039
Password = ""
' <yes> <report> VBNET_PASSWORD_EMPTY 000039
Password = "" + ""
Password = "" + a + b
' <yes> <report> VBNET_PASSWORD_EMPTY 000038
myEngine.rdoDefaultPassword =  ""
' <yes> <report> VBNET_PASSWORD_EMPTY 000038
myEngine.rdoDefaultPassword =  "" + ""
myEngine.rdoDefaultPassword =  "" + a
' <yes> <report> VBNET_PASSWORD_EMPTY 000039
myEnv.Password = ""
myEnv.Password = "" + a

' <yes> <report> VBNET_PASSWORD_EMPTY fmhlte
connectionstring = "Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=;"
' <yes> <report> VBNET_PASSWORD_EMPTY gmktrk
Dim conn as New SqlConnection("Initial Catalog=TestCatalog; Data Source=myDataSource;user id=admin;password=;")
