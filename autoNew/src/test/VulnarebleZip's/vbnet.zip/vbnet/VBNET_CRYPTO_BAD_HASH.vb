' <yes> <report> VBNET_CRYPTO_BAD_HASH 000048
Using hasher As MD2 = MD2.Create()
end using
' <yes> <report> VBNET_CRYPTO_BAD_HASH 000048
Dim hasher As MD4 = MD4.Create()
' <yes> <report> VBNET_CRYPTO_BAD_HASH 000048
Using hasher As MD5 = MD5.Create()
end using
' <yes> <report> VBNET_CRYPTO_BAD_HASH 000048
Using hasher As SHA1 = SHA1.Create()
end using
Dim obj As New Chilkat.Crypt2()
crypt.HashAlgorithm = "sha256"
' <yes> <report> VBNET_CRYPTO_BAD_HASH 000666
crypt.HashAlgorithm = "sha1"