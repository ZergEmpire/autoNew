' <yes> <report> VBNET_CRYPTO_BAD_RANDOM 000002
a = CInt(Math.Ceiling(Rnd() * n)) + 1
' <no> <report>
rnd = CInt(Math.Ceiling(SecurityRandom() * n)) + 1