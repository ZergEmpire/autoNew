Dim Message, Title, Default, MyValue
Message = "Enter a value between 1 and 3"
Title = "InputBox Demo"
Default = "1"
' <yes> <report> VBNET_INFORMATION_LEAK_EXTERNAL 000085
MyValue = InputBox(Message, Title, Default)
' <yes> <report> VBNET_INFORMATION_LEAK_EXTERNAL 000084
InputBox(Message, Title, Default)

Dim e As New Exception()
textBox1 = new TextBox()
' <yes> <report> VBNET_INFORMATION_LEAK_EXTERNAL gjrmsk
textBox1.AppendText(e.ToString())
