' <yes> <report> VBNET_CRYPTO_KEY_NULL mfkskr
encryptionKey = Nothing
' <no> <report>
encryptionKey = Nothing & a
' <yes> <report> VBNET_CRYPTO_KEY_NULL lforpe
publicKey = Nothing
' <no> <report>
publicKey = Nothing & a
' <yes> <report> VBNET_CRYPTO_KEY_NULL jfktpr
Private Const encryptionKey As String = Nothing
' <yes> <report> VBNET_CRYPTO_KEY_NULL mfkelw
Private Const publicKey As String = Nothing