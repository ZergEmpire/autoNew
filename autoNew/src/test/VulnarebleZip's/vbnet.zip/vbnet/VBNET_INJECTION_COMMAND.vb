' <no> <report>
Imports Microsoft.VisualStudio.Shell.Interop

Private Sub Run_Calc()
Dim procID As Integer
' <yes> <report> VBNET_INJECTION_COMMAND 000003
procID = Shell("C:\Windows\system32\calc.exe", AppWinStyle.NormalFocus)
Dim variable as String = "C:\Windows\system32\calc.exe"
' <yes> <report> VBNET_INJECTION_COMMAND 000003
procID = Shell(variable, AppWinStyle.NormalFocus)
' <no> <report>
Shell = Asics("C:\Windows\system32\calc.exe", AppWinStyle.NormalFocus)
End Sub