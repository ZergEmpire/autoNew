'<yes> <report> VBNET_CRYPTO_BAD_SEED 030052
Randomize(3)
'<yes> <report> VBNET_CRYPTO_BAD_RANDOM 000002
Dim value As Integer = CInt(Int((6 * Rnd()) + 1))