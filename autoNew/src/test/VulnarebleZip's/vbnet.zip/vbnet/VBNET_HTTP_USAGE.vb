Dim socket As New ChilkatSocket
Dim cl As New ChilkatSocket
Dim xml As New xml
'<yes> <report> VBNET_HTTP_USAGE http00
success = socket.Connect("http://www.example.com/wpstyle/?p=364", 22, tls,maxWaitMillisec)

'<yes> <report> VBNET_HTTP_USAGE http00
url = "http://url.url"
'<yes> <report> VBNET_HTTP_USAGE http00
url2 = "http://1.1.1.1"
'<yes> <report> VBNET_HTTP_USAGE httpl0
url3 = "http://localhost"
'<yes> <report> VBNET_HTTP_USAGE http00
url4 = cl.a("http://1.1.1.1")
' <no> <report>
url5 = xml.a("http://utl.itr")
