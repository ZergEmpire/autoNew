Private Sub useHashAlgorithm()
' <yes> <report> VBNET_ERROR_HANDLING_EMPTY_CATCH 63438e
Try
Catch
End Try
' <no> <report>
Try
Catch
    Dim a As New Aes()
End Try
End Sub