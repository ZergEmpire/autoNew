' <yes> <report> VBNET_PASSWORD_NULL 000004
myPassword = Nothing
' <no> <report>
myPassword = Nothing & a
' <yes> <report> VBNET_PASSWORD_NULL 000005
Password = Nothing
' <no> <report>
Password = Nothing & a
' <yes> <report> VBNET_PASSWORD_NULL 500053
Private Const PASSWORD As String = Nothing
' <yes> <report> VBNET_PASSWORD_NULL 600053
Private Const MYPASSWORD As String = Nothing