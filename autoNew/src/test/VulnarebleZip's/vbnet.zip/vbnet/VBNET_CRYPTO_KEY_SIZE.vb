Private Sub useHashAlgorithm()
Dim a As New Aes()
' <yes> <report> VBNET_CRYPTO_KEY_SIZE sdfrwq
a.KeySize = 64
Dim r As New RSA()
' <yes> <report> VBNET_CRYPTO_KEY_SIZE sdbgwq
r.KeySize = 1024
' <yes> <report> VBNET_CRYPTO_KEY_SIZE dsrwes
Dim r2 As New RSACryptoServiceProvider(1024)
End Sub