Dim value As Integer
' <yes> <report> VBNET_BACKDOOR_HIDDEN_FUNCTIONALITY 000061 <yes> <report> VBNET_INJECTION_COMMAND 000003
value = Shell(Base64DecodeString("SGVsbG8="))
' <yes> <report> VBNET_BACKDOOR_HIDDEN_FUNCTIONALITY 000161 <yes> <report> VBNET_INJECTION_COMMAND 000055
Call Shell(UrlDecode("SGVsbG8="))
' <yes> <report> VBNET_BACKDOOR_HIDDEN_FUNCTIONALITY 000161
Execute(Base64DecodeString("SGVsbG8="))
Dim myConnection As New Connection()
' <yes> <report> VBNET_BACKDOOR_HIDDEN_FUNCTIONALITY 000161
myConnection.Execute(Base64DecodeString("SGVsbG8="), recordsAffected, Nothing)
' <yes> <report> VBNET_BACKDOOR_HIDDEN_FUNCTIONALITY 000061
value = myConnection.Execute(Base64DecodeString("SGVsbG8="), recordsAffected, Nothing)
