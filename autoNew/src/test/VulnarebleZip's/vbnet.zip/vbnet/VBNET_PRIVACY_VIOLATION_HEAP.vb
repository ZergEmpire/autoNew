Private Sub useHashAlgorithm()
' <yes> <report> VBNET_PRIVACY_VIOLATION_HEAP lekrfj
Dim password As String
' <yes> <report> VBNET_PRIVACY_VIOLATION_HEAP lfdrfj
Dim password123 As String
' <yes> <report> VBNET_PASSWORD_HARDCODED 000043
password = "123"
' <yes> <report> VBNET_PASSWORD_HARDCODED 000042
password123 = "123"
End Sub