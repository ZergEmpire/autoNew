' <yes> <report> VBNET_FILE_SEPARATOR_HARDCODED lirenk
Directory.CreateDirectory(path1 & "\" & path2)
' <yes> <report> VBNET_FILE_SEPARATOR_HARDCODED lirenk
Directory.CreateDirectory(path1 + "\" + path2)
