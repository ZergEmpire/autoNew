Private Sub useHashAlgorithm()
Dim myData = New EnvelopedCms()
' <yes> <report> VBNET_CRYPTO_BAD_ALGORITHM 000049
myData.ContentEncryptionAlgorithm.Oid = New Oid("1.2.840.113549.3.4")
' <yes> <report> VBNET_CRYPTO_BAD_ALGORITHM 000049
myData.ContentEncryptionAlgorithm.Oid = New Oid("1.3.36.3.1.1")
' <yes> <report> VBNET_CRYPTO_BAD_ALGORITHM 000050
myData.ContentEncryptionAlgorithm.Oid = New Oid("1.2.840.113549.3.2")
' <yes> <report> VBNET_CRYPTO_BAD_ALGORITHM 000051
myData.ContentEncryptionAlgorithm = New AlgorithmIdentifier(New Oid("1.2.840.113549.3.4"))
' <yes> <report> VBNET_CRYPTO_BAD_ALGORITHM 000051
myData.ContentEncryptionAlgorithm = New AlgorithmIdentifier(New Oid("1.3.36.3.1.1"))
' <yes> <report> VBNET_CRYPTO_BAD_ALGORITHM 100052
myData.ContentEncryptionAlgorithm = New AlgorithmIdentifier(New Oid("1.2.840.113549.3.2"))
End Sub