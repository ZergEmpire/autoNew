from datetime import datetime
import time

dt = datetime(2016, 4, 27)

# <yes> <report> PYTHON_BACKDOOR_TIMEBOMB a25180
if datetime.now() > dt:
    print("backdoor activated! hahaha")

# <yes> <report> PYTHON_BACKDOOR_TIMEBOMB a25180
if ((datetime.now() > dt)):
    print("backdoor activated! hahaha")

t = time.strptime("30 Nov 17", "%d %b %y")

# <yes> <report> PYTHON_BACKDOOR_TIMEBOMB 270b18
if t <= time.time():
    print("another backdoor")
