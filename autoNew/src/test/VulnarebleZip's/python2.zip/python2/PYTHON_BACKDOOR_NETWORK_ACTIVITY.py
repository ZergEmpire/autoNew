# <yes> <report> PYTHON_SSL_HOSTNAME_VERIFICATION ef0a72
import urllib
# <yes> <report> PYTHON_SSL_HOSTNAME_VERIFICATION ef0a72
import urllib2
import requests
import socket


# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 96f7fa
urllib.request.urlopen('http://example.com:8080/')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 96f7fb
response = urllib.request.urlopen('?:action=list_classifiers'+'?:action=list_classifiers')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 6f04ca
urllib2.urlopen('http://www.example.com')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 6f04cb
response = urllib2.urlopen('?:action=list_classifiers'+'?:action=list_classifiers')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 4413f3
response = requests.get('?:action=list_classifiers'+'?:action=list_classifiers')

# <no> <report>
response = requests.get(self.repository+'?:action=list_classifiers')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 4413f4
requests.get('http://79.174.66.120')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 730d11
response = socket.connect('?:action=list_classifiers'+'?:action=list_classifiers')

# <yes> <report> PYTHON_BACKDOOR_NETWORK_ACTIVITY 730d12
socket.connect('ftp://public.ftp-servers.example.com/file.txt')
