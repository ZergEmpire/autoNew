from Crypto.Cipher import AES

# <yes> <report> PYTHON_CRYPTO_KEY_NULL 126609
cipher = AES.new(None, AES.MODE_CBC, 'iv')

# <yes> <report> PYTHON_CRYPTO_KEY_NULL c37c11
token = None

