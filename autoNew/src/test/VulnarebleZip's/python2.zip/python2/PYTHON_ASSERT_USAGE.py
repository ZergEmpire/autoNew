import unittes
# <yes> <report> PYTHON_ASSERT_USAGE assert
assert logged_in

# <no> <report>
import unittest
assert logged_in
