from MiddleKit.Run import MySQLObjectStore
from django.db import connection

store = MySQLObjectStore()
query = 'DROP TABLE students'

# <yes> <report> PYTHON_INJECTION_SQL extra5
Entry.objects.extra(where=[query, "baz = 'a'"])

lname = 'Doe'
query = 'SELECT * FROM myapp_person WHERE last_name = %s' % lname

# <yes> <report> PYTHON_INJECTION_SQL rawsql
Person.objects.raw(query)

# <no> <report>
Person.objects.raw('SELECT * FROM myapp_person WHERE last_name = %s', [lname])

# <yes> <report> PYTHON_INJECTION_SQL c8d15e
store.executeSQL(query)

# <no> <report>
store.executeSQL('SELECT * FROM table')

cursor = connection.cursor()

# <yes> <report> PYTHON_INJECTION_SQL f5e2fc
cursor.execute('INSERT INTO table VALUES (%s, %s, %s)', var1, var2, var3)

# <no> <report>
cursor.execute('SELECT * FROM table')  # FIXME

id = 14

# <yes> <report> PYTHON_INJECTION_SQL f5e2fc
cursor.execute("SELECT foo FROM bar WHERE baz = '30%%' AND id = %s", id)

db =_mysql.connect(host="localhost", user="joebob",
                  passwd=pwd, db="thangs")

# <yes> <report> PYTHON_INJECTION_SQL jfek43
db.query(query)
