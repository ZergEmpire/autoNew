import time
from zipfile import ZipExtFile, ZipFile
import marshal
import asyncore
import socket

# <yes> <report> PYTHON_DOS 7be7e0
time.sleep(delay)
# <no> <report>
time.sleep(10)

with ZipFile('z.zip') as zipfile:
    # <todo> <report> PYTHON_DOS f605ce
    zipfile.extractall(dest_dir)

with ZipExtFile('e.zip') as zipextfile:
    # <todo> <report> PYTHON_DOS e8ea0b
    zipextfile.read(dest_dir)


f = open('marshal.bin', 'wb')
s = ("string", 123)
# <yes> <report> PYTHON_DOS w8ea7b
marshal.dump(s, f)
f.close()
 
inf = open('marshal.bin', 'rb')

# <yes> <report> PYTHON_DOS w8ea7b
obj = marshal.load(inf)

inf.close()


# <yes> <report> PYTHON_DOS g8ed7q
class HTTPClient(asyncore.dispatcher):

    def __init__(self, host, path):
        # <yes> <report> PYTHON_DOS g8ed7q
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, 80))
        self.buffer = 'GET %s HTTP/1.0\r\n\r\n' % path


client = HTTPClient('www.python.org', '/')
# <yes> <report> PYTHON_DOS g8ed7q
asyncore.loop()
