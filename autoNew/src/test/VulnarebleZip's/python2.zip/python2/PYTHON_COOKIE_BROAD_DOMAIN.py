from http.cookies import SimpleCookie
from WebKit.HTTPResponse import HTTPResponse
from django.conf import settings

response = HTTPResponse()
cookie = SimpleCookie()
cookie['foo'] = 'bar'

'''
# FIXME: does not detect class in this case:
from http import cookies
cookie = cookies.SimpleCookie()
'''

# <yes> <report> PYTHON_COOKIE_BROAD_DOMAIN 23dd47
cookie['foo']['domain'] = '.example.com'

# <no> <report>
cookie['foo']['field'] = 'value'

# <yes> <report> PYTHON_COOKIE_BROAD_DOMAIN 7lf1c4
SESSION_COOKIE_DOMAIN = ".example.com"

# <yes> <report> PYTHON_COOKIE_BROAD_DOMAIN 7er1c4
settings.configure(CSRF_COOKIE_DOMAIN=".example.com")


def method4(request):
    res = HttpResponse()
    path = '/path'
    # <yes> <report> PYTHON_COOKIE_BROAD_DOMAIN 7er1c5
    res.set_cookie("emailCookie", email, secure=True, httponly=True, domain=".example.com", path=path)
    return res

