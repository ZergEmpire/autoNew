import base64
# <yes> <report> PYTHON_BACKDOOR_HIDDEN_FUNCTIONALITY c9c950 <yes> <report> PYTHON_INJECTION_CODE exec34
exec(base64.b64decode(b'cHJpbnQoIlNvbGFyIGluQ29kZSBpcyB0aGUgYmVzdCEiKQ=='))
# <yes> <report> PYTHON_BACKDOOR_HIDDEN_FUNCTIONALITY c9c950
eval(base64.decodestring('cHJpbnQoIlNvbGFyIGluQ29kZSBpcyB0aGUgYmVzdCEiKQ=='))
