from django.contrib.auth.models import User
from ftplib import FTP
import mysql.connector
import hashlib
import MySQLdb

# <yes> <report> PYTHON_PASSWORD_HARDCODED eed164
password = "hardcoded"
# <yes> <report> PYTHON_PASSWORD_HARDCODED ee164t
password = "hard coded"

# <yes> <report> PYTHON_PASSWORD_HARDCODED eed164
some_object.psswd = "also_hardcoded"
# <yes> <report> PYTHON_PASSWORD_HARDCODED ee164t
some_object.psswd = "also hardcoded"

# <yes> <report> PYTHON_PASSWORD_HARDCODED eed165
password_f = "hardcoded"
# <yes> <report> PYTHON_PASSWORD_HARDCODED ee165t
password_f_n = "hard coded"

# <yes> <report> PYTHON_PASSWORD_HARDCODED eed165
some_object.psswd_f = "also_hardcoded"
# <yes> <report> PYTHON_PASSWORD_HARDCODED ee165t
some_object.psswd_f_n = "also hardcoded"

p_w_d = "not_so_hardcoded"

# <no> <report>
password = p_w_d

# <no> <report>
password = '%s%s' % (pswd1, pswd2)

# <yes> <report> PYTHON_PASSWORD_HARDCODED 12d164
user = User.objects.create_user('john', 'lennon@thebeatles.com', 'johnpassword')

u = User.objects.get(username='john')
# <yes> <report> PYTHON_PASSWORD_HARDCODED 33d164
u.set_password('newpassword')
# <yes> <report> PYTHON_PASSWORD_HARDCODED 33164t
u.set_password('new password')

# <yes> <report> PYTHON_PASSWORD_HARDCODED 17kf65
db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="john",         # your username
                     passwd="megajonhy",  # your password
                     db="jonhydb")

# <yes> <report> PYTHON_PASSWORD_HARDCODED 17kf65
cnx = mysql.connector.connect(user='scott', password='tiger',
                              host='127.0.0.1',
                              database='employees')

# <yes> <report> PYTHON_PASSWORD_HARDCODED 17kf65
self._userCreationLoop(
            uname=user1,
            host='localhost',
            password='pwd`\'"1',
            new_password='pwd`\'"1b',
            connection_user=self.user,
            connection_pass=self.password
        )

# <yes> <report> PYTHON_PASSWORD_HARDCODED 17kf65
hash = hashlib.pbkdf2(salt, iterations, password='word', digest=self.digest)

# <yes> <report> PYTHON_PASSWORD_HARDCODED the7ts
hash = hashlib.pbkdf2('word', salt, iterations, digest=self.digest)

M = poplib.POP3('localhost')
M.user(getpass.getuser())

# <yes> <report> PYTHON_PASSWORD_HARDCODED jkwl3w
M.pass_('password')


ftp = FTP('ftp.debian.org')

# <yes> <report> PYTHON_PASSWORD_HARDCODED polem3
ftp.login('anonymous', 'password', '')

M = imaplib.IMAP4()

# <yes> <report> PYTHON_PASSWORD_HARDCODED k433ws
M.login(getpass.getuser(), "password")

server = smtplib.SMTP(HOST)

# <yes> <report> PYTHON_PASSWORD_HARDCODED 8ieuww
server.login(username, 'password')

# <yes> <report> PYTHON_PASSWORD_HARDCODED fnemw3
db=_mysql.connect("127.0.0.1", "root", "umer", "sys")

passman2 = urllib2.HTTPPasswordMgr()

# <yes> <report> PYTHON_PASSWORD_HARDCODED jtetrn
passman2.add_password(None, proxy.url, proxy.user, 'proxy.password')

# <yes> <report> PYTHON_PASSWORD_HARDCODED kfmess
db = MySQLdb.connect("localhost", "root", "password")

# <yes> <report> PYTHON_PASSWORD_HARDCODED 17kf65
db = MySQLdb.connect(user="my-username", passwd="my-password", host="localhost", db="my-databasename")

zf = zipfile.ZipFile("sav.zip")

# <yes> <report> PYTHON_PASSWORD_HARDCODED fjsh43
zf.setpassword("1234")

# <no> <report>
conn = MySQLdb.connect(_info['hostname'],
                               _info['username'],
                               _info['password'],
                               _info['database'])
# <yes> <report> PYTHON_PASSWORD_HARDCODED hdnc98
app.config['SQLALCHEMY_DATABASE_URI']="mysql+pymysql://root:root@localhost:5000/myDbName"
