import hmac


# <yes> <report> PYTHON_CRYPTO_KEY_EMPTY 2af1de
priv_key = ''

# <yes> <report> PYTHON_CRYPTO_KEY_EMPTY 2af1df
secret_key_ = ''

# <yes> <report> PYTHON_CRYPTO_KEY_EMPTY 126e09 <yes> <report> PYTHON_CRYPTO_BAD_ALGORITHM b36e09
cipher = DES.new("", DES.MODE_CBC, 'iv')

# <yes> <report> PYTHON_CRYPTO_KEY_EMPTY 226e09
mac = hmac.new("", plaintext).hexdigest()

# <yes> <report> PYTHON_CRYPTO_KEY_EMPTY 2af1de
token = ""
