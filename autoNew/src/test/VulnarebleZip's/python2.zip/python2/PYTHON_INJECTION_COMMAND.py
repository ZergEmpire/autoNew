import os
import subprocess
import commands
import popen2
import smtplib
import paramiko

command = 'print("system command")'
args = 'arg1'

# <yes> <report> PYTHON_INJECTION_COMMAND parami
paramiko.exec_command('something; reallly; unsafe')

# <yes> <report> PYTHON_INJECTION_COMMAND py12ic1
os.spawn(arg1, command)

# <no> <report>
os.spawn(arg1, 'command')

# <yes> <report> PYTHON_INJECTION_COMMAND py13ic1
os.exec('string1', arg2)

# <yes> <report> PYTHON_INJECTION_COMMAND py13ic1
os.exec(arg1, string2)

# <yes> <report> PYTHON_INJECTION_COMMAND py14ic1
popen2.Popen3.__init__(arg1, arg2)

# <no> <report>
popen2.Popen3.__init__ (arg1, 'string2')

# <yes> <report> PYTHON_INJECTION_COMMAND py15ic1
popen2.popen3(arg1, arg2)

# <yes> <report> PYTHON_INJECTION_COMMAND py16ic1
commands.getoutput(arg1, arg2)

# <no> <report>
commands.getoutput('string1', arg2)

# <yes> <report> PYTHON_INJECTION_COMMAND py17ic1
smtplib.SMTP.docmd(cmd, arg2)

# <no> <report>
smtplib.SMTP.docmd (cmd, 'string2')

# <yes> <report> PYTHON_INJECTION_COMMAND py18ic1
subprocess.check_output(arg1, shell=True)

# <yes> <report> PYTHON_INJECTION_COMMAND py19ic1
subprocess.Popen.__init__(arg1, arg2, shell=True)

# <no> <report>
subprocess.Popen.__init__(arg1, 'string2', shell = True)

# <yes> <report> PYTHON_INJECTION_COMMAND subpro
subprocess.Popen('/bin/ls *', shell=True)

# <yes> <report> PYTHON_INJECTION_COMMAND subpro
subprocess.Popen('/bin/ls %s' % ('something',), shell=True)

# <yes> <report> PYTHON_INJECTION_COMMAND subpro
subprocess.Popen('/bin/ls {}'.format('something'), shell=True)

# <yes> <report> PYTHON_INJECTION_COMMAND shell1
os.popen2('command')

# <yes> <report> PYTHON_INJECTION_COMMAND shell1
os.system('echo -ne "TAG:\\n  " > %s' % readme)

# <yes> <report> PYTHON_INJECTION_COMMAND shell1
os.system('command')

# <yes> <report> PYTHON_INJECTION_COMMAND popen2
popen2.popen2('string1', arg2)

# <yes> <report> PYTHON_INJECTION_COMMAND popen2
popen2.popen3('/bin/echo hi')

# <yes> <report> PYTHON_INJECTION_COMMAND popen2
popen2.Popen4('/bin/echo hi')

# <yes> <report> PYTHON_INJECTION_COMMAND subpr2
subprocess.call("mycmd" + args, shell=False)

# <yes> <report> PYTHON_INJECTION_COMMAND subpr2
subprocess.check_output('string1', shell=True)

# <yes> <report> PYTHON_INJECTION_COMMAND subpr2
subprocess.check_call(['/bin/ls', '-l'], shell=False)

# <yes> <report> PYTHON_INJECTION_COMMAND subpr2
subprocess.check_output(['/bin/ls', '-l'])

# <yes> <report>
eval('string1')

# <yes> <report> PYTHON_INJECTION_COMMAND py11i2
eval(arg1)

# <yes> <report> PYTHON_INJECTION_COMMAND af00c9
pop('gcc --version', shell=False)

# <yes> <report> PYTHON_INJECTION_COMMAND af00c9
pipe = Popen(command, shell=False, bufsize=bufsize, stdout=PIPE).stdout

# <yes> <report> PYTHON_INJECTION_COMMAND kp0tr7
pipe = Popen(command, shell=True, bufsize=bufsize, stdout=PIPE)

# <yes> <report> PYTHON_INJECTION_COMMAND kp0tr7
pop('/bin/gcc --version', shell=True)

# <yes> <report> PYTHON_INJECTION_COMMAND 3fbfda
sys.call_tracing(command)

# <yes> <report> PYTHON_INJECTION_COMMAND cd6f58
input(command)

# <yes> <report> PYTHON_INJECTION_COMMAND fr7f87
importlib.find_loader(name, path=None)
