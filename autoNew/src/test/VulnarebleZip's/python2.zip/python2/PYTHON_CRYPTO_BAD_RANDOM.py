import random


# <yes> <report> PYTHON_CRYPTO_BAD_RANDOM a49606
random.random()

items = [1, 2, 3, 4, 5]
low = 0
high = 1
mode = 0.5

# <yes> <report> PYTHON_CRYPTO_BAD_RANDOM a49606
random.choice(items)

# <yes> <report> PYTHON_CRYPTO_BAD_RANDOM a49606
random.triangular(low, high, mode)
