docker -H tcp://0.0.0.0:2375 //d0cks0ck
export DOCKER_HOST="tcp://0.0.0.0:2375" DOCKER_TLS_VERIFY=1

docker run --rm -d --network host --name my_nginx nginx //docknethost
docker run -t -i --privileged ubuntu bash //privileged
docker run --rm -it --security-opt seccomp=unconfined debian:jessie //secoptcheck