# <yes> <report> RUBY_PASSWORD_NULL 000020
mypwd = nil
# <yes> <report> RUBY_PASSWORD_NULL 000025
pwd = nil