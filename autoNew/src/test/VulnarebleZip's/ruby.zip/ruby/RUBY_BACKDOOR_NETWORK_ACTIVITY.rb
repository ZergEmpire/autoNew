# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url1 = "https://url.irl";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url2 = "https://1.1.1.1";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne002
url3 = "https://localhost";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "1.1.1.1";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne003
url5 = cl("https://url.url");
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne003
url5 = cl "https://url.url";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne004
url6 = cl("https://localhost");
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne004
url6 = cl "https://localhost"
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "1.1.1.1/yourself";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "https://[::1]";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "https://[1762:0:0:0:0:B03:1:AF18]";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "https://[fe80::219:7eff:fe46:6c42]";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "https://[2001:0db8:0000:0000:0000:ff00:0042:8329]";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001
url4 = "https://[2001:db8::ff00:42:8329]";
