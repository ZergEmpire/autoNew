# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh000
OpenSSL::HMAC.digest('md5', key, data)
# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh000
OpenSSL::HMAC.hexdigest('SHA1', key, data)

# <yes> <report> RUBY_CRYPTO_BAD_HASH 000005
hash = OpenSSL::Digest::SHA1.new
OpenSSL::HMAC.hexdigest(hash, key, data)

# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh001
key = OpenSSL::KDF.pbkdf2_hmac('pass', salt: 'salt', iterations: 300000,
                               length: 256, hash: "md5")

# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh001
OpenSSL::KDF.pbkdf2_hmac('pass', salt: 'salt', iterations: 300000,
                               length: 256, hash: "MD4")

# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh001
OpenSSL::KDF.hkdf('pass', :salt=>'salt', :info=>'info', :length=>10, :hash=>'MD4')
# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh001
OpenSSL::KDF.hkdf('pass', salt: 'salt', info: 'info', length: 10, hash: 'sha1')
# <yes> <report> RUBY_CRYPTO_BAD_HMAC cbh001
OpenSSL::KDF.hkdf('pass', 'salt': 'salt', 'info': 'info', 'length': 10, 'hash': 'MD5')

#covered before with BAD_HASH
value = OpenSSL::KDF.pbkdf2_hmac(pass, salt: salt, iterations: iter,
                                length: len, hash: hash)

# <yes> <report> RUBY_CRYPTO_BAD_HASH 000006
digest = OpenSSL::Digest.new('md4')
OpenSSL::HMAC.digest(digest, key, data)
instance = OpenSSL::HMAC.new(key, digest)

# <no> <report>
OpenSSL::Digest.new('sha256')
# <no> <report>
OpenSSL::HMAC.digest('sha512', key, data)
# <no> <report>
OpenSSL::KDF.hkdf('pass', 'salt': 'salt', 'info': 'info', 'length': 10, 'hash': 'SHA256')
