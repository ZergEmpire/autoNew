# <yes> <report> RUBY_COOKIE_NOT_OVER_SSL 000029 <yes> <report> RUBY_COOKIE_NOT_HTTPONLY 000030
HTTP::Cookie.new("uid", "a12345", :domain => 'example.org')
# <yes> <report> RUBY_COOKIE_NOT_OVER_SSL 000029 <yes> <report> RUBY_COOKIE_NOT_HTTPONLY 000030
HTTP::Cookie.new("uid", "a12345", domain: 'example.org')
# <yes> <report> RUBY_COOKIE_NOT_OVER_SSL 000029
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure: false, httponly: true)
# <yes> <report> RUBY_COOKIE_NOT_OVER_SSL 000029
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure?: false, httponly: true)
# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure: true, httponly: true)
# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure?: true, httponly: true)

#https://www.ruby-toolbox.com/search?utf8=✓&display=compact&q=Cookie