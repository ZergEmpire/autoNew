user_input = request.file
# <yes> <report> RUBY_PATH_MANIPULATION 000028
File.delete "/tmp/" + user_input
# <yes> <report> RUBY_PATH_MANIPULATION 000028
File.delete("/tmp/" + user_input)
# <yes> <report> RUBY_PATH_MANIPULATION 000028
File.delete "/tmp/" + request.file
# <yes> <report> RUBY_PATH_MANIPULATION 000028
File.delete "path/to/dir/#{user_input}"
# <yes> <report> RUBY_PATH_MANIPULATION 000028
Dir.entries "/tmp/" + user_input
# <yes> <report> RUBY_PATH_MANIPULATION 000028
Dir.entries "/tmp/" + request.file
# <yes> <report> RUBY_PATH_MANIPULATION 000028
Dir.entries "path/to/dir/#{user_input}"
# <yes> <report> RUBY_PATH_MANIPULATION 000028
Dir.entries("path/to/dir/#{user_input}")

var = "const"
# <no> <report>
File.delete "/tmp/" + var
# <no> <report>
Dir.entries "path/to/dir/#{var}"
# <no> <report>
File.delete "fixed/path"
# <no> <report>
File.delete("/tmp/" + var)
# <no> <report>
Dir.entries("path/to/dir/#{var}")
# <no> <report>
File.delete("fixed/path")
