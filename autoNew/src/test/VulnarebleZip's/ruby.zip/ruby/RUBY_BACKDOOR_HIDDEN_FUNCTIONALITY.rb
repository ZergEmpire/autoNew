require "base64"

msg = "ZWNobyAiU29sYXIgaW5Db2RlIGlzIHRoZSBiZXN0ISI="
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf000
`#{Base64.decode64(msg)}`
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf000
%x[#{Base64.strict_decode64(msg)}]
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
system(Base64.decode64(msg))
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
Kernel.spawn(Base64.decode64(msg))
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
exec(Base64.decode64(msg))
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
Process.spawn(Base64.decode64(msg))
# <yes> <report> RUBY_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
IO.popen(Base64.decode64(msg))

# <no> <report>
puts Base64.decode64(msg)
# <no> <report>
`echo "hello world"`
# <no> <report>
exec("echo hello world")

#flag flow is needed
=begin
command = Base64.urlsafe_decode64(msg)
# <yes>
system(command)
# <yes>
Kernel.system(command)
# <yes>
spawn(command)
# <yes>
Kernel.spawn(command)
# <yes>
exec(command)
# <yes>
Kernel.exec(command)
# <yes>
f = IO.popen(command)
f.readlines
# <yes>
Process.exec(command)
# <yes>
Process.spawn(command)
=end