require 'openssl'
# <yes> <report> RUBY_CRYPTO_KEY_SIZE 000017
OpenSSL::PKey::RSA.new 1024
# <no> <report>
OpenSSL::PKey::RSA.new 2048
# <yes> <report> RUBY_CRYPTO_KEY_SIZE 000017
OpenSSL::PKey::RSA.new(1024)
# <no> <report>
OpenSSL::PKey::RSA.new(2048)