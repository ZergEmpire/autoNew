require 'digest'
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000005
md5 = Digest::MD5.new
md5.update 'message1'
md5 << 'message2'
md5.hexdigest
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000007
Digest::MD5.digest 'message'
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000007
Digest::MD5.hexdigest('message')
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000007
Digest::MD5.hexdigest ('message')

require 'openssl'
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000005
digest = OpenSSL::Digest::MD4.new
hash = digest.update('digestdata')

# <yes> <report> RUBY_CRYPTO_BAD_HASH 000006
digest = OpenSSL::Digest.new('sha1')
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000008
sha = OpenSSL::Digest.digest("SHA", "abc")
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000008
sha = OpenSSL::Digest.digest "SHA", "abc"

require 'chilkat'
crypt = Chilkat::CkCrypt2.new()
s = "The quick brown fox jumps over the lazy dog"
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000014
crypt.put_HashAlgorithm("sha1")
# <yes> <report> RUBY_CRYPTO_BAD_HASH 000014
crypt.put_HashAlgorithm "sha1"
crypt.put_EncodingMode("hex")
