require 'openssl'
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000001
encrypt = OpenSSL::Cipher::Cipher.new("des-ecb")
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000001
encrypt = OpenSSL::Cipher::Cipher.new "des-ecb"
encrypt.encrypt
encrypted = encrypt.update("Mypassword")



# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000002
cipher = OpenSSL::Cipher::RC2.new(40, :CBC)
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000002
cipher = OpenSSL::Cipher::RC2.new 40, :CBC
cipher.encrypt
encrypted2 = cipher.update("Very, very confidential data") + cipher.final

require 'rc4'
key = "nuff rspec"
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000003
enc = RC4.new(key)
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000003
enc = RC4.new key
encrypted3 = enc.encrypt("super-cool-test")
puts encrypted3

# <no> <report>
pool = described_class.new(:http_proxy => http_proxy)

require 'chilkat'

crypt = Chilkat::CkCrypt2.new()
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000004
crypt.put_CryptAlgorithm("3des")
# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000004
crypt.put_CryptAlgorithm '3des'
encStr = crypt.encryptStringENC("The quick brown fox jumps over the lazy dog.")
