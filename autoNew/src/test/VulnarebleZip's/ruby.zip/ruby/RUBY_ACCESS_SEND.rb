a = [1, 2, 3]
# <yes> <report> RUBY_ACCESS_SEND 000026
a.send "to_s"
# <yes> <report> RUBY_ACCESS_SEND 000026
a.send(:to_s)
# <yes> <report> RUBY_ACCESS_SEND 000027
a.__send__ :take, 2

class Test
  def send
    "Hello"
  end
end

t = Test.new
# <no> <report>
t.send
# <no> <report>
t.send.index 'l'