require 'bcrypt'

message = 'something'
# <yes> <report> RUBY_CRYPTO_SALT_HARDCODED csh000
hash_something = message.crypt('salt')
# <yes> <report> RUBY_CRYPTO_SALT_HARDCODED csh000
hash_something = message.crypt 'salt'

salt = BCrypt::Engine.generate_salt
# <no> <report>
hash_func = BCrypt::Engine.hash_secret 'secret', salt
