# <yes> <report> RUBY_PASSWORD_HARDCODED 000021
mypassword = 'password'
# <yes> <report> RUBY_PASSWORD_HARDCODED 000021
mypassword = "password"
# <yes> <report> RUBY_PASSWORD_HARDCODED 00021t
mypassword = 'pass word'
# <yes> <report> RUBY_PASSWORD_HARDCODED 00021t
mypassword = "pass word"
# <yes> <report> RUBY_PASSWORD_HARDCODED 000021
mypwd = 123456
# <yes> <report> RUBY_PASSWORD_HARDCODED 000024
password = 'password'
# <yes> <report> RUBY_PASSWORD_HARDCODED 000024
password = "password"
# <yes> <report> RUBY_PASSWORD_HARDCODED 00024t
password = 'pass word'
# <yes> <report> RUBY_PASSWORD_HARDCODED 00024t
password = "pass word"
# <yes> <report> RUBY_PASSWORD_HARDCODED 000024
pwd = 123456

p_w_d = "not_so_hardcoded"
# <no> <report>
password = p_w_d
# <no> <report>
mypwd += 1