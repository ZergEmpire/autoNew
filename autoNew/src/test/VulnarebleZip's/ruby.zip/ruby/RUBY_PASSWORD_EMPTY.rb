# <yes> <report> RUBY_PASSWORD_EMPTY 000019
password123 = ''
# <yes> <report> RUBY_PASSWORD_EMPTY 000019
pswd123 = ""
# <yes> <report> RUBY_PASSWORD_EMPTY 000023
password = ''
# <yes> <report> RUBY_PASSWORD_EMPTY 000023
pswd = ""