# <yes> <report> RUBY_OPEN_URI 001022
require 'open-uri'
require 'net/http'
params = {'param1' => 'value1', 'param2' => 'value2'}
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne003 <yes> <report> RUBY_HTTP_USAGE rhhtp1
url = URI.parse('http://thewebsite.com/thepath')
resp, data = Net::HTTP.post_form(url, params)
puts resp.inspect
puts data.inspect
