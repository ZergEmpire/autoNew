# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> RUBY_HTTP_USAGE rhhtp0
url1 = "http://url.irl";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne001 <yes> <report> RUBY_HTTP_USAGE rhhtp0
url2 = "http://1.1.1.1";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne002 <yes> <report> RUBY_HTTP_USAGE rhhtp0
url3 = "http://localhost";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne003 <yes> <report> RUBY_HTTP_USAGE rhhtp1
url4 = cl("http://url.url");
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne003 <yes> <report> RUBY_HTTP_USAGE rhhtp1
url4 = cl "http://url.url";
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne004 <yes> <report> RUBY_HTTP_USAGE rhhtp1
url5 = cl("http://localhost");
# <yes> <report> RUBY_BACKDOOR_NETWORK_ACTIVITY bne004 <yes> <report> RUBY_HTTP_USAGE rhhtp1
url5 = cl "http://localhost"