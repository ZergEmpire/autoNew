# <yes> <report> RUBY_PASSWORD_HARDCODED 000024
password = 'qwerty'
# <yes> <report> RUBY_CRYPTO_KEY_HARDCODED ckh002
key = '917bfd5a'
hash = 'abcdef'

# <yes> <report> RUBY_PASSWORD_HARDCODED 000021
right_password = 'qwerte'
# <yes> <report> RUBY_CRYPTO_KEY_HARDCODED ckh002
right_key = '716544cf'
right_hash = 'abcdef'

# <yes> <report> RUBY_TIMING_ATTACK ta0000
if password == right_password then
    p 'possible timing attack'
end
# <yes> <report> RUBY_TIMING_ATTACK ta0000
if key != right_key then
else
    p 'possible timing attack'
end
# <yes> <report> RUBY_TIMING_ATTACK ta0000 <yes> <report> RUBY_BACKDOOR_SPECIAL_ACCOUNT 000132
if 'ba7651cd9008761d' == hash then
    p 'possible timing attack'
end
# <yes> <report> RUBY_TIMING_ATTACK ta0000
unless key == right_key then
    p 'possible timing attack'
end
# <yes> <report> RUBY_TIMING_ATTACK ta0000
func if password == right_password
# <yes> <report> RUBY_TIMING_ATTACK ta0000
func unless password != right_password

# <no> <report>
if key != 1 then
end
# <no> <report>
return 123 if the_key == ' t'
key_size = 6
# <no> <report>
if key.length != key_size then
    raise "Incorrect DES key length (%d bytes)" % key.length
end
