config.middleware.insert_before 0, Rack::Cors do
    allow do
        # <yes> <report> RUBY_HTML5_CORS htmlc0
        origins '*'
        resource(
            '*',
            headers: :any,
            methods: [:get, :patch, :put, :delete, :post, :options]
        )
    end
end

Rails.application.config.middleware.insert_before 0, Rack::Cors do
    allow do
        # <yes> <report> RUBY_HTML5_CORS htmlc0
        origins '*'
        resource '*', headers: :any, methods: [:get, :post, :patch, :put]
    end
end

Rails.application.config.middleware.insert_before 0, Rack::Cors do
    allow do
        # <yes> <report> RUBY_HTML5_CORS htmlc0
        origins '*example.com'
        resource '*', headers: :any, methods: [:get, :post, :patch, :put]
    end
end

Rails.application.config.middleware.insert_before 0, Rack::Cors do
    allow do
        # <yes> <report> RUBY_HTML5_CORS htmlc0
        origins('example.com*')
        resource '*', headers: :any, methods: [:get, :post, :patch, :put]
    end
end

Rails.application.config.middleware.insert_before 0, Rack::Cors do
    allow do
        # <no> <report>
        origins 'example.com/*'
        resource '*', headers: :any, methods: [:get, :post, :patch, :put]
    end
end

smthg do
    # <no> <report>
    origins '*'
end

# <no> <report>
origins('*')