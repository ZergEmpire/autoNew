# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure?: true, httponly?: true, path: "/somepath")
# <yes> <report> RUBY_COOKIE_BROAD_DOMAIN 000032
HTTP::Cookie.new("uid", "a12345", domain: '.example.org', secure?: true, httponly?: true, path: "/somepath")
# <yes> <report> RUBY_COOKIE_BROAD_DOMAIN 000032
HTTP::Cookie.new("uid", "a12345", domain: '.example.org', for_domain: false, secure?: true, httponly?: true, path: "/somepath")
# <yes> <report> RUBY_COOKIE_BROAD_DOMAIN 000032
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', for_domain: true, secure?: true, httponly?: true, path: "/somepath")
# <yes> <report> RUBY_COOKIE_BROAD_DOMAIN 000032
HTTP::Cookie.new("uid", "a12345", domain: "example.org", for_domain: true, secure?: true, httponly?: true, path: "/somepath")

#https://www.ruby-toolbox.com/search?utf8=✓&display=compact&q=Cookie