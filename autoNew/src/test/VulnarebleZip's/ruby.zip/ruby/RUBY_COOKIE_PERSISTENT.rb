# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', for_domain: false, secure?: true, httponly?: true, path: "/somepath", expires_at: Time.now + 900)
# <yes> <report> RUBY_COOKIE_PERSISTENT 000033
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', for_domain: false, secure?: true, httponly?: true, path: "/somepath", expires: Time.now + 1000)
# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', for_domain: false, secure?: true, httponly?: true, path: "/somepath", max_age: 900)
# <yes> <report> RUBY_COOKIE_PERSISTENT 000034
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', for_domain: false, secure?: true, httponly?: true, path: "/somepath", max_age: 1000)