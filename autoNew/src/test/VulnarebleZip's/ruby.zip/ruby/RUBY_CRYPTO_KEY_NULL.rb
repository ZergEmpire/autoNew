# <yes> <report> RUBY_CRYPTO_KEY_NULL ckn001
priv_key = nil

# <yes> <report> RUBY_CRYPTO_KEY_NULL ckn000
secret_key_ = nil

# <yes> <report> RUBY_CRYPTO_KEY_NULL ckn002
key = nil