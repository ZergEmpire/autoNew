require 'openssl'
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011
prng = Random.new
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011
prng = Random.new()

# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000013
prng.rand(100)
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000013
prng.rand
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000013
prng.rand 100

# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000012    
rand

# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000012
rand(1000)
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000012
rand 1000
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011
random_string = Random.new.bytes(10)
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011
random_string = Random.new.bytes 10
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011 <yes> <report> RUBY_CRYPTO_BAD_SEED 000015
bytes = Random.new(100).bytes(10)
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011 <yes> <report> RUBY_CRYPTO_BAD_SEED 000015
bytes = Random.new(100).bytes 10

require 'securerandom'
8.times do 
	puts SecureRandom.random_number(100)
end


arr = [1, 2, 3, 4, 5]
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000018
arr.sample(2)
# <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000018
arr.sample 2
x = SomeClass.new
# <no> <report>
x.sample

require 'securerandom'

# <no> <report>
SecureRandom.random_number