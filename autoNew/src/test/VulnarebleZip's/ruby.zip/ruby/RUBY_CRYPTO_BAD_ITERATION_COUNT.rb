# <yes> <report> RUBY_CRYPTO_BAD_ITERATION_COUNT cbic00
OpenSSL::KDF.pbkdf2_hmac('pass', salt: 'salt', iterations: 40960,
                               length: 256, hash: "SHA512")

# <yes> <report> RUBY_CRYPTO_BAD_ITERATION_COUNT cbic01
OpenSSL::KDF.pbkdf2_hmac('pass', :salt=>'salt', :iterations=>50,
                               :length=>256, :hash=>"SHA512")

# <no> <report>
OpenSSL::KDF.pbkdf2_hmac('pass', 'salt': 'salt', 'iterations': 300000,
                               'length': 256, 'hash': "SHA512")

# <yes> <report> RUBY_CRYPTO_BAD_ITERATION_COUNT cbic02
BCrypt::Engine.cost = 10
# <yes> <report> RUBY_CRYPTO_BAD_ITERATION_COUNT cbic03
BCrypt::Password.create('secret', cost: 8)
# <no> <report>
BCrypt::Password.create('secret', :cost => 20)
