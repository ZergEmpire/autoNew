# <yes> <report> RUBY_CRYPTO_KEY_HARDCODED ckh002
key = "7bf651dda432aadd"
# <no> <report>
key = 'key'
# <no> <report>
k = "not_so_hardcoded"
# <no> <report>
key = k