require 'rexml/document'
include REXML
xmlfile = File.new("payments.xml")
xmldoc = Document.new(xmlfile)
# Необходимо рассмотреть библиотеки для XPath в Ruby
payments = XPath.each(xmldoc, "//payment[@pan=#{params[:pan]}]")

#https://www.ruby-toolbox.com/categories/html_parsing