# <yes> <report> RUBY_COOKIE_NOT_HTTPONLY 000030
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure: true, path: "/somepath",  httponly: false)
# <yes> <report> RUBY_COOKIE_NOT_HTTPONLY 000030
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure: true, path: "/somepath", httponly?: false)
# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure: true, path: "/somepath", httponly: true)
# <no> <report>
HTTP::Cookie.new("uid", "a12345", domain: 'example.org', secure?: true, path: "/somepath", httponly?: true)

#https://www.ruby-toolbox.com/search?utf8=✓&display=compact&q=Cookie