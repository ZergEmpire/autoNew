#нужно поддерживать популярные библиотеки
#https://www.ruby-toolbox.com/categories/SQL_Database_Adapters