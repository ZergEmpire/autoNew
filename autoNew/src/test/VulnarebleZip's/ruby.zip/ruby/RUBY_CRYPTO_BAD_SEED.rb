# <yes> <report> RUBY_CRYPTO_BAD_SEED 000015 <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011 
prng = Random.new(12)
# <yes> <report> RUBY_CRYPTO_BAD_SEED 000015 <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011
prng = Random.new 12
# <yes> <report> RUBY_CRYPTO_BAD_SEED 000015 <yes> <report> RUBY_CRYPTO_BAD_RANDOM 000011
Random.new(12).to_s
# <yes> <report> RUBY_CRYPTO_BAD_SEED 000016
srand(1234)
# <yes> <report> RUBY_CRYPTO_BAD_SEED 000016
srand 1234