require 'openssl'
def encrypt_RSA(key, message )
# <no> <report>
    key.public_encrypt(message, OpenSSL::PKey::RSA::PKCS1_OAEP_PADDING)
# <no> <report>
    key.public_encrypt message, OpenSSL::PKey::RSA::PKCS1_OAEP_PADDING
end
def encrypt_RSA(key, message )
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.public_decrypt(message)
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.public_decrypt message
end
def encrypt_RSA(key, message )	
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.private_encrypt(message)
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.private_encrypt message
end
def encrypt_RSA(key, message )
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.public_encrypt(message)
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.public_encrypt message
end
def encrypt_RSA(key, message )
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.private_decrypt(message)
# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000009
    key.private_decrypt message
end

# <yes> <report> RUBY_CRYPTO_BAD_PADDING 000010
def crypt(value, padding = OpenSSL::PKey::RSA::NO_PADDING )
  public_key = get_rsa_key 'public.pem'
  public_key.public_encrypt value, padding
end
