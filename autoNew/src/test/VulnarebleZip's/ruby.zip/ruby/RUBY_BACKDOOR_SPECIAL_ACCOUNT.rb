# <yes> <report> RUBY_BACKDOOR_SPECIAL_ACCOUNT 000131
if password == "qwerty"
    puts "Hello, World!"
end
# <yes> <report> RUBY_BACKDOOR_SPECIAL_ACCOUNT 000131
if pass == "1325355132"
    puts "Hello, World!"
end
# <yes> <report> RUBY_BACKDOOR_SPECIAL_ACCOUNT 000131
if username == "1234567777777"
    puts "Hello, World!"
end
# <yes> <report> RUBY_BACKDOOR_SPECIAL_ACCOUNT 000131
if usr == '1234567777777'
    puts "Hello, World!"
end
# <yes> <report> RUBY_BACKDOOR_SPECIAL_ACCOUNT 000132
if password == "8743b52063cd84097a65d1633f5c74f5"
    puts "Hello, World!"
end
# <no> <report>
if password == ""
    puts "Hello, World!"
end
# <no> <report>
if f(username) == "ads"
    puts "Hello, World!"
end
# <no> <report>
if username == f("asd")
    puts "Hello, World!"
end
# <no> <report>
if pwd == "#{pass}"
    puts "nonono"
end
# <no> <report>
if pwd == "vecjnlc#{pass}97246"
    puts "nonono"
end
# <no> <report>
if password == true
    puts "nonono"
end