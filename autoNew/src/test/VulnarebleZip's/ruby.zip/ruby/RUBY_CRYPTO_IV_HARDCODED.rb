decipher = OpenSSL::Cipher::AES.new(128, :CBC)
# <yes> <report> RUBY_CRYPTO_IV_HARDCODED civh00
decipher.iv = "\xD0:\x86\xB4\xD9\xA8\x8E\x89\xFD\xFAv]\xD4\t\xEE\a"

# <yes> <report> RUBY_CRYPTO_BAD_ALGORITHM 000001
decipher = OpenSSL::Cipher::Cipher.new 'des-cbc'
# <yes> <report> RUBY_CRYPTO_IV_HARDCODED civh00
decipher.iv = "\xD0:\x86\xB4\xD9\xA8\x8E\x89\xFD\xFAv]\xD4\t\xEE\a"

decipher = OpenSSL::Cipher.new 'aes-256-ofb'
# <yes> <report> RUBY_CRYPTO_IV_HARDCODED civh00
decipher.iv = "\xD0:\x86\xB4\xD9\xA8\x8E\x89\xFD\xFAv]\xD4\t\xEE\a"

cipher = OpenSSL::Cipher::AES256.new(:CFB)
# <yes> <report> RUBY_CRYPTO_IV_HARDCODED civh00
cipher.iv = "\xD0:\x86\xB4\xD9\xA8\x8E\x89\xFD\xFAv]\xD4\t\xEE\a"
# <no> <report>
cipher.key = cipher.random_key
