# <yes> <report> PERL_PASSWORD_EMPTY pwde01
my $password = "";
# <yes> <report> PERL_PASSWORD_EMPTY pwde02
$secret_pwd = '';
# <yes> <report> PERL_PASSWORD_EMPTY pwde02
$pwd_user = qq!!;
# <yes> <report> PERL_PASSWORD_EMPTY pwde03
$dbh = DBI->connect(
     "DBI:mysql:$database",
     $user, "");
# <yes> <report> PERL_PASSWORD_EMPTY pwde05
$myConnection = Mysql->connect('localhost','DBNAME','USERNAME','');
# <yes> <report> PERL_PASSWORD_EMPTY pwde04
$lda = &ora_login('personnel', 'scott', '');

my $ua = LWP::UserAgent->new( cookie_jar => $jar );
# <yes> <report> PERL_PASSWORD_EMPTY pwde06
$ua->credentials("www.example.com:80", "Some Realm", "foo", "");