# <yes> <report> PERL_BACKDOOR_TIMEBOMB btb000
if (localtime() == '11.11.2099') { #localtime(), gmtime(), time()
    ...
}