# <yes> <report> PERL_PASSWORD_HARDCODED pwdh01
my $password = "s3kr1t_password";
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh1t
my $password = "s3kr1t password";
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh02
$secret_pwd = 'passw';
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh2t
$secret_pwd = 'pas sw';
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh02
$secret_pwd = 123;
# <no> <report> PERL_PASSWORD_HARDCODED pwdh02
$pwd_column_num = 1;
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh02
$pwd_user = qq!passw!;
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh03
$dbh = DBI->connect(
     "DBI:mysql:$database",
     $user, "password");
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh04
$lda = &ora_login('personnel', 'scott', 'tiger');
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh05
$myConnection = Mysql->connect('localhost','DBNAME','USERNAME','PASSWORD');

my $ua = LWP::UserAgent->new( cookie_jar => $jar );
# <yes> <report> PERL_PASSWORD_HARDCODED pwdh06
$ua->credentials("www.example.com:80", "Some Realm", "foo", "secret"); # $ua->credentials( $netloc, $realm, $uname, $pass );