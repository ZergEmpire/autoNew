use Digest::MD5;
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$ctx = Digest::MD5->new;
$ctx->add($data);
$ctx->addfile($file_handle);
$digest = $ctx->digest;

use Digest::SHA;
use Digest::SHA::PurePerl;

# <yes> <report> PERL_CRYPTO_BAD_HASH hash03
$sha = Digest::SHA->new($alg); # Allowed values for $alg are 1, 224, 256, 384, 512, 512224, or 512256
# <yes> <report> PERL_CRYPTO_BAD_HASH hash03
$sha2 = Digest::SHA::PurePerl->new($alg);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash04
$sha3 = Digest::SHA->new(1);
# <no> <report> PERL_CRYPTO_BAD_HASH
$sha4 = Digest::SHA::PurePerl->new(256);

# OO style
use Digest::MD2;
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$ctx = Digest::MD2->new;
$digest = $ctx->digest;


use Digest::MD5 qw(md5 md5_hex md5_base64);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = md5($data);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = md5_hex($data);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = md5_base64($data);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$hash = md5 $data;
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$hash = md5_hex $data;
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$hash = md5_base64 $data;

use Digest::SHA qw(sha1 sha1_hex sha1_base64 ...);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = sha1($data);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = sha1 $data;
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = sha1_hex($data);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = sha1_base64($data);
# <no> <report> PERL_CRYPTO_BAD_HASH
$digest = sha256($data);
# <no> <report> PERL_CRYPTO_BAD_HASH
$digest = sha384_hex($data);
# <no> <report> PERL_CRYPTO_BAD_HASH
$digest = sha512_base64($data);

use MD5;

# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$context = new MD5;
$string = $context->hexdigest();
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$digest = MD5->hash(SCALAR);
# <yes> <report> PERL_CRYPTO_BAD_HASH hash01
$string = MD5->hexhash(SCALAR);