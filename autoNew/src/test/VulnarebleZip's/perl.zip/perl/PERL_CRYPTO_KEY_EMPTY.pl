# <yes> <report> PERL_CRYPTO_KEY_EMPTY keye01
my $encryption_key = "";
# <yes> <report> PERL_CRYPTO_KEY_EMPTY keye02
$public_key = '';
# <yes> <report> PERL_CRYPTO_KEY_EMPTY keye03
$key = '';