# <yes> <report> PERL_BACKDOOR_HIDDEN_FUNCTIONALITY bhf000
eval(decode_base64("sfjenfwenfj="));
# <yes> <report> PERL_BACKDOOR_HIDDEN_FUNCTIONALITY bhf000
eval decode_base64url("sfjenfwenfj=");
# <yes> <report> PERL_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
evalbytes(MIME::Base64::decode("dsfdsfwe29e2djqef923="));
# <yes> <report> PERL_BACKDOOR_HIDDEN_FUNCTIONALITY bhf001
evalbytes MIME::Base64::decode("dsfdsfwe29e2djqef923=");