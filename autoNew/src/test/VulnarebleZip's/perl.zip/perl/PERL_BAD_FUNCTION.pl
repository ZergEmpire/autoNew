# <yes> <report> PERL_BAD_FUNCTION open01
open(my $FILE, $filename) or croak("file not found");
# <yes> <report> PERL_BAD_FUNCTION open01
open(my $FILE, "<$filename");
# <no> <report> PERL_BAD_FUNCTION
open(my $FILE, '<FILE');
# <yes> <report> PERL_BAD_FUNCTION open02
open my $FILE, "<$filename";
# <no> <report> PERL_BAD_FUNCTION
open my $FILE, '<FILE';
# <yes> <report> PERL_BAD_FUNCTION open03
while (<ARGV>) {
    print ":: $_";
};
# <yes> <report> PERL_BAD_FUNCTION open03
while (<>) {
    print ":: $_";
};
# <no> <report> PERL_BAD_FUNCTION
open(my $FILE, "<", $filename) or croak("file not found");
while (<$FILE>) {
    print "$filename: $_";
};