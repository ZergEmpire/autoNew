# <no> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url1 = "https://url.url/$a";
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url2 = 'https://1.1.1.1';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url3 = '1.1.1.1';
# <no> <report>
$version = '1.1.1';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne001
$url1 = 'https://localhost';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url2 = 'https://1.1.1.1/never';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url2 = 'https://[::1]';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url2 = 'https://[1762:0:0:0:0:B03:1:AF18]';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url2 = 'https://[fe80::219:7eff:fe46:6c42]';
# <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$url2 = 'https://[2001:0db8:0000:0000:0000:ff00:0042:8329]';
