# <yes> <report> PERL_CRYPTO_BAD_RANDOM rand01
int(rand(10));
# <yes> <report> PERL_CRYPTO_BAD_RANDOM rand01
rand 10;
# <yes> <report> PERL_CRYPTO_BAD_RANDOM rand02
print rand(), "\n";
# <yes> <report> PERL_CRYPTO_BAD_RANDOM rand01
$elt = $array[rand @array];

# Replace rand().
use Math::Random::Secure qw(rand);

# <no> <report>
my $float = rand();