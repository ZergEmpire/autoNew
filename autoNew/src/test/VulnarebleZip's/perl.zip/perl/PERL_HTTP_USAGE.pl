require HTTP::Request;
# <yes> <report> PERL_HTTP_USAGE http01 <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
$request = HTTP::Request->new(GET => 'http://www.example.com/');
# <yes> <report> PERL_HTTP_USAGE httpl1 <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne001
$request = HTTP::Request->new(GET => 'http://localhost');
# <yes> <report> PERL_HTTP_USAGE http01 <yes> <report> PERL_BACKDOOR_NETWORK_ACTIVITY bne000
my $url = 'http://www.example.com/api/user/123';
my $r = HTTP::Request->new('POST', $url, $header, $encoded_data);