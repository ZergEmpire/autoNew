# <yes> <report> PERL_COOKIE_BROAD_PATH cookp1
my $cookie = CGI::Cookie->new(
    -name => 'testcookie', -value => 'testvalue', -path  =>  '/', -secure => 1, -httponly => 1);