# <yes> <report> PERL_COOKIE_NOT_HTTPONLY cookh1
my $cookie = CGI::Cookie->new(
    -name => 'testcookie', -value => 'testvalue', -path  =>  '/path', -secure => 1, -httponly => 0);
# <yes> <report> PERL_COOKIE_NOT_HTTPONLY cookh2
my $cookie = CGI::Cookie->new(
    -name => 'testcookie', -value => 'testvalue', -path  =>  '/path', -secure => 1);