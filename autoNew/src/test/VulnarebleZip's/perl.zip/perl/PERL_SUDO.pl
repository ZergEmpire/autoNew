# <yes> <report> PERL_SUDO sudoe2
$command = `sudo /tmp/1.pl`;
# <no> <report>
$command = `/tmp/1.pl`;
# <yes> <report> PERL_SUDO sudoe1
system "sudo /tmp/1.pl";
# <no> <report>
system( "sh", "script.sh", "--help" );
# <yes> <report> PERL_SUDO sudoe1
system("sudo /tmp/1.pl");
# <yes> <report> PERL_SUDO sudoe1
exec "sudo /tmp/1.pl";
# <no> <report>
exec '/bin/echo', 'Your arguments are: ', @ARGV;
# <yes> <report> PERL_SUDO sudoe1
exec("sudo /tmp/1.pl");