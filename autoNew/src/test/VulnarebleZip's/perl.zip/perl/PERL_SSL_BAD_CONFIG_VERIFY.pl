use LWP::UserAgent ();
my $ua = LWP::UserAgent->new(timeout => 10);
# <yes> <report> PERL_SSL_BAD_CONFIG_VERIFY sslb01
$ua->ssl_opts( verify_hostname => 0 );

my $client = IO::Socket::SSL->new(
    # where to connect
    PeerHost => "www.example.com",
    PeerPort => "https",

    # <yes> <report> PERL_SSL_BAD_CONFIG_VERIFY sslb02
    SSL_verify_mode => SSL_VERIFY_NONE,

    # location of CA store
    # need only be given if default store should not be used
    SSL_ca_path => '/etc/ssl/certs', # typical CA path on Linux
    SSL_ca_file => '/etc/ssl/cert.pem', # typical CA file on BSD

    # or just use default path on system:
    IO::Socket::SSL::default_ca(), # either explicitly
    # or implicitly by not giving SSL_ca_*

    # easy hostname verification
    # It will use PeerHost as default name a verification
    # scheme as default, which is safe enough for most purposes.
    SSL_verifycn_name => 'foo.bar',
    SSL_verifycn_scheme => 'http',

    # SNI support - defaults to PeerHost
    SSL_hostname => 'foo.bar',

) or die "failed connect or ssl handshake: $!,$SSL_ERROR";