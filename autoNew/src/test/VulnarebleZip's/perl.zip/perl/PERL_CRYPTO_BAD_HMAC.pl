use Digest::SHA qw(hmac_sha1 hmac_sha1_hex ...);
# <yes> <report> PERL_CRYPTO_BAD_HMAC hmac01
$digest = hmac_sha1($data, $key);
# <yes> <report> PERL_CRYPTO_BAD_HMAC hmac01
$digest = hmac_md5($data, $key);
# <yes> <report> PERL_CRYPTO_BAD_HMAC hmac01
$digest = hmac_md5 $data, $key;
# <no> <report> PERL_CRYPTO_BAD_HMAC
$digest = hmac_sha224_hex($data, $key);
# <no> <report> PERL_CRYPTO_BAD_HMAC
$digest = hmac_sha256_base64($data, $key);

# <yes> <report> PERL_CRYPTO_BAD_HMAC hmac02
$hmac = Digest->HMAC_MD5($key);

use Digest::HMAC_SHA1;
$hmac = Digest::HMAC_SHA1->new($key);

$hmac->add($data);
$hmac->addfile(*FILE);