# <yes> <report> PERL_CRYPTO_BAD_SEED seed01
srand(42);
# <yes> <report> PERL_CRYPTO_BAD_SEED seed01
srand 42;

use Math::Random::Secure::RNG;
# <yes> <report> PERL_CRYPTO_BAD_SEED seed02
my $rng = Math::Random::Secure::RNG->new(seed => 'dfkedfje');