# <yes> <report> PERL_BACKDOOR_SPECIAL_ACCOUNT bsa000 <yes> <report> PERL_BACKDOOR_SPECIAL_ACCOUNT bsa000
if($usermame == "admin" && $password == "admin"){
    ...
}