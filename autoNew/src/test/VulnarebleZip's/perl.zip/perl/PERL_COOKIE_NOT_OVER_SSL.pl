# <yes> <report> PERL_COOKIE_NOT_OVER_SSL cooks1
my $cookie = CGI::Cookie->new(
    -name => 'testcookie', -value => 'testvalue', -path  =>  '/path', -secure => 0, -httponly => 1);
# <yes> <report> PERL_COOKIE_NOT_OVER_SSL cooks2
my $cookie = CGI::Cookie->new(
    -name => 'testcookie', -value => 'testvalue', -path  =>  '/path', -httponly => 1);