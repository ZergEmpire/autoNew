# <yes> <report> PERL_CRYPTO_KEY_HARDCODED keyh01
my $encryption_key = "fjreglj4iojgf2ow3melkf";
# <yes> <report> PERL_CRYPTO_KEY_HARDCODED keyh02
$public_key = 'fewrfoi24jfjweof';
# <yes> <report> PERL_CRYPTO_KEY_HARDCODED keyh03
$key = 'fewrfoi24jfjweof';