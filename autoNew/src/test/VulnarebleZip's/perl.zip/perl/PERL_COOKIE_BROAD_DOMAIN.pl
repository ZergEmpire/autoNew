require CGI::Cookie;
# <yes> <report> PERL_COOKIE_BROAD_DOMAIN cookd1
my $cookie = CGI::Cookie->new(
    -name => 'testcookie', -value => 'testvalue', -domain  =>  '.capricorn.com', -secure => 1, -httponly => 1);