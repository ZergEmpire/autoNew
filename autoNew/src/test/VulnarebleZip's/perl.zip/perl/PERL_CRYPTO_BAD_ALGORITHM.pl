# waiting for type propogation
my $cipher = new Crypt::DES $key;
# <yes> <report> PERL_CRYPTO_BAD_ALGORITHM algo01
my $ciphertext = $cipher->encrypt($plaintext);