# https://metacpan.org/pod/IO::Socket::SSL#Essential-Information-About-SSL/TLS
# <no> <report>
SSL_version = 'SSLv23:!SSLv2:!SSLv3:!TLSv1_1:!TLSv1_2';
# <yes> <report> PERL_SSL_BAD_CONFIG sslbc1
SSL_version = 'SSLv23:!SSLv2:!TLSv1_1:!TLSv1_2'; # SSLv3 is accepted
# <yes> <report> PERL_SSL_BAD_CONFIG sslbc1
SSL_version = 'SSLv23:!SSLv3';  # SSLv2 is accepted
# <yes> <report> PERL_SSL_BAD_CONFIG sslbc1
SSL_version = 'SSLv3';

# https://metacpan.org/pod/IO::Socket::SSL#SSL_cipher_list